.. SPDX-FileCopyrightText: Copyright (c) 2025 The Newton Developers
.. SPDX-License-Identifier: CC-BY-4.0

newton.math
===========

.. py:module:: newton.math
.. currentmodule:: newton.math

.. rubric:: Functions

.. autosummary::
   :toctree: _generated
   :signatures: long

   boltzmann
   leaky_max
   leaky_min
   normalize_with_norm
   orthonormal_basis
   quat_between_axes
   quat_between_vectors_robust
   quat_decompose
   quat_velocity
   safe_div
   smooth_max
   smooth_min
   transform_twist
   transform_wrench
   vec_abs
   vec_allclose
   vec_inside_limits
   vec_leaky_max
   vec_leaky_min
   vec_max
   vec_min
   velocity_at_point

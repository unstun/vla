.. SPDX-FileCopyrightText: Copyright (c) 2025 The Newton Developers
.. SPDX-License-Identifier: CC-BY-4.0

newton.usd
==========

Utilities for working with the Universal Scene Description (USD) format.

This module provides both low-level USD utility helpers and public schema
resolver types used by :meth:`newton.ModelBuilder.add_usd`.

.. py:module:: newton.usd
.. currentmodule:: newton.usd

.. rubric:: Classes

.. autosummary::
   :toctree: _generated
   :nosignatures:

   PrimType
   SchemaResolver
   SchemaResolverMjc
   SchemaResolverNewton
   SchemaResolverPhysx

.. rubric:: Functions

.. autosummary::
   :toctree: _generated
   :signatures: long

   find_tetmesh_prims
   get_attribute
   get_attributes_in_namespace
   get_custom_attribute_declarations
   get_custom_attribute_values
   get_float
   get_gprim_axis
   get_mesh
   get_physics_scenes
   get_quat
   get_scale
   get_tetmesh
   get_transform
   has_applied_api_schema
   has_attribute
   type_to_warp
   value_to_warp

.. rubric:: Constants

.. list-table::
   :header-rows: 1

   * - Name
     - Value
   * - ``DEFORMABLE_LEGACY_NAMESPACES``
     - ``('omniphysics', 'physxDeformableBody')``

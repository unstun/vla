.. SPDX-FileCopyrightText: Copyright (c) 2025 The Newton Developers
.. SPDX-License-Identifier: CC-BY-4.0

newton.sensors
==============

.. py:module:: newton.sensors
.. currentmodule:: newton.sensors

.. rubric:: Classes

.. autosummary::
   :toctree: _generated
   :nosignatures:

   SensorContact
   SensorFrameTransform
   SensorIMU
   SensorTiledCamera

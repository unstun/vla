.. SPDX-FileCopyrightText: Copyright (c) 2025 The Newton Developers
.. SPDX-License-Identifier: CC-BY-4.0

Development
===========

This document covers environment setup and operational workflows for developers
who want to contribute to Newton or understand its internal workings.

See the repository's
`CONTRIBUTING.md <https://github.com/newton-physics/newton/blob/main/CONTRIBUTING.md>`_
for contribution and pull-request workflows. The
`governance contribution guidelines <https://github.com/newton-physics/newton-governance/blob/main/CONTRIBUTING.md>`_
cover legal requirements, project roles, and approval authority. Code and
public API changes must follow the :doc:`source_code_guidelines`. Reviewers may
use the suggested :doc:`review_guidelines`.

Installation
------------

For regular end-user installation, see the :doc:`installation` guide.

To install Newton from source for development or contribution, first clone the
repository:

.. code-block:: console

    git clone https://github.com/newton-physics/newton.git
    cd newton

Method 1: Using uv (Recommended)
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

Install `uv <https://docs.astral.sh/uv/>`_ if you don't have it already:

.. tab-set::
    :sync-group: os

    .. tab-item:: macOS / Linux
        :sync: linux

        .. code-block:: console

            curl -LsSf https://astral.sh/uv/install.sh | sh

    .. tab-item:: Windows
        :sync: windows

        .. code-block:: console

            powershell -ExecutionPolicy ByPass -c "irm https://astral.sh/uv/install.ps1 | iex"

Then create a local project environment with the ``dev`` dependency extras:

.. code-block:: console

    uv sync --extra dev

After syncing, the ``dev`` extras are available to all ``uv run`` commands
without needing to pass ``--extra dev`` each time. For example, to list all
available examples:

.. code-block:: console

    uv run -m newton.examples --list

See the :ref:`extra-dependencies` section of the installation guide for a
description of all available extras.

Method 2: Using pip in a Virtual Environment
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

To manually manage a virtual environment, create and activate one first:

.. tab-set::
    :sync-group: os

    .. tab-item:: macOS / Linux
        :sync: linux

        .. code-block:: console

            python -m venv .venv
            source .venv/bin/activate

    .. tab-item:: Windows (console)
        :sync: windows

        .. code-block:: console

            python -m venv .venv
            .venv\Scripts\activate.bat

    .. tab-item:: Windows (PowerShell)
        :sync: windows-ps

        .. code-block:: console

            python -m venv .venv
            .venv\Scripts\Activate.ps1

Then locally install Newton in editable mode with its development dependencies:

.. code-block:: console

    pip install -e ".[dev]" --extra-index-url https://pypi.nvidia.com/

The ``--extra-index-url`` flag points pip to the NVIDIA package index, which is
required to find ``warp-lang`` versions newer than those available on PyPI.

Python Dependency Management
----------------------------

uv lockfile management
^^^^^^^^^^^^^^^^^^^^^^

When using uv, the `lockfile <https://docs.astral.sh/uv/concepts/projects/layout/#the-lockfile>`__
(``uv.lock``) is used to resolve project dependencies into exact versions for reproducibility among different machines.

We maintain a lockfile in the root of the repository that pins exact versions of all dependencies and their transitive dependencies.

Sometimes, a dependency in the lockfile needs to be updated to a newer version.
This can be done by running ``uv lock -P <package-name>``:

.. code-block:: console

    uv lock -P warp-lang --prerelease allow

    uv lock -P mujoco-warp

The ``--prerelease allow`` flag is needed for dependencies that use pre-release versions (e.g. ``warp-lang``).

uv also provides a command to update all dependencies in the lockfile:

.. code-block:: console

    uv lock -U

Remember to commit ``uv.lock`` after running a command that updates the lockfile.

Running the tests
-----------------

The Newton test suite supports both ``uv`` and standard ``venv`` workflows,
and by default runs in up to eight parallel processes. The tests can be run
in a serial manner with ``--serial-fallback``.

Pass ``--help`` to either run method below to see all available flags.

.. note::

    If a test run aborts with ``concurrent.futures.process.BrokenProcessPool``,
    a worker process crashed (out-of-memory, segfault, or similar). The runner
    parallelizes across ``min(cpu_count, 8)`` workers by default; on
    memory-constrained machines this can saturate RAM and kill a worker.
    Retry with fewer workers via ``--jobs`` (or ``--serial-fallback`` for a
    single process):

    .. code-block:: console

        python -m newton.tests --jobs 4

.. tab-set::
    :sync-group: env

    .. tab-item:: uv
        :sync: uv
        
        .. code-block:: console

            # install development extras and run tests
            uv run --extra dev -m newton.tests

    .. tab-item:: venv
        :sync: venv

        .. code-block:: console

            # install dev extras (including testing & coverage deps)
            python -m pip install -e ".[dev]"
            # run tests
            python -m newton.tests
            
Specific Newton examples can be tested in isolation via the ``-k`` argument:

.. tab-set::
    :sync-group: env

    .. tab-item:: uv
        :sync: uv
        
        .. code-block:: console

            # test the basic_shapes example
            uv run --extra dev -m newton.tests.test_examples -k test_basic.example_basic_shapes

    .. tab-item:: venv
        :sync: venv

        .. code-block:: console

            # test the basic_shapes example
            python -m newton.tests.test_examples -k test_basic.example_basic_shapes


To generate a coverage report:

.. tab-set::
    :sync-group: env

    .. tab-item:: uv
        :sync: uv

        .. code-block:: console
            
            # append the coverage flags:
            uv run --extra dev -m newton.tests --coverage --coverage-html htmlcov

    .. tab-item:: venv
        :sync: venv

        .. code-block:: console

            # append the coverage flags and make sure `coverage[toml]` is installed (it comes in `[dev]`)
            python -m newton.tests --coverage --coverage-html htmlcov

The file ``htmlcov/index.html`` can be opened with a web browser to view the coverage report.

Code formatting and linting
---------------------------

`Ruff <https://docs.astral.sh/ruff/>`_ is used for Python linting and code formatting.
`pre-commit <https://pre-commit.com/>`_ can be used to ensure that local code complies with Newton's checks.
From the top of the repository, run:

.. tab-set::
    :sync-group: env

    .. tab-item:: uv
        :sync: uv

        .. code-block:: console

            uvx pre-commit run -a

    .. tab-item:: venv
        :sync: venv

        .. code-block:: console

            python -m pip install pre-commit
            pre-commit run -a

To automatically run pre-commit hooks with ``git commit``:

.. tab-set::
    :sync-group: env

    .. tab-item:: uv
        :sync: uv

        .. code-block:: console

            uvx pre-commit install

    .. tab-item:: venv
        :sync: venv

        .. code-block:: console

            pre-commit install

The hooks can be uninstalled with ``pre-commit uninstall``.

Typos
-----

To proactively catch spelling mistakes, Newton uses the `typos <https://github.com/crate-ci/typos>`_ tool. Typos scans source files for common misspellings and is integrated into our pre-commit hooks, so spelling errors in both code and documentation are flagged when you run or install pre-commit (see above). You can also run ``typos`` manually if needed. Refer to the `typos documentation <https://github.com/crate-ci/typos?tab=readme-ov-file#documentation>`_ for more details on usage and configuration options.

Dealing with false positives
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

Typos may occasionally flag legitimate project-specific terminology, domain terms, or variable names as misspellings (false positives). To handle these, the Newton codebase configures typos in ``pyproject.toml`` at the repository root.

False positives are managed as follows:

- **File exclusions:** The ``[tool.typos]`` section includes ``files.extend-exclude`` to ignore matching files and directories, such as ``examples/assets`` and specific model or asset file types (e.g., ``*.urdf``, ``*.usd``).
- **Word allowlist:** Words or acronyms that would otherwise be flagged can be listed in ``[tool.typos.default.extend-words]`` (e.g., ``ba``, ``HAA``).
- **Identifier allowlist:** Specific identifiers, such as variable or constant names, can be declared in ``[tool.typos.default.extend-identifiers]`` (e.g., ``PNGs``).

When typos reports a word that is valid within the Newton codebase, you can add it to the appropriate section in ``pyproject.toml`` to suppress future warnings. After updating, re-run typos (or pre-commit) to confirm that the word is ignored. Use these options to keep the codebase clean while ensuring needed flexibility for accepted project-specific words and identifiers.


License headers
---------------

Every source file in the repository must carry a 2-line `SPDX <https://spdx.dev/>`_ license
header. The project's Apache-2.0 license is in ``LICENSE.md`` at the repository root, and additional and third-party license texts are available in the ``newton/licenses`` directory, so no further
boilerplate is required in individual files.

The required headers depend on the file type:

- **Python files** (``.py``):

  .. code-block:: python

      # SPDX-FileCopyrightText: Copyright (c) <year> The Newton Developers
      # SPDX-License-Identifier: Apache-2.0

- **Documentation files** (``.rst``) — CC-BY-4.0:

  .. code-block:: rst

      .. SPDX-FileCopyrightText: Copyright (c) <year> The Newton Developers
      .. SPDX-License-Identifier: CC-BY-4.0

- **Jupyter notebooks** (``.ipynb``) — CC-BY-4.0 (plain text in the first cell, no comment prefix):

  .. code-block:: text

      SPDX-FileCopyrightText: Copyright (c) <year> The Newton Developers
      SPDX-License-Identifier: CC-BY-4.0

Use the year the file was **first created**. Do not update the year when modifying an
existing file, and do not use year ranges — git history is the authoritative record of
when changes were made.

A CI check (``pr_license_check.yml``) enforces headers on every pull request using
`Apache SkyWalking Eyes <https://github.com/apache/skywalking-eyes>`_.

To run the license checks locally with Docker before pushing:

.. code-block:: console

    # Check Python source headers (Apache-2.0)
    docker run -it --rm -v $(pwd):/github/workspace apache/skywalking-eyes header check

    # Check documentation headers (CC-BY-4.0)
    docker run -it --rm -v $(pwd):/github/workspace apache/skywalking-eyes -c .licenserc-docs.yaml header check

Using a local Warp installation with uv
---------------------------------------

Use the following steps to run Newton with a local build of Warp:

.. code-block:: console

    uv venv
    source .venv/bin/activate
    uv sync --extra dev
    uv pip install -e "warp-lang @ ../warp"

The Warp initialization message should then properly reflect the local Warp installation instead of the locked version,
e.g. when running ``python -m newton.examples basic_pendulum``.

.. _building-the-documentation:

Building the documentation
--------------------------

To build the documentation locally, ensure you have the documentation dependencies installed.

.. tab-set::
    :sync-group: env

    .. tab-item:: uv
        :sync: uv

        .. code-block:: console

            rm -rf docs/_build
            uv run --extra docs --extra sim sphinx-build -j auto -W -b html docs docs/_build/html

    .. tab-item:: venv
        :sync: venv

        .. code-block:: console

            python -m pip install -e ".[docs]"
            cd path/to/newton/docs && make html

The built documentation will be available in ``docs/_build/html``.

.. note::

    The documentation build requires `pandoc <https://pandoc.org/>`_ for converting Jupyter notebooks.
    The ``[docs]`` dependencies include ``pypandoc_binary``, and ``docs/conf.py`` will
    automatically use that bundled executable when it is available. If your environment
    still cannot locate pandoc, install it separately:

    - **Ubuntu/Debian:** ``sudo apt-get install pandoc``
    - **macOS:** ``brew install pandoc``
    - **Windows:** Download from https://pandoc.org/installing.html or ``choco install pandoc``

Serving the documentation locally
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

After building the documentation, you can serve it locally using the ``docs/serve.py`` script.
This is particularly useful for testing interactive features like the Viser 3D visualizations
in the tutorial notebooks, which require proper MIME types for WebAssembly and JavaScript modules.

.. tab-set::
    :sync-group: env

    .. tab-item:: uv
        :sync: uv

        .. code-block:: console

            uv run docs/serve.py

    .. tab-item:: venv
        :sync: venv

        .. code-block:: console

            python docs/serve.py

Then open http://localhost:8000 in your browser. You can specify a custom port with ``--port``:

.. tab-set::
    :sync-group: env

    .. tab-item:: uv
        :sync: uv

        .. code-block:: console

            uv run docs/serve.py --port 8080

    .. tab-item:: venv
        :sync: venv

        .. code-block:: console

            python docs/serve.py --port 8080

.. note::

    Using Python's built-in ``http.server`` or simply opening the HTML files directly
    will not work correctly for the interactive Viser visualizations, as they require
    specific CORS headers and MIME types that ``serve.py`` provides.

Documentation Versioning
------------------------

Newton's documentation is versioned and hosted on GitHub Pages. Multiple versions
are available simultaneously, with a version switcher dropdown in the navigation bar.

How It Works
^^^^^^^^^^^^

The ``gh-pages`` branch contains versioned documentation in subdirectories:

.. code-block:: text

    /
    ├── index.html      # Redirects to /stable/
    ├── switcher.json   # Version manifest for dropdown
    ├── stable/         # Copy of latest release
    ├── latest/         # Dev docs from main branch
    ├── 1.1.0/          # Release versions
    └── 1.0.0/

Two GitHub Actions workflows manage deployment:

- **docs-dev.yml**: Deploys to ``/latest/`` on every push to ``main``
- **docs-release.yml**: Deploys to ``/X.Y.Z/`` and updates ``/stable/`` on version tags

Deploying Documentation
^^^^^^^^^^^^^^^^^^^^^^^

**Dev docs** are deployed automatically when changes are pushed to ``main``.

**Release docs** are deployed when a version tag is pushed:

.. code-block:: bash

    git tag v1.0.0
    git push origin v1.0.0

Only strict semver tags (``vX.Y.Z``) trigger release deployments. Pre-release tags
like ``v1.0.0-rc.1`` are ignored.

Manual Operations
^^^^^^^^^^^^^^^^^

**Removing a version** (rare):

1. Check out the ``gh-pages`` branch
2. Delete the version directory (e.g., ``rm -rf 1.0.0``)
3. Edit ``switcher.json`` to remove the entry
4. Commit and push

**Rebuilding all docs** (disaster recovery): Check out each version tag, build its
docs with Sphinx, and deploy to the corresponding directory on ``gh-pages``. Update
``switcher.json`` after each version using ``scripts/ci/update_docs_switcher.py``.

API documentation
-----------------

The :ref:`source-code-guidelines` define the canonical-export and ``__all__``
requirements. The following procedure publishes that API in Newton's reference
documentation.

The API reference is auto-generated from the ``__all__`` lists of Newton's
public modules. The script ``docs/generate_api.py`` produces reStructuredText
files under ``docs/api/`` that Sphinx processes via ``autosummary`` to create
individual pages for every public symbol.

Whenever you add, remove, or rename a public symbol in one of the public modules
(``newton``, ``newton.geometry``, ``newton.solvers``, ``newton.sensors``, etc.),
regenerate the API pages:

.. tab-set::
    :sync-group: env

    .. tab-item:: uv
        :sync: uv

        .. code-block:: console

            uv run python docs/generate_api.py

    .. tab-item:: venv
        :sync: venv

        .. code-block:: console

            python docs/generate_api.py

After running the script, rebuild the documentation to verify the result (see
:ref:`building-the-documentation` above).

.. note::

    Only symbols listed in a Newton public module's ``__all__`` are supported
    public API. ``docs/generate_api.py`` rejects modules that do not define
    ``__all__`` as a list or tuple so undeclared attributes cannot be published
    accidentally. Export a user-facing symbol from ``newton/_src/`` through
    its canonical public module before generating the API pages.

.. _experimental-features:

Experimental features
^^^^^^^^^^^^^^^^^^^^^

The :ref:`source-code-guidelines` define the experimental public API contract.
Use the ``.. experimental::`` directive in the public docstring or concept page
selected by that policy.

With no body, the directive renders Newton's standard notice:

.. experimental::

.. code-block:: rst

    .. experimental::

Use this form for an entire module, class, method, or function when the full
feature is experimental.

For experimental behavior inside an otherwise stable API, add custom content that
names the exact scope:

.. code-block:: rst

    Args:
        contact_matching: Frame-to-frame contact matching mode.

            .. experimental::

                The ``"sticky"`` mode may change without prior notice.

When documenting experimental public API:

- keep status tables and summaries concise; use plain text such as
  ``experimental`` instead of linking every status label to the marker;
- run ``uv run python docs/generate_api.py`` when public API symbols change.

Testing documentation code snippets
-----------------------------------

The ``doctest`` Sphinx builder is used to ensure that code snippets in the documentation remain up-to-date.

The doctests can be run with:

.. tab-set::
    :sync-group: env

    .. tab-item:: uv
        :sync: uv

        .. code-block:: console

            uv run --extra docs --extra sim sphinx-build -j auto -W -b doctest docs docs/_build/doctest

    .. tab-item:: venv
        :sync: venv

        .. code-block:: console

            python -m sphinx -j auto -W -b doctest docs docs/_build/doctest

For more information, see the `sphinx.ext.doctest <https://www.sphinx-doc.org/en/master/usage/extensions/doctest.html>`__
documentation.

Changelog
---------

Pull requests with user-facing changes add fragments under ``changelog/``
instead of editing ``CHANGELOG.md``. Use a GitHub issue number as the identifier
when one exists, or a readable identifier beginning with ``+`` for work without
an issue. For example:

.. code-block:: text

   3607.added.md
   3607.fixed.md
   +camera-rays-a1b2c3d4.added.md

The supported categories are:

- **Added** — new features
- **Changed** — changes to existing functionality (include migration guidance)
- **Deprecated** — features that will be removed (include migration guidance,
  e.g. "Deprecate ``Model.geo_meshes`` in favor of ``Model.shapes``")
- **Removed** — removed features (include migration guidance)
- **Fixed** — bug fixes

Each file contains one entry without a leading bullet. Use imperative present
tense ("Add X", not "Added X"), end with a period, and keep entries concise.
An optional one-line ``.skip`` fragment can record why work has no user-facing
impact. Multiline entries, multiple categories, same-category counters,
creation commands, and Towncrier's non-mutating ``--draft`` preview are
documented in the `changelog fragment guide
<https://github.com/newton-physics/newton/blob/main/changelog/README.md>`__.

Writing examples
----------------

Examples live in ``newton/examples/<category>/example_<category>_<name>.py`` (e.g.
``newton/examples/basic/example_basic_pendulum.py``). Each file defines an ``Example``
class with the following interface:

.. code-block:: python

    class Example:
        def __init__(self, viewer, args):
            """Build the model, create solver/state/control, and set up the viewer."""
            ...

        def step(self):
            """Advance the simulation by one frame (typically with substeps)."""
            ...

        def render(self):
            """Update the viewer with the current state."""
            ...

        def test_final(self):
            """Optionally validate the simulation state after the example completes."""
            ...

        def test_post_step(self):
            """Optional per-step validation, called after every step() in test mode."""
            ...

Every example must implement ``test_final()`` or ``test_post_step()``; it may
implement both. In test mode, ``test_post_step()`` runs after each simulation
step and ``test_final()`` runs after the example completes. An example that
implements neither raises ``NotImplementedError`` in CI.

Discovery and registration
^^^^^^^^^^^^^^^^^^^^^^^^^^

Examples are discovered automatically: any file matching
``newton/examples/<category>/example_*.py`` is picked up by ``newton.examples.get_examples()``.
The short name used on the command line is the filename without the ``example_`` prefix and
``.py`` extension (e.g. ``basic_pendulum``).

New examples must also be registered in the examples ``README.md`` with a                                                        
``python -m newton.examples <example_name>`` command and a 320x320 jpg screenshot.  

.. tab-set::
    :sync-group: env

    .. tab-item:: uv
        :sync: uv

        .. code-block:: console

            # list all available examples
            uv run -m newton.examples --list

            # run an example by short name
            uv run -m newton.examples basic_pendulum

            # run in headless test mode (used by CI)
            uv run -m newton.examples basic_pendulum --viewer null --test

    .. tab-item:: venv
        :sync: venv

        .. code-block:: console

            # list all available examples
            python -m newton.examples --list

            # run an example by short name
            python -m newton.examples basic_pendulum

            # run in headless test mode (used by CI)
            python -m newton.examples basic_pendulum --viewer null --test

Asset version pinning
---------------------

Several Newton tests and examples rely on external assets hosted in separate Git
repositories.  To ensure that any given Newton commit always downloads the same
asset versions, each repository is pinned to a specific commit SHA.  The pinned
revisions are defined as constants in ``newton/_src/utils/download_assets.py``:

- ``NEWTON_ASSETS_REF`` — pinned SHA for the ``newton-assets`` repository
- ``MENAGERIE_REF`` — pinned SHA for the ``mujoco_menagerie`` repository

Updating pinned revisions
^^^^^^^^^^^^^^^^^^^^^^^^^

When upstream assets change and the new versions need to be adopted:

1. Look up the new commit SHA from the asset repository.
2. Update the corresponding ``*_REF`` constant in ``download_assets.py``.
3. Run the full test suite to verify that no tests break with the new assets.
4. Commit the SHA update together with any test adjustments.

Overriding the pinned revision
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

The ``download_asset()`` function accepts a ``ref`` parameter that overrides the
default pinned SHA.

Roadmap and Future Work
-----------------------

(Placeholder for future roadmap and planned features)

- Advanced solver coupling
- More comprehensive sensor models
- Expanded robotics examples

See the `GitHub Discussions <https://github.com/newton-physics/newton/discussions>`__ and `GitHub Roadmap <https://github.com/orgs/newton-physics/projects/1>`__ for ongoing feature planning.

Benchmarking with airspeed velocity
-----------------------------------

The Newton repository contains a benchmarking suite implemented using the `airspeed velocity <https://asv.readthedocs.io/en/latest/>`__ framework.
The full set of benchmarks is intended to be run on a machine with a CUDA-capable GPU.

To get started, install airspeed velocity from PyPI:

.. code-block:: console

    python -m pip install asv

.. tip::

    With ``uv``, airspeed velocity can be run without installing it into the
    project environment by using ``uvx``:

    .. code-block:: console

        uvx --with virtualenv asv run --launch-method spawn ...

If airspeed velocity has not been previously run on the machine, it will need to be initialized with:

.. code-block:: console

    asv machine --yes

To run the benchmarks, run the following command from the root of the repository:

.. tab-set::
    :sync-group: shell

    .. tab-item:: Unix
        :sync: unix

        .. code-block:: console

            asv run --launch-method spawn main^!

    .. tab-item:: Windows
        :sync: windows

        .. code-block:: console

            asv run --launch-method spawn main^^!

.. note::

    On Windows CMD, the ``^`` character is an escape character, so it must be doubled (``^^``) to be interpreted literally.

The benchmarks discovered by airspeed velocity are in the ``asv/benchmarks`` directory. This command runs the
benchmark code from the ``asv/benchmarks`` directory against the code state of the ``main`` branch. Note that
the benchmark definitions themselves are not checked out from different branches—only the code being
benchmarked is.

Simulation benchmark metrics
^^^^^^^^^^^^^^^^^^^^^^^^^^^^

The nightly robot and policy simulation benchmarks publish several metrics from one cached benchmark run. This
includes the batched MuJoCo and Kamino KPI workloads, the non-policy DR Legs workload, the pretrained Anymal
workload, and the XPBD quadruped workload. Companion ``FastMetrics*`` classes reuse the exact factories, scenes,
solvers, and frame counts of existing aggregate benchmarks. Rendering, IK, inverse dynamics, CPU-backend
regression, material/contact microbenchmarks, and startup benchmarks are not experience-collection workloads and
are outside this metric set.

Let ``F`` be the number of measured frames across all samples, ``S`` the number of physics substeps per frame,
``W`` the world count, ``dt`` the physics timestep in seconds, ``T`` the synchronized complete-step wall time in
seconds, and ``T_physics`` the workload's synchronized internal physics time. The reported metrics are:

* mean world-step time: ``1000 * T_physics / (F * S * W)`` in ``ms/world-step`` for workloads with an internal
  timer and ``1000 * T / (F * S * W)`` otherwise;
* simulation throughput: ``F * S * W / T`` in ``world-steps/s``;
* real-time factor: ``F * S * W * dt / T``;
* p95 step time: the 95th percentile of synchronized complete-step times in ``ms/frame``; and
* steady-state GPU memory in ``MiB``; and
* mean and maximum MuJoCo solver iteration counts across worlds at the final frame of each measured sample.

The existing KPI mean world-step series keeps its ``track_simulate`` name and definition, and existing
``time_simulate`` aggregate series remain unchanged. ``world_count`` remains an ASV parameter where applicable,
while ``sim_dt`` and ``sim_substeps`` are also recorded as tracked values so dashboard results retain the
configuration needed to interpret throughput and real-time factor. The existing KPI mean series continues to use
each workload's internal physics timer. Throughput, real-time factor, and p95 metrics time and synchronize the
complete ``step()`` operation, including any policy or control work it performs.

GPU memory is the decrease in ``Device.free_memory`` between a baseline immediately before the first finalized
workload is created and a measurement after initialization, CUDA graph capture, and the first complete measured
sample, while that sample's workload is still live. This device-level delta includes allocations from Warp,
PyTorch, solver support, and CUDA graphs. Because the measurement is device-wide, runners must provide exclusive
GPU access during the measurement interval. The remaining samples do not affect this measurement. A benchmark
fails instead of publishing metrics if its final simulation state is invalid, has non-normalized body rotations,
or exceeds the workload's body-speed bounds.

Benchmarks can also be run against a range of commits using the ``commit1..commit2`` syntax.
This is useful for comparing performance across several recent changes:

.. tab-set::
    :sync-group: shell

    .. tab-item:: Unix
        :sync: unix

        .. code-block:: console

            asv run --launch-method spawn HEAD~4..HEAD

    .. tab-item:: Windows
        :sync: windows

        .. code-block:: console

            asv run --launch-method spawn HEAD~4..HEAD

Note that the older commit has to come first.
Commit hashes can be used instead of relative references:

.. tab-set::
    :sync-group: shell

    .. tab-item:: Unix
        :sync: unix

        .. code-block:: console

            asv run --launch-method spawn abc1234..def5678

    .. tab-item:: Windows
        :sync: windows

        .. code-block:: console

            asv run --launch-method spawn abc1234..def5678

Running benchmarks standalone
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

Benchmark files can also be run directly as Python scripts, without the airspeed velocity
harness. This is useful for quick iteration during development since it skips the
environment setup that airspeed velocity performs. Each benchmark file under
``asv/benchmarks/`` supports a ``--bench`` flag to select specific benchmark classes:

.. tab-set::
    :sync-group: env

    .. tab-item:: uv
        :sync: uv

        .. code-block:: console

            uv run python asv/benchmarks/simulation/bench_mujoco.py --bench FastAllegro

    .. tab-item:: venv
        :sync: venv

        .. code-block:: console

            python asv/benchmarks/simulation/bench_mujoco.py --bench FastAllegro

When ``--bench`` is omitted, all benchmarks in the file are run. The ``--bench`` flag can
be repeated to select multiple benchmarks:

.. tab-set::
    :sync-group: env

    .. tab-item:: uv
        :sync: uv

        .. code-block:: console

            uv run python asv/benchmarks/simulation/bench_mujoco.py --bench FastAllegro --bench FastG1

    .. tab-item:: venv
        :sync: venv

        .. code-block:: console

            python asv/benchmarks/simulation/bench_mujoco.py --bench FastAllegro --bench FastG1

Tips for writing benchmarks
^^^^^^^^^^^^^^^^^^^^^^^^^^^

Rather than running the entire benchmark suite, use the ``--bench BENCH, -b BENCH`` flag to filter the benchmarks
to just the ones under development:

.. tab-set::
    :sync-group: shell

    .. tab-item:: Unix
        :sync: unix

        .. code-block:: console

            asv run --launch-method spawn main^! --bench FastG1

    .. tab-item:: Windows
        :sync: windows

        .. code-block:: console

            asv run --launch-method spawn main^^! --bench FastG1

The most time-consuming benchmarks are those that measure the time it takes to load and run one frame of the example
starting from an empty kernel cache.
These benchmarks have names ending with ``time_load``. It is sometimes convenient to exclude these benchmarks
from running by using the following command:

.. tab-set::
    :sync-group: shell

    .. tab-item:: Unix
        :sync: unix

        .. code-block:: console

            asv run --launch-method spawn main^! -b '^(?!.*time_load$).*'

    .. tab-item:: Windows
        :sync: windows

        .. code-block:: console

            asv run --launch-method spawn main^^! -b "^^(?!.*time_load$).*"

While airspeed velocity has built-in mechanisms to determine automatically how to collect measurements,
it is often useful to manually specify benchmark attributes like ``repeat`` and ``number`` to control the
number of times a benchmark is run and the number of times a benchmark is repeated.

.. code-block:: python

    class PretrainedSimulate:
        repeat = 3
        number = 1

As the airspeed documentation on `benchmark attributes <https://asv.readthedocs.io/en/stable/writing_benchmarks.html#benchmark-attributes>`__ notes,
the ``setup`` and ``teardown`` methods are not run between the ``number`` iterations that make up a sample.

These benchmark attributes should be tuned to ensure that the benchmark runs in a reasonable amount of time while
also ensuring that the benchmark is run a sufficient number of times to get a statistically meaningful result.

The ``--durations all`` flag can be passed to the ``asv run`` command to show the durations of all benchmarks,
which is helpful for ensuring that a single benchmark is not requiring an abnormally long amount of time compared
to the other benchmarks.


Release process
---------------

See :doc:`release` for the full release workflow, including versioning,
branching strategy, testing criteria, and publication steps.

.. toctree::
   :hidden:

   release

# Classification Helpers

This reference is loaded during Phases 3, 4, and 5 of the skill. It defines concrete path and naming rules Claude relies on when analyzing commits and CHANGELOG entries.

## Public API surface (Phase 4a, 4e)

Used to decide whether a symbol is "genuinely new" vs. "pre-existed and got extended":

Newton exposes its public surface through per-topic re-export modules discovered dynamically by `docs/generate_api.py`:

- `api_modules()` imports `newton`, starts with the top-level module, and adds every module-valued name exported through `newton.__all__`.
- Each discovered module's own `__all__` list or tuple defines its public symbols. `public_symbols()` rejects missing declarations, invalid containers, and non-string entries.
- `solver_submodule_pages()` adds public solver submodules and recursively exposed module trees under `newton.solvers`.
- There is no fixed `MODULES` constant. Inspect `docs/generate_api.py`, `newton/__init__.py`, and `newton/solvers.py` at both refs so additions such as a new top-level public module or nested experimental solver namespace are included.

Representative modules include `newton.geometry`, `newton.solvers`, and `newton.viewer`. Each public module re-exports from `newton/_src/<topic>/...`. `newton._src` is internal (`CODING_GUIDELINES.rst`: examples and docs must not import from `newton._src`).

**To determine if `newton.X` existed at base**:
- Inspect module-valued exports in `newton.__all__` at base and target using the `api_modules()` rules above.
- For top-level symbols: `git show <base>:newton/__init__.py` and check `from ._src.<submodule> import X` / `__all__`.
- For submodule public attributes (e.g., `newton.geometry.Mesh`): `git show <base>:newton/geometry.py` and check imports / `__all__`.
- For nested solver modules: apply `solver_submodule_pages()` reachability rules to `newton.solvers` at the relevant ref.
- For method additions on an existing class (e.g., `SolverXPBD.update_contacts`): resolve the class's real source file (e.g., `newton/_src/solvers/xpbd.py`) and `ast`-walk it at base.

**Public-API declaration and exposure check (Phase 4a addition)**: inspect every discovered public module at HEAD. Its `__all__` must be a list or tuple containing only strings. For every genuinely new symbol, collect all public-module `__all__` declarations that contain it. Zero memberships raise a 🕵️ Private-only flag; one establishes the canonical public import path; more than one raises a duplicate-public-export policy finding listing all paths. Reason: `CODING_GUIDELINES.rst` requires each public symbol to appear in exactly one public module's `__all__` and forbids examples/docs from importing `newton._src`.

## No kernel-scope builtin registry

Newton has no separate builtin registry to audit. All user-facing symbols are ordinary Python classes, functions, enums, and constants defined in `newton/_src/**` and re-exported through the public modules above. Skip kernel-scope symbol extraction.

## Paths that trigger Phase 4f semantic-change review

Commits touching these paths get per-commit judgment (Phase 4f). Not every change in them is a semantic shift — Claude reads the diff and decides:

- `newton/_src/solvers/**` — solver implementations (XPBD, MuJoCo, Featherstone, VBD, implicit MPM). Changes can alter convergence, contact handling, step semantics.
- `newton/_src/sim/**` — integrators, collision pipeline, model building, state transfer. Changes can alter per-step dynamics or contact ordering.
- `newton/_src/math/**` — math helpers, raycast, quaternion utilities. Changes can shift numerical output.
- `newton/_src/geometry/**` — geometry primitives, SDF / mesh representations, support functions. Changes can shift contact normals, distances, or inside/outside tests.

Typical NOT-SEMANTIC-SHIFTING signals in these paths:
- Pure internal refactors, renames of internal identifiers.
- Comment or formatting changes.
- Performance optimizations that preserve observable output (e.g., vectorization, precomputed AABBs).
- Caching / memoization where the cached value is equivalent.
- Test-only changes.
- Build-system touches.
- Bug fixes where the previous behavior was demonstrably wrong.

Typical SEMANTIC-SHIFTING signals:
- Algorithm swaps that produce different numerical results (e.g., switching SDF construction from winding-number to parity).
- Default parameter value changes that affect physics (e.g., changing MPM quadrature, contact stiffness, solver iteration defaults).
- Ordering / determinism changes that affect contact reduction or constraint solving.
- Convergence criteria changes (different tolerance, different iteration bound behavior).
- Unit / frame-of-reference changes for authored values (e.g., "stop multiplying joint damping by 180/π").
- Control-flow changes that alter when callbacks / registered hooks / user kernels are invoked.

**Never attempt to build and run Newton at base vs. HEAD for verification.** Newton's output depends on Warp codegen, MuJoCo, and GPU state; reliable head-to-head numerical verification in a one-shot audit is out of scope. When in doubt, route the commit to a "Review candidates" section in the report's review notes rather than speculating in Breaking Changes.

## Heuristic paths commonly relevant (reference only)

These are noted here so Claude can pattern-match when reading commits, but the skill does NOT use them to produce an appendix-style commit audit. Purpose is recognition, not bucketing:

- `.github/**`, `.pre-commit-config.yaml`, `uv.lock`, `.python-version` — infrastructure, not user-facing.
- `asv.conf.json`, `asv/**`, root-level `_bench_*.py` — benchmark harness.
- `docs/**`, root-level `*.md`, `CHANGELOG.md`, `changelog/**` — documentation.
- `newton/examples/**` — example scripts. New files here are user-facing (a new example is a release-notable addition). Changes to existing examples are typically not release-notable unless they change the example's registered name or behavior.
- `newton/_src/**` other than the solver / sim / math / geometry paths above — internal Python implementation.
- `pyproject.toml`, `uv.lock`, and files matched by `project.license-files` — dependency and license-audit inputs. New external dependency names, direct requirement scope changes, new resolved package names, and notice-file changes belong in "Dependency & License Audit". Version bumps are not release-notable on their own; dependency changes may also belong in "Behavioral & Support Changes" if a user-visible pin moves (e.g., `mujoco-warp ~=3.7.0`).

## Newton-specific rename and parameter-reorder recognition (Phase 4d, 5a)

Newton's CHANGELOG does NOT use the `**Breaking:**` literal marker. Instead, migration-required changes appear in `### Changed` with prose like:

- "Rename `X.old_name` to `X.new_name`. Old name still accepted as keyword argument but emits a `DeprecationWarning`."
- "Reorder `X()` parameters so `a` precedes `b`."
- "Migrate all Y logic to Z, all Y functions now return ..."

When Phase 4d / 5a encounter these patterns, treat them as migration-required changes (Kind `rename` or `parameter reorder` in the Changes-to-Existing-API table). Check that the entry includes migration guidance (`Use ...`, `in favor of ...`, `prefer ...`). If guidance is missing, raise a ⬆️ flag in the language review.

## Deprecation policy (Phase 4d)

`CODING_GUIDELINES.rst`: breaking changes require a deprecation first. A prior released `### Deprecated` entry is the preferred evidence. A matching runtime `DeprecationWarning` at the base ref also proves that users received a deprecation window, even if the released CHANGELOG omitted it. The warning may be emitted directly or by a shared helper / decorator that clearly applies to the removed API or behavior.

When Phase 4d cannot find the prior Deprecated entry:
- Resolve the symbol or legacy behavior in code at the base ref.
- Run a targeted `git grep` for `DeprecationWarning` / `deprecated` in the candidate path and inspect the warning context.
- If the candidate calls or applies a shared deprecation helper / decorator, resolve that name and inspect its definition at the base ref. Verify that the candidate's call site connects the helper to the exact removed API or behavior and that the helper emits `DeprecationWarning`. A generic helper's existence or import alone is not evidence.
- If a matching direct or helper-mediated runtime warning exists, record the base ref, warning text, and the direct source path or connected helper application / emission paths. Do not emit a policy violation; flag the missing released CHANGELOG entry as a documentation gap.
- If no matching warning exists, surface `🚨 Policy: removed without prior deprecation` in the Breaking Changes section and cite the Removed entry in full.
- Note whether the current CHANGELOG's own `### Deprecated` section also names the same symbol. Deprecating and removing in the same release is a policy violation because the warning did not ship in a prior release.

A release manager reading the report should see one of three resolved outcomes:
1. Prior CHANGELOG entry found: report its release version.
2. Runtime `DeprecationWarning` found at base: deprecation policy satisfied, with a non-blocking CHANGELOG documentation flag.
3. Neither found: block the release or add a deprecation shim for one more release cycle.

Do not infer a policy violation from CHANGELOG evidence alone. The code-level check is mandatory before raising the blocking flag.

# SPDX-FileCopyrightText: Copyright (c) 2025 The Newton Developers
# SPDX-License-Identifier: Apache-2.0

"""
Factory methods for building 'basic' models.

This module provides a set of functions to create simple mechanical assemblies
using the ModelBuilderKamino interface. These include fundamental configurations such
as a box on a plane, a box pendulum, a cartpole, and various linked box systems.

Each function constructs a specific model by adding rigid bodies, joints,
and collision geometries to a ModelBuilderKamino instance. The models are designed
to serve as foundational examples for testing and demonstration purposes,
and each features a certain subset of ill-conditioned dynamics.
"""

import math

import warp as wp

from ......core.types import Axis
from ...core import ModelBuilderKamino, inertia
from ...core.joints import JOINT_TAUMAX, JointActuationType, JointDoFType
from ...core.math import FLOAT32_MAX, FLOAT32_MIN, I_3, axis_to_mat33
from ...core.shapes import BoxShape, PlaneShape, SphereShape

###
# Module interface
###

__all__ = [
    "build_box_on_plane",
    "build_box_pendulum",
    "build_box_pendulum_vertical",
    "build_boxes_fourbar",
    "build_boxes_hinged",
    "build_boxes_nunchaku",
    "build_boxes_nunchaku_vertical",
]


###
# Functions
###


def build_box_on_plane(
    builder: ModelBuilderKamino | None = None,
    z_offset: float = 0.0,
    ground: bool = True,
    new_world: bool = True,
    world_index: int = 0,
) -> ModelBuilderKamino:
    """
    Constructs a basic model of a free-floating 'box' body and a ground box geom.

    Args:
        builder: An optional existing model builder to populate.
            If `None`, a new builder is created.
        z_offset: A vertical offset to apply to the initial position of the box.
        ground: Whether to add a static ground plane to the model.
        new_world: Whether to create a new world in the builder for this model.
            If `False`, the model is added to the existing world specified by `world_index`.
            If `True`, a new world is created and added to the builder. In this case the `world_index`
            argument is ignored, and the index of the newly created world will be used instead.
        world_index: The index of the world to which the model should be added if `new_world` is False.
            If `new_world` is True, this argument is ignored.
            If the value does not correspond to an existing world, an error will be raised.
            Defaults to `0`.

    Returns:
        The populated model builder.
    """
    # Create a new builder if none is provided
    if builder is None:
        _builder = ModelBuilderKamino(default_world=False)
    else:
        _builder = builder

    # Create a new world in the builder if requested or if a new builder was created
    if new_world or builder is None:
        world_index = _builder.add_world(name="box_on_plane")

    # Add first body
    bid0 = _builder.add_rigid_body(
        m_i=1.0,
        i_I_i=inertia.solid_cuboid_body_moment_of_inertia(1.0, 0.2, 0.2, 0.2),
        q_i_0=wp.transformf(0.0, 0.0, 0.1 + z_offset, 0.0, 0.0, 0.0, 1.0),
        u_i_0=wp.spatial_vectorf(0.0, 0.0, 0.0, 0.0, 0.0, 0.0),
        world_index=world_index,
    )

    # Add collision geometries
    _builder.add_geometry(body=bid0, shape=BoxShape(0.1, 0.1, 0.1), world_index=world_index)

    # Add a static collision geometry for the plane
    if ground:
        _builder.add_geometry(
            body=-1,
            shape=BoxShape(10.0, 10.0, 0.5),
            offset=wp.transformf(0.0, 0.0, -0.5, 0.0, 0.0, 0.0, 1.0),
            world_index=world_index,
        )

    # Return the lists of element indices
    return _builder


def build_box_pendulum(
    builder: ModelBuilderKamino | None = None,
    z_offset: float = 0.7,
    ground: bool = True,
    new_world: bool = True,
    dynamic_joints: bool = False,
    implicit_pd: bool = False,
    world_index: int = 0,
) -> ModelBuilderKamino:
    """
    Constructs a basic model of a single box pendulum body with a unary revolute joint.

    This version initializes the pendulum in a horizontal configuration.

    Args:
        builder: An optional existing model builder to populate.
            If `None`, a new builder is created.
        z_offset: A vertical offset to apply to the initial position of the box.
        ground: Whether to add a static ground plane to the model.
        new_world: Whether to create a new world in the builder for this model.
            If `False`, the model is added to the existing world specified by `world_index`.
            If `True`, a new world is created and added to the builder. In this case the `world_index`
            argument is ignored, and the index of the newly created world will be used instead.
        world_index: The index of the world to which the model should be added if `new_world` is False.
            If `new_world` is True, this argument is ignored.
            If the value does not correspond to an existing world, an error will be raised.
            Defaults to `0`.

    Returns:
        The populated model builder.
    """
    # Create a new builder if none is provided
    if builder is None:
        _builder = ModelBuilderKamino(default_world=False)
    else:
        _builder = builder

    # Create a new world in the builder if requested or if a new builder was created
    if new_world or builder is None:
        world_index = _builder.add_world(name="box_pendulum")

    # Model constants
    m = 1.0
    d = 0.5
    w = 0.1
    h = 0.1
    z_0 = z_offset  # Initial z offset for the body

    # Add box pendulum body
    bid0 = _builder.add_rigid_body(
        name="pendulum",
        m_i=m,
        i_I_i=inertia.solid_cuboid_body_moment_of_inertia(m, d, w, h),
        q_i_0=wp.transformf(0.5 * d, 0.0, 0.5 * h + z_0, 0.0, 0.0, 0.0, 1.0),
        u_i_0=wp.spatial_vectorf(0.0, 0.0, 0.0, 0.0, 0.0, 0.0),
        world_index=world_index,
    )

    # Add a joint between the two bodies
    _builder.add_joint(
        name="world_to_pendulum",
        dof_type=JointDoFType.REVOLUTE,
        act_type=JointActuationType.POSITION_VELOCITY if implicit_pd else JointActuationType.FORCE,
        bid_B=-1,
        bid_F=bid0,
        B_r_Bj=wp.vec3f(0.0, 0.0, 0.5 * h + z_0),
        F_r_Fj=wp.vec3f(-0.5 * d, 0.0, 0.0),
        X_Bj=axis_to_mat33(Axis.Y),
        tau_j_max=math.inf,  # Setting effort limit to match USD convention (`inf` for active joints)
        a_j=1.0 if dynamic_joints else None,
        b_j=0.1 if dynamic_joints else None,
        k_p_j=100.0 if implicit_pd else None,
        k_d_j=1.0 if implicit_pd else None,
        world_index=world_index,
    )

    # Add collision geometries
    _builder.add_geometry(
        name="box",
        body=bid0,
        shape=BoxShape(0.5 * d, 0.5 * w, 0.5 * h),
        world_index=world_index,
    )

    # Add a static collision geometry for the plane
    if ground:
        _builder.add_geometry(
            name="ground",
            body=-1,
            shape=BoxShape(10.0, 10.0, 0.5),
            offset=wp.transformf(0.0, 0.0, -0.5, 0.0, 0.0, 0.0, 1.0),
            world_index=world_index,
        )

    # Return the lists of element indices
    return _builder


def build_box_pendulum_vertical(
    builder: ModelBuilderKamino | None = None,
    z_offset: float = 0.7,
    ground: bool = True,
    new_world: bool = True,
    world_index: int = 0,
) -> ModelBuilderKamino:
    """
    Constructs a basic model of a single box pendulum body with a unary revolute joint.

    This version initializes the pendulum in a vertical configuration.

    Args:
        builder: An optional existing model builder to populate.
            If `None`, a new builder is created.
        z_offset: A vertical offset to apply to the initial position of the box.
        ground: Whether to add a static ground plane to the model.
        new_world: Whether to create a new world in the builder for this model.
            If `False`, the model is added to the existing world specified by `world_index`.
            If `True`, a new world is created and added to the builder. In this case the `world_index`
            argument is ignored, and the index of the newly created world will be used instead.
        world_index: The index of the world to which the model should be added if `new_world` is False.
            If `new_world` is True, this argument is ignored.
            If the value does not correspond to an existing world, an error will be raised.
            Defaults to `0`.

    Returns:
        The populated model builder.
    """
    # Create a new builder if none is provided
    if builder is None:
        _builder = ModelBuilderKamino(default_world=False)
    else:
        _builder = builder

    # Create a new world in the builder if requested or if a new builder was created
    if new_world or builder is None:
        world_index = _builder.add_world(name="box_pendulum_vertical")

    # Model constants
    m = 1.0
    d = 0.1
    w = 0.1
    h = 0.5
    z_0 = z_offset  # Initial z offset for the body

    # Add box pendulum body
    bid0 = _builder.add_rigid_body(
        name="pendulum",
        m_i=m,
        i_I_i=inertia.solid_cuboid_body_moment_of_inertia(m, d, w, h),
        q_i_0=wp.transformf(0.0, 0.0, -0.5 * h + z_0, 0.0, 0.0, 0.0, 1.0),
        u_i_0=wp.spatial_vectorf(0.0, 0.0, 0.0, 0.0, 0.0, 0.0),
        world_index=world_index,
    )

    # Add a joint between the two bodies
    _builder.add_joint(
        name="world_to_pendulum",
        dof_type=JointDoFType.REVOLUTE,
        act_type=JointActuationType.FORCE,
        bid_B=-1,
        bid_F=bid0,
        B_r_Bj=wp.vec3f(0.0, 0.0, 0.0 + z_0),
        F_r_Fj=wp.vec3f(0.0, 0.0, 0.5 * h),
        X_Bj=axis_to_mat33(Axis.Y),
        world_index=world_index,
    )

    # Add collision geometries
    _builder.add_geometry(
        name="box",
        body=bid0,
        shape=BoxShape(0.5 * d, 0.5 * w, 0.5 * h),
        world_index=world_index,
    )

    # Add a static collision geometry for the plane
    if ground:
        _builder.add_geometry(
            name="ground",
            body=-1,
            shape=BoxShape(10.0, 10.0, 0.5),
            offset=wp.transformf(0.0, 0.0, -0.5, 0.0, 0.0, 0.0, 1.0),
            world_index=world_index,
        )

    # Return the lists of element indices
    return _builder


def build_cartpole(
    builder: ModelBuilderKamino | None = None,
    z_offset: float = 0.0,
    ground: bool = True,
    new_world: bool = True,
    limits: bool = True,
    world_index: int = 0,
) -> ModelBuilderKamino:
    """
    Constructs a basic model of a cartpole mounted onto a rail.

    Args:
        builder: An optional existing model builder to populate.
            If `None`, a new builder is created.
        z_offset: A vertical offset to apply to the initial position of the box.
        ground: Whether to add a static ground plane to the model.
        new_world: Whether to create a new world in the builder for this model.
            If `False`, the model is added to the existing world specified by `world_index`.
            If `True`, a new world is created and added to the builder. In this case the `world_index`
            argument is ignored, and the index of the newly created world will be used instead.
        world_index: The index of the world to which the model should be added if `new_world` is False.
            If `new_world` is True, this argument is ignored.
            If the value does not correspond to an existing world, an error will be raised.
            Defaults to `0`.

    Returns:
        The populated model builder.
    """
    # Create a new builder if none is provided
    if builder is None:
        _builder = ModelBuilderKamino(default_world=False)
    else:
        _builder = builder

    # Create a new world in the builder if requested or if a new builder was created
    if new_world or builder is None:
        world_index = _builder.add_world(name="cartpole")

    # Model constants
    m_cart = 1.0
    m_pole = 0.2
    dims_rail = (0.03, 8.0, 0.03)  # full dimensions (used for inertia, positions)
    dims_cart = (0.2, 0.5, 0.2)
    dims_pole = (0.05, 0.05, 0.75)
    half_dims_rail = (0.5 * dims_rail[0], 0.5 * dims_rail[1], 0.5 * dims_rail[2])
    half_dims_cart = (0.5 * dims_cart[0], 0.5 * dims_cart[1], 0.5 * dims_cart[2])
    half_dims_pole = (0.5 * dims_pole[0], 0.5 * dims_pole[1], 0.5 * dims_pole[2])

    # Add box cart body
    bid0 = _builder.add_rigid_body(
        name="cart",
        m_i=m_cart,
        i_I_i=inertia.solid_cuboid_body_moment_of_inertia(m_cart, *dims_cart),
        q_i_0=wp.transformf(0.0, 0.0, z_offset, 0.0, 0.0, 0.0, 1.0),
        u_i_0=wp.spatial_vectorf(0.0, 0.0, 0.0, 0.0, 0.0, 0.0),
        world_index=world_index,
    )

    # Add box pole body
    x_0_pole = 0.5 * dims_pole[0] + 0.5 * dims_cart[0]
    z_0_pole = 0.5 * dims_pole[2] + z_offset
    bid1 = _builder.add_rigid_body(
        name="pole",
        m_i=m_pole,
        i_I_i=inertia.solid_cuboid_body_moment_of_inertia(m_pole, *dims_pole),
        q_i_0=wp.transformf(x_0_pole, 0.0, z_0_pole, 0.0, 0.0, 0.0, 1.0),
        u_i_0=wp.spatial_vectorf(0.0, 0.0, 0.0, 0.0, 0.0, 0.0),
        world_index=world_index,
    )

    # Add a prismatic joint for the cart
    _builder.add_joint(
        name="rail_to_cart",
        dof_type=JointDoFType.PRISMATIC,
        act_type=JointActuationType.FORCE,
        bid_B=-1,
        bid_F=bid0,
        B_r_Bj=wp.vec3f(0.0, 0.0, z_offset),
        F_r_Fj=wp.vec3f(0.0, 0.0, 0.0),
        X_Bj=axis_to_mat33(Axis.Y),
        q_j_min=[-4.0] if limits else [float(FLOAT32_MIN)],
        q_j_max=[4.0] if limits else [float(FLOAT32_MAX)],
        tau_j_max=[1000.0],
        world_index=world_index,
    )

    # Add a revolute joint for the pendulum
    _builder.add_joint(
        name="cart_to_pole",
        dof_type=JointDoFType.REVOLUTE,
        act_type=JointActuationType.PASSIVE,
        bid_B=bid0,
        bid_F=bid1,
        B_r_Bj=wp.vec3f(0.5 * dims_cart[0], 0.0, 0.0),
        F_r_Fj=wp.vec3f(-0.5 * dims_pole[0], 0.0, -0.5 * dims_pole[2]),
        X_Bj=axis_to_mat33(Axis.X),
        world_index=world_index,
    )

    # Add collision geometries
    _builder.add_geometry(
        name="cart",
        body=bid0,
        shape=BoxShape(*half_dims_cart),
        group=2,
        collides=2,
        world_index=world_index,
    )
    _builder.add_geometry(
        name="pole",
        body=bid1,
        shape=BoxShape(*half_dims_pole),
        group=3,
        collides=3,
        world_index=world_index,
    )
    _builder.add_geometry(
        name="rail",
        body=-1,
        shape=BoxShape(*half_dims_rail),
        offset=wp.transformf(0.0, 0.0, z_offset, 0.0, 0.0, 0.0, 1.0),
        group=1,
        collides=1,
        world_index=world_index,
    )

    # Add a static collision geometry for the plane
    if ground:
        _builder.add_geometry(
            name="ground",
            body=-1,
            shape=BoxShape(10.0, 10.0, 0.5),
            offset=wp.transformf(0.0, 0.0, -1.0 + z_offset, 0.0, 0.0, 0.0, 1.0),
            group=1,
            collides=1,
            world_index=world_index,
        )

    # Return the lists of element indices
    return _builder


def build_boxes_hinged(
    builder: ModelBuilderKamino | None = None,
    z_offset: float = 0.0,
    ground: bool = True,
    dynamic_joints: bool = False,
    implicit_pd: bool = False,
    new_world: bool = True,
    world_index: int = 0,
) -> ModelBuilderKamino:
    """
    Constructs a basic model of a two floating boxes connected via revolute joint.

    Args:
        builder: An optional existing model builder to populate.
            If `None`, a new builder is created.
        z_offset: A vertical offset to apply to the initial position of the box.
        ground: Whether to add a static ground plane to the model.
        new_world: Whether to create a new world in the builder for this model.
            If `False`, the model is added to the existing world specified by `world_index`.
            If `True`, a new world is created and added to the builder. In this case the `world_index`
            argument is ignored, and the index of the newly created world will be used instead.
        world_index: The index of the world to which the model should be added if `new_world` is False.
            If `new_world` is True, this argument is ignored.
            If the value does not correspond to an existing world, an error will be raised.
            Defaults to `0`.

    Returns:
        The populated model builder.
    """
    # Create a new builder if none is provided
    if builder is None:
        _builder = ModelBuilderKamino(default_world=False)
    else:
        _builder = builder

    # Create a new world in the builder if requested or if a new builder was created
    if new_world or builder is None:
        world_index = _builder.add_world(name="boxes_hinged")

    # Model constants
    m_0 = 1.0
    m_1 = 1.0
    d = 0.5
    w = 0.1
    h = 0.1
    z0 = z_offset  # Initial z offset for the bodies

    # Add first body
    bid0 = _builder.add_rigid_body(
        name="base",
        m_i=m_0,
        i_I_i=inertia.solid_cuboid_body_moment_of_inertia(m_0, d, w, h),
        q_i_0=wp.transformf(0.25, -0.05, 0.05 + z0, 0.0, 0.0, 0.0, 1.0),
        u_i_0=wp.spatial_vectorf(0.0, 0.0, 0.0, 0.0, 0.0, 0.0),
        world_index=world_index,
    )

    # Add second body
    bid1 = _builder.add_rigid_body(
        name="follower",
        m_i=m_1,
        i_I_i=inertia.solid_cuboid_body_moment_of_inertia(m_1, d, w, h),
        q_i_0=wp.transformf(0.75, 0.05, 0.05 + z0, 0.0, 0.0, 0.0, 1.0),
        u_i_0=wp.spatial_vectorf(0.0, 0.0, 0.0, 0.0, 0.0, 0.0),
        world_index=world_index,
    )

    # Add a joint between the two bodies
    _builder.add_joint(
        name="hinge",
        dof_type=JointDoFType.REVOLUTE,
        act_type=JointActuationType.POSITION_VELOCITY if implicit_pd else JointActuationType.FORCE,
        bid_B=bid0,
        bid_F=bid1,
        B_r_Bj=wp.vec3f(0.25, 0.05, 0.0),
        F_r_Fj=wp.vec3f(-0.25, -0.05, 0.0),
        X_Bj=axis_to_mat33(Axis.Y),
        tau_j_max=math.inf,  # Setting effort limit to match USD convention (`inf` for active joints)
        a_j=1.0 if dynamic_joints else None,
        b_j=0.1 if dynamic_joints else None,
        k_p_j=100.0 if implicit_pd else None,
        k_d_j=1.0 if implicit_pd else None,
        world_index=world_index,
    )

    # Add collision geometries
    _builder.add_geometry(
        name="base/box",
        body=bid0,
        shape=BoxShape(0.5 * d, 0.5 * w, 0.5 * h),
        group=2,
        collides=3,
        world_index=world_index,
    )
    _builder.add_geometry(
        name="follower/box",
        body=bid1,
        shape=BoxShape(0.5 * d, 0.5 * w, 0.5 * h),
        group=3,
        collides=5,
        world_index=world_index,
    )

    # Add a static collision geometry for the plane
    if ground:
        _builder.add_geometry(
            name="ground",
            body=-1,
            shape=BoxShape(10.0, 10.0, 0.5),
            offset=wp.transformf(0.0, 0.0, -0.5, 0.0, 0.0, 0.0, 1.0),
            group=1,
            collides=7,
            world_index=world_index,
        )

    # Return the lists of element indices
    return _builder


def build_boxes_nunchaku(
    builder: ModelBuilderKamino | None = None,
    z_offset: float = 0.0,
    ground: bool = True,
    new_world: bool = True,
    world_index: int = 0,
) -> ModelBuilderKamino:
    """
    Constructs a basic model of a faux nunchaku consisting of
    two boxes and one sphere connected via spherical joints.

    This version initializes the nunchaku in a horizontal configuration.

    Args:
        builder: An optional existing model builder to populate.
            If `None`, a new builder is created.
        z_offset: A vertical offset to apply to the initial position of the box.
        ground: Whether to add a static ground plane to the model.
        new_world: Whether to create a new world in the builder for this model.
            If `False`, the model is added to the existing world specified by `world_index`.
            If `True`, a new world is created and added to the builder. In this case the `world_index`
            argument is ignored, and the index of the newly created world will be used instead.
        world_index: The index of the world to which the model should be added if `new_world` is False.
            If `new_world` is True, this argument is ignored.
            If the value does not correspond to an existing world, an error will be raised.
            Defaults to `0`.

    Returns:
        The populated model builder.
    """
    # Create a new builder if none is provided
    if builder is None:
        _builder = ModelBuilderKamino(default_world=False)
    else:
        _builder = builder

    # Create a new world in the builder if requested or if a new builder was created
    if new_world or builder is None:
        world_index = _builder.add_world(name="boxes_nunchaku")

    # Model constants
    m_0 = 1.0
    m_1 = 1.0
    m_2 = 1.0
    d = 0.5
    w = 0.1
    h = 0.1
    r = 0.05

    # Constant to set an initial z offset for the bodies
    # NOTE: for testing purposes, recommend values are {0.0, -0.001}
    z_0 = z_offset

    # Add first body
    bid0 = _builder.add_rigid_body(
        name="box_bottom",
        m_i=m_0,
        i_I_i=inertia.solid_cuboid_body_moment_of_inertia(m_0, d, w, h),
        q_i_0=wp.transformf(0.5 * d, 0.0, 0.5 * h + z_0, 0.0, 0.0, 0.0, 1.0),
        u_i_0=wp.spatial_vectorf(0.0, 0.0, 0.0, 0.0, 0.0, 0.0),
        world_index=world_index,
    )

    # Add second body
    bid1 = _builder.add_rigid_body(
        name="sphere_middle",
        m_i=m_1,
        i_I_i=inertia.solid_sphere_body_moment_of_inertia(m_1, r),
        q_i_0=wp.transformf(r + d, 0.0, r + z_0, 0.0, 0.0, 0.0, 1.0),
        u_i_0=wp.spatial_vectorf(0.0, 0.0, 0.0, 0.0, 0.0, 0.0),
        world_index=world_index,
    )

    # Add third body
    bid2 = _builder.add_rigid_body(
        name="box_top",
        m_i=m_2,
        i_I_i=inertia.solid_cuboid_body_moment_of_inertia(m_2, d, w, h),
        q_i_0=wp.transformf(1.5 * d + 2.0 * r, 0.0, 0.5 * h + z_0, 0.0, 0.0, 0.0, 1.0),
        u_i_0=wp.spatial_vectorf(0.0, 0.0, 0.0, 0.0, 0.0, 0.0),
        world_index=world_index,
    )

    # Add a joint between the first and second body
    _builder.add_joint(
        name="box_bottom_to_sphere_middle",
        dof_type=JointDoFType.SPHERICAL,
        act_type=JointActuationType.PASSIVE,
        bid_B=bid0,
        bid_F=bid1,
        B_r_Bj=wp.vec3f(0.5 * d, 0.0, 0.0),
        F_r_Fj=wp.vec3f(-r, 0.0, 0.0),
        X_Bj=I_3,
        world_index=world_index,
    )

    # Add a joint between the second and third body
    _builder.add_joint(
        name="sphere_middle_to_box_top",
        dof_type=JointDoFType.SPHERICAL,
        act_type=JointActuationType.PASSIVE,
        bid_B=bid1,
        bid_F=bid2,
        B_r_Bj=wp.vec3f(r, 0.0, 0.0),
        F_r_Fj=wp.vec3f(-0.5 * d, 0.0, 0.0),
        X_Bj=I_3,
        world_index=world_index,
    )

    # Add collision geometries
    _builder.add_geometry(
        name="box_bottom",
        body=bid0,
        shape=BoxShape(0.5 * d, 0.5 * w, 0.5 * h),
        group=2,
        collides=3,
        world_index=world_index,
    )
    _builder.add_geometry(
        name="sphere_middle", body=bid1, shape=SphereShape(r), group=3, collides=5, world_index=world_index
    )
    _builder.add_geometry(
        name="box_top",
        body=bid2,
        shape=BoxShape(0.5 * d, 0.5 * w, 0.5 * h),
        group=2,
        collides=3,
        world_index=world_index,
    )

    # Add a static collision geometry for the plane
    if ground:
        _builder.add_geometry(
            name="ground",
            body=-1,
            shape=BoxShape(10.0, 10.0, 0.5),
            offset=wp.transformf(0.0, 0.0, -0.5, 0.0, 0.0, 0.0, 1.0),
            group=1,
            collides=7,
            world_index=world_index,
        )

    # Return the lists of element indices
    return _builder


def build_boxes_nunchaku_vertical(
    builder: ModelBuilderKamino | None = None,
    z_offset: float = 0.0,
    ground: bool = True,
    new_world: bool = True,
    world_index: int = 0,
) -> ModelBuilderKamino:
    """
    Constructs a basic model of a faux nunchaku consisting of
    two boxes and one sphere connected via spherical joints.

    This version initializes the nunchaku in a vertical configuration.

    Args:
        builder: An optional existing model builder to populate.
            If `None`, a new builder is created.
        z_offset: A vertical offset to apply to the initial position of the box.
        ground: Whether to add a static ground plane to the model.
        new_world: Whether to create a new world in the builder for this model.
            If `False`, the model is added to the existing world specified by `world_index`.
            If `True`, a new world is created and added to the builder. In this case the `world_index`
            argument is ignored, and the index of the newly created world will be used instead.
        world_index: The index of the world to which the model should be added if `new_world` is False.
            If `new_world` is True, this argument is ignored.
            If the value does not correspond to an existing world, an error will be raised.
            Defaults to `0`.

    Returns:
        The populated model builder.
    """
    # Create a new builder if none is provided
    if builder is None:
        _builder = ModelBuilderKamino(default_world=False)
    else:
        _builder = builder

    # Create a new world in the builder if requested or if a new builder was created
    if new_world or builder is None:
        world_index = _builder.add_world(name="boxes_nunchaku_vertical")

    # Model constants
    m_0 = 1.0
    m_1 = 1.0
    m_2 = 1.0
    d = 0.1
    w = 0.1
    h = 0.5
    r = 0.05

    # Constant to set an initial z offset for the bodies
    # NOTE: for testing purposes, recommend values are {0.0, -0.001}
    z_0 = z_offset

    # Add first body
    bid0 = _builder.add_rigid_body(
        name="box_bottom",
        m_i=m_0,
        i_I_i=inertia.solid_cuboid_body_moment_of_inertia(m_0, d, w, h),
        q_i_0=wp.transformf(0.0, 0.0, 0.5 * h + z_0, 0.0, 0.0, 0.0, 1.0),
        u_i_0=wp.spatial_vectorf(0.0, 0.0, 0.0, 0.0, 0.0, 0.0),
        world_index=world_index,
    )

    # Add second body
    bid1 = _builder.add_rigid_body(
        name="sphere_middle",
        m_i=m_1,
        i_I_i=inertia.solid_sphere_body_moment_of_inertia(m_1, r),
        q_i_0=wp.transformf(0.0, 0.0, h + r + z_0, 0.0, 0.0, 0.0, 1.0),
        u_i_0=wp.spatial_vectorf(0.0, 0.0, 0.0, 0.0, 0.0, 0.0),
        world_index=world_index,
    )

    # Add third body
    bid2 = _builder.add_rigid_body(
        name="box_top",
        m_i=m_2,
        i_I_i=inertia.solid_cuboid_body_moment_of_inertia(m_2, d, w, h),
        q_i_0=wp.transformf(0.0, 0.0, 1.5 * h + 2.0 * r + z_0, 0.0, 0.0, 0.0, 1.0),
        u_i_0=wp.spatial_vectorf(0.0, 0.0, 0.0, 0.0, 0.0, 0.0),
        world_index=world_index,
    )

    # Add a joint between the first and second body
    _builder.add_joint(
        name="box_bottom_to_sphere_middle",
        dof_type=JointDoFType.SPHERICAL,
        act_type=JointActuationType.PASSIVE,
        bid_B=bid0,
        bid_F=bid1,
        B_r_Bj=wp.vec3f(0.0, 0.0, 0.5 * h),
        F_r_Fj=wp.vec3f(0.0, 0.0, -r),
        X_Bj=I_3,
        world_index=world_index,
    )

    # Add a joint between the second and third body
    _builder.add_joint(
        name="sphere_middle_to_box_top",
        dof_type=JointDoFType.SPHERICAL,
        act_type=JointActuationType.PASSIVE,
        bid_B=bid1,
        bid_F=bid2,
        B_r_Bj=wp.vec3f(0.0, 0.0, r),
        F_r_Fj=wp.vec3f(0.0, 0.0, -0.5 * h),
        X_Bj=I_3,
        world_index=world_index,
    )

    # Add collision geometries
    _builder.add_geometry(
        name="box_bottom",
        body=bid0,
        shape=BoxShape(0.5 * d, 0.5 * w, 0.5 * h),
        group=2,
        collides=3,
        world_index=world_index,
    )
    _builder.add_geometry(
        name="sphere_middle", body=bid1, shape=SphereShape(r), group=3, collides=5, world_index=world_index
    )
    _builder.add_geometry(
        name="box_top",
        body=bid2,
        shape=BoxShape(0.5 * d, 0.5 * w, 0.5 * h),
        group=2,
        collides=3,
        world_index=world_index,
    )

    # Add a static collision geometry for the plane
    if ground:
        _builder.add_geometry(
            name="ground",
            body=-1,
            shape=BoxShape(10.0, 10.0, 0.5),
            offset=wp.transformf(0.0, 0.0, -0.5, 0.0, 0.0, 0.0, 1.0),
            group=1,
            collides=7,
            world_index=world_index,
        )

    # Return the lists of element indices
    return _builder


def build_boxes_fourbar(
    builder: ModelBuilderKamino | None = None,
    z_offset: float = 0.0,
    fixedbase: bool = False,
    floatingbase: bool = False,
    limits: bool = True,
    ground: bool = True,
    dynamic_joints: bool = False,
    implicit_pd: bool = False,
    verbose: bool = False,
    new_world: bool = True,
    world_index: int = 0,
    actuator_ids: list[int] | None = None,
    use_plane_shape: bool = False,
) -> ModelBuilderKamino:
    """
    Constructs a basic model of a four-bar linkage.

    Args:
        builder: An optional existing model builder to populate.
            If `None`, a new builder is created.
        z_offset: A vertical offset to apply to the initial position of the first box.
        fixedbase: Whether to add a fixed joint between the first box and the world.
        floatingbase: Whether to add a free joint between the first box and the world.
        limits: Whether to set finite position limits to revolute joints.
        ground: Whether to add a static ground plane to the model.
        dynamic_joints: Whether to set non-trivial armature and damping to the first revolute joint.
        implicit_pd: Whether to set non-trivial implicit PD gains to the first revolute joint.
        verbose: Whether to print debug information such as body/joint positions.
        new_world: Whether to create a new world in the builder for this model.
            If `False`, the model is added to the existing world specified by `world_index`.
            If `True`, a new world is created and added to the builder. In this case the `world_index`
            argument is ignored, and the index of the newly created world will be used instead.
        world_index: The index of the world to which the model should be added if `new_world` is False.
            If `new_world` is `True`, this argument is ignored.
            If the value does not correspond to an existing world, an error will be raised.
            Defaults to `0`.
        actuator_ids: List of revolute joint indices in [1, 2, 3, 4] to make into actuators.
            If not provided, defaults to [1, 3]
        use_plane_shape: If `True`, and `ground` is `True`, will use a plane shape for the ground instead
            of a wide and thin box. Note that planes are not supported in the primitive collision pipeline.

    Returns:
        A model builder containing the four-bar linkage.
    """
    if fixedbase and floatingbase:
        raise ValueError("At most one of fixedbase or floatingbase can be enabled.")

    # Create a new builder if none is provided
    if builder is None:
        _builder = ModelBuilderKamino(default_world=False)
    else:
        _builder = builder

    # Create a new world in the builder if requested or if a new builder was created
    if new_world or builder is None:
        world_index = _builder.add_world(name="boxes_fourbar")

    # Set default actuator IDs if none are provided
    if actuator_ids is None:
        actuator_ids = [1, 3]
    elif not isinstance(actuator_ids, list):
        raise TypeError("actuator_ids, if specified, must be provided as a list of integers.")

    ###
    # Base Parameters
    ###

    # Constant to set an initial z offset for the bodies
    # NOTE: for testing purposes, recommend values are {0.0, -0.001}
    z_0 = z_offset

    # Box dimensions
    d = 0.01
    w = 0.01
    h = 0.1

    # Margins
    mj = 0.001
    dj = 0.5 * d + mj

    ###
    # Body parameters
    ###

    # Box dimensions
    d_1 = h
    w_1 = w
    h_1 = d
    d_2 = d
    w_2 = w
    h_2 = h
    d_3 = h
    w_3 = w
    h_3 = d
    d_4 = d
    w_4 = w
    h_4 = h

    # Inertial properties
    m_i = 1.0
    i_I_i_1 = inertia.solid_cuboid_body_moment_of_inertia(m_i, d_1, w_1, h_1)
    i_I_i_2 = inertia.solid_cuboid_body_moment_of_inertia(m_i, d_2, w_2, h_2)
    i_I_i_3 = inertia.solid_cuboid_body_moment_of_inertia(m_i, d_3, w_3, h_3)
    i_I_i_4 = inertia.solid_cuboid_body_moment_of_inertia(m_i, d_4, w_4, h_4)
    if verbose:
        print(f"i_I_i_1:\n{i_I_i_1}")
        print(f"i_I_i_2:\n{i_I_i_2}")
        print(f"i_I_i_3:\n{i_I_i_3}")
        print(f"i_I_i_4:\n{i_I_i_4}")

    # Initial body positions
    r_0 = wp.vec3f(0.0, 0.0, z_0)
    dr_b1 = wp.vec3f(0.0, 0.0, 0.5 * d)
    dr_b2 = wp.vec3f(0.5 * h + dj, 0.0, 0.5 * h + dj)
    dr_b3 = wp.vec3f(0.0, 0.0, 0.5 * d + h + dj + mj)
    dr_b4 = wp.vec3f(-0.5 * h - dj, 0.0, 0.5 * h + dj)

    # Initial positions of the bodies
    r_b1 = r_0 + dr_b1
    r_b2 = r_b1 + dr_b2
    r_b3 = r_b1 + dr_b3
    r_b4 = r_b1 + dr_b4
    if verbose:
        print(f"r_b1: {r_b1}")
        print(f"r_b2: {r_b2}")
        print(f"r_b3: {r_b3}")
        print(f"r_b4: {r_b4}")

    # Initial body poses
    q_i_1 = wp.transformf(r_b1, wp.quat_identity())
    q_i_2 = wp.transformf(r_b2, wp.quat_identity())
    q_i_3 = wp.transformf(r_b3, wp.quat_identity())
    q_i_4 = wp.transformf(r_b4, wp.quat_identity())

    # Initial joint positions
    r_j1 = wp.vec3f(r_b2.x, 0.0, r_b1.z)
    r_j2 = wp.vec3f(r_b2.x, 0.0, r_b3.z)
    r_j3 = wp.vec3f(r_b4.x, 0.0, r_b3.z)
    r_j4 = wp.vec3f(r_b4.x, 0.0, r_b1.z)
    if verbose:
        print(f"r_j1: {r_j1}")
        print(f"r_j2: {r_j2}")
        print(f"r_j3: {r_j3}")
        print(f"r_j4: {r_j4}")

    # Joint axes matrix
    X_j = axis_to_mat33(Axis.Y)

    ###
    # Bodies
    ###

    bid1 = _builder.add_rigid_body(
        name="link_1",
        m_i=m_i,
        i_I_i=i_I_i_1,
        q_i_0=q_i_1,
        u_i_0=wp.spatial_vectorf(0.0),
        world_index=world_index,
    )

    bid2 = _builder.add_rigid_body(
        name="link_2",
        m_i=m_i,
        i_I_i=i_I_i_2,
        q_i_0=q_i_2,
        u_i_0=wp.spatial_vectorf(0.0),
        world_index=world_index,
    )

    bid3 = _builder.add_rigid_body(
        name="link_3",
        m_i=m_i,
        i_I_i=i_I_i_3,
        q_i_0=q_i_3,
        u_i_0=wp.spatial_vectorf(0.0),
        world_index=world_index,
    )

    bid4 = _builder.add_rigid_body(
        name="link_4",
        m_i=m_i,
        i_I_i=i_I_i_4,
        q_i_0=q_i_4,
        u_i_0=wp.spatial_vectorf(0.0),
        world_index=world_index,
    )

    ###
    # Joints
    ###

    if limits:
        qmin = -0.25 * math.pi
        qmax = 0.25 * math.pi
    else:
        qmin = float(FLOAT32_MIN)
        qmax = float(FLOAT32_MAX)

    if fixedbase:
        _builder.add_joint(
            name="world_to_link1",
            dof_type=JointDoFType.FIXED,
            act_type=JointActuationType.PASSIVE,
            bid_B=-1,
            bid_F=bid1,
            B_r_Bj=wp.vec3f(0.0),
            F_r_Fj=wp.vec3f(0.0),
            X_Bj=I_3,
            world_index=world_index,
        )

    if floatingbase:
        _builder.add_joint(
            name="world_to_link1",
            dof_type=JointDoFType.FREE,
            act_type=JointActuationType.FORCE if 0 in actuator_ids else JointActuationType.PASSIVE,
            bid_B=-1,
            bid_F=bid1,
            B_r_Bj=wp.vec3f(0.0),
            F_r_Fj=wp.vec3f(0.0),
            X_Bj=I_3,
            world_index=world_index,
        )

    joint_1_type_if_implicit_pd = JointActuationType.POSITION_VELOCITY if implicit_pd else JointActuationType.FORCE
    joint_1_type = joint_1_type_if_implicit_pd if 1 in actuator_ids else JointActuationType.PASSIVE
    _builder.add_joint(
        name="link1_to_link2",
        dof_type=JointDoFType.REVOLUTE,
        act_type=joint_1_type,
        bid_B=bid1,
        bid_F=bid2,
        B_r_Bj=r_j1 - r_b1,
        F_r_Fj=r_j1 - r_b2,
        X_Bj=X_j,
        q_j_min=[qmin],
        q_j_max=[qmax],
        # Setting effort limit to match USD convention (`inf` sentinel for
        # active joints, `JOINT_TAUMAX` for passive joints).
        tau_j_max=math.inf if 1 in actuator_ids else JOINT_TAUMAX,
        a_j=0.1 if dynamic_joints else None,
        b_j=0.001 if dynamic_joints else None,
        k_p_j=1000.0 if implicit_pd else None,
        k_d_j=20.0 if implicit_pd else None,
        world_index=world_index,
    )

    _builder.add_joint(
        name="link2_to_link3",
        dof_type=JointDoFType.REVOLUTE,
        act_type=JointActuationType.FORCE if 2 in actuator_ids else JointActuationType.PASSIVE,
        bid_B=bid2,
        bid_F=bid3,
        B_r_Bj=r_j2 - r_b2,
        F_r_Fj=r_j2 - r_b3,
        X_Bj=X_j,
        q_j_min=[qmin],
        q_j_max=[qmax],
        # Setting effort limit to match USD convention (`inf` sentinel for
        # active joints, `JOINT_TAUMAX` for passive joints).
        tau_j_max=math.inf if 2 in actuator_ids else JOINT_TAUMAX,
        world_index=world_index,
    )

    _builder.add_joint(
        name="link3_to_link4",
        dof_type=JointDoFType.REVOLUTE,
        act_type=JointActuationType.FORCE if 3 in actuator_ids else JointActuationType.PASSIVE,
        bid_B=bid3,
        bid_F=bid4,
        B_r_Bj=r_j3 - r_b3,
        F_r_Fj=r_j3 - r_b4,
        X_Bj=X_j,
        q_j_min=[qmin],
        q_j_max=[qmax],
        # Setting effort limit to match USD convention (`inf` sentinel for
        # active joints, `JOINT_TAUMAX` for passive joints).
        tau_j_max=math.inf if 3 in actuator_ids else JOINT_TAUMAX,
        world_index=world_index,
    )

    _builder.add_joint(
        name="link4_to_link1",
        dof_type=JointDoFType.REVOLUTE,
        act_type=JointActuationType.FORCE if 4 in actuator_ids else JointActuationType.PASSIVE,
        bid_B=bid4,
        bid_F=bid1,
        B_r_Bj=r_j4 - r_b4,
        F_r_Fj=r_j4 - r_b1,
        X_Bj=X_j,
        q_j_min=[qmin],
        q_j_max=[qmax],
        # Setting effort limit to match USD convention (`inf` sentinel for
        # active joints, `JOINT_TAUMAX` for passive joints).
        tau_j_max=math.inf if 4 in actuator_ids else JOINT_TAUMAX,
        world_index=world_index,
    )

    ###
    # Geometries
    ###

    # Add collision geometries
    _builder.add_geometry(
        name="box_1", body=bid1, shape=BoxShape(0.5 * d_1, 0.5 * w_1, 0.5 * h_1), world_index=world_index
    )
    _builder.add_geometry(
        name="box_2", body=bid2, shape=BoxShape(0.5 * d_2, 0.5 * w_2, 0.5 * h_2), world_index=world_index
    )
    _builder.add_geometry(
        name="box_3", body=bid3, shape=BoxShape(0.5 * d_3, 0.5 * w_3, 0.5 * h_3), world_index=world_index
    )
    _builder.add_geometry(
        name="box_4", body=bid4, shape=BoxShape(0.5 * d_4, 0.5 * w_4, 0.5 * h_4), world_index=world_index
    )

    # Add a static collision geometry for the plane
    if ground:
        _builder.add_geometry(
            name="ground",
            body=-1,
            shape=PlaneShape() if use_plane_shape else BoxShape(10.0, 10.0, 0.5),
            offset=None if use_plane_shape else wp.transformf(0.0, 0.0, -0.5, 0.0, 0.0, 0.0, 1.0),
            world_index=world_index,
        )

    # Return the lists of element indices
    return _builder


def make_basics_heterogeneous_builder(
    ground: bool = True,
    dynamic_joints: bool = False,
    implicit_pd: bool = False,
) -> ModelBuilderKamino:
    """
    Creates a multi-world builder with different worlds in each model.

    This function constructs a model builder containing all basic models.

    Returns:
        The constructed model builder.
    """
    builder = ModelBuilderKamino(default_world=False)
    builder.add_builder(build_boxes_fourbar(ground=ground, dynamic_joints=dynamic_joints, implicit_pd=implicit_pd))
    builder.add_builder(build_boxes_nunchaku(ground=ground))
    builder.add_builder(build_boxes_hinged(ground=ground, dynamic_joints=dynamic_joints, implicit_pd=implicit_pd))
    builder.add_builder(build_box_pendulum(ground=ground, dynamic_joints=dynamic_joints, implicit_pd=implicit_pd))
    builder.add_builder(build_box_on_plane(ground=ground))
    builder.add_builder(build_cartpole(z_offset=0.5, ground=ground))
    return builder

# SPDX-FileCopyrightText: Copyright (c) 2026 The Newton Developers
# SPDX-License-Identifier: Apache-2.0

"""Defines the Warp kernels used by the Forward Kinematics solver."""

from __future__ import annotations

from functools import cache

import warp as wp

from ...core.joints import JointActuationType, JointDoFType
from ...core.math import (
    G_of,
    quat_left_jacobian_inverse,
    quat_log,
    unit_quat_apply,
    unit_quat_apply_jacobian,
    unit_quat_conj_apply,
    unit_quat_conj_apply_jacobian,
    unit_quat_conj_to_rotation_matrix,
)
from ...core.types import mat34f
from ...kinematics.joints import (
    correct_quat_vector_coord,
    correct_rotational_coord,
    get_joint_coords_mapping_function,
    gimbal_transported_axes,
)
from ...linalg.sparse_matrix import BlockDType
from .types import FKJointDoFType

###
# Module interface
###

__all__ = [
    "_add_regularizer_to_diagonal",
    "_apply_line_search_step",
    "_compute_fk_axis_joint_frames",
    "_compute_fk_joint_frames",
    "_correct_actuator_coords",
    "_correct_universal_constraint_velocities",
    "_eval_actuator_coords",
    "_eval_body_velocities",
    "_eval_fk_actuated_dofs_or_coords",
    "_eval_incremental_target_actuator_coords",
    "_eval_linear_combination",
    "_eval_regularizer_gradient",
    "_eval_rhs",
    "_eval_stepped_state",
    "_eval_target_constraint_velocities",
    "_eval_target_relative_transformations",
    "_eval_unit_quaternion_constraints",
    "_eval_unit_quaternion_constraints_jacobian",
    "_eval_unit_quaternion_constraints_sparse_jacobian",
    "_initialize_jacobian_update_masks",
    "_line_search_check",
    "_newton_check",
    "_reset_state",
    "_reset_state_base_q",
    "_resolve_fk_actuation_types",
    "_update_cg_tolerance_kernel",
    "create_1d_tile_based_kernels",
    "create_2d_tile_based_kernels",
    "create_eval_joint_constraints_jacobian_kernel",
    "create_eval_joint_constraints_kernel",
    "create_eval_joint_constraints_sparse_jacobian_kernel",
    "create_eval_min_num_iterations_kernel",
    "read_quat_from_array",
    "validate_fk_actuation_updates",
]


###
# Module configs
###

wp.set_module_options({"enable_backward": False, "default_grid_stride": False})


###
# Types
###


class block_type(BlockDType(dtype=wp.float32, shape=(7,)).warp_type):
    pass


###
# Functions
###


@wp.func
def read_quat_from_array(array: wp.array[wp.float32], offset: int, normalize: bool) -> wp.quatf:
    """
    Utility function to read a quaternion from a flat array
    """
    q = wp.quatf(array[offset], array[offset + 1], array[offset + 2], array[offset + 3])
    if normalize:
        return wp.normalize(q)
    return q


@wp.func
def _resolve_fk_actuation_type(act_type: wp.int32, fk_act_flag: wp.int32) -> wp.int32:
    """Apply an optional FK actuation override to a model actuation type."""
    if fk_act_flag == 0:
        return JointActuationType.PASSIVE
    if fk_act_flag == 1:
        return JointActuationType.FORCE
    return act_type


@wp.func
def _load_joint_poses(
    base_id: wp.int32, follower_id: wp.int32, bodies_q: wp.array[wp.transformf]
) -> tuple[wp.vec3f, wp.quatf, wp.vec3f, wp.quatf]:
    """Load the base and follower poses, using the identity pose for the world."""
    c_base = wp.vec3f(0.0, 0.0, 0.0)
    q_base = wp.quatf(0.0, 0.0, 0.0, 1.0)
    if base_id >= 0:
        c_base = wp.transform_get_translation(bodies_q[base_id])
        q_base = wp.transform_get_rotation(bodies_q[base_id])
    c_follower = wp.transform_get_translation(bodies_q[follower_id])
    q_follower = wp.transform_get_rotation(bodies_q[follower_id])
    return c_base, q_base, c_follower, q_follower


@wp.func
def _get_reduced_constraint_ids(
    joint_id: wp.int32, ct_full_to_red_map: wp.array[wp.int32]
) -> tuple[wp.vec3i, wp.vec3i]:
    """Load the translational and rotational reduced constraint ids for a joint."""
    first_ct_id_full = 6 * joint_id
    trans_ct_ids_red = wp.vec3i(
        ct_full_to_red_map[first_ct_id_full],
        ct_full_to_red_map[first_ct_id_full + 1],
        ct_full_to_red_map[first_ct_id_full + 2],
    )
    rot_ct_ids_red = wp.vec3i(
        ct_full_to_red_map[first_ct_id_full + 3],
        ct_full_to_red_map[first_ct_id_full + 4],
        ct_full_to_red_map[first_ct_id_full + 5],
    )
    return trans_ct_ids_red, rot_ct_ids_red


@wp.func
def _eval_translation_jacobian_blocks(
    X_T: wp.mat33f,
    q_base: wp.quatf,
    q_follower: wp.quatf,
    x_follower: wp.vec3f,
    c_base: wp.vec3f,
    c_follower: wp.vec3f,
    has_base: wp.bool,
) -> tuple[wp.mat33f, mat34f, wp.mat33f, mat34f]:
    """Evaluate the base and follower blocks of a translational constraint Jacobian."""
    X_T_R_base_T = X_T * unit_quat_conj_to_rotation_matrix(q_base)
    jac_trans_c_base = wp.mat33f(0.0)
    jac_trans_q_base = mat34f(0.0)
    if has_base:
        jac_trans_c_base = -X_T_R_base_T
        delta_pos = unit_quat_apply(q_follower, x_follower) + c_follower - c_base
        jac_trans_q_base = X_T * unit_quat_conj_apply_jacobian(q_base, delta_pos)
    jac_trans_c_follower = X_T_R_base_T
    jac_trans_q_follower = X_T_R_base_T * unit_quat_apply_jacobian(q_follower, x_follower)
    return jac_trans_c_base, jac_trans_q_base, jac_trans_c_follower, jac_trans_q_follower


@wp.func
def _eval_rotation_jacobian_blocks(
    X_T: wp.mat33f,
    q_base: wp.quatf,
    q_follower: wp.quatf,
    q_rel_body: wp.quatf,
    has_base: wp.bool,
) -> tuple[mat34f, mat34f]:
    """Evaluate the base and follower blocks of a rotational constraint Jacobian."""
    q_base_sq_norm = wp.dot(q_base, q_base)
    q_follower_sq_norm = wp.dot(q_follower, q_follower)
    R_base_T = unit_quat_conj_to_rotation_matrix(q_base / wp.sqrt(q_base_sq_norm))
    q_rel = q_follower * wp.quat_inverse(q_rel_body) * wp.quat_inverse(q_base)
    temp = X_T * R_base_T * quat_left_jacobian_inverse(q_rel)
    jac_rot_q_base = mat34f(0.0)
    if has_base:
        jac_rot_q_base = (-2.0 / q_base_sq_norm) * temp * G_of(q_base)
    jac_rot_q_follower = (2.0 / q_follower_sq_norm) * temp * G_of(q_follower)
    return jac_rot_q_base, jac_rot_q_follower


@wp.func
def _eval_passive_universal_jacobian_blocks(
    X_B_T: wp.mat33f,
    X_F_T: wp.mat33f,
    q_base: wp.quatf,
    q_follower: wp.quatf,
    has_base: wp.bool,
) -> tuple[wp.vec4f, wp.vec4f]:
    """Evaluate the base and follower blocks of a passive universal constraint Jacobian."""
    a_x = X_B_T[0]  # x-axis on base
    a_y = X_F_T[1]  # y-axis on follower
    jac_q_base = wp.vec4f(0.0)
    if has_base:
        a_y_follower = unit_quat_apply(q_follower, a_y)
        jac_q_base = -a_y_follower * unit_quat_apply_jacobian(q_base, a_x)
    a_x_base = unit_quat_apply(q_base, a_x)
    jac_q_follower = -a_x_base * unit_quat_apply_jacobian(q_follower, a_y)
    return jac_q_base, jac_q_follower


@wp.func
def _correct_rotational_actuator_coord(
    actuators_q: wp.array[wp.float32], actuators_q_ref: wp.array[wp.float32], coord_id: wp.int32
):
    """Correct an angular actuator coordinate against its reference."""
    actuators_q[coord_id] = correct_rotational_coord(actuators_q[coord_id], actuators_q_ref[coord_id])


@wp.func
def _correct_quat_actuator_coords(
    actuators_q: wp.array[wp.float32], actuators_q_ref: wp.array[wp.float32], coord_id: wp.int32
):
    """Correct four quaternion actuator coordinates against their reference."""
    quat = wp.vec4f(
        actuators_q[coord_id], actuators_q[coord_id + 1], actuators_q[coord_id + 2], actuators_q[coord_id + 3]
    )
    quat_ref = wp.vec4f(
        actuators_q_ref[coord_id],
        actuators_q_ref[coord_id + 1],
        actuators_q_ref[coord_id + 2],
        actuators_q_ref[coord_id + 3],
    )
    quat_corrected = correct_quat_vector_coord(quat, quat_ref)
    for i in range(4):
        actuators_q[coord_id + i] = quat_corrected[i]


###
# Kernels
###


@wp.kernel
def _resolve_fk_actuation_types(
    # Inputs
    model_act_type: wp.array[wp.int32],
    model_fk_act_flag: wp.array[wp.int32],
    # Outputs
    fk_act_type: wp.array[wp.int32],
):
    """Resolve effective FK actuation types for the main model joints."""
    joint = wp.tid()
    flag = wp.int32(-1)
    if model_fk_act_flag:
        flag = model_fk_act_flag[joint]
    fk_act_type[joint] = _resolve_fk_actuation_type(model_act_type[joint], flag)


@wp.kernel
def validate_fk_actuation_updates(
    # Inputs
    model_act_type: wp.array[wp.int32],
    model_fk_act_flag: wp.array[wp.int32],
    built_fk_actuated: wp.array[wp.int32],
    # Outputs
    violations: wp.array[wp.int32],
):
    """Find invalid overrides and changes to the set of joints actuated for FK.

    ``built_fk_actuated`` is indexed by model joint: 0 is passive, 1 is
    actuated, and -1 skips validation for a joint replaced by FK.
    """
    joint = wp.tid()
    flag = wp.int32(-1)
    if model_fk_act_flag:
        flag = model_fk_act_flag[joint]
        if flag < -1 or flag > 1:
            wp.atomic_min(violations, 1, joint)
            return

    built_actuated = built_fk_actuated[joint]
    if built_actuated < 0:
        return

    act_type = _resolve_fk_actuation_type(model_act_type[joint], flag)
    if (act_type != JointActuationType.PASSIVE) != (built_actuated != 0):
        wp.atomic_min(violations, 0, joint)


@wp.kernel
def _compute_fk_joint_frames(
    # Inputs
    source_joint: wp.array[wp.int32],
    model_B_r_Bj: wp.array[wp.vec3f],
    model_F_r_Fj: wp.array[wp.vec3f],
    model_X_Bj: wp.array[wp.mat33f],
    model_X_Fj: wp.array[wp.mat33f],
    # Outputs
    fk_B_r_Bj: wp.array[wp.vec3f],
    fk_F_r_Fj: wp.array[wp.vec3f],
    fk_X_Bj: wp.array[wp.mat33f],
    fk_X_Fj: wp.array[wp.mat33f],
):
    """Compute FK joint frames from the current model data."""
    fk_joint = wp.tid()
    model_joint = source_joint[fk_joint]
    if model_joint >= 0:
        # Preserve frames for joints copied from the model.
        fk_B_r_Bj[fk_joint] = model_B_r_Bj[model_joint]
        fk_F_r_Fj[fk_joint] = model_F_r_Fj[model_joint]
        fk_X_Bj[fk_joint] = model_X_Bj[model_joint]
        fk_X_Fj[fk_joint] = model_X_Fj[model_joint]
    else:
        # FK-added base and axis joints start at identity; axis orientations are
        # overwritten by _compute_fk_axis_joint_frames.
        fk_B_r_Bj[fk_joint] = wp.vec3f(0.0)
        fk_F_r_Fj[fk_joint] = wp.vec3f(0.0)
        fk_X_Bj[fk_joint] = wp.identity(n=3, dtype=wp.float32)
        fk_X_Fj[fk_joint] = wp.identity(n=3, dtype=wp.float32)


@wp.kernel
def _compute_fk_axis_joint_frames(
    # Inputs
    axis_fk_joint: wp.array[wp.int32],
    axis_body: wp.array[wp.int32],
    axis_joint_0: wp.array[wp.int32],
    axis_joint_1: wp.array[wp.int32],
    model_joint_bid_B: wp.array[wp.int32],
    model_joint_B_r_Bj: wp.array[wp.vec3f],
    model_joint_F_r_Fj: wp.array[wp.vec3f],
    model_body_q_0: wp.array[wp.transformf],
    # Outputs
    fk_X_Bj: wp.array[wp.mat33f],
    fk_X_Fj: wp.array[wp.mat33f],
):
    """Compute synthetic axis-joint frames from the model data."""
    axis_joint = wp.tid()
    fk_joint = axis_fk_joint[axis_joint]
    body = axis_body[axis_joint]
    joint_0 = axis_joint_0[axis_joint]
    joint_1 = axis_joint_1[axis_joint]
    body_q = model_body_q_0[body]

    # Locate both spherical-joint anchors in the tie-rod body frame.
    local_0 = model_joint_F_r_Fj[joint_0]
    if model_joint_bid_B[joint_0] == body:
        local_0 = model_joint_B_r_Bj[joint_0]
    local_1 = model_joint_F_r_Fj[joint_1]
    if model_joint_bid_B[joint_1] == body:
        local_1 = model_joint_B_r_Bj[joint_1]

    # Evaluate the anchors in the initial pose and align the joint X axis with
    # the line that connects them.
    pos_0 = wp.transform_point(body_q, local_0)
    pos_1 = wp.transform_point(body_q, local_1)
    a_x = wp.normalize(pos_1 - pos_0)
    if wp.abs(a_x[2]) < 0.99:
        a_y = wp.normalize(wp.cross(wp.vec3f(0.0, 0.0, 1.0), a_x))
    else:
        a_y = wp.normalize(wp.cross(wp.vec3f(0.0, 1.0, 0.0), a_x))
    a_z = wp.normalize(wp.cross(a_x, a_y))
    X_Bj = wp.matrix_from_cols(a_x, a_y, a_z)
    fk_X_Bj[fk_joint] = X_Bj
    # Match the follower frame to the base frame in the initial pose.
    fk_X_Fj[fk_joint] = wp.quat_to_matrix(wp.transform_get_rotation(body_q)) * X_Bj


@wp.kernel
def _reset_state(
    # Inputs
    num_bodies: wp.array[wp.int32],
    first_body_id: wp.array[wp.int32],
    bodies_q_0_flat: wp.array[wp.float32],
    world_mask: wp.array[wp.bool],
    # Outputs
    bodies_q_flat: wp.array[wp.float32],
):
    """
    A kernel resetting the fk state (body poses) to the reference state

    Inputs:
        num_bodies: Num bodies per world
        first_body_id: First body id per world
        bodies_q_0_flat: Reference state, flattened
        world_mask: Per-world boolean flag to perform the operation (False = skip)
    Outputs:
        bodies_q_flat: State to reset, flattened
    """
    wd_id, state_id_loc = wp.tid()  # Thread indices (= world index, state index)
    rb_id_loc = state_id_loc // 7
    if wd_id < num_bodies.shape[0] and world_mask[wd_id] and rb_id_loc < num_bodies[wd_id]:
        state_id_tot = 7 * first_body_id[wd_id] + state_id_loc
        bodies_q_flat[state_id_tot] = bodies_q_0_flat[state_id_tot]


@wp.kernel
def _reset_state_base_q(
    # Inputs
    base_joint_id: wp.array[wp.int32],
    base_q: wp.array[wp.transformf],
    joints_bid_F: wp.array[wp.int32],
    joints_X_Bj: wp.array[wp.mat33f],
    joints_X_Fj: wp.array[wp.mat33f],
    joints_B_r_B: wp.array[wp.vec3f],
    joints_F_r_F: wp.array[wp.vec3f],
    num_bodies: wp.array[wp.int32],
    first_body_id: wp.array[wp.int32],
    bodies_q_0: wp.array[wp.transformf],
    world_mask: wp.array[wp.bool],
    # Outputs
    bodies_q: wp.array[wp.transformf],
):
    """
    A kernel resetting the fk state (body poses) to a rigid transformation of the reference state,
    computed so that the base body is aligned on its prescribed pose.

    Inputs:
        base_joint_id: Base joint id per world (-1 = None)
        base_q: Base body pose per world, in base joint coordinates
        joints_bid_F: Joint follower body id
        joints_X_Bj: Joint local frame on base body
        joints_X_Fj: Joint local frame on follower body
        joints_B_r_B: Joint local position on base body
        joints_F_r_F: Joint local position on follower body
        num_bodies: Num bodies per world
        first_body_id: First body id per world
        bodies_q_0: Reference body poses
        world_mask: Per-world boolean flag to perform the operation (False = skip)
    Outputs:
        bodies_q: Body poses to reset
    """
    wd_id, rb_id_loc = wp.tid()  # Thread indices (= world index, body index)
    if wd_id < num_bodies.shape[0] and world_mask[wd_id] and rb_id_loc < num_bodies[wd_id]:
        # Worlds without base joint: just copy the reference pose
        rb_id_tot = first_body_id[wd_id] + rb_id_loc
        base_jt_id = base_joint_id[wd_id]
        body_q_0 = bodies_q_0[rb_id_tot]
        if base_jt_id < 0:
            bodies_q[rb_id_tot] = body_q_0
            return

        # Read memory
        base_q_wd = base_q[wd_id]
        bid_F = joints_bid_F[base_jt_id]
        X_B = joints_X_Bj[base_jt_id]
        X_F = joints_X_Fj[base_jt_id]
        x_B = joints_B_r_B[base_jt_id]
        x_F = joints_F_r_F[base_jt_id]
        body_q_F_0 = bodies_q_0[bid_F]

        # Compute pose of the base body (follower of the base joint) given current joint coordinates
        # Note: the relative transform from base to follower can be written
        # t_jt = X_B^T * R_B^T * (c_F + R_F * x_F - c_B - R_B * x_B)
        # q_jt = X_B^T * R_B^T * R_F * X_F
        # We invert these equations, using R_B = I and c_B = 0 (base body = world)
        t_jt = wp.transform_get_translation(base_q_wd)
        q_jt = wp.transform_get_rotation(base_q_wd)
        q_X_B = wp.quat_from_matrix(X_B)
        q_X_F = wp.quat_from_matrix(X_F)
        q_F = q_X_B * q_jt * wp.quat_inverse(q_X_F)
        c_F = wp.quat_rotate(q_X_B, t_jt) - wp.quat_rotate(q_F, x_F) + x_B
        body_q_F = wp.transformf(c_F, q_F)

        # Compute the transform that was applied to the base body relative to the base pose,
        # and apply that transform to all rigid bodies
        transform_tot = wp.transform_multiply(body_q_F, wp.transform_inverse(body_q_F_0))
        bodies_q[rb_id_tot] = wp.transform_multiply(transform_tot, body_q_0)


@wp.kernel
def _eval_fk_actuated_dofs_or_coords(
    # Inputs
    model_base_dofs: wp.array2d[wp.float32],
    model_actuated_dofs: wp.array2d[wp.float32],
    actuated_dofs_map: wp.array[wp.int32],
    # Outputs
    fk_actuated_dofs: wp.array2d[wp.float32],
):
    """
    A kernel mapping actuated and base dofs/coordinates of the main model to actuated dofs/coordinates of the fk model,
    which has a modified version of the joints, notably actuated free joints to control floating bases.

    This uses a map from fk to model dofs/cords, that has >= 0 indices for fk dofs/coords that correspond to
    main model actuated dofs/coords, and negative indices for base dofs/coords (base dof/coord i is stored as -i - 1)

    Processes a batch of batch_size sets of dofs/coords in parallel.

    Inputs:
        model_base_dofs: Base dofs or coordinates of the main model, with shape (batch_size, num_base_dofs_or_coords).
            Shape (1, num_base_dofs_or_coords) is also supported for uniform base dofs/coords along the batch.
        model_actuated_dofs: Actuated dofs/coords of the main model, with shape (batch_size, num_actuated_dofs_or_coords)
        actuated_dofs_map: Map of fk to main model actuated/base dofs/coords
    Outputs:
        fk_actuated_dofs: Actuated dofs or coordinates of the fk model, with shape (batch_size, num_fk_actuated_dofs_or_coords)
    """

    # Retrieve the thread index (= batch id, fk actuated dof or coordinate index)
    # Note: we use "dof" in variables naming to mean either dof or coordinate
    batch_id, fk_dof_id = wp.tid()

    if batch_id < fk_actuated_dofs.shape[0] and fk_dof_id < fk_actuated_dofs.shape[1]:
        model_dof_id = actuated_dofs_map[fk_dof_id]
        if model_dof_id >= 0:
            fk_actuated_dofs[batch_id, fk_dof_id] = model_actuated_dofs[batch_id, model_dof_id]
        else:  # Base dofs/coordinates are encoded as negative indices
            base_dof_id = -(model_dof_id + 1)  # Recover base dof/coord id
            if model_base_dofs.shape[0] == 1:
                fk_actuated_dofs[batch_id, fk_dof_id] = model_base_dofs[0, base_dof_id]
            else:
                fk_actuated_dofs[batch_id, fk_dof_id] = model_base_dofs[batch_id, base_dof_id]


def _make_typed_joint_transform_to_coords_func(dof_type: JointDoFType):
    """Factory returning a function extracting joint coords from joint transform, for a single joint type."""
    num_coords = dof_type.num_coords

    @wp.func
    def _typed_joint_transform_to_coords(
        pos_rel: wp.vec3f,
        q_rel: wp.quatf,
        offset: wp.int32,
        output: wp.array[wp.float32],
    ):
        coords = wp.static(get_joint_coords_mapping_function(dof_type))(pos_rel, q_rel)
        for i in range(num_coords):
            output[offset + i] = coords[i]

    return _typed_joint_transform_to_coords


@wp.func
def _joint_transform_to_coords(
    dof_type: wp.int32,
    pos_rel: wp.vec3f,
    q_rel: wp.quatf,
    offset: wp.int32,
    output: wp.array[wp.float32],
):
    """Function extracting joint coordinates from the joint transform, and writing them out in an array."""
    if dof_type == FKJointDoFType.CARTESIAN:
        wp.static(_make_typed_joint_transform_to_coords_func(JointDoFType.CARTESIAN))(pos_rel, q_rel, offset, output)
    elif dof_type == FKJointDoFType.CYLINDRICAL:
        wp.static(_make_typed_joint_transform_to_coords_func(JointDoFType.CYLINDRICAL))(pos_rel, q_rel, offset, output)
    elif dof_type == FKJointDoFType.FREE:
        wp.static(_make_typed_joint_transform_to_coords_func(JointDoFType.FREE))(pos_rel, q_rel, offset, output)
    elif dof_type == FKJointDoFType.PRISMATIC:
        wp.static(_make_typed_joint_transform_to_coords_func(JointDoFType.PRISMATIC))(pos_rel, q_rel, offset, output)
    elif dof_type == FKJointDoFType.REVOLUTE:
        wp.static(_make_typed_joint_transform_to_coords_func(JointDoFType.REVOLUTE))(pos_rel, q_rel, offset, output)
    elif dof_type == FKJointDoFType.SPHERICAL:
        wp.static(_make_typed_joint_transform_to_coords_func(JointDoFType.SPHERICAL))(pos_rel, q_rel, offset, output)
    elif dof_type == FKJointDoFType.GIMBAL:
        wp.static(_make_typed_joint_transform_to_coords_func(JointDoFType.GIMBAL))(pos_rel, q_rel, offset, output)
    elif dof_type == FKJointDoFType.GIMBAL_LEFT_HANDED:
        wp.static(_make_typed_joint_transform_to_coords_func(JointDoFType.GIMBAL_LEFT_HANDED))(
            pos_rel, q_rel, offset, output
        )
    elif dof_type == FKJointDoFType.UNIVERSAL:
        wp.static(_make_typed_joint_transform_to_coords_func(JointDoFType.UNIVERSAL))(pos_rel, q_rel, offset, output)


@wp.kernel
def _eval_actuator_coords(
    num_joints: wp.array[wp.int32],
    first_joint_id: wp.array[wp.int32],
    joints_dof_type: wp.array[wp.int32],
    joints_bid_B: wp.array[wp.int32],
    joints_bid_F: wp.array[wp.int32],
    joints_X_Bj: wp.array[wp.mat33f],
    joints_X_Fj: wp.array[wp.mat33f],
    joints_B_r_B: wp.array[wp.vec3f],
    joints_F_r_F: wp.array[wp.vec3f],
    bodies_q: wp.array[wp.transformf],
    actuated_coord_offsets: wp.array[wp.int32],
    actuators_q: wp.array[wp.float32],
):
    """
    A kernel evaluating effective actuator coordinates based on body poses.

    Inputs:
        num_joints: Num joints per world.
        first_joint_id: First joint id per world.
        joints_dof_type: Joint dof type (i.e. revolute, spherical, ...).
        joints_bid_B: Joint base body id.
        joints_bid_F: Joint follower body id.
        joints_X_Bj: Joint local frame on base body
        joints_X_Fj: Joint local frame on follower body
        joints_B_r_B: Joint local position on base body.
        joints_F_r_F: Joint local position on follower body.
        bodies_q: Body poses.
        actuated_coord_offsets: Joint first actuated coordinate id, among all actuated coordinates in all worlds.
    Outputs:
        actuators_q: Actuator coordinates.
    """
    # Retrieve the thread index (= world index, joint index within world)
    wd_id, jt_id_loc = wp.tid()

    # Get global joint index
    if jt_id_loc >= num_joints[wd_id]:
        return
    jt_id = first_joint_id[wd_id] + jt_id_loc

    # Get joint actuated coords size and offset
    coord_id = actuated_coord_offsets[jt_id]
    num_coords = actuated_coord_offsets[jt_id + 1] - coord_id
    if num_coords == 0:
        return

    # Get joint dof type, local positions and local orientation
    dof_type = joints_dof_type[jt_id]
    x_base = joints_B_r_B[jt_id]
    x_follower = joints_F_r_F[jt_id]
    q_X_B = wp.quat_from_matrix(joints_X_Bj[jt_id])
    q_X_F = wp.quat_from_matrix(joints_X_Fj[jt_id])

    # Get base and follower transformations
    base_id = joints_bid_B[jt_id]
    follower_id = joints_bid_F[jt_id]
    c_base, q_base, c_follower, q_follower = _load_joint_poses(base_id, follower_id, bodies_q)

    # Compute relative pose of follower body in joint frame of base body
    pos_base = c_base + wp.quat_rotate(q_base, x_base)
    pos_follower = c_follower + wp.quat_rotate(q_follower, x_follower)
    ori_base_T = wp.quat_inverse(q_base * q_X_B)
    ori_follower = q_follower * q_X_F
    pos_rel = wp.quat_rotate(ori_base_T, pos_follower - pos_base)
    q_rel = ori_base_T * ori_follower

    # Extract joint coordinates from relative pose
    _joint_transform_to_coords(dof_type, pos_rel, q_rel, coord_id, actuators_q)


@wp.kernel
def _correct_actuator_coords(
    # Inputs
    actuated_coord_offsets: wp.array[wp.int32],
    joints_dof_type: wp.array[wp.int32],
    actuators_q_ref: wp.array[wp.float32],
    # Outputs
    actuators_q: wp.array[wp.float32],
):
    """
    A kernel correcting actuator coordinates w.r.t. reference coordinates, ensuring that
    angles are within +/- 2 pi of the reference, and quaternions are closer to the reference
    than to its opposite.

    Inputs:
        actuated_coord_offsets: Joint first actuated coordinate id, among all actuated coordinates in all worlds.
        joints_dof_type: Joint dof type (i.e. revolute, spherical, ...).
        actuators_q_ref: Reference actuator coordinates.
    Outputs:
        actuators_q: Actuator coordinates to correct w.r.t. the reference.
    """
    # Retrieve the thread index (= joint index)
    joint_id = wp.tid()

    # Get joint actuated coords size and offset
    coord_id = actuated_coord_offsets[joint_id]
    num_coords = actuated_coord_offsets[joint_id + 1] - coord_id
    if num_coords == 0:
        return

    # Apply correction based on DoFs
    dof_type = joints_dof_type[joint_id]
    if (
        dof_type == FKJointDoFType.CARTESIAN or dof_type == FKJointDoFType.FIXED or dof_type == FKJointDoFType.PRISMATIC
    ):  # No correction needed
        return
    elif dof_type == FKJointDoFType.CYLINDRICAL:  # Correct angle up to +/- 2 pi
        _correct_rotational_actuator_coord(actuators_q, actuators_q_ref, coord_id + 1)
    elif dof_type == FKJointDoFType.FREE:  # Correct quaternion up to sign
        _correct_quat_actuator_coords(actuators_q, actuators_q_ref, coord_id + 3)
    elif dof_type == FKJointDoFType.REVOLUTE:  # Correct angle up to +/- 2 pi
        _correct_rotational_actuator_coord(actuators_q, actuators_q_ref, coord_id)
    elif dof_type == FKJointDoFType.SPHERICAL:  # Correct quaternion up to sign
        _correct_quat_actuator_coords(actuators_q, actuators_q_ref, coord_id)
    elif dof_type == FKJointDoFType.UNIVERSAL:  # Correct angles up to +/- 2 pi
        _correct_rotational_actuator_coord(actuators_q, actuators_q_ref, coord_id)
        _correct_rotational_actuator_coord(actuators_q, actuators_q_ref, coord_id + 1)
    elif dof_type == FKJointDoFType.GIMBAL or dof_type == FKJointDoFType.GIMBAL_LEFT_HANDED:
        # Correct angles up to +/- 2 pi
        for i in range(3):
            _correct_rotational_actuator_coord(actuators_q, actuators_q_ref, coord_id + i)
    else:
        assert False, "Unexpected actuator dof type"  # noqa: B011


@wp.kernel
def _eval_incremental_target_actuator_coords(
    # Inputs
    world_actuated_coord_offsets: wp.array[wp.int32],
    actuators_q_prev: wp.array[wp.float32],
    actuators_q_next: wp.array[wp.float32],
    delta_q_max: wp.array[wp.float32],
    iteration: wp.array[wp.int32],
    world_mask: wp.array[wp.bool],
    # Outputs
    actuators_q_curr: wp.array[wp.float32],
):
    """
    A kernel evaluating the actuator coordinates to solve for given the Newton iteration
    number and the target actuator coordinates, by interpolating between initial and target
    coordinates if necessary to avoid too large jumps per iteration.

    Inputs:
        world_actuated_coord_offsets: World first actuated coordinate id, among all actuated coordinates in all worlds.
        actuators_q_prev: Previous actuator coordinates.
        actuators_q_next: Next actuator coordinates (= target).
        delta_q_max: Maximal allowed step per coordinate, for one Newton iteration.
        iteration: Current Newton iteration per world.
        world_mask: Per-world boolean flag to perform the computation (False = skip).
    Outputs:
        actuators_q_curr: Actuator coordinates to use as target for the current iteration (= incremental target).
    """
    # Retrieve the thread index (= world index, coordinate index in world)
    wd_id, coord_id_loc = wp.tid()

    # Early return based on world mask
    if not world_mask[wd_id]:
        return

    # Read data
    coord_id = world_actuated_coord_offsets[wd_id] + coord_id_loc
    if coord_id >= world_actuated_coord_offsets[wd_id + 1]:
        return
    q_prev = actuators_q_prev[coord_id]
    q_next = actuators_q_next[coord_id]
    delta = delta_q_max[coord_id]
    it = iteration[wd_id]

    # Interpolate coordinate
    sign = wp.where(q_prev > q_next, -1.0, 1.0)
    actuators_q_curr[coord_id] = sign * wp.min(sign * q_prev + wp.float32(it + 1) * delta, sign * q_next)


@wp.func
def min_iteration_op(v0: wp.float32, v1: wp.float32, d: wp.float32) -> wp.int32:
    """Function returning the floor of the absolute division of (v1 - v0) by d."""
    eps = 1e-7  # Epsilon to ensure that we round down if |v1 - v0| = d
    return wp.int32(wp.floor((wp.abs(v1 - v0) - eps) / d))


@wp.func
def less_than_op(i: wp.int32, threshold: wp.int32) -> wp.int32:
    """Thresholding operation."""
    return wp.where(i < threshold, 1, 0)


@wp.func
def mul_mask_int(mask: wp.int32, value: wp.int32) -> wp.int32:
    """Return value if mask is positive, else 0"""
    return wp.where(mask > 0, value, 0)


@wp.func
def mul_mask_float(mask: wp.int32, value: wp.float32) -> wp.float32:
    """Return value if mask is positive, else 0"""
    return wp.where(mask > 0, value, 0.0)


@cache
def create_eval_min_num_iterations_kernel(TILE_SIZE: int):
    @wp.kernel(module="unique", module_options={"enable_backward": False, "default_grid_stride": False})
    def _eval_min_num_iterations(
        # Inputs
        world_actuated_coord_offsets: wp.array[wp.int32],
        actuators_q_prev: wp.array[wp.float32],
        actuators_q_next: wp.array[wp.float32],
        delta_q_max: wp.array[wp.float32],
        # Outputs
        min_iterations: wp.array[wp.int32],
    ):
        """
        A kernel evaluating the minimal number of Newton iterations needed per world, for incremental steps
        in actuator coordinates to have converged to the target coordinates.

        Inputs:
            world_actuated_coord_offsets: World first actuated coordinate id, among all actuated coordinates in all worlds.
            actuators_q_prev: Previous actuator coordinates.
            actuators_q_next: Next actuator coordinates (= target).
            delta_q_max: Maximal allowed step per coordinate, for one Newton iteration.
        Outputs:
            min_iterations: Minimum iterations needed per world.
        """
        # Retrieve the thread index (= world index, input tile index, thread index in block)
        wd_id, i, tid = wp.tid()

        # Read data
        world_offset = world_actuated_coord_offsets[wd_id]
        next_world_offset = world_actuated_coord_offsets[wd_id + 1]
        offset = world_offset + i * TILE_SIZE
        if offset >= next_world_offset:
            return  # Early return if tile is fully outside of the world's data
        q_prev = wp.tile_load(actuators_q_prev, shape=TILE_SIZE, offset=offset)
        q_next = wp.tile_load(actuators_q_next, shape=TILE_SIZE, offset=offset)
        delta = wp.tile_load(delta_q_max, shape=TILE_SIZE, offset=offset)

        # Compute min iterations count per coordinate, and take the maximum per world
        min_it = wp.tile_map(min_iteration_op, q_prev, q_next, delta)
        if offset + TILE_SIZE > next_world_offset:  # Mask out values from next world if needed
            mask = wp.tile_map(less_than_op, wp.tile_arange(TILE_SIZE, dtype=wp.int32), next_world_offset - offset)
            min_it = wp.tile_map(mul_mask_int, mask, min_it)
        min_it_max = wp.tile_max(min_it)[0]
        if tid == 0:
            wp.atomic_max(min_iterations, wd_id, min_it_max)

    return _eval_min_num_iterations


@wp.kernel
def _initialize_jacobian_update_masks(
    # Inputs
    newton_mask: wp.array[wp.bool],
    min_iterations: wp.array[wp.int32],
    # Outputs
    jacobian_early_update_mask: wp.array[wp.bool],
    jacobian_late_update_mask: wp.array[wp.bool],
):
    """
    Kernel initializing the early/late Jacobian update masks for the first iteration, depending
    on the minimum iterations per world (and therefore, of whether an incremental control update
    will happen in the first iteration).

    Inputs:
        newton_mask: Flag indicating whether Gauss-Newton is still running per world.
        min_iterations: Minimal number of Newton iterations per world.
    Outputs:
        jacobian_early_update_mask: Flag set to True in worlds needing an early Jacobian update.
        jacobian_late_update_mask: Flag set to True in worlds needing a late Jacobian update.

    """
    wd_id = wp.tid()  # Get thread id (= world index)

    newton_flag = newton_mask[wd_id]
    min_it = min_iterations[wd_id]
    jacobian_early_update_mask[wd_id] = newton_flag and min_it == 0
    jacobian_late_update_mask[wd_id] = newton_flag and min_it > 0


@wp.kernel
def _eval_target_relative_transformations(
    # Inputs
    joints_dof_type: wp.array[wp.int32],
    joints_act_type: wp.array[wp.int32],
    actuated_coords_offset: wp.array[wp.int32],
    joints_X_Bj: wp.array[wp.mat33f],
    joints_X_Fj: wp.array[wp.mat33f],
    actuators_q: wp.array[wp.float32],
    normalize_quaternions: wp.bool,
    joints_world_id: wp.array[wp.int32],
    world_mask: wp.array[wp.bool],
    # Outputs
    target_rel_transforms: wp.array[wp.transformf],
):
    """
    A kernel computing a target relative transformation per joint, from the joint frame on the base body
    to the joint frame on the follower body.

    This integrates the transformation imposed by actuator coordinates, and a fixed offset for joints with
    non-aligned base/follower frames, so that constraints and their derivatives may be evaluated by other
    kernels assuming a single local frame X_j = X_Bj = X_Fj.

    The translation part is expressed in joint frame (e.g., translation is along [1,0,0] for a prismatic joint)
    The rotation part is expressed in body frame (e.g., rotation is about X[:,0] for a revolute joint)

    Inputs:
        joints_dof_type: Joint dof type (i.e. revolute, spherical, ...)
        joints_act_type: Joint actuation type (i.e. passive or actuated)
        actuated_coords_offset: Joint first actuated coordinate id, among all actuated coordinates in all worlds
        joints_X_Bj: Joint local frame on base body
        joints_X_Fj: Joint local frame on follower body
        actuators_q: Actuated coordinates
        normalize_quaternions: Whether to normalize quaternions in actuators_q (else unit length is assumed)
        joints_world_id: World index per joint
        world_mask: Per-world boolean flag to perform the computation (False = skip)
    Outputs:
        target_rel_transforms: Joint target relative transformation
    """

    # Retrieve the thread index (= joint index)
    jt_id = wp.tid()

    # Early return based on world mask
    wid = joints_world_id[jt_id]
    if not world_mask[wid]:
        return

    if jt_id < joints_dof_type.shape[0]:
        # Retrieve the joint model data
        dof_type_j = joints_dof_type[jt_id]
        act_type_j = joints_act_type[jt_id]
        X_B = joints_X_Bj[jt_id]
        X_F = joints_X_Fj[jt_id]

        # Initialize transform to identity (already covers the passive case)
        t = wp.vec3f(0.0, 0.0, 0.0)
        q = wp.quatf(0.0, 0.0, 0.0, 1.0)

        # In the actuated case, set translation/rotation as per joint generalized coordinates
        if act_type_j != JointActuationType.PASSIVE:
            offset_q_j = actuated_coords_offset[jt_id]
            if dof_type_j == FKJointDoFType.CARTESIAN:
                t[0] = actuators_q[offset_q_j]
                t[1] = actuators_q[offset_q_j + 1]
                t[2] = actuators_q[offset_q_j + 2]
            elif dof_type_j == FKJointDoFType.CYLINDRICAL:
                t[0] = actuators_q[offset_q_j]
                q = wp.quat_from_axis_angle(X_B[:, 0], actuators_q[offset_q_j + 1])
            elif dof_type_j == FKJointDoFType.FIXED:
                pass  # No dofs to apply
            elif dof_type_j == FKJointDoFType.FREE:
                t[0] = actuators_q[offset_q_j]
                t[1] = actuators_q[offset_q_j + 1]
                t[2] = actuators_q[offset_q_j + 2]
                q_X_B = wp.quat_from_matrix(X_B)
                q_loc = read_quat_from_array(actuators_q, offset_q_j + 3, normalize_quaternions)
                q = q_X_B * q_loc * wp.quat_inverse(q_X_B)
            elif dof_type_j == FKJointDoFType.PRISMATIC:
                t[0] = actuators_q[offset_q_j]
            elif dof_type_j == FKJointDoFType.REVOLUTE:
                q = wp.quat_from_axis_angle(wp.vec3f(X_B[:, 0]), actuators_q[offset_q_j])
            elif dof_type_j == FKJointDoFType.SPHERICAL:
                q_X_B = wp.quat_from_matrix(X_B)
                q_loc = read_quat_from_array(actuators_q, offset_q_j, normalize_quaternions)
                q = q_X_B * q_loc * wp.quat_inverse(q_X_B)
            elif dof_type_j == FKJointDoFType.GIMBAL or dof_type_j == FKJointDoFType.GIMBAL_LEFT_HANDED:
                third_axis_sign = 1.0
                if dof_type_j == FKJointDoFType.GIMBAL_LEFT_HANDED:
                    third_axis_sign = -1.0
                axes = X_B @ gimbal_transported_axes(
                    wp.vec3f(actuators_q[offset_q_j], actuators_q[offset_q_j + 1], actuators_q[offset_q_j + 2]),
                    third_axis_sign,
                )
                q_0 = wp.quat_from_axis_angle(wp.vec3f(axes[:, 0]), actuators_q[offset_q_j])
                q_1 = wp.quat_from_axis_angle(wp.vec3f(axes[:, 1]), actuators_q[offset_q_j + 1])
                q_2 = wp.quat_from_axis_angle(wp.vec3f(axes[:, 2]), actuators_q[offset_q_j + 2])
                q = q_2 * q_1 * q_0
            elif dof_type_j == FKJointDoFType.UNIVERSAL:
                q_x = wp.quat_from_axis_angle(wp.vec3f(X_B[:, 0]), actuators_q[offset_q_j])
                q_y = wp.quat_from_axis_angle(wp.vec3f(X_B[:, 1]), actuators_q[offset_q_j + 1])
                q = q_x * q_y
            else:
                assert False, "Unexpected actuator dof type"  # noqa: B011

        # If X_B != X_F, absorb the offset in q_rel so downstream kernels can keep using ``q_F = q_B * q_rel``
        any_diff = wp.bool(False)
        for r in range(3):
            for c in range(3):
                if X_B[r, c] != X_F[r, c]:
                    any_diff = wp.bool(True)
        if any_diff:
            q = q * wp.quat_from_matrix(X_B) * wp.quat_inverse(wp.quat_from_matrix(X_F))

        # Write out transformation
        target_rel_transforms[jt_id] = wp.transformf(t, q)


@wp.kernel
def _eval_unit_quaternion_constraints(
    # Inputs
    num_bodies: wp.array[wp.int32],
    first_body_id: wp.array[wp.int32],
    bodies_q: wp.array[wp.transformf],
    world_mask: wp.array[wp.bool],
    # Outputs
    constraints: wp.array2d[wp.float32],
):
    """
        A kernel computing unit norm quaternion constraints for each body, written at the top of the constraints vector

        Inputs:
            num_bodies: Num bodies per world
            first_body_id: First body id per world
            bodies_q: Body poses
            world_mask: Per-world boolean flag to perform the computation (False = skip)
        Outputs:
            constraints: Constraint vector per world
    ):
    """

    # Retrieve the thread indices (= world index, body index)
    wd_id, rb_id_loc = wp.tid()

    if wd_id < num_bodies.shape[0] and world_mask[wd_id] and rb_id_loc < num_bodies[wd_id]:
        # Get overall body id
        rb_id_tot = first_body_id[wd_id] + rb_id_loc

        # Evaluate unit quaternion constraint
        q = wp.transform_get_rotation(bodies_q[rb_id_tot])
        constraints[wd_id, rb_id_loc] = wp.dot(q, q) - 1.0


@cache
def create_eval_joint_constraints_kernel(has_universal_joints: bool):
    """
    Returns the joint constraints evaluation kernel, statically baking in whether there are universal joints
    or not (these joints need a separate handling)
    """

    @wp.kernel
    def _eval_joint_constraints(
        # Inputs
        num_joints: wp.array[wp.int32],
        first_joint_id: wp.array[wp.int32],
        joints_dof_type: wp.array[wp.int32],
        joints_act_type: wp.array[wp.int32],
        joints_bid_B: wp.array[wp.int32],
        joints_bid_F: wp.array[wp.int32],
        joints_X_Bj: wp.array[wp.mat33f],
        joints_X_Fj: wp.array[wp.mat33f],
        joints_B_r_B: wp.array[wp.vec3f],
        joints_F_r_F: wp.array[wp.vec3f],
        bodies_q: wp.array[wp.transformf],
        target_rel_transforms: wp.array[wp.transformf],
        ct_full_to_red_map: wp.array[wp.int32],
        world_mask: wp.array[wp.bool],
        # Outputs
        constraints: wp.array2d[wp.float32],
    ):
        """
        A kernel computing joint constraints with the log map formulation, first computing 6 constraints per
        joint (treating it as a fixed joint), then writing out the relevant subset of constraints (only along
        relevant directions) using a precomputed full to reduced map.

        Note: the log map formulation doesn't allow to formulate passive universal joints. If such joints are
        present, the right number of (incorrect) constraints is first written with the log map, then the result
        is overwritten in a second pass with the correct constraints.

        Inputs:
            num_joints: Num joints per world
            first_joint_id: First joint id per world
            joints_dof_type: Joint dof type (i.e. revolute, spherical, ...)
            joints_act_type: Joint actuation type (i.e. passive or actuated)
            joints_bid_B: Joint base body id
            joints_bid_F: Joint follower body id
            joints_X_Bj: Joint local frame on base body
            joints_X_Fj: Joint local frame on follower body
            joints_B_r_B: Joint local position on base body
            joints_F_r_F: Joint local position on follower body
            bodies_q: Body poses
            target_rel_transforms: Joint target relative transformation
            ct_full_to_red_map: Map from full to reduced constraint id
            world_mask: Per-world boolean flag to perform the computation (False = skip)
        Outputs:
            constraints: Constraint vector per world
        """

        # Retrieve the thread indices (= world index, joint index)
        wd_id, jt_id_loc = wp.tid()

        if wd_id < num_joints.shape[0] and world_mask[wd_id] and jt_id_loc < num_joints[wd_id]:
            # Get overall joint id
            jt_id_tot = first_joint_id[wd_id] + jt_id_loc

            # Get reduced constraint ids (-1 meaning constraint is not used)
            trans_ct_ids_red, rot_ct_ids_red = _get_reduced_constraint_ids(jt_id_tot, ct_full_to_red_map)

            # Get joint local positions and orientation
            x_base = joints_B_r_B[jt_id_tot]
            x_follower = joints_F_r_F[jt_id_tot]
            X_T = wp.transpose(joints_X_Bj[jt_id_tot])

            # Get base and follower transformations
            base_id = joints_bid_B[jt_id_tot]
            follower_id = joints_bid_F[jt_id_tot]
            c_base, q_base, c_follower, q_follower = _load_joint_poses(base_id, follower_id, bodies_q)

            # Get target relative transformation, in joint/body frame for translation/rotation part
            t_rel_joint = wp.transform_get_translation(target_rel_transforms[jt_id_tot])
            q_rel_body = wp.transform_get_rotation(target_rel_transforms[jt_id_tot])

            # Translation constraints: compute "error" translation, in joint frame
            pos_follower_world = unit_quat_apply(q_follower, x_follower) + c_follower
            pos_follower_base = unit_quat_conj_apply(q_base, pos_follower_world - c_base)
            pos_rel_base = (
                pos_follower_base - x_base
            )  # Relative position on base body (should match translation from controls)
            t_error = X_T * pos_rel_base - t_rel_joint  # Error in joint frame

            # Rotation constraints: compute "error" rotation with the log map, in joint frame
            q_error_base = wp.quat_inverse(q_base) * q_follower * wp.quat_inverse(q_rel_body)
            rot_error = X_T * quat_log(q_error_base)

            # Write out constraint
            for i in range(3):
                if trans_ct_ids_red[i] >= 0:
                    constraints[wd_id, trans_ct_ids_red[i]] = t_error[i]
                if rot_ct_ids_red[i] >= 0:
                    constraints[wd_id, rot_ct_ids_red[i]] = rot_error[i]

            # Correct constraints for passive universal joints
            if wp.static(has_universal_joints):
                # Check for a passive universal joint
                dof_type_j = joints_dof_type[jt_id_tot]
                act_type_j = joints_act_type[jt_id_tot]
                if dof_type_j != FKJointDoFType.UNIVERSAL or act_type_j != JointActuationType.PASSIVE:
                    return

                # Compute constraint (dot product between x axis on base and y axis on follower)
                a_x = X_T[0]
                a_y = wp.transpose(joints_X_Fj[jt_id_tot])[1]
                a_x_base = unit_quat_apply(q_base, a_x)
                a_y_follower = unit_quat_apply(q_follower, a_y)
                ct = -wp.dot(a_x_base, a_y_follower)

                # Set constraint in output (at a location corresponding to z rotational constraint)
                constraints[wd_id, rot_ct_ids_red[2]] = ct

    return _eval_joint_constraints


@wp.kernel
def _eval_unit_quaternion_constraints_jacobian(
    # Inputs
    num_bodies: wp.array[wp.int32],
    first_body_id: wp.array[wp.int32],
    bodies_q: wp.array[wp.transformf],
    world_mask: wp.array[wp.bool],
    # Outputs
    constraints_jacobian: wp.array3d[wp.float32],
):
    """
    A kernel computing the Jacobian of unit norm quaternion constraints for each body, written at the top of the
    constraints Jacobian

    Inputs:
        num_bodies: Num bodies per world
        first_body_id: First body id per world
        bodies_q: Body poses
        world_mask: Per-world boolean flag to perform the computation (False = skip)
    Outputs:
        constraints_jacobian: Constraints Jacobian per world
    """

    # Retrieve the thread indices (= world index, body index)
    wd_id, rb_id_loc = wp.tid()

    if wd_id < num_bodies.shape[0] and world_mask[wd_id] and rb_id_loc < num_bodies[wd_id]:
        # Get overall body id
        rb_id_tot = first_body_id[wd_id] + rb_id_loc

        # Evaluate constraint Jacobian
        q = wp.transform_get_rotation(bodies_q[rb_id_tot])
        state_offset = 7 * rb_id_loc + 3
        constraints_jacobian[wd_id, rb_id_loc, state_offset] = 2.0 * q.x
        constraints_jacobian[wd_id, rb_id_loc, state_offset + 1] = 2.0 * q.y
        constraints_jacobian[wd_id, rb_id_loc, state_offset + 2] = 2.0 * q.z
        constraints_jacobian[wd_id, rb_id_loc, state_offset + 3] = 2.0 * q.w


@wp.kernel
def _eval_unit_quaternion_constraints_sparse_jacobian(
    # Inputs
    num_bodies: wp.array[wp.int32],
    first_body_id: wp.array[wp.int32],
    bodies_q: wp.array[wp.transformf],
    rb_nzb_id: wp.array[wp.int32],
    world_mask: wp.array[wp.bool],
    # Outputs
    jacobian_nzb: wp.array[block_type],
):
    """
    A kernel computing the sparse Jacobian of unit norm quaternion constraints for each body, written at the top of the
    constraints Jacobian

    Inputs:
        num_bodies: Num bodies per world
        first_body_id: First body id per world
        bodies_q: Body poses
        rb_nzb_id: Id of the nzb corresponding to the constraint per body
        world_mask: Per-world boolean flag to perform the computation (False = skip)
    Outputs:
        jacobian_nzb: Non-zero blocks of the sparse Jacobian
    """

    # Retrieve the thread indices (= world index, body index)
    wd_id, rb_id_loc = wp.tid()

    if wd_id < num_bodies.shape[0] and world_mask[wd_id] and rb_id_loc < num_bodies[wd_id]:
        # Get overall body id
        rb_id_tot = first_body_id[wd_id] + rb_id_loc

        # Evaluate constraint Jacobian
        q = wp.transform_get_rotation(bodies_q[rb_id_tot])
        nzb_id = rb_nzb_id[rb_id_tot]
        jacobian_nzb[nzb_id][3] = 2.0 * q.x
        jacobian_nzb[nzb_id][4] = 2.0 * q.y
        jacobian_nzb[nzb_id][5] = 2.0 * q.z
        jacobian_nzb[nzb_id][6] = 2.0 * q.w


@cache
def create_eval_joint_constraints_jacobian_kernel(has_universal_joints: bool):
    """
    Returns the joint constraints Jacobian evaluation kernel, statically baking in whether there are universal joints
    or not (these joints need a separate handling)
    """

    @wp.kernel
    def _eval_joint_constraints_jacobian(
        # Inputs
        num_joints: wp.array[wp.int32],
        first_joint_id: wp.array[wp.int32],
        first_body_id: wp.array[wp.int32],
        joints_dof_type: wp.array[wp.int32],
        joints_act_type: wp.array[wp.int32],
        joints_bid_B: wp.array[wp.int32],
        joints_bid_F: wp.array[wp.int32],
        joints_X_Bj: wp.array[wp.mat33f],
        joints_X_Fj: wp.array[wp.mat33f],
        joints_B_r_B: wp.array[wp.vec3f],
        joints_F_r_F: wp.array[wp.vec3f],
        bodies_q: wp.array[wp.transformf],
        target_rel_transforms: wp.array[wp.transformf],
        ct_full_to_red_map: wp.array[wp.int32],
        world_mask: wp.array[wp.bool],
        # Outputs
        constraints_jacobian: wp.array3d[wp.float32],
    ):
        """
        A kernel computing the Jacobian of the joint constraints.
        The Jacobian is assumed to have already been filled with zeros, at least in the coefficients that
        are always zero due to joint connectivity.

        Inputs:
            num_joints: Num joints per world
            first_joint_id: First joint id per world
            first_body_id: First body id per world
            joints_dof_type: Joint dof type (i.e. revolute, spherical, ...)
            joints_act_type: Joint actuation type (i.e. passive or actuated)
            joints_bid_B: Joint base body id
            joints_bid_F: Joint follower body id
            joints_X_Bj: Joint local frame on base body
            joints_X_Fj: Joint local frame on follower body
            joints_B_r_B: Joint local position on base body
            joints_F_r_F: Joint local position on follower body
            bodies_q: Body poses
            target_rel_transforms: Joint target relative transformation
            ct_full_to_red_map: Map from full to reduced constraint id
            world_mask: Per-world boolean flag to perform the computation (False = skip)
        Outputs:
            constraints_jacobian: Constraint Jacobian per world
        """

        # Retrieve the thread indices (= world index, joint index)
        wd_id, jt_id_loc = wp.tid()

        if wd_id < num_joints.shape[0] and world_mask[wd_id] and jt_id_loc < num_joints[wd_id]:
            # Get overall joint id
            jt_id_tot = first_joint_id[wd_id] + jt_id_loc

            # Get reduced constraint ids (-1 meaning constraint is not used)
            trans_ct_ids_red, rot_ct_ids_red = _get_reduced_constraint_ids(jt_id_tot, ct_full_to_red_map)

            # Get joint local positions and orientation
            x_follower = joints_F_r_F[jt_id_tot]
            X_T = wp.transpose(joints_X_Bj[jt_id_tot])

            # Get base and follower transformations
            base_id_tot = joints_bid_B[jt_id_tot]
            follower_id_tot = joints_bid_F[jt_id_tot]
            c_base, q_base, c_follower, q_follower = _load_joint_poses(base_id_tot, follower_id_tot, bodies_q)
            base_id_loc = base_id_tot - first_body_id[wd_id]
            follower_id_loc = follower_id_tot - first_body_id[wd_id]

            # Get target relative transformation (rotation part only, as translation part doesn't affect the Jacobian)
            q_rel_body = wp.transform_get_rotation(target_rel_transforms[jt_id_tot])

            # Translation constraints
            jac_trans_c_base, jac_trans_q_base, jac_trans_c_follower, jac_trans_q_follower = (
                _eval_translation_jacobian_blocks(
                    X_T, q_base, q_follower, x_follower, c_base, c_follower, base_id_tot >= 0
                )
            )
            # Rotation constraints
            jac_rot_q_base, jac_rot_q_follower = _eval_rotation_jacobian_blocks(
                X_T, q_base, q_follower, q_rel_body, base_id_tot >= 0
            )
            # Note: we need X^T * R_base^T both for translation and rotation constraints, but to get the correct
            # derivatives for non-unit quaternions (which may be encountered before convergence) we end up needing
            # to use a separate formula to evaluate R_base in either case

            # Write out Jacobian
            base_offset = 7 * base_id_loc
            follower_offset = 7 * follower_id_loc
            for i in range(3):
                trans_ct_id_red = trans_ct_ids_red[i]
                if trans_ct_id_red >= 0:
                    for j in range(3):
                        if base_id_tot >= 0:
                            constraints_jacobian[wd_id, trans_ct_id_red, base_offset + j] = jac_trans_c_base[i, j]
                        constraints_jacobian[wd_id, trans_ct_id_red, follower_offset + j] = jac_trans_c_follower[i, j]
                    for j in range(4):
                        if base_id_tot >= 0:
                            constraints_jacobian[wd_id, trans_ct_id_red, base_offset + 3 + j] = jac_trans_q_base[i, j]
                        constraints_jacobian[wd_id, trans_ct_id_red, follower_offset + 3 + j] = jac_trans_q_follower[
                            i, j
                        ]
                rot_ct_id_red = rot_ct_ids_red[i]
                if rot_ct_id_red >= 0:
                    for j in range(4):
                        if base_id_tot >= 0:
                            constraints_jacobian[wd_id, rot_ct_id_red, base_offset + 3 + j] = jac_rot_q_base[i, j]
                        constraints_jacobian[wd_id, rot_ct_id_red, follower_offset + 3 + j] = jac_rot_q_follower[i, j]

            # Correct Jacobian for passive universal joints
            if wp.static(has_universal_joints):
                # Check for a passive universal joint
                dof_type_j = joints_dof_type[jt_id_tot]
                act_type_j = joints_act_type[jt_id_tot]
                if dof_type_j != FKJointDoFType.UNIVERSAL or act_type_j != JointActuationType.PASSIVE:
                    return

                # Compute constraint Jacobian (cross product between x axis on base and y axis on follower)
                jac_q_base, jac_q_follower = _eval_passive_universal_jacobian_blocks(
                    X_T, wp.transpose(joints_X_Fj[jt_id_tot]), q_base, q_follower, base_id_tot >= 0
                )

                # Write out Jacobian
                for i in range(4):
                    rot_ct_id_red = rot_ct_ids_red[2]
                    if base_id_tot >= 0:
                        constraints_jacobian[wd_id, rot_ct_id_red, base_offset + 3 + i] = jac_q_base[i]
                    constraints_jacobian[wd_id, rot_ct_id_red, follower_offset + 3 + i] = jac_q_follower[i]

    return _eval_joint_constraints_jacobian


@cache
def create_eval_joint_constraints_sparse_jacobian_kernel(has_universal_joints: bool):
    """
    Returns the joint constraints sparse Jacobian evaluation kernel,
    statically baking in whether there are universal joints or not
    (these joints need a separate handling)
    """

    @wp.kernel
    def _eval_joint_constraints_sparse_jacobian(
        # Inputs
        num_joints: wp.array[wp.int32],
        first_joint_id: wp.array[wp.int32],
        first_body_id: wp.array[wp.int32],
        joints_dof_type: wp.array[wp.int32],
        joints_act_type: wp.array[wp.int32],
        joints_bid_B: wp.array[wp.int32],
        joints_bid_F: wp.array[wp.int32],
        joints_X_Bj: wp.array[wp.mat33f],
        joints_X_Fj: wp.array[wp.mat33f],
        joints_B_r_B: wp.array[wp.vec3f],
        joints_F_r_F: wp.array[wp.vec3f],
        bodies_q: wp.array[wp.transformf],
        target_rel_transforms: wp.array[wp.transformf],
        ct_nzb_id_base: wp.array[wp.int32],
        ct_nzb_id_follower: wp.array[wp.int32],
        world_mask: wp.array[wp.bool],
        # Outputs
        jacobian_nzb: wp.array[block_type],
    ):
        """
        A kernel computing the Jacobian of the joint constraints.
        The Jacobian is assumed to have already been filled with zeros, at least in the coefficients that
        are always zero due to joint connectivity.

        Inputs:
            num_joints: Num joints per world
            first_joint_id: First joint id per world
            first_body_id: First body id per world
            joints_dof_type: Joint dof type (i.e. revolute, spherical, ...)
            joints_act_type: Joint actuation type (i.e. passive or actuated)
            joints_bid_B: Joint base body id
            joints_bid_F: Joint follower body id
            joints_X_Bj: Joint local frame on base body
            joints_X_Fj: Joint local frame on follower body
            joints_B_r_B: Joint local position on base body
            joints_F_r_F: Joint local position on follower body
            bodies_q: Body poses
            target_rel_transforms: Joint target relative transformation
            ct_nzb_id_base: Map from full constraint id to nzb id, for the base body blocks
            ct_nzb_id_base: Map from full constraint id to nzb id, for the follower body blocks
            world_mask: Per-world boolean flag to perform the computation (False = skip)
        Outputs:
            jacobian_nzb: Non-zero blocks of the sparse Jacobian
        """

        # Retrieve the thread indices (= world index, joint index)
        wd_id, jt_id_loc = wp.tid()

        if wd_id < num_joints.shape[0] and world_mask[wd_id] and jt_id_loc < num_joints[wd_id]:
            # Get overall joint id
            jt_id_tot = first_joint_id[wd_id] + jt_id_loc

            # Get nzb ids (-1 meaning constraint is not used)
            start = 6 * jt_id_tot
            end = start + 6
            nzb_ids_base = ct_nzb_id_base[start:end]
            nzb_ids_follower = ct_nzb_id_follower[start:end]

            # Get joint local positions and orientation
            x_follower = joints_F_r_F[jt_id_tot]
            X_T = wp.transpose(joints_X_Bj[jt_id_tot])

            # Get base and follower transformations
            base_id = joints_bid_B[jt_id_tot]
            follower_id = joints_bid_F[jt_id_tot]
            c_base, q_base, c_follower, q_follower = _load_joint_poses(base_id, follower_id, bodies_q)

            # Get target relative transformation (rotation part only, as translation part doesn't affect the Jacobian)
            q_rel_body = wp.transform_get_rotation(target_rel_transforms[jt_id_tot])

            # Translation constraints
            jac_trans_c_base, jac_trans_q_base, jac_trans_c_follower, jac_trans_q_follower = (
                _eval_translation_jacobian_blocks(X_T, q_base, q_follower, x_follower, c_base, c_follower, base_id >= 0)
            )
            # Rotation constraints
            jac_rot_q_base, jac_rot_q_follower = _eval_rotation_jacobian_blocks(
                X_T, q_base, q_follower, q_rel_body, base_id >= 0
            )
            # Note: we need X^T * R_base^T both for translation and rotation constraints, but to get the correct
            # derivatives for non-unit quaternions (which may be encountered before convergence) we end up needing
            # to use a separate formula to evaluate R_base in either case

            # Write out Jacobian
            if base_id >= 0:
                for i in range(3):
                    nzb_id = nzb_ids_base[i]
                    if nzb_id >= 0:
                        for j in range(3):
                            jacobian_nzb[nzb_id][j] = jac_trans_c_base[i, j]
                        for j in range(4):
                            jacobian_nzb[nzb_id][3 + j] = jac_trans_q_base[i, j]
                for i in range(3):
                    nzb_id = nzb_ids_base[i + 3]
                    if nzb_id >= 0:
                        for j in range(4):
                            jacobian_nzb[nzb_id][3 + j] = jac_rot_q_base[i, j]
            for i in range(3):
                nzb_id = nzb_ids_follower[i]
                if nzb_id >= 0:
                    for j in range(3):
                        jacobian_nzb[nzb_id][j] = jac_trans_c_follower[i, j]
                    for j in range(4):
                        jacobian_nzb[nzb_id][3 + j] = jac_trans_q_follower[i, j]
            for i in range(3):
                nzb_id = nzb_ids_follower[i + 3]
                if nzb_id >= 0:
                    for j in range(4):
                        jacobian_nzb[nzb_id][3 + j] = jac_rot_q_follower[i, j]

            # Correct Jacobian for passive universal joints
            if wp.static(has_universal_joints):
                # Check for a passive universal joint
                dof_type_j = joints_dof_type[jt_id_tot]
                act_type_j = joints_act_type[jt_id_tot]
                if dof_type_j != FKJointDoFType.UNIVERSAL or act_type_j != JointActuationType.PASSIVE:
                    return

                # Compute constraint Jacobian (cross product between x axis on base and y axis on follower)
                jac_q_base, jac_q_follower = _eval_passive_universal_jacobian_blocks(
                    X_T, wp.transpose(joints_X_Fj[jt_id_tot]), q_base, q_follower, base_id >= 0
                )

                # Write out Jacobian
                if base_id >= 0:
                    nzb_id = nzb_ids_base[5]
                    for j in range(4):
                        jacobian_nzb[nzb_id][3 + j] = jac_q_base[j]
                nzb_id = nzb_ids_follower[5]
                for j in range(4):
                    jacobian_nzb[nzb_id][3 + j] = jac_q_follower[j]

    return _eval_joint_constraints_sparse_jacobian


@cache
def create_2d_tile_based_kernels(TILE_SIZE_CTS: wp.int32, TILE_SIZE_VRS: wp.int32):
    """
    Generates and returns all kernels based on 2d tiles in this module, given the tile size to use along the constraints
    and variables (i.e. body poses) dimensions in the constraint vector, Jacobian, step vector etc.

    These are _eval_pattern_T_pattern, _eval_jacobian_T_jacobian, eval_jacobian_T_constraints
    (returned in this order)
    """

    # Create separate warp module for compiling kernels in this factory
    module = wp.get_module(__name__ + "_tile_2d")
    module.options.update({"enable_backward": False, "default_grid_stride": False})

    @wp.func
    def clip_to_one(x: wp.float32):
        """
        Clips an number to 1 if it is above
        """
        return wp.min(x, 1.0)

    @wp.kernel(module=module)
    def _eval_pattern_T_pattern(
        # Inputs
        sparsity_pattern: wp.array3d[wp.float32],
        # Outputs
        pattern_T_pattern: wp.array3d[wp.float32],
    ):
        """
        A kernel computing the sparsity pattern of J^T * J given that of J, in each world
        More specifically, given an integer matrix of zeros and ones representing a sparsity pattern, multiply it by
        its transpose and clip values to [0, 1] to get the sparsity pattern of J^T * J
        Note: mostly redundant with _eval_jacobian_T_jacobian apart from the clipping, could possibly be removed
        (was initially written to take wp.int32, but wp.float32 is actually faster)

        Inputs:
            sparsity_pattern: Jacobian sparsity pattern per world
        Outputs:
            pattern_T_pattern: Jacobian^T * Jacobian sparsity pattern per world
        """
        wd_id, i, j = wp.tid()  # Thread indices (= world index, output tile indices)

        if (
            wd_id < pattern_T_pattern.shape[0]
            and i * TILE_SIZE_VRS < pattern_T_pattern.shape[1]
            and j * TILE_SIZE_VRS < pattern_T_pattern.shape[2]
        ):
            tile_out = wp.tile_zeros(shape=(TILE_SIZE_VRS, TILE_SIZE_VRS), dtype=wp.float32)

            num_cts = sparsity_pattern.shape[1]
            num_tiles_K = (num_cts + TILE_SIZE_CTS - 1) // TILE_SIZE_CTS  # Equivalent to ceil(num_cts / TILE_SIZE_CTS)

            for k in range(num_tiles_K):
                tile_i_3d = wp.tile_load(
                    sparsity_pattern,
                    shape=(1, TILE_SIZE_CTS, TILE_SIZE_VRS),
                    offset=(wd_id, k * TILE_SIZE_CTS, i * TILE_SIZE_VRS),
                )
                tile_i = wp.tile_reshape(tile_i_3d, (TILE_SIZE_CTS, TILE_SIZE_VRS))
                tile_i_T = wp.tile_transpose(tile_i)
                tile_j_3d = wp.tile_load(
                    sparsity_pattern,
                    shape=(1, TILE_SIZE_CTS, TILE_SIZE_VRS),
                    offset=(wd_id, k * TILE_SIZE_CTS, j * TILE_SIZE_VRS),
                )
                tile_j = wp.tile_reshape(tile_j_3d, (TILE_SIZE_CTS, TILE_SIZE_VRS))
                wp.tile_matmul(tile_i_T, tile_j, tile_out)

            tile_out_3d = wp.tile_reshape(tile_out, (1, TILE_SIZE_VRS, TILE_SIZE_VRS))
            tile_out_3d_clipped = wp.tile_map(clip_to_one, tile_out_3d)
            wp.tile_store(pattern_T_pattern, tile_out_3d_clipped, offset=(wd_id, i * TILE_SIZE_VRS, j * TILE_SIZE_VRS))

    @wp.kernel(module=module)
    def _eval_jacobian_T_jacobian(
        # Inputs
        constraints_jacobian: wp.array3d[wp.float32],
        tile_sparsity_pattern: wp.array3d[wp.int32],
        world_mask: wp.array[wp.bool],
        # Outputs
        jacobian_T_jacobian: wp.array3d[wp.float32],
    ):
        """
        A kernel computing the matrix product J^T * J given the Jacobian J, in each world

        Inputs:
            constraints_jacobian: Constraint Jacobian per world
            tile_sparsity_pattern: Per-tile sparsity pattern of the Jacobian (0 = tile is fully zero)
            world_mask: Per-world boolean flag to perform the computation (False = skip)
        Outputs:
            jacobian_T_jacobian: Jacobian^T * Jacobian per world
        """
        wd_id, i, j = wp.tid()  # Thread indices (= world index, output tile indices)

        if (
            wd_id < jacobian_T_jacobian.shape[0]
            and world_mask[wd_id]
            and i * TILE_SIZE_VRS < jacobian_T_jacobian.shape[1]
            and j * TILE_SIZE_VRS < jacobian_T_jacobian.shape[2]
        ):
            tile_out = wp.tile_zeros(shape=(TILE_SIZE_VRS, TILE_SIZE_VRS), dtype=wp.float32)

            num_cts = constraints_jacobian.shape[1]
            num_tiles_K = (num_cts + TILE_SIZE_CTS - 1) // TILE_SIZE_CTS  # Equivalent to ceil(num_cts / TILE_SIZE_CTS)

            for k in range(num_tiles_K):
                if tile_sparsity_pattern[wd_id, k, i] == 0 or tile_sparsity_pattern[wd_id, k, j] == 0:
                    continue
                tile_i_3d = wp.tile_load(
                    constraints_jacobian,
                    shape=(1, TILE_SIZE_CTS, TILE_SIZE_VRS),
                    offset=(wd_id, k * TILE_SIZE_CTS, i * TILE_SIZE_VRS),
                )
                tile_i = wp.tile_reshape(tile_i_3d, (TILE_SIZE_CTS, TILE_SIZE_VRS))
                tile_i_T = wp.tile_transpose(tile_i)
                tile_j_3d = wp.tile_load(
                    constraints_jacobian,
                    shape=(1, TILE_SIZE_CTS, TILE_SIZE_VRS),
                    offset=(wd_id, k * TILE_SIZE_CTS, j * TILE_SIZE_VRS),
                )
                tile_j = wp.tile_reshape(tile_j_3d, (TILE_SIZE_CTS, TILE_SIZE_VRS))
                wp.tile_matmul(tile_i_T, tile_j, tile_out)

            tile_out_3d = wp.tile_reshape(tile_out, (1, TILE_SIZE_VRS, TILE_SIZE_VRS))
            wp.tile_store(jacobian_T_jacobian, tile_out_3d, offset=(wd_id, i * TILE_SIZE_VRS, j * TILE_SIZE_VRS))

    @wp.kernel(module=module)
    def _eval_jacobian_T_constraints(
        # Inputs
        constraints_jacobian: wp.array3d[wp.float32],
        constraints: wp.array3d[wp.float32],
        tile_sparsity_pattern: wp.array3d[wp.int32],
        world_mask: wp.array[wp.bool],
        # Outputs
        jacobian_T_constraints: wp.array3d[wp.float32],
    ):
        """
        A kernel computing the matrix product J^T * C given the Jacobian J and the constraints vector C, in each world

        Processes a batch of batch_size vectors C in parallel.

        Inputs:
            constraints_jacobian: Constraint Jacobian per world
            constraints: Constraint vectors, with shape (num_worlds, num_cts_max, batch_size)
            tile_sparsity_pattern: Per-tile sparsity pattern of the Jacobian (0 = tile is fully zero)
            world_mask: Per-world boolean flag to perform the computation (False = skip)
        Outputs:
            jacobian_T_constraints: Jacobian^T * Constraints, with shape (num_worlds, num_states_max, batch_size)
        """
        wd_id, i, batch_id = wp.tid()  # Thread indices (= world index, output tile index, batch index)

        if (
            wd_id < jacobian_T_constraints.shape[0]
            and world_mask[wd_id]
            and i * TILE_SIZE_VRS < jacobian_T_constraints.shape[1]
        ):
            segment_out = wp.tile_zeros(shape=(TILE_SIZE_VRS, 1), dtype=wp.float32)

            num_cts = constraints_jacobian.shape[1]
            num_tiles_K = (num_cts + TILE_SIZE_CTS - 1) // TILE_SIZE_CTS  # Equivalent to ceil(num_cts / TILE_SIZE_CTS)

            for k in range(num_tiles_K):
                if tile_sparsity_pattern[wd_id, k, i] == 0:
                    continue
                tile_i_3d = wp.tile_load(
                    constraints_jacobian,
                    shape=(1, TILE_SIZE_CTS, TILE_SIZE_VRS),
                    offset=(wd_id, k * TILE_SIZE_CTS, i * TILE_SIZE_VRS),
                )
                tile_i = wp.tile_reshape(tile_i_3d, (TILE_SIZE_CTS, TILE_SIZE_VRS))
                tile_i_T = wp.tile_transpose(tile_i)
                segment_k_3d = wp.tile_load(
                    constraints,
                    shape=(1, TILE_SIZE_CTS, 1),
                    offset=(wd_id, k * TILE_SIZE_CTS, batch_id),
                )
                segment_k = wp.tile_reshape(segment_k_3d, (TILE_SIZE_CTS, 1))
                wp.tile_matmul(tile_i_T, segment_k, segment_out)

            segment_out_3d = wp.tile_reshape(
                segment_out,
                (
                    1,
                    TILE_SIZE_VRS,
                    1,
                ),
            )
            wp.tile_store(
                jacobian_T_constraints,
                segment_out_3d,
                offset=(
                    wd_id,
                    i * TILE_SIZE_VRS,
                    batch_id,
                ),
            )

    return _eval_pattern_T_pattern, _eval_jacobian_T_jacobian, _eval_jacobian_T_constraints


@cache
def create_1d_tile_based_kernels(TILE_SIZE_CTS: wp.int32, TILE_SIZE_VRS: wp.int32, use_regularization: bool):
    """
    Generates and returns all kernels based on 1d tiles in this module, given the tile size to use along the constraints
    and variables (i.e. body poses) dimensions in the constraint vector, Jacobian, step vector etc.

    These are _eval_max_residual, _eval_merit_function, _eval_regularizer, _eval_merit_function_gradient
    (returned in this order)
    """

    # Create separate warp module for compiling kernels in this factory
    module = wp.get_module(__name__ + "_tile_1d")
    module.options.update({"enable_backward": False, "default_grid_stride": False})

    @wp.func
    def _isnan(x: wp.float32) -> wp.int32:
        """Calls wp.isnan and converts the result to wp.int32"""
        return wp.int32(wp.isnan(x))

    TILE_SIZE = TILE_SIZE_VRS if use_regularization else TILE_SIZE_CTS

    @wp.kernel(module=module)
    def _eval_max_residual(
        # Inputs
        residual: wp.array2d[wp.float32],
        # Outputs
        max_residual: wp.array[wp.float32],
    ):
        """
        A kernel computing the max absolute residual from the residual vector, in each world.
        This is the constraint vector in the general case, but the gradient vector for the regularized case.

        Inputs:
            residual: Residual vector per world
        Outputs:
            max_residual: Max absolute residual per world; must be zero-initialized
        """
        wd_id, i, tid = wp.tid()  # Thread indices (= world index, input tile index, thread index in block)

        if wd_id < residual.shape[0] and i * TILE_SIZE < residual.shape[1]:
            segment = wp.tile_load(residual, shape=(1, TILE_SIZE), offset=(wd_id, i * TILE_SIZE))
            segment_max = wp.tile_max(wp.tile_map(wp.abs, segment))[0]
            segment_has_nan = wp.tile_max(wp.tile_map(_isnan, segment))[0]

            if tid == 0:
                if segment_has_nan:
                    # Write NaN in max (non-atomically, as this will overwrite any non-NaN value)
                    max_residual[wd_id] = wp.nan
                else:
                    # Atomically update the max, only if it is not yet NaN (in CUDA, the max() operation only
                    # considers non-NaN values, so the NaN value would get overwritten by a non-NaN otherwise)
                    while True:
                        curr_val = max_residual[wd_id]
                        if wp.isnan(curr_val):
                            break
                        check_val = wp.atomic_cas(max_residual, wd_id, curr_val, wp.max(curr_val, segment_max))
                        if check_val == curr_val:
                            break

    @wp.kernel(module=module)
    def _eval_merit_function(
        # Inputs
        constraints: wp.array2d[wp.float32],
        # Outputs
        merit_function_val: wp.array[wp.float32],
    ):
        """
        A kernel computing the merit function, i.e. the least-squares error 1/2 * ||C||^2, from the constraints
        vector C, in each world

        Inputs:
            constraints: Constraint vector per world
        Outputs:
            merit_function_val: Merit function value per world; must be zero-initialized
        """
        wd_id, i, tid = wp.tid()  # Thread indices (= world index, input tile index, thread index in block)

        if wd_id < constraints.shape[0] and i * TILE_SIZE_CTS < constraints.shape[1]:
            segment = wp.tile_load(constraints, shape=(1, TILE_SIZE_CTS), offset=(wd_id, i * TILE_SIZE_CTS))
            segment_error = 0.5 * wp.tile_sum(wp.tile_map(wp.mul, segment, segment))[0]

            if tid == 0:
                wp.atomic_add(merit_function_val, wd_id, segment_error)

    @wp.kernel(module=module)
    def _eval_regularizer(
        # Inputs
        first_body_id: wp.array[wp.int32],
        reg_weight: wp.float32,
        bodies_q_flat: wp.array[wp.float32],
        bodies_q_ref_flat: wp.array[wp.float32],
        # Outputs
        merit_function_val: wp.array[wp.float32],
    ):
        """
        A kernel computing the least-squares regularizer reg_weight * ||s - s_ref||^2 in each world,
        and adding it to the merit function value.

        Inputs:
            first_body_id: First body index per world.
            reg_weight: Regularizer weight.
            bodies_q_flat: Flattened array of current body poses.
            bodies_q_ref_flat: Flattened array of reference body poses.
        Outputs:
            merit_function_val: Merit function value per world; must be zero-initialized
        """
        wd_id, i, tid = wp.tid()  # Thread indices (= world index, input tile index, thread index in block)

        # Load data
        offset = 7 * first_body_id[wd_id] + i * TILE_SIZE_VRS
        next_world_start = 7 * first_body_id[wd_id + 1]
        if offset >= next_world_start:
            return  # Early return if tile is fully outside of this world's data
        tile = wp.tile_load(bodies_q_flat, shape=TILE_SIZE_VRS, offset=offset)
        tile_ref = wp.tile_load(bodies_q_ref_flat, shape=TILE_SIZE_VRS, offset=offset)

        # Compute regularizer
        reg_tile = tile - tile_ref
        reg_tile = wp.tile_map(wp.mul, reg_tile, reg_tile)
        if offset + TILE_SIZE_VRS > next_world_start:  # Mask out values from next world if needed
            mask = wp.tile_map(less_than_op, wp.tile_arange(TILE_SIZE_VRS, dtype=wp.int32), next_world_start - offset)
            reg_tile = wp.tile_map(mul_mask_float, mask, reg_tile)
        reg = wp.tile_sum(reg_tile)[0]
        if tid == 0:
            wp.atomic_add(merit_function_val, wd_id, 0.5 * reg_weight * reg)

    @wp.kernel(module=module)
    def _eval_merit_function_gradient(
        # Inputs
        step: wp.array2d[wp.float32],
        grad: wp.array2d[wp.float32],
        # Outputs
        merit_function_grad: wp.array[wp.float32],
    ):
        """
        A kernel computing the merit function gradient w.r.t. line search step size, from the step direction
        and the gradient in state space (= dC_ds^T * C). This is simply the dot product between these two vectors.

        Inputs:
            step: Step in variables per world
            grad: Gradient w.r.t. state (i.e. body poses) per world
        Outputs:
            merit_function_grad: Merit function gradient per world; must be zero-initialized
        """
        wd_id, i, tid = wp.tid()  # Thread indices (= world index, input tile index, thread index in block)

        if wd_id < step.shape[0] and i * TILE_SIZE_VRS < step.shape[1]:
            step_segment = wp.tile_load(step, shape=(1, TILE_SIZE_VRS), offset=(wd_id, i * TILE_SIZE_VRS))
            grad_segment = wp.tile_load(grad, shape=(1, TILE_SIZE_VRS), offset=(wd_id, i * TILE_SIZE_VRS))
            tile_dot_prod = wp.tile_sum(wp.tile_map(wp.mul, step_segment, grad_segment))[0]

            if tid == 0:
                wp.atomic_add(merit_function_grad, wd_id, tile_dot_prod)

    return _eval_max_residual, _eval_merit_function, _eval_regularizer, _eval_merit_function_gradient


@wp.kernel
def _eval_rhs(
    # Inputs
    grad: wp.array2d[wp.float32],
    # Outputs
    rhs: wp.array2d[wp.float32],
):
    """
    A kernel computing rhs := -grad (where rhs has shape (num_worlds, num_states_max, 1))

    Inputs:
        grad: Merit function gradient w.r.t. state (i.e. body poses) per world
    Outputs:
        rhs: Gauss-Newton right-hand side per world
    """
    wd_id, state_id_loc = wp.tid()  # Thread indices (= world index, state index)
    if wd_id < grad.shape[0] and state_id_loc < grad.shape[1]:
        rhs[wd_id, state_id_loc] = -grad[wd_id, state_id_loc]


@wp.kernel
def _add_regularizer_to_diagonal(
    # Inputs
    reg_weight: wp.float32,
    active_size: wp.array[wp.int32],
    world_mask: wp.array[wp.bool],
    # Outputs
    A: wp.array3d[wp.float32],
):
    """
    A kernel adding a multiple of the identity to the matrix of a linear system (to regularize it).

    Inputs:
        reg_weight: Regularization weight to add to diagonal coefficients.
        active_size: Active size of the matrix in each world, from the top-left corner.
        world_mask: Per-world boolean flag to perform the computation (False = skip).
    Outputs:
        A: Stack of system matrices (one per world) to regularize.
    """
    wd_id, row_id = wp.tid()  # Thread indices (= world index, row index)
    if world_mask[wd_id] and row_id < active_size[wd_id]:
        A[wd_id, row_id, row_id] = A[wd_id, row_id, row_id] + reg_weight


@wp.kernel
def _eval_regularizer_gradient(
    # Inputs
    num_bodies: wp.array[wp.int32],
    first_body_id: wp.array[wp.int32],
    reg_weight: wp.float32,
    bodies_q_flat: wp.array[wp.float32],
    bodies_q_ref_flat: wp.array[wp.float32],
    world_mask: wp.array[wp.bool],
    # Outputs
    gradient: wp.array2d[wp.float32],
):
    """
    A kernel evaluating the gradient of the least-squares regularizer on body poses, and adding it to the
    overall gradient vector.

    Inputs:
        num_bodies: Number of bodies per world.
        first_body_id: First body index per world.
        reg_weight: Regularizer weight.
        bodies_q_flat: Flattened array of current body poses.
        bodies_q_ref_flat: Flattened array of reference body poses.
        world_mask: Per-world boolean flag to perform the computation (False = skip).
    Outputs:
        gradient: Gradient vector, to which to add the regularizer gradient.
    """
    wd_id, state_id_loc = wp.tid()  # Get thread id (= world index, state index within world)

    rb_id_loc = state_id_loc // 7
    if not world_mask[wd_id] or rb_id_loc >= num_bodies[wd_id]:
        return
    state_id = 7 * first_body_id[wd_id] + state_id_loc

    gradient[wd_id, state_id_loc] += reg_weight * (bodies_q_flat[state_id] - bodies_q_ref_flat[state_id])


@wp.kernel
def _eval_linear_combination(
    # Inputs
    alpha: wp.float32,
    x: wp.array2d[wp.float32],
    beta: wp.float32,
    y: wp.array2d[wp.float32],
    num_rows: wp.array[wp.int32],
    world_mask: wp.array[wp.bool],
    # Outputs
    z: wp.array2d[wp.float32],
):
    """
    A kernel computing z := alpha * x + beta * y

    Inputs:
        alpha: Scalar coefficient
        x: Stack of vectors (one per world) to be multiplied by alpha
        beta: Scalar coefficient
        y: Stack of vectors (one per world) to be multiplied by beta
        num_rows: Active size of the vectors (x, y and z) per world
        world_mask: Per-world boolean flag to perform the computation (False = skip)
    Outputs:
        z: Output stack of vectors
    """
    wd_id, row_id = wp.tid()  # Thread indices (= world index, row index)
    if wd_id < num_rows.shape[0] and world_mask[wd_id] and row_id < num_rows[wd_id]:
        z[wd_id, row_id] = alpha * x[wd_id, row_id] + beta * y[wd_id, row_id]


@wp.kernel
def _eval_stepped_state(
    # Inputs
    num_bodies: wp.array[wp.int32],
    first_body_id: wp.array[wp.int32],
    bodies_q_0_flat: wp.array[wp.float32],
    alpha: wp.array[wp.float32],
    step: wp.array2d[wp.float32],
    world_mask: wp.array[wp.bool],
    # Outputs
    bodies_q_alpha_flat: wp.array[wp.float32],
):
    """
    A kernel computing states_alpha := states_0 + alpha * step

    Inputs:
        num_bodies: Num bodies per world
        first_body_id: First body id per world
        bodies_q_0_flat: Previous state (for step size 0), flattened
        alpha: Step size per world
        step: Step direction per world
        world_mask: Per-world boolean flag to perform the computation (False = skip)
    Outputs:
        bodies_q_alpha_flat: New state (for step size alpha), flattened
    """
    wd_id, state_id_loc = wp.tid()  # Thread indices (= world index, state index)
    rb_id_loc = state_id_loc // 7
    if wd_id < num_bodies.shape[0] and world_mask[wd_id] and rb_id_loc < num_bodies[wd_id]:
        state_id_tot = 7 * first_body_id[wd_id] + state_id_loc
        bodies_q_alpha_flat[state_id_tot] = bodies_q_0_flat[state_id_tot] + alpha[wd_id] * step[wd_id, state_id_loc]


@wp.kernel
def _apply_line_search_step(
    # Inputs
    num_bodies: wp.array[wp.int32],
    first_body_id: wp.array[wp.int32],
    bodies_q_alpha: wp.array[wp.transformf],
    line_search_success: wp.array[wp.bool],
    # Outputs
    bodies_q: wp.array[wp.transformf],
):
    """
    A kernel replacing the state with the line search result, in worlds where line search succeeded
    Note: relies on the fact that the success flag is left at zero for worlds that don't run line search
    (otherwise would also need to check against line search mask)

    Inputs
        num_bodies: Num bodies per world
        first_body_id: First body id per world
        bodies_q_alpha: Stepped states (line search result)
        line_search_success: Per-world line search success flag
    Outputs
        bodies_q: Output state (rigid body poses)
    """
    wd_id, rb_id_loc = wp.tid()  # Thread indices (= world index, body index)
    if wd_id < num_bodies.shape[0] and line_search_success[wd_id] and rb_id_loc < num_bodies[wd_id]:
        rb_id_tot = first_body_id[wd_id] + rb_id_loc
        bodies_q[rb_id_tot] = bodies_q_alpha[rb_id_tot]


@wp.kernel
def _line_search_check(
    # Inputs
    val_0: wp.array[wp.float32],
    grad_0: wp.array[wp.float32],
    alpha: wp.array[wp.float32],
    val_alpha: wp.array[wp.float32],
    iteration: wp.array[wp.int32],
    max_iterations: wp.array[wp.int32],
    # Outputs
    line_search_success: wp.array[wp.bool],
    line_search_mask: wp.array[wp.bool],
    line_search_loop_condition: wp.array[wp.int32],
):
    """
    A kernel checking the sufficient decrease condition in line search in each world, and updating the looping
    condition (zero if max iterations reached, or all worlds successful)

    Inputs:
        val_0: Merit function value at 0, per world
        grad_0: Merit function gradient at 0, per world
        alpha: Step size per world (in/out)
        val_alpha: Merit function value at alpha, per world
        iteration: Iteration count, per world
        max_iterations: Max iterations (size 1 array)
    Outputs:
        line_search_success: Convergence per world
        line_search_mask: Per-world flag to continue line search (True = continue, False = skip)
        line_search_loop_condition: Loop condition; must be zero-initialized (size 1 array)
    """
    wd_id = wp.tid()  # Thread index (= world index)
    if wd_id < val_0.shape[0] and line_search_mask[wd_id]:
        iteration[wd_id] += 1
        success = (
            wp.isfinite(val_alpha[wd_id]) and val_alpha[wd_id] <= val_0[wd_id] + 1e-4 * alpha[wd_id] * grad_0[wd_id]
        )
        line_search_success[wd_id] = success
        continue_loop_world = iteration[wd_id] < max_iterations[0] and not success
        line_search_mask[wd_id] = continue_loop_world
        if continue_loop_world:
            alpha[wd_id] *= 0.5
        wp.atomic_max(line_search_loop_condition, 0, wp.int32(continue_loop_world))


@wp.kernel
def _newton_check(
    # Inputs
    max_residual: wp.array[wp.float32],
    tolerance: wp.array[wp.float32],
    iteration: wp.array[wp.int32],
    min_iterations: wp.array[wp.int32],
    max_iterations: wp.array[wp.int32],
    line_search_success: wp.array[wp.bool],
    # Outputs
    newton_success: wp.array[wp.bool],
    newton_mask: wp.array[wp.bool],
    newton_loop_condition: wp.array[wp.int32],
    jacobian_early_update_mask: wp.array[wp.bool],
    jacobian_late_update_mask: wp.array[wp.bool],
):
    """
    A kernel checking the convergence (max residual vs tolerance) in each world, and updating the looping
    condition (zero if max iterations reached, or all worlds successful)

    If provided (non-zero size), also updates masks keeping tracks of worlds where the Jacobian needs to be
    updated before/after the controls (based on whether min iterations was already reached or not)

    Inputs
        max_residual: Max absolute residual per world
        tolerance: Tolerance on max residual (size 1 array)
        iteration: Iteration count, per world
        min_iterations: Min iterations per world (may be > 0 if incremental solve is enabled)
        max_iterations: Max iterations (size 1 array)
        line_search_success: Per-world line search success flag
    Outputs
        newton_success: Convergence per world
        newton_mask: Flag to keep iterating per world
        newton_loop_condition: Loop condition; must be zero-initialized (size 1 array)
        jacobian_early_update_mask: Optional mask, set to True in worlds needing an early Jacobian update
        jacobian_late_update_mask: Optional mask, set to True in worlds needing a late Jacobian update
    """
    wd_id = wp.tid()  # Thread index (= world index)
    if wd_id < max_residual.shape[0] and newton_mask[wd_id]:
        iteration_prev = iteration[wd_id]  # Index of the iteration that just ran
        iteration_next = iteration_prev + 1  # Index of the iteration that is about to run
        min_iterations_wd = min_iterations[wd_id]
        iteration[wd_id] = iteration_next
        reached_min_it = iteration_prev >= min_iterations_wd
        max_residual_wd = max_residual[wd_id]
        is_finite = wp.isfinite(max_residual_wd)
        success = is_finite and reached_min_it and max_residual_wd <= tolerance[0]
        newton_success[wd_id] = success
        newton_continue_world = (
            iteration_next < max_iterations[0]
            and not success
            and is_finite  # Abort when encountering NaN / Inf values
            and line_search_success[wd_id]  # Abort in case of line search failure
        )
        newton_mask[wd_id] = newton_continue_world
        if jacobian_early_update_mask.shape[0] > 0:
            jacobian_early_update_mask[wd_id] = newton_continue_world and iteration_next >= min_iterations_wd
        if jacobian_late_update_mask.shape[0] > 0:
            jacobian_late_update_mask[wd_id] = newton_continue_world and iteration_next <= min_iterations_wd
        wp.atomic_max(newton_loop_condition, 0, wp.int32(newton_continue_world))


@wp.kernel
def _eval_target_constraint_velocities(
    # Inputs
    num_joints: wp.array[wp.int32],
    first_joint_id: wp.array[wp.int32],
    joints_dof_type: wp.array[wp.int32],
    joints_act_type: wp.array[wp.int32],
    actuated_coords_offset: wp.array[wp.int32],
    actuated_dofs_offset: wp.array[wp.int32],
    ct_full_to_red_map: wp.array[wp.int32],
    actuators_q: wp.array[wp.float32],
    actuators_u: wp.array2d[wp.float32],
    world_mask: wp.array[wp.bool],
    # Outputs
    target_cts_u: wp.array3d[wp.float32],
):
    """
    A kernel computing the target constraint velocities, i.e. zero for passive constraints
    and the prescribed dof velocity for actuated constraints.

    Processes a batch of batch_size velocity vectors in parallel.

    Inputs:
        num_joints: Num joints per world
        first_joint_id: First joint id per world
        joints_dof_type: Joint dof type (i.e. revolute, spherical, ...)
        joints_act_type: Joint actuation type (i.e. passive or actuated)
        actuated_dofs_offset: Joint first actuated dof id, among all actuated dofs in all worlds
        ct_full_to_red_map: Map from full to reduced constraint id
        actuators_u: Actuated joint velocities, with shape ``(batch_size, num_fk_actuated_dofs)``
        world_mask: Per-world boolean flag to perform the computation (False = skip)
    Outputs:
        target_cts_u: Target constraint velocities, with shape ``(num_worlds, num_cts_max, batch_size)``
            (assumed to be zero-initialized)
    """
    # Retrieve the thread indices (= batch index, world index, joint index)
    batch_id, wd_id, jt_id_loc = wp.tid()
    if wd_id >= world_mask.shape[0] or not world_mask[wd_id] or jt_id_loc >= num_joints[wd_id]:
        return

    # Retrieve the joint model data
    jt_id_tot = first_joint_id[wd_id] + jt_id_loc
    if joints_act_type[jt_id_tot] == JointActuationType.PASSIVE:
        return
    dof_type_j = joints_dof_type[jt_id_tot]
    offset_q_j = actuated_coords_offset[jt_id_tot]
    offset_u_j = actuated_dofs_offset[jt_id_tot]
    offset_cts_j = ct_full_to_red_map[6 * jt_id_tot]

    if dof_type_j == FKJointDoFType.CARTESIAN:
        target_cts_u[wd_id, offset_cts_j, batch_id] = actuators_u[batch_id, offset_u_j]
        target_cts_u[wd_id, offset_cts_j + 1, batch_id] = actuators_u[batch_id, offset_u_j + 1]
        target_cts_u[wd_id, offset_cts_j + 2, batch_id] = actuators_u[batch_id, offset_u_j + 2]
    elif dof_type_j == FKJointDoFType.CYLINDRICAL:
        target_cts_u[wd_id, offset_cts_j, batch_id] = actuators_u[batch_id, offset_u_j]
        target_cts_u[wd_id, offset_cts_j + 3, batch_id] = actuators_u[batch_id, offset_u_j + 1]
    elif dof_type_j == FKJointDoFType.FIXED:
        pass  # No dofs to apply
    elif dof_type_j == FKJointDoFType.FREE:
        for i in range(6):
            target_cts_u[wd_id, offset_cts_j + i, batch_id] = actuators_u[batch_id, offset_u_j + i]
    elif dof_type_j == FKJointDoFType.PRISMATIC:
        target_cts_u[wd_id, offset_cts_j, batch_id] = actuators_u[batch_id, offset_u_j]
    elif dof_type_j == FKJointDoFType.REVOLUTE:
        target_cts_u[wd_id, offset_cts_j + 3, batch_id] = actuators_u[batch_id, offset_u_j]
    elif dof_type_j == FKJointDoFType.SPHERICAL:
        for i in range(3):
            target_cts_u[wd_id, offset_cts_j + 3 + i, batch_id] = actuators_u[batch_id, offset_u_j + i]
    elif dof_type_j == FKJointDoFType.GIMBAL or dof_type_j == FKJointDoFType.GIMBAL_LEFT_HANDED:
        third_axis_sign = 1.0
        if dof_type_j == FKJointDoFType.GIMBAL_LEFT_HANDED:
            third_axis_sign = -1.0
        axes = gimbal_transported_axes(
            wp.vec3f(actuators_q[offset_q_j], actuators_q[offset_q_j + 1], actuators_q[offset_q_j + 2]),
            third_axis_sign,
        )
        omega = (
            wp.vec3f(axes[:, 0]) * actuators_u[batch_id, offset_u_j]
            + wp.vec3f(axes[:, 1]) * actuators_u[batch_id, offset_u_j + 1]
            + wp.vec3f(axes[:, 2]) * actuators_u[batch_id, offset_u_j + 2]
        )
        for i in range(3):
            target_cts_u[wd_id, offset_cts_j + 3 + i, batch_id] = omega[i]
    elif dof_type_j == FKJointDoFType.UNIVERSAL:
        target_cts_u[wd_id, offset_cts_j + 3, batch_id] = actuators_u[batch_id, offset_u_j]
        target_cts_u[wd_id, offset_cts_j + 4, batch_id] = actuators_u[batch_id, offset_u_j + 1]
    else:
        assert False, "Unexpected actuator dof type"  # noqa: B011


@wp.kernel
def _correct_universal_constraint_velocities(
    # Inputs
    num_joints: wp.array[wp.int32],
    first_joint_id: wp.array[wp.int32],
    joints_dof_type: wp.array[wp.int32],
    joints_act_type: wp.array[wp.int32],
    joints_bid_B: wp.array[wp.int32],
    joints_bid_F: wp.array[wp.int32],
    joints_X_Bj: wp.array[wp.mat33f],
    joints_X_Fj: wp.array[wp.mat33f],
    ct_full_to_red_map: wp.array[wp.int32],
    bodies_q: wp.array[wp.transformf],
    world_mask: wp.array[wp.bool],
    # Outputs
    target_cts_u: wp.array3d[wp.float32],
):
    """
    A kernel correcting the prescribed target velocities for universal actuators.
    This is needed because for universal joints, the dof-space velocity is expressed in the frame of the
    intermediary body, rather than in the frame on the base body.

    Processes a batch of batch_size velocity vectors in parallel.

    Inputs:
        num_joints: Num joints per world
        first_joint_id: First joint id per world
        joints_dof_type: Joint dof type (i.e. revolute, spherical, ...)
        joints_act_type: Joint actuation type (i.e. passive or actuated)
        joints_bid_B: Joint base body id
        joints_bid_F: Joint follower body id
        joints_X_Bj: Joint local frame on base body
        joints_X_Fj: Joint local frame on follower body
        ct_full_to_red_map: Map from full to reduced constraint id
        bodies_q: Current body poses.
        world_mask: Per-world boolean flag to perform the computation (False = skip)
    Outputs:
        target_cts_u: Corrected target constraint velocities, with shape ``(num_worlds, num_cts_max, batch_size)``
            (provided uncorrected as input).
    """
    # Retrieve the thread indices (= batch index, world index, joint index)
    batch_id, wd_id, jt_id_loc = wp.tid()
    if wd_id >= world_mask.shape[0] or not world_mask[wd_id] or jt_id_loc >= num_joints[wd_id]:
        return

    # Early return if this is not a universal actuator
    jt_id_tot = first_joint_id[wd_id] + jt_id_loc
    if (
        joints_act_type[jt_id_tot] == JointActuationType.PASSIVE
        or joints_dof_type[jt_id_tot] != FKJointDoFType.UNIVERSAL
    ):
        return

    # Read target angular velocity (currently, in dof space i.e. in the frame of the intermediary body)
    offset_cts_j = ct_full_to_red_map[6 * jt_id_tot]
    omega_curr = wp.vec3f(
        target_cts_u[wd_id, offset_cts_j + 3, batch_id],
        target_cts_u[wd_id, offset_cts_j + 4, batch_id],
        0.0,
    )
    # Compute relative orientation of joint frame on follower body w.r.t. joint frame on base body
    bid_B = joints_bid_B[jt_id_tot]
    bid_F = joints_bid_F[jt_id_tot]
    q_B = wp.quatf(0.0, 0.0, 0.0, 1.0) if bid_B < 0 else wp.transform_get_rotation(bodies_q[bid_B])
    q_F = wp.transform_get_rotation(bodies_q[bid_F])
    q_X_B = wp.quat_from_matrix(joints_X_Bj[jt_id_tot])
    q_X_F = wp.quat_from_matrix(joints_X_Fj[jt_id_tot])
    q_rel = wp.quat_inverse(q_B * q_X_B) * q_F * q_X_F

    # Compute intermediary body axes, in the joint frame on the base body
    e_x = wp.vec3f(1.0, 0.0, 0.0)
    e_y = wp.vec3f(0.0, 1.0, 0.0)
    a_x = e_x  # x axis on base
    a_y_raw = wp.quat_rotate(q_rel, e_y)  # y axis on follower (constrained to be orthogonal to a_x)
    a_y = a_y_raw - wp.dot(a_y_raw, a_x) * a_x  # orthogonalize (in case of constraint violations)
    a_y = wp.normalize(a_y)
    a_z = wp.cross(a_x, a_y)

    # Convert target angular velocity back to joint frame on the base body
    omega = omega_curr[0] * a_x + omega_curr[1] * a_y + omega_curr[2] * a_z
    for i in range(3):
        target_cts_u[wd_id, offset_cts_j + 3 + i, batch_id] = omega[i]


@wp.kernel
def _eval_body_velocities(
    # Inputs
    num_bodies: wp.array[wp.int32],
    first_body_id: wp.array[wp.int32],
    bodies_q: wp.array[wp.transformf],
    bodies_q_dot: wp.array3d[wp.float32],
    world_mask: wp.array[wp.bool],
    # Outputs
    bodies_u: wp.array2d[wp.spatial_vectorf],
):
    """
    A kernel computing the body velocities (twists) from the time derivative of body poses,
    computing in particular angular velocities omega = 2G(q)q_dot.

    Processes a batch of batch_size velocity vectors in parallel.

    Inputs:
        num_bodies: Number of bodies per world
        first_body_id: First body id per world
        bodies_q: Body poses
        bodies_q_dot: Time derivative of body poses, with shape ``(num_worlds, num_states_max, batch_size)``
        world_mask: Per-world boolean flag to perform the computation (False = skip)
    Outputs:
        bodies_u: Body velocities (twists), with shape ``(batch_size, sum_of_num_bodies)``
    """
    # Retrieve the thread indices (= batch index, world index, body index)
    batch_id, wd_id, rb_id_loc = wp.tid()
    if not world_mask[wd_id] or rb_id_loc >= num_bodies[wd_id]:
        return

    # Indices / offsets
    rb_id_tot = first_body_id[wd_id] + rb_id_loc
    offset_q_dot = 7 * rb_id_loc

    # Copy linear velocity
    linear = wp.vec3f(
        bodies_q_dot[wd_id, offset_q_dot, batch_id],
        bodies_q_dot[wd_id, offset_q_dot + 1, batch_id],
        bodies_q_dot[wd_id, offset_q_dot + 2, batch_id],
    )
    # Compute angular velocity
    q = wp.transform_get_rotation(bodies_q[rb_id_tot])
    q_dot = wp.vec4f(
        bodies_q_dot[wd_id, offset_q_dot + 3, batch_id],
        bodies_q_dot[wd_id, offset_q_dot + 4, batch_id],
        bodies_q_dot[wd_id, offset_q_dot + 5, batch_id],
        bodies_q_dot[wd_id, offset_q_dot + 6, batch_id],
    )
    omega = 2.0 * (G_of(q) * q_dot)
    bodies_u[batch_id, rb_id_tot] = wp.spatial_vector(linear, omega)


@wp.kernel
def _update_cg_tolerance_kernel(
    # Input
    max_residual: wp.array[wp.float32],
    world_mask: wp.array[wp.bool],
    # Output
    atol: wp.array[wp.float32],
    rtol: wp.array[wp.float32],
):
    """
    A kernel heuristically adapting the CG tolerance based on the current constraint/gradient residual
    (starting with a loose tolerance, and tightening it as we converge)
    Note: needs to be refined, until then we are still using a fixed tolerance
    """
    wd_id = wp.tid()
    if wd_id >= world_mask.shape[0] or not world_mask[wd_id]:
        return
    tol = wp.max(1e-8, wp.min(1e-5, 1e-3 * max_residual[wd_id]))
    atol[wd_id] = tol
    rtol[wd_id] = tol

# SPDX-FileCopyrightText: Copyright (c) 2025 The Newton Developers
# SPDX-License-Identifier: Apache-2.0

"""KAMINO: Shape Types & Containers"""

from __future__ import annotations

from abc import ABC, abstractmethod
from collections.abc import Sequence

import numpy as np
import warp as wp

from .....core.types import Vec2, Vec3, override
from .....geometry.types import GeoType, Heightfield, Mesh
from .types import Descriptor

###
# Module interface
###

__all__ = [
    "BoxShape",
    "CapsuleShape",
    "ConeShape",
    "CylinderShape",
    "EllipsoidShape",
    "EmptyShape",
    "GeoType",
    "MeshShape",
    "PlaneShape",
    "ShapeDescriptor",
    "ShapeDescriptorType",
    "SphereShape",
    "max_contacts_for_shape_pair",
]


###
# Module configs
###

wp.set_module_options({"enable_backward": False})


###
# Containers
###

ShapeParamsLike = None | float | Sequence[float]
"""A type union that can represent any shape parameters, including None, single float, or sequence of floats."""

ShapeDataLike = None | Mesh | Heightfield
"""A type union that can represent any shape data, including None, Mesh, and Heightfield."""


class ShapeDescriptor(ABC, Descriptor):
    """Abstract base class for all shape descriptors."""

    def __init__(self, type: GeoType, name: str = "", uid: str | None = None):
        """
        Initialize the shape descriptor.

        Args:
            type: The geometry type from Newton's :class:`GeoType`.
            name: The name of the shape descriptor.
            uid: Optional unique identifier of the shape descriptor.
        """
        super().__init__(name, uid)
        self._type: GeoType = type

    @override
    def __hash__(self) -> int:
        """Returns a hash of the ShapeDescriptor based on its name, uid, type and params."""
        return hash((self.type, self.params))

    @override
    def __repr__(self):
        """Returns a human-readable string representation of the ShapeDescriptor."""
        return f"ShapeDescriptor(\ntype: {self.type},\nname: {self.name},\nuid: {self.uid},\n)"

    @property
    def type(self) -> GeoType:
        """Returns the geometry type of the shape."""
        return self._type

    @property
    def is_solid(self) -> bool:
        """Returns whether the shape is solid (i.e., not empty)."""
        # TODO: Fix this since `is_solid` is meant to represent hollow shells.
        return self._type != GeoType.NONE

    @property
    @abstractmethod
    def paramsvec(self) -> wp.vec3f:
        return wp.vec3f(0.0)

    @property
    @abstractmethod
    def params(self) -> ShapeParamsLike:
        return None

    @property
    @abstractmethod
    def data(self) -> ShapeDataLike:
        return None


###
# Primitive Shapes
###


class EmptyShape(ShapeDescriptor):
    """
    A shape descriptor for the empty shape that can serve as a placeholder.
    """

    def __init__(self, name: str = "empty", uid: str | None = None):
        super().__init__(GeoType.NONE, name, uid)

    @override
    def __repr__(self):
        """Returns a human-readable string representation of the EmptyShape."""
        return f"EmptyShape(\nname: {self.name},\nuid: {self.uid}\n)"

    @property
    @override
    def paramsvec(self) -> wp.vec3f:
        return wp.vec3f(0.0)

    @property
    @override
    def params(self) -> ShapeParamsLike:
        return None

    @property
    @override
    def data(self) -> None:
        return None


class SphereShape(ShapeDescriptor):
    """
    A shape descriptor for spheres.

    Attributes:
        radius: The radius of the sphere [m].
    """

    def __init__(self, radius: float, name: str = "sphere", uid: str | None = None):
        super().__init__(GeoType.SPHERE, name, uid)
        self.radius: float = radius

    @override
    def __repr__(self):
        """Returns a human-readable string representation of the SphereShape."""
        return f"SphereShape(\nname: {self.name},\nuid: {self.uid},\nradius: {self.radius}\n)"

    @property
    @override
    def paramsvec(self) -> wp.vec3f:
        return wp.vec3f(self.radius, 0.0, 0.0)

    @property
    @override
    def params(self) -> float:
        return self.radius

    @property
    @override
    def data(self) -> None:
        return None


class CylinderShape(ShapeDescriptor):
    """
    A shape descriptor for cylinders.

    Attributes:
        radius: The radius of the cylinder [m].
        half_height: The half-height of the cylinder [m].
    """

    def __init__(self, radius: float, half_height: float, name: str = "cylinder", uid: str | None = None):
        super().__init__(GeoType.CYLINDER, name, uid)
        self.radius: float = radius
        self.half_height: float = half_height

    @override
    def __repr__(self):
        """Returns a human-readable string representation of the CylinderShape."""
        return f"CylinderShape(\nname: {self.name},\nuid: {self.uid},\nradius: {self.radius},\nhalf_height: {self.half_height}\n)"

    @property
    @override
    def paramsvec(self) -> wp.vec3f:
        return wp.vec3f(self.radius, self.half_height, 0.0)

    @property
    @override
    def params(self) -> tuple[float, float]:
        return (self.radius, self.half_height)

    @property
    @override
    def data(self) -> None:
        return None


class ConeShape(ShapeDescriptor):
    """
    A shape descriptor for cones.

    Attributes:
        radius: The radius of the cone [m].
        half_height: The half-height of the cone [m].
    """

    def __init__(self, radius: float, half_height: float, name: str = "cone", uid: str | None = None):
        super().__init__(GeoType.CONE, name, uid)
        self.radius: float = radius
        self.half_height: float = half_height

    @override
    def __repr__(self):
        """Returns a human-readable string representation of the ConeShape."""
        return f"ConeShape(\nname: {self.name},\nuid: {self.uid},\nradius: {self.radius},\nhalf_height: {self.half_height}\n)"

    @property
    @override
    def paramsvec(self) -> wp.vec3f:
        return wp.vec3f(self.radius, self.half_height, 0.0)

    @property
    @override
    def params(self) -> tuple[float, float]:
        return (self.radius, self.half_height)

    @property
    @override
    def data(self) -> None:
        return None


class CapsuleShape(ShapeDescriptor):
    """
    A shape descriptor for capsules.

    Attributes:
        radius: The radius of the capsule [m].
        half_height: The half-height of the capsule (cylindrical part) [m].
    """

    def __init__(self, radius: float, half_height: float, name: str = "capsule", uid: str | None = None):
        super().__init__(GeoType.CAPSULE, name, uid)
        self.radius: float = radius
        self.half_height: float = half_height

    @override
    def __repr__(self):
        """Returns a human-readable string representation of the CapsuleShape."""
        return f"CapsuleShape(\nname: {self.name},\nuid: {self.uid},\nradius: {self.radius},\nhalf_height: {self.half_height}\n)"

    @property
    @override
    def paramsvec(self) -> wp.vec3f:
        return wp.vec3f(self.radius, self.half_height, 0.0)

    @property
    @override
    def params(self) -> tuple[float, float]:
        return (self.radius, self.half_height)

    @property
    @override
    def data(self) -> None:
        return None


class BoxShape(ShapeDescriptor):
    """
    A shape descriptor for boxes.

    Attributes:
        hx: The half-extent along the local X-axis [m].
        hy: The half-extent along the local Y-axis [m].
        hz: The half-extent along the local Z-axis [m].
    """

    def __init__(self, hx: float, hy: float, hz: float, name: str = "box", uid: str | None = None):
        super().__init__(GeoType.BOX, name, uid)
        self.hx: float = hx
        self.hy: float = hy
        self.hz: float = hz

    @override
    def __repr__(self):
        """Returns a human-readable string representation of the BoxShape."""
        return f"BoxShape(\nname: {self.name},\nuid: {self.uid},\nhx: {self.hx},\nhy: {self.hy},\nhz: {self.hz}\n)"

    @property
    @override
    def paramsvec(self) -> wp.vec3f:
        return wp.vec3f(self.hx, self.hy, self.hz)

    @property
    @override
    def params(self) -> tuple[float, float, float]:
        return (self.hx, self.hy, self.hz)

    @property
    @override
    def data(self) -> None:
        return None


class EllipsoidShape(ShapeDescriptor):
    """
    A shape descriptor for ellipsoids.

    Attributes:
        rx: The semi-axis length along the X-axis [m].
        ry: The semi-axis length along the Y-axis [m].
        rz: The semi-axis length along the Z-axis [m].
    """

    def __init__(self, rx: float, ry: float, rz: float, name: str = "ellipsoid", uid: str | None = None):
        super().__init__(GeoType.ELLIPSOID, name, uid)
        self.rx: float = rx
        self.ry: float = ry
        self.rz: float = rz

    @override
    def __repr__(self):
        """Returns a human-readable string representation of the EllipsoidShape."""
        return (
            f"EllipsoidShape(\nname: {self.name},\nuid: {self.uid},\nrx: {self.rx},\nry: {self.ry},\nrz: {self.rz}\n)"
        )

    @property
    @override
    def paramsvec(self) -> wp.vec3f:
        return wp.vec3f(self.rx, self.ry, self.rz)

    @property
    @override
    def params(self) -> tuple[float, float, float]:
        return (self.rx, self.ry, self.rz)

    @property
    @override
    def data(self) -> None:
        return None


class PlaneShape(ShapeDescriptor):
    """
    A shape descriptor for planes.

    Attributes:
        normal:
            The normal vector of the plane in world coordinates.
            Defaults to (0, 0, 1) for a horizontal plane.
        distance: The distance from the origin to the plane along its normal [m].
        width: The width of the plane [m]. Defaults to 0, which represents an infinite plane.
        length: The length of the plane [m]. Defaults to 0, which represents an infinite plane.
        name: Optional name of the shape descriptor.
        uid: Optional unique identifier of the shape descriptor.
    """

    def __init__(
        self,
        normal: Vec3 = (0.0, 0.0, 1.0),
        distance: float = 0.0,
        width: float = 0.0,
        length: float = 0.0,
        name: str = "plane",
        uid: str | None = None,
    ):
        super().__init__(GeoType.PLANE, name, uid)
        self.normal: Vec3 = normal
        self.distance: float = distance
        self.width: float = width
        self.length: float = length

    @override
    def __repr__(self):
        """Returns a human-readable string representation of the PlaneShape."""
        return f"PlaneShape(\nname: {self.name},\nuid: {self.uid},\nnormal: {self.normal},\ndistance: {self.distance},\nwidth: {self.width},\nlength: {self.length}\n)"

    @property
    @override
    def paramsvec(self) -> wp.vec3f:
        return wp.vec3f(self.width, self.length, 0.0)

    @property
    @override
    def params(self) -> tuple[float, float]:
        return (self.width, self.length)

    @property
    @override
    def data(self) -> None:
        return None


###
# Explicit Shapes
###


class MeshShape(ShapeDescriptor):
    """
    A shape descriptor for mesh shapes.

    This class is a lightweight wrapper around the newton.Mesh geometry type,
    that provides the necessary interfacing to be used with the Kamino solver.

    Attributes:
        vertices: The vertices of the mesh.
        indices: The triangle indices of the mesh.
        normals: The vertex normals of the mesh.
        uvs: The texture coordinates of the mesh.
        color: The color of the mesh.
        is_solid: Whether the mesh is solid.
        is_convex: Whether the mesh is convex.
    """

    MAX_HULL_VERTICES = Mesh.MAX_HULL_VERTICES
    """Utility attribute to expose this constant without needing to import the newton.Mesh class directly."""

    def __init__(
        self,
        vertices: Sequence[Vec3] | np.ndarray,
        indices: Sequence[int] | np.ndarray,
        normals: Sequence[Vec3] | np.ndarray | None = None,
        uvs: Sequence[Vec2] | np.ndarray | None = None,
        color: Vec3 | None = None,
        maxhullvert: int | None = None,
        compute_inertia: bool = True,
        is_solid: bool = True,
        is_convex: bool = False,
        name: str = "mesh",
        uid: str | None = None,
    ):
        """
        Initialize the mesh shape descriptor.

        Args:
            vertices: The vertices of the mesh.
            indices: The triangle indices of the mesh.
            normals: The vertex normals of the mesh.
            uvs: The texture coordinates of the mesh.
            color: The color of the mesh.
            maxhullvert: The maximum number of hull vertices for convex shapes.
            compute_inertia: Whether to compute inertia for the mesh.
            is_solid: Whether the mesh is solid.
            is_convex: Whether the mesh is convex.
            name: The name of the shape descriptor.
            uid: Optional unique identifier of the shape descriptor.
        """
        # Determine the mesh shape type, and adapt default name if necessary
        if is_convex:
            geo_type = GeoType.CONVEX_MESH
            name = "convex" if name == "mesh" else name
        else:
            geo_type = GeoType.MESH

        # Initialize the base shape descriptor
        super().__init__(geo_type, name, uid)

        # Create the underlying mesh data container
        self._data: Mesh = Mesh(
            vertices=vertices,
            indices=indices,
            normals=normals,
            uvs=uvs,
            compute_inertia=compute_inertia,
            is_solid=is_solid,
            maxhullvert=maxhullvert,
            color=color,
        )

    @override
    def __hash__(self) -> int:
        """Returns a hash computed using the underlying newton.Mesh hash implementation."""
        return self._data.__hash__()

    @override
    def __repr__(self):
        """Returns a human-readable string representation of the MeshShape."""
        label = "ConvexShape" if self.type == GeoType.CONVEX_MESH else "MeshShape"
        normals_shape = self._data._normals.shape if self._data._normals is not None else None
        return (
            f"{label}(\n"
            f"name: {self.name},\n"
            f"uid: {self.uid},\n"
            f"vertices: {self._data.vertices.shape},\n"
            f"indices: {self._data.indices.shape},\n"
            f"normals: {normals_shape},\n"
            f")"
        )

    @property
    @override
    def paramsvec(self) -> wp.vec3f:
        return wp.vec3f(1.0, 1.0, 1.0)

    @property
    @override
    def params(self) -> tuple[float, float, float]:
        """Returns the XYZ scaling of the mesh."""
        return 1.0, 1.0, 1.0

    @property
    @override
    def data(self) -> Mesh:
        return self._data

    @property
    def vertices(self) -> np.ndarray:
        """Returns the vertices of the mesh."""
        return self._data.vertices

    @property
    def indices(self) -> np.ndarray:
        """Returns the indices of the mesh."""
        return self._data.indices

    @property
    def normals(self) -> np.ndarray | None:
        """Returns the normals of the mesh."""
        return self._data._normals

    @property
    def uvs(self) -> np.ndarray | None:
        """Returns the UVs of the mesh."""
        return self._data._uvs

    @property
    def color(self) -> Vec3 | None:
        """Returns the color of the mesh."""
        return self._data._color


class HFieldShape(ShapeDescriptor):
    """A shape descriptor for height-field (terrain) shapes.

    Attributes:
        heightfield: The underlying :class:`Heightfield` data.
    """

    def __init__(self, heightfield: Heightfield, name: str = "hfield", uid: str | None = None):
        """Initialize the height-field shape descriptor.

        Args:
            heightfield: A :class:`Heightfield` instance containing elevation data.
            name: The name of the shape descriptor.
            uid: Optional unique identifier of the shape descriptor.
        """
        super().__init__(GeoType.HFIELD, name, uid)
        self._data: Heightfield = heightfield

    @override
    def __repr__(self):
        return f"HFieldShape(\nname: {self.name},\nuid: {self.uid}\n)"

    @property
    @override
    def paramsvec(self) -> wp.vec3f:
        return wp.vec3f(1.0, 1.0, 1.0)

    @property
    @override
    def params(self) -> tuple[float, float, float]:
        """Returns the XYZ scaling of the height-field."""
        return 1.0, 1.0, 1.0

    @property
    @override
    def data(self) -> Heightfield:
        return self._data


###
# Aliases
###


ShapeDescriptorType = (
    EmptyShape
    | SphereShape
    | CylinderShape
    | ConeShape
    | CapsuleShape
    | BoxShape
    | EllipsoidShape
    | PlaneShape
    | MeshShape
    | HFieldShape
)
"""A type union that can represent any shape descriptor, including primitive and explicit shapes."""


###
# Utilities
###

# Contact counts for mesh/heightfield pairs are dynamic (bounded by the
# pipeline's max_contacts_per_pair setting).  The values below are
# conservative upper-bound estimates used for capacity allocation.
_MESH_CONVEX_MAX = 32
_MESH_MESH_MAX = 64


@wp.func
def max_contacts_for_shape_pair(type_a: int, type_b: int) -> tuple[int, int]:
    """
    Count the number of potential contact points for a collision pair in both
    directions of the collision pair (collisions from A to B and from B to A).

    Shape types are canonicalized such that the type of shape A is less than or equal to the type of shape B.

    Args:
        type_a: First shape type as :class:`GeoType` integer value.
        type_b: Second shape type as :class:`GeoType` integer value.

    Returns:
        Number of contact points for collisions between A->B and B->A.
        Each component independently bounds the contacts generated in its
        direction. The reverse capacity is zero only when the pair's
        narrow-phase implementation emits contacts in canonical order alone;
        otherwise it reserves capacity for the reverse pass.
    """
    # Ensure the shape types are ordered canonically
    if type_a > type_b:
        type_a, type_b = type_b, type_a

    return _max_contacts_for_shape_pair_impl(type_a, type_b)


@wp.func
def _max_contacts_for_shape_pair_impl(type_a: int, type_b: int) -> tuple[int, int]:
    """
    Return the contact capacity for a canonical shape pair without reordering.

    This is used for testing purposes, asserting that type_a > type_b always returns (0, 0).
    This enforces that the implementation doesn't accidentally specify an unreachable pair.
    """
    if type_a == GeoType.PLANE:
        if type_b == GeoType.HFIELD:
            return _MESH_CONVEX_MAX, 0
        elif type_b == GeoType.SPHERE:
            return 1, 0
        elif type_b == GeoType.CAPSULE:
            return 2, 0
        elif type_b == GeoType.ELLIPSOID:
            return 1, 0
        elif type_b == GeoType.CYLINDER:
            return 4, 0
        elif type_b == GeoType.BOX:
            return 4, 0
        elif type_b == GeoType.MESH or type_b == GeoType.CONVEX_MESH:
            return _MESH_CONVEX_MAX, 0
        elif type_b == GeoType.CONE:
            return 5, 0

    elif type_a == GeoType.HFIELD:
        if type_b == GeoType.MESH:
            return _MESH_MESH_MAX, 0
        elif type_b >= GeoType.HFIELD:
            return _MESH_CONVEX_MAX, 0

    elif type_a == GeoType.SPHERE:
        if type_b == GeoType.MESH or type_b == GeoType.CONVEX_MESH:
            return _MESH_CONVEX_MAX, 0
        elif type_b >= GeoType.SPHERE:
            return 1, 0

    elif type_a == GeoType.CAPSULE:
        if type_b == GeoType.CAPSULE:
            return 2, 0
        elif type_b == GeoType.ELLIPSOID:
            return 1, 0
        elif type_b == GeoType.CYLINDER:
            return 5, 0
        elif type_b == GeoType.BOX:
            return 5, 0
        elif type_b == GeoType.MESH or type_b == GeoType.CONVEX_MESH:
            return _MESH_CONVEX_MAX, 0
        elif type_b == GeoType.CONE:
            return 5, 0

    elif type_a == GeoType.ELLIPSOID:
        if type_b == GeoType.ELLIPSOID:
            return 1, 0
        elif type_b == GeoType.CYLINDER:
            return 1, 0
        elif type_b == GeoType.BOX:
            return 1, 0
        elif type_b == GeoType.MESH or type_b == GeoType.CONVEX_MESH:
            return _MESH_CONVEX_MAX, 0
        elif type_b == GeoType.CONE:
            return 1, 0

    elif type_a == GeoType.CYLINDER:
        if type_b == GeoType.CYLINDER:
            return 5, 0
        elif type_b == GeoType.BOX:
            return 5, 0
        elif type_b == GeoType.MESH or type_b == GeoType.CONVEX_MESH:
            return _MESH_CONVEX_MAX, 0
        elif type_b == GeoType.CONE:
            return 5, 0

    elif type_a == GeoType.BOX:
        if type_b == GeoType.BOX:
            return 8, 0
        elif type_b == GeoType.MESH or type_b == GeoType.CONVEX_MESH:
            return _MESH_CONVEX_MAX, 0
        elif type_b == GeoType.CONE:
            return 5, 0

    elif type_a == GeoType.MESH:
        if type_b == GeoType.MESH:
            return _MESH_MESH_MAX, 0
        elif type_b == GeoType.CONE:
            return _MESH_CONVEX_MAX, 0
        elif type_b == GeoType.CONVEX_MESH:
            return _MESH_MESH_MAX, 0

    elif type_a == GeoType.CONE:
        if type_b == GeoType.CONE:
            return 5, 0
        elif type_b == GeoType.CONVEX_MESH:
            return _MESH_CONVEX_MAX, 0

    elif type_a == GeoType.CONVEX_MESH:
        if type_b == GeoType.CONVEX_MESH:
            return _MESH_MESH_MAX, 0

    # unsupported type combination
    return 0, 0

# SPDX-FileCopyrightText: Copyright (c) 2025 The Newton Developers
# SPDX-License-Identifier: Apache-2.0

from __future__ import annotations

import inspect
import subprocess
import warnings
from typing import Any
from urllib.parse import urlencode

import numpy as np
import warp as wp

import newton

from ..core.types import override
from ..utils.mesh import compute_vertex_normals
from .utils import prepare_viewer_texture, promote_to_clamped_float_array, to_numpy
from .viewer import ViewerBase, is_jupyter_notebook

try:
    import rerun as rr
    import rerun.blueprint as rrb
except ImportError:
    rr = None
    rrb = None


class ViewerRerun(ViewerBase):
    """
    ViewerRerun provides a backend for visualizing Newton simulations using the rerun visualization library.

    This viewer logs mesh and instance data to rerun, enabling real-time or offline visualization of simulation
    geometry and transforms. By default, it spawns a viewer. Alternatively, it can connect to a specific
    rerun server address. Multiple parallel simulations are supported—use unique app_id values to differentiate them.
    The class manages mesh assets, instanced geometry, and frame/timeline synchronization with rerun.
    """

    @staticmethod
    def _call_rr_constructor(ctor, **kwargs):
        """Call a rerun constructor with only supported keyword args."""
        try:
            signature = inspect.signature(ctor)
        except (TypeError, ValueError):
            return ctor(**kwargs)

        accepts_kwargs = any(param.kind == inspect.Parameter.VAR_KEYWORD for param in signature.parameters.values())
        allowed = kwargs if accepts_kwargs else {k: v for k, v in kwargs.items() if k in signature.parameters}
        return ctor(**allowed)

    @staticmethod
    def _flip_uvs_for_rerun(uvs: np.ndarray) -> np.ndarray:
        """Rerun uses top-left UV origin; flip V from OpenGL-style UVs."""
        uvs = np.asarray(uvs, dtype=np.float32)
        if uvs.size == 0:
            return uvs
        flipped = uvs.copy()
        flipped[:, 1] = 1.0 - flipped[:, 1]
        return flipped

    @staticmethod
    def _build_texture_components(texture_image: np.ndarray):
        """Create rerun ImageBuffer/ImageFormat components from a texture."""
        if texture_image is None:
            return None, None
        if rr is None:
            return None, None

        height, width, channels = texture_image.shape
        texture_image = np.ascontiguousarray(texture_image)

        try:
            color_model = rr.datatypes.ColorModel.RGBA if channels == 4 else rr.datatypes.ColorModel.RGB
        except Exception:
            color_model = "RGBA" if channels == 4 else "RGB"

        try:
            channel_dtype = rr.datatypes.ChannelDatatype.U8
        except Exception:
            channel_dtype = "U8"

        texture_buffer = rr.components.ImageBuffer(texture_image.tobytes())
        texture_format = rr.components.ImageFormat(
            width=int(width),
            height=int(height),
            color_model=color_model,
            channel_datatype=channel_dtype,
        )
        return texture_buffer, texture_format

    @staticmethod
    def _rgb_to_u8(color: tuple[float, float, float] | np.ndarray | None, default=(180, 180, 180)) -> np.ndarray:
        """Convert an RGB color in 0-1 or 0-255 range to uint8."""
        if color is None:
            return np.asarray(default, dtype=np.uint8)
        color_np = np.asarray(color, dtype=np.float32).reshape(3)
        if np.max(color_np) <= 1.0:
            color_np = color_np * 255.0
        return np.clip(np.round(color_np), 0.0, 255.0).astype(np.uint8)

    @staticmethod
    def _opacity_to_u8(opacity: float | None) -> int:
        return int(round(float(np.clip(1.0 if opacity is None else opacity, 0.0, 1.0)) * 255.0))

    def _mesh3d_supports(self, field_name: str) -> bool:
        if not self._mesh3d_params:
            return True
        return field_name in self._mesh3d_params

    def __init__(
        self,
        *,
        app_id: str | None = None,
        rec_id: str | None = None,
        address: str | None = None,
        serve_web_viewer: bool = True,
        web_port: int = 9090,
        grpc_port: int = 9876,
        keep_historical_data: bool = False,
        keep_scalar_history: bool = True,
        record_to_rrd: str | None = None,
    ):
        """
        Initialize the ViewerRerun backend for Newton using the Rerun.io visualization library.

        This viewer supports both standalone and Jupyter notebook environments. When an address is provided,
        it connects to that remote rerun server regardless of environment. When address is None, it spawns
        a local viewer (web-based or standalone, depending on ``serve_web_viewer`` flag), only if not running in a Jupyter notebook (notebooks use show_notebook() instead).

        Args:
            app_id: Application ID for rerun (defaults to 'newton-viewer').
                                 Use different IDs to differentiate between parallel viewer instances.
            rec_id: Recording ID for rerun. If provided, multiple processes using the
                                 same recording ID will share a single recording, allowing their data
                                 to be visualized together. If None, a random ID is generated.
            address: Optional server address to connect to a remote rerun server via gRPC.
                                  You will need to start a stand-alone rerun server first, e.g. by typing ``rerun`` in your terminal.
                                  See rerun.io documentation for supported address formats.
                                  If provided, connects to the specified server regardless of environment.
            serve_web_viewer: If True, serves a web viewer over HTTP on the given ``web_port`` and opens it in the browser.
                                     If False, spawns a native Rerun viewer (only outside Jupyter notebooks).
                                     Defaults to True.
            web_port: Port to serve the web viewer on. Only used if ``serve_web_viewer`` is True.
            grpc_port: Port to serve the gRPC server on.
            keep_historical_data: If True, keep historical data in the timeline of the web viewer.
                If False, the web viewer will only show the current frame to keep the memory usage constant when sending transform updates via :meth:`~newton.viewer.ViewerBase.log_state`.
                This is useful for visualizing long and complex simulations that would quickly fill up the web viewer's memory if the historical data was kept.
                If True, the historical simulation data is kept in the viewer to be able to scrub through the simulation timeline. Defaults to False.
            keep_scalar_history: If True, historical scala data logged via :meth:`ViewerRerun.log_scalar` is kept in the viewer.
            record_to_rrd: Path to record the viewer to a ``*.rrd`` recording file (e.g. "my_recording.rrd"). If None, the viewer will not record to a file.
        """
        if rr is None:
            raise ImportError("rerun package is required for ViewerRerun. Install with: pip install rerun-sdk")

        self._rerun_initialized = False
        super().__init__()

        self.app_id = app_id or "newton-viewer"
        self.rec_id = rec_id
        self._running = True
        self._viewer_process = None
        self.keep_historical_data = keep_historical_data
        self.keep_scalar_history = keep_scalar_history

        # Store mesh data for instances
        self._meshes = {}
        self._instances = {}

        # Store scalar data for logging
        self._scalars = {}

        # Initialize rerun using a blueprint that only shows the 3D view and a collapsed time panel
        blueprint = self._get_blueprint()
        rr.init(self.app_id, recording_id=self.rec_id, default_blueprint=blueprint)

        if record_to_rrd is not None:
            rr.save(record_to_rrd, default_blueprint=blueprint)

        try:
            self._mesh3d_params = set(inspect.signature(rr.Mesh3D).parameters)
        except Exception:
            self._mesh3d_params = set()

        self._grpc_server_uri = None

        # Launch viewer client
        self.is_jupyter_notebook = is_jupyter_notebook()
        if address is not None:
            rr.connect_grpc(address)
        elif not self.is_jupyter_notebook:
            if serve_web_viewer:
                self._grpc_server_uri = rr.serve_grpc(grpc_port=grpc_port, default_blueprint=blueprint)
                rr.serve_web_viewer(connect_to=self._grpc_server_uri, web_port=web_port)
                query = urlencode({"url": self._grpc_server_uri})
                print(f"Rerun web viewer running at: http://127.0.0.1:{web_port}/?{query}", flush=True)
            else:
                rr.spawn(port=grpc_port)

        # Make sure the timeline is set up
        rr.set_time("time", timestamp=0.0)
        self._rerun_initialized = True

    def _get_blueprint(self):
        scalar_panel = None
        if len(self._scalars) > 0:
            scalar_panel = rrb.TimeSeriesView()

        return rrb.Blueprint(
            rrb.Horizontal(
                *[rrb.Spatial3DView(), scalar_panel] if scalar_panel is not None else [rrb.Spatial3DView()],
            ),
            rrb.TimePanel(timeline="time", state="collapsed"),
            collapse_panels=True,
        )

    @override
    def clear_model(self):
        """Clear the active layer's local caches and Rerun entity subtree."""
        owns = self._is_layer_owned_path

        if getattr(self, "_rerun_initialized", False):
            prefix = self.layer.name_prefix
            if prefix:
                rr.log(prefix, rr.Clear(recursive=True))
            else:
                names = (
                    set(getattr(self, "_meshes", {}))
                    | set(getattr(self, "_instances", {}))
                    | set(getattr(self, "_scalars", {}))
                )
                for name in names:
                    if owns(name):
                        rr.log(name, rr.Clear(recursive=True))

        if hasattr(self, "_meshes"):
            self._meshes = {name: value for name, value in self._meshes.items() if not owns(name)}
        if hasattr(self, "_instances"):
            self._instances = {name: value for name, value in self._instances.items() if not owns(name)}
        if hasattr(self, "_scalars"):
            self._scalars = {name: value for name, value in self._scalars.items() if not owns(name)}

        super().clear_model()

    @override
    def log_mesh(
        self,
        name: str,
        points: wp.array[wp.vec3],
        indices: wp.array[wp.int32] | wp.array[wp.uint32],
        normals: wp.array[wp.vec3] | None = None,
        uvs: wp.array[wp.vec2] | None = None,
        texture: np.ndarray | str | None = None,
        hidden: bool = False,
        backface_culling: bool = True,
        color: tuple[float, float, float] | None = None,
        roughness: float | None = None,
        metallic: float | None = None,
        dynamic: bool = False,
        opacity: float | None = None,
    ):
        """
        Log a mesh to rerun for visualization.

        Args:
            name: Entity path for the mesh.
            points: Vertex positions.
            indices: Triangle indices.
            normals: Vertex normals.
            uvs: UV coordinates.
            texture: Optional texture path/URL or image array.
            hidden: Whether the mesh is hidden.
            backface_culling: Whether to enable backface culling (unused).
            color: Optional base color as an RGB tuple with values in
                [0, 1]. Used when no texture is provided.
            roughness: Surface roughness in ``[0, 1]``. ``0`` is perfectly
                smooth, ``1`` is fully rough.
            metallic: Metallicity in ``[0, 1]``. ``0`` is dielectric, ``1``
                is metal.
            dynamic: Whether mesh topology may change between frames.
            opacity: Optional display opacity in [0, 1].
        """
        name = self._qualify(name)
        previous_mesh = self._meshes.get(name)
        was_visible = isinstance(previous_mesh, dict) and previous_mesh.get("visible", False)

        if not hidden:
            assert isinstance(points, wp.array)
            assert isinstance(indices, wp.array)
            assert normals is None or isinstance(normals, wp.array)
            assert uvs is None or isinstance(uvs, wp.array)

        # Convert to numpy arrays
        points_np = to_numpy(points).astype(np.float32)
        indices_np = to_numpy(indices).astype(np.uint32)

        # Rerun expects indices as (N, 3) for triangles
        if indices_np.ndim == 1:
            indices_np = indices_np.reshape(-1, 3)

        if normals is None:
            if hidden and not (isinstance(points, wp.array) and isinstance(indices, wp.array)):
                # Hidden-mode callers can use lightweight array-like objects that are
                # incompatible with compute_vertex_normals.
                normals_np = None
            else:
                normals = compute_vertex_normals(points, indices, device=self.device)
                normals_np = to_numpy(normals)
        else:
            normals_np = to_numpy(normals)

        uvs_np = to_numpy(uvs).astype(np.float32) if uvs is not None else None
        texture_image = prepare_viewer_texture(texture)

        if uvs_np is not None and len(uvs_np) != len(points_np):
            uvs_np = None
            texture_image = None
        if texture_image is not None and uvs_np is None:
            texture_image = None

        if uvs_np is not None:
            uvs_np = self._flip_uvs_for_rerun(uvs_np)

        texture_buffer = None
        texture_format = None
        if texture_image is not None and self._mesh3d_supports("albedo_texture_buffer"):
            texture_buffer, texture_format = self._build_texture_components(texture_image)

        # make sure deformable mesh updates are not kept in the viewer if desired
        static = name in self._meshes and not self.keep_historical_data

        # Store mesh data for instancing
        self._meshes[name] = {
            "points": points_np,
            "indices": indices_np,
            "normals": normals_np,
            "uvs": uvs_np,
            "texture_image": texture_image,
            "texture_buffer": texture_buffer,
            "texture_format": texture_format,
            "opacity": opacity,
            "color": color,
            "visible": not hidden,
        }

        if hidden:
            if was_visible:
                rr.log(name, rr.Clear(recursive=False))
            return

        mesh_kwargs = {
            "vertex_positions": points_np,
            "triangle_indices": indices_np,
            "vertex_normals": self._meshes[name]["normals"],
        }
        if uvs_np is not None and self._mesh3d_supports("vertex_texcoords"):
            mesh_kwargs["vertex_texcoords"] = uvs_np
        if texture_buffer is not None and texture_format is not None:
            mesh_kwargs["albedo_texture_buffer"] = texture_buffer
            mesh_kwargs["albedo_texture_format"] = texture_format
        elif texture_image is not None and self._mesh3d_supports("albedo_texture"):
            mesh_kwargs["albedo_texture"] = texture_image

        if opacity is not None or color is not None:
            opacity_u8 = self._opacity_to_u8(opacity)
            has_texture = texture_buffer is not None or texture_image is not None
            if not has_texture:
                vertex_color = self._rgb_to_u8(color)
                mesh_kwargs["vertex_colors"] = np.tile(vertex_color, (len(points_np), 1))
                if opacity is not None and self._mesh3d_supports("albedo_factor"):
                    mesh_kwargs["albedo_factor"] = (255, 255, 255, opacity_u8)
            elif self._mesh3d_supports("albedo_factor"):
                base_rgb = self._rgb_to_u8(color, default=(255, 255, 255))
                mesh_kwargs["albedo_factor"] = (*base_rgb.tolist(), opacity_u8)

        # Log the mesh as a static asset
        mesh_3d = self._call_rr_constructor(rr.Mesh3D, **mesh_kwargs)

        rr.log(name, mesh_3d, static=static)

    @override
    def log_instances(
        self,
        name: str,
        mesh: str,
        xforms: wp.array[wp.transform] | None,
        scales: wp.array[wp.vec3] | None,
        colors: wp.array[wp.vec3] | None,
        materials: wp.array[wp.vec4] | None,
        hidden: bool = False,
        opacities: wp.array[wp.float32] | None = None,
    ):
        """
        Log instanced mesh data to rerun using InstancePoses3D.

        Args:
            name: Entity path for the instances.
            mesh: Name of the mesh asset to instance.
            xforms: Instance transforms.
            scales: Instance scales.
            colors: Instance colors.
            materials: Instance materials.
            hidden: Whether the instances are hidden.
            opacities: Instance opacities.
        """
        name = self._qualify(name)
        mesh = self._qualify(mesh)

        if hidden:
            if name in self._instances:
                rr.log(name, rr.Clear(recursive=False))
                self._instances.pop(name, None)
            return

        # Check that mesh exists
        if mesh not in self._meshes:
            raise RuntimeError(f"Mesh {mesh} not found. Call log_mesh first.")

        # re-run needs to generate a new mesh for each instancer
        appearance_changed = colors is not None or opacities is not None
        if name not in self._instances or appearance_changed:
            mesh_data = self._meshes[mesh]
            previous_appearance = self._instances.get(name)
            if not isinstance(previous_appearance, dict):
                previous_appearance = {}
            has_texture = (
                mesh_data.get("texture_buffer") is not None and mesh_data.get("texture_format") is not None
            ) or mesh_data.get("texture_image") is not None

            # Rerun poses do not carry per-instance appearance, so bake one
            # representative color/opacity into the mesh logged for this batch.
            vertex_colors = None
            albedo_factor = None
            first_opacity = 1.0
            num_instances = len(xforms) if xforms is not None else 0
            opacity_source = opacities
            if opacity_source is None:
                opacity_source = previous_appearance.get("opacities", mesh_data.get("opacity"))
            opacities_np = promote_to_clamped_float_array(
                opacity_source,
                num_instances,
                value_name="Opacity",
            )
            if opacities_np is not None and len(opacities_np) > 0:
                first_opacity = float(opacities_np[0])
                if not np.allclose(opacities_np, first_opacity):
                    warnings.warn(
                        "ViewerRerun does not support per-instance opacity; using the first opacity for the batch.",
                        stacklevel=2,
                    )
            if colors is not None and not has_texture:
                colors_np = to_numpy(colors).astype(np.float32)
                # Take the first instance's color and apply to all vertices
                color_rgb = self._rgb_to_u8(colors_np[0])
                num_vertices = len(mesh_data["points"])
                vertex_colors = np.tile(color_rgb, (num_vertices, 1))
                if opacities_np is not None and self._mesh3d_supports("albedo_factor"):
                    albedo_factor = (255, 255, 255, self._opacity_to_u8(first_opacity))
            elif previous_appearance.get("vertex_colors") is not None and not has_texture:
                vertex_colors = previous_appearance["vertex_colors"].copy()
                if opacities_np is not None and self._mesh3d_supports("albedo_factor"):
                    previous_albedo = previous_appearance.get("albedo_factor")
                    albedo_rgb = (255, 255, 255) if previous_albedo is None else tuple(previous_albedo[:3])
                    albedo_factor = (*albedo_rgb, self._opacity_to_u8(first_opacity))
            elif (opacities_np is not None or mesh_data.get("color") is not None) and not has_texture:
                base_rgb = self._rgb_to_u8(mesh_data.get("color"))
                num_vertices = len(mesh_data["points"])
                vertex_colors = np.tile(base_rgb, (num_vertices, 1))
                if opacities_np is not None and self._mesh3d_supports("albedo_factor"):
                    albedo_factor = (255, 255, 255, self._opacity_to_u8(first_opacity))
            elif (
                opacities_np is not None or colors is not None or mesh_data.get("color") is not None
            ) and self._mesh3d_supports("albedo_factor"):
                previous_albedo = previous_appearance.get("albedo_factor")
                if colors is not None:
                    base_rgb = self._rgb_to_u8(to_numpy(colors)[0], default=(255, 255, 255))
                elif previous_albedo is not None:
                    base_rgb = np.asarray(previous_albedo[:3], dtype=np.uint8)
                else:
                    base_rgb = self._rgb_to_u8(mesh_data.get("color"), default=(255, 255, 255))
                albedo_factor = (*base_rgb.tolist(), self._opacity_to_u8(first_opacity))

            # Log the base mesh with optional colors
            mesh_kwargs = {
                "vertex_positions": mesh_data["points"],
                "triangle_indices": mesh_data["indices"],
                "vertex_normals": mesh_data["normals"],
            }
            if vertex_colors is not None:
                mesh_kwargs["vertex_colors"] = vertex_colors
            if albedo_factor is not None:
                mesh_kwargs["albedo_factor"] = albedo_factor
            if mesh_data.get("uvs") is not None and self._mesh3d_supports("vertex_texcoords"):
                mesh_kwargs["vertex_texcoords"] = mesh_data["uvs"]
            if mesh_data.get("texture_buffer") is not None and mesh_data.get("texture_format") is not None:
                mesh_kwargs["albedo_texture_buffer"] = mesh_data["texture_buffer"]
                mesh_kwargs["albedo_texture_format"] = mesh_data["texture_format"]
            elif mesh_data.get("texture_image") is not None and self._mesh3d_supports("albedo_texture"):
                mesh_kwargs["albedo_texture"] = mesh_data["texture_image"]

            mesh_3d = self._call_rr_constructor(rr.Mesh3D, **mesh_kwargs)
            rr.log(name, mesh_3d)

            self._instances[name] = {
                "mesh_3d": mesh_3d,
                "vertex_colors": vertex_colors,
                "albedo_factor": albedo_factor,
                "opacities": None if opacities_np is None else opacities_np.copy(),
            }

            # hide the reference mesh
            rr.log(mesh, rr.Clear(recursive=False))

        # Convert transforms and properties to numpy
        if xforms is not None:
            # Convert warp arrays to numpy first
            xforms_np = to_numpy(xforms)

            # Extract positions and quaternions using vectorized operations
            # Warp transform format: [x, y, z, qx, qy, qz, qw]
            translations = xforms_np[:, :3].astype(np.float32)

            # Warp quaternion is in (x, y, z, w) order,
            # rerun expects (x, y, z, w) for Quaternion datatype
            quaternions = xforms_np[:, 3:7].astype(np.float32)

            scales_np = None
            if scales is not None:
                scales_np = to_numpy(scales).astype(np.float32)

            # Colors are already handled in the mesh
            # (first instance color applied to all)

            # Create instance poses
            instance_poses = rr.InstancePoses3D(
                translations=translations,
                quaternions=quaternions,
                scales=scales_np,
            )

            # Log the instance poses
            rr.log(name, instance_poses, static=not self.keep_historical_data)

    @override
    def begin_frame(self, time: float):
        """
        Begin a new frame and set the timeline for rerun.

        Args:
            time: The current simulation time.
        """
        self.time = time
        # Set the timeline for this frame
        rr.set_time("time", timestamp=time)

    @override
    def end_frame(self):
        """
        End the current frame.

        Note:
            Rerun handles frame finishing automatically.
        """
        # Rerun handles frame finishing automatically
        pass

    @override
    def is_running(self) -> bool:
        """
        Check if the viewer is still running.

        Returns:
            bool: True if the viewer is running, False otherwise.
        """
        # Check if viewer process is still alive
        if self._viewer_process is not None:
            return self._viewer_process.poll() is None
        return self._running

    @override
    def close(self):
        """
        Close the viewer and clean up resources.

        This will terminate any spawned viewer process and disconnect from rerun.
        """
        self._running = False

        # Close viewer process if we spawned one
        if self._viewer_process is not None:
            try:
                self._viewer_process.terminate()
                self._viewer_process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                self._viewer_process.kill()
            except Exception:
                pass
            self._viewer_process = None

        # Disconnect from rerun
        try:
            rr.disconnect()
        except Exception:
            pass

    @override
    def apply_forces(self, state: newton.State):
        """Rerun backend does not apply interactive forces.

        Args:
            state: Current simulation state.
        """
        pass

    @override
    def log_lines(
        self,
        name: str,
        starts: wp.array[wp.vec3] | None,
        ends: wp.array[wp.vec3] | None,
        colors: (wp.array[wp.vec3] | wp.array[wp.float32] | tuple[float, float, float] | list[float] | None),
        width: float = 0.01,
        hidden: bool = False,
    ):
        """
        Log lines for visualization.

        Args:
            name: Name of the line batch.
            starts: Line start points.
            ends: Line end points.
            colors: Line colors.
            width: Line width.
            hidden: Whether the lines are hidden.
        """
        name = self._qualify(name)

        if hidden:
            rr.log(name, rr.Clear(recursive=False))
            return  # Do not log hidden lines

        if starts is None or ends is None:
            rr.log(name, rr.Clear(recursive=False))
            return  # Nothing to log

        # Convert inputs to numpy for rerun API compatibility
        # Expecting starts/ends as wp arrays or numpy arrays
        starts_np = to_numpy(starts)
        ends_np = to_numpy(ends)
        colors_np = to_numpy(colors) if colors is not None else None

        # Both starts and ends should be (N, 3)
        if starts_np is None or ends_np is None or len(starts_np) == 0:
            return

        # LineStrips3D expects a list of line strips, where each strip is a sequence of points
        # For disconnected line segments, each segment becomes its own strip of 2 points
        line_strips = []
        for start, end in zip(starts_np, ends_np, strict=False):
            line_strips.append([start, end])

        # Prepare line color argument
        rr_kwargs = {}
        if colors_np is not None:
            # If single color for all lines (shape (3,))
            if colors_np.ndim == 1 and colors_np.shape[0] == 3:
                rr_kwargs["colors"] = colors_np
            # If (N,3), per-line colors
            elif colors_np.ndim == 2 and colors_np.shape[1] == 3:
                rr_kwargs["colors"] = colors_np
        if width is not None:
            rr_kwargs["radii"] = width

        # Log to rerun
        rr.log(name, rr.LineStrips3D(line_strips, **rr_kwargs), static=not self.keep_historical_data)

    @override
    def log_array(self, name: str, array: wp.array[Any] | np.ndarray):
        """
        Log a generic array for visualization.

        Args:
            name: Name of the array.
            array: The array data (can be a wp.array or a numpy array).
        """
        name = self._qualify(name)

        if array is None:
            return
        array_np = to_numpy(array)
        rr.log(name, rr.Scalars(array_np), static=not self.keep_historical_data)

    @override
    def log_scalar(self, name: str, value: int | float | bool | np.number, *, clear: bool = False, smoothing: int = 1):
        """
        Log a scalar value for visualization.

        Args:
            name: Name of the scalar.
            value: The scalar value.
        """
        # Basic scalar logging for rerun: log as a 'Scalar' component (if present)
        if name is None:
            return
        name = self._qualify(name)

        # Only support standard Python/numpy scalars, not generic objects for now
        if hasattr(value, "item"):
            val = value.item()
        else:
            val = value
        rr.log(name, rr.Scalars(val), static=not self.keep_scalar_history)

        if len(self._scalars) == 0:
            self._scalars[name] = val
            blueprint = self._get_blueprint()
            rr.send_blueprint(blueprint)
        else:
            self._scalars[name] = val

    @override
    def log_geo(
        self,
        name: str,
        geo_type: int,
        geo_scale: tuple[float, ...],
        geo_thickness: float,
        geo_is_solid: bool,
        geo_src: newton.Mesh | newton.Heightfield | None = None,
        hidden: bool = False,
    ):
        """Log a geometry primitive, with plane expansion for infinite planes.

        Args:
            name: Unique path/name for the geometry asset.
            geo_type: Geometry type value from `newton.GeoType`.
            geo_scale: Geometry scale tuple interpreted by `geo_type`.
            geo_thickness: Shell thickness for mesh-like geometry.
            geo_is_solid: Whether mesh geometry is treated as solid.
            geo_src: Optional source geometry for mesh-backed types.
            hidden: Whether the resulting geometry is hidden.
        """
        # Generate vertices/indices for supported primitive types
        if geo_type == newton.GeoType.PLANE:
            # Handle "infinite" planes encoded with non-positive scales
            if geo_scale[0] == 0.0 or geo_scale[1] == 0.0:
                extents = self._get_world_extents()
                if extents is None:
                    width, length = 10.0, 10.0
                else:
                    max_extent = max(extents) * 1.5
                    width = max_extent
                    length = max_extent
            else:
                width = geo_scale[0]
                length = geo_scale[1] if len(geo_scale) > 1 else 10.0
            mesh = newton.Mesh.create_plane(width, length, compute_inertia=False)
            points = wp.array(mesh.vertices, dtype=wp.vec3, device=self.device)
            normals = wp.array(mesh.normals, dtype=wp.vec3, device=self.device)
            uvs = wp.array(mesh.uvs, dtype=wp.vec2, device=self.device)
            indices = wp.array(mesh.indices, dtype=wp.int32, device=self.device)
            self.log_mesh(name, points, indices, normals, uvs, hidden=hidden)
        else:
            super().log_geo(name, geo_type, geo_scale, geo_thickness, geo_is_solid, geo_src, hidden)

    @override
    def log_points(
        self,
        name: str,
        points: wp.array[wp.vec3] | None,
        radii: wp.array[wp.float32] | float | None = None,
        colors: (wp.array[wp.vec3] | wp.array[wp.float32] | tuple[float, float, float] | list[float] | None) = None,
        hidden: bool = False,
    ):
        """
        Log points for visualization.

        Args:
            name: Name of the point batch.
            points: Point positions (can be a wp.array or a numpy array).
            radii: Point radii (can be a wp.array or a numpy array).
            colors: Point colors (can be a wp.array or a numpy array).
            hidden: Whether the points are hidden.
        """
        name = self._qualify(name)

        if hidden:
            # Optionally, skip logging hidden points
            rr.log(name, rr.Clear(recursive=False))
            return

        if points is None:
            rr.log(name, rr.Clear(recursive=False))
            return

        pts = to_numpy(points)
        n_points = pts.shape[0]

        # Handle radii (point size)
        if radii is not None:
            size = to_numpy(radii)
            if size.ndim == 0 or size.shape == ():
                sizes = np.full((n_points,), float(size))
            elif size.shape == (n_points,):
                sizes = size
            else:
                sizes = np.full((n_points,), 0.1)
        else:
            sizes = np.full((n_points,), 0.1)

        # Handle colors
        if colors is not None:
            cols = to_numpy(colors)
            if cols.shape == (n_points, 3):
                colors_val = cols
            elif cols.shape == (3,):
                colors_val = np.tile(cols, (n_points, 1))
            else:
                colors_val = np.full((n_points, 3), 1.0)
        else:
            colors_val = np.full((n_points, 3), 1.0)

        # Log as points to rerun
        rr.log(
            name,
            rr.Points3D(
                positions=pts,
                radii=sizes,
                colors=colors_val,
            ),
            static=not self.keep_historical_data,
        )

    def show_notebook(self, width: int = 1000, height: int = 400, legacy_notebook_show: bool = False):
        """
        Show the viewer in a Jupyter notebook.

        Args:
            width: Width of the viewer in pixels.
            height: Height of the viewer in pixels.
            legacy_notebook_show: Whether to use ``rr.legacy_notebook_show`` instead of ``rr.notebook_show`` for displaying the viewer as static HTML with embedded recording data.
        """
        if legacy_notebook_show and self.is_jupyter_notebook:
            rr.legacy_notebook_show(width=width, height=height, blueprint=self._get_blueprint())
        else:
            rr.notebook_show(width=width, height=height, blueprint=self._get_blueprint())

    def _ipython_display_(self):
        """
        Display the viewer in an IPython notebook when the viewer is at the end of a cell.
        """
        self.show_notebook()

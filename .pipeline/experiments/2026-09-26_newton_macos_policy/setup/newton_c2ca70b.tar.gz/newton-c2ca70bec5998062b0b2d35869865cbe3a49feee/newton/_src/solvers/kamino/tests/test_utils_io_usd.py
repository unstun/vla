# SPDX-FileCopyrightText: Copyright (c) 2025 The Newton Developers
# SPDX-License-Identifier: Apache-2.0

"""Unit tests for the USD importer utility."""

import math
import unittest

import numpy as np
import warp as wp

import newton
from newton import Model, ModelBuilder
from newton._src.core.types import Axis
from newton._src.geometry.flags import ShapeFlags
from newton._src.geometry.types import GeoType
from newton._src.solvers.kamino import SolverKamino
from newton._src.solvers.kamino._src.core.builder import ModelBuilderKamino
from newton._src.solvers.kamino._src.core.gravity import GravityDescriptor
from newton._src.solvers.kamino._src.core.joints import JOINT_QMAX, JOINT_QMIN, JointActuationType, JointDoFType
from newton._src.solvers.kamino._src.models.builders import basics
from newton._src.solvers.kamino._src.utils import logger as msg
from newton._src.solvers.kamino._src.utils.io.usd import USDImporter
from newton._src.solvers.kamino.tests import setup_tests, test_context
from newton.tests import get_kamino_basics_asset, get_kamino_testing_asset
from newton.tests.kamino.utils.checks import assert_builders_equal
from newton.tests.unittest_utils import USD_AVAILABLE

###
# Tests
###


class TestUSDImporter(unittest.TestCase):
    def setUp(self):
        if not test_context.setup_done:
            setup_tests(clear_cache=False)
        self.default_device = wp.get_device(test_context.device)
        self.verbose = test_context.verbose  # Set to True for verbose output

        # Set debug-level logging to print verbose test output to console
        if self.verbose:
            print("\n")  # Add newline before test output for better readability
            msg.set_log_level(msg.LogLevel.DEBUG)
        else:
            msg.reset_log_level()

    def tearDown(self):
        self.default_device = None
        if self.verbose:
            msg.reset_log_level()

    def test_gravity_descriptor_from_usd_default_magnitude(self):
        """Resolve OpenUSD's negative-infinity gravity sentinel."""
        gravity = GravityDescriptor.from_usd((0.0, 0.0, 0.0), -float("inf"), Axis.Y, 1.0)

        np.testing.assert_array_equal(gravity.vector, np.array([0.0, -9.81, 0.0], dtype=np.float32))

    def test_gravity_descriptor_from_usd_negative_magnitude(self):
        """Preserve an explicitly authored negative gravity magnitude."""
        gravity = GravityDescriptor.from_usd((0.0, 0.0, -1.0), -1.0, Axis.Y, 1.0)

        np.testing.assert_array_equal(gravity.vector, np.array([0.0, 0.0, 1.0], dtype=np.float32))

    def test_gravity_descriptor_from_usd_explicit_values(self):
        """Normalize and scale explicitly authored OpenUSD gravity."""
        gravity = GravityDescriptor.from_usd((3.0, 4.0, 0.0), 8.0, Axis.Z, 0.5)

        np.testing.assert_allclose(gravity.vector, np.array([2.4, 3.2, 0.0], dtype=np.float32))

    @unittest.skipUnless(USD_AVAILABLE, "Requires usd-core")
    def test_import_default_physics_scene_gravity(self):
        """Import the resolved default gravity of a USD physics scene."""
        from pxr import Usd, UsdGeom, UsdPhysics

        stage = Usd.Stage.CreateInMemory()
        UsdGeom.SetStageUpAxis(stage, UsdGeom.Tokens.y)
        UsdGeom.SetStageMetersPerUnit(stage, 1.0)
        UsdPhysics.Scene.Define(stage, "/PhysicsScene")

        builder = USDImporter().import_from(stage, load_static_geometry=False, load_materials=False)

        np.testing.assert_array_equal(builder.gravity[0].vector, np.array([0.0, -9.81, 0.0], dtype=np.float32))

    @unittest.skipUnless(USD_AVAILABLE, "Requires usd-core")
    def test_import_zero_gravity_uses_stage_up_axis(self):
        """Retain the stage up axis when imported gravity is zero."""
        from pxr import Usd, UsdGeom, UsdPhysics

        stage = Usd.Stage.CreateInMemory()
        UsdGeom.SetStageUpAxis(stage, UsdGeom.Tokens.y)
        UsdGeom.SetStageMetersPerUnit(stage, 1.0)
        scene = UsdPhysics.Scene.Define(stage, "/PhysicsScene")
        scene.CreateGravityMagnitudeAttr(0.0)

        builder = USDImporter().import_from(stage, load_static_geometry=False, load_materials=False)

        self.assertEqual(builder.up_axes[0], Axis.Y)
        np.testing.assert_array_equal(builder.gravity[0].vector, np.zeros(3, dtype=np.float32))

    ###
    # Joints supported natively by USD
    ###

    @unittest.skipUnless(USD_AVAILABLE, "Requires usd-core")
    def test_preserve_floating_articulation_root_free_joint_with_loop(self):
        """Test preserving a floating root while importing a loop without tree sorting."""
        from pxr import Gf, Usd, UsdGeom, UsdPhysics

        stage = Usd.Stage.CreateInMemory()
        root = UsdGeom.Cube.Define(stage, "/Root")
        child = UsdGeom.Cube.Define(stage, "/Child")
        for body in (root, child):
            UsdPhysics.RigidBodyAPI.Apply(body.GetPrim())
            mass = UsdPhysics.MassAPI.Apply(body.GetPrim())
            mass.CreateMassAttr(1.0)
            mass.CreateDiagonalInertiaAttr(Gf.Vec3f(1.0, 1.0, 1.0))
        UsdPhysics.ArticulationRootAPI.Apply(root.GetPrim())

        primary = UsdPhysics.FixedJoint.Define(stage, "/Primary")
        primary.CreateBody0Rel().SetTargets([root.GetPath()])
        primary.CreateBody1Rel().SetTargets([child.GetPath()])
        loop = UsdPhysics.FixedJoint.Define(stage, "/Loop")
        loop.CreateBody0Rel().SetTargets([child.GetPath()])
        loop.CreateBody1Rel().SetTargets([root.GetPath()])
        loop.CreateExcludeFromArticulationAttr().Set(True)

        builder = USDImporter().import_from(stage, load_static_geometry=False, load_materials=False)

        self.assertEqual(builder.num_joints, 3)
        self.assertEqual(builder.num_joint_coords, 7)
        self.assertEqual(builder.num_joint_dofs, 6)
        self.assertEqual([joint.name for joint in builder.joints[0]], ["world_to_Root", "Primary", "Loop"])
        self.assertEqual(builder.joints[0][0].dof_type, JointDoFType.FREE)

        model = builder.finalize(device=self.default_device)
        self.assertEqual(model.info.base_joint_index.numpy().tolist(), [0])

    def test_import_joint_revolute_passive_unary(self):
        """Test importing a passive revolute joint with limits from a USD file"""
        usd_asset_filename = get_kamino_testing_asset("joints/test_joint_revolute_passive_unary.usda")
        importer = USDImporter()
        builder_usd: ModelBuilderKamino = importer.import_from(source=usd_asset_filename)
        # Check the loaded contents
        self.assertEqual(builder_usd.num_bodies, 1)
        self.assertEqual(builder_usd.num_joints, 1)
        self.assertEqual(builder_usd.joints[0][0].act_type, JointActuationType.PASSIVE)
        self.assertEqual(builder_usd.joints[0][0].dof_type, JointDoFType.REVOLUTE)
        self.assertEqual(builder_usd.joints[0][0].wid, 0)
        self.assertEqual(builder_usd.joints[0][0].jid, 0)
        self.assertEqual(builder_usd.joints[0][0].bilateral_cts_offset, 0)
        self.assertEqual(builder_usd.joints[0][0].dofs_offset, 0)
        self.assertEqual(builder_usd.joints[0][0].bid_B, -1)
        self.assertEqual(builder_usd.joints[0][0].bid_F, 0)
        self.assertEqual(len(builder_usd.joints[0][0].q_j_min), 1)
        self.assertEqual(len(builder_usd.joints[0][0].q_j_max), 1)
        self.assertEqual(len(builder_usd.joints[0][0].tau_j_max), 1)
        self.assertEqual(builder_usd.joints[0][0].q_j_min, [-0.5 * math.pi])
        self.assertEqual(builder_usd.joints[0][0].q_j_max, [0.5 * math.pi])

    def test_import_joint_revolute_passive(self):
        """Test importing a passive revolute joint with limits from a USD file"""
        usd_asset_filename = get_kamino_testing_asset("joints/test_joint_revolute_passive.usda")
        importer = USDImporter()
        builder_usd: ModelBuilderKamino = importer.import_from(source=usd_asset_filename)
        # Check the loaded contents
        self.assertEqual(builder_usd.num_bodies, 2)
        self.assertEqual(builder_usd.num_joints, 1)
        self.assertEqual(builder_usd.joints[0][0].act_type, JointActuationType.PASSIVE)
        self.assertEqual(builder_usd.joints[0][0].dof_type, JointDoFType.REVOLUTE)
        self.assertEqual(builder_usd.joints[0][0].wid, 0)
        self.assertEqual(builder_usd.joints[0][0].jid, 0)
        self.assertEqual(builder_usd.joints[0][0].bilateral_cts_offset, 0)
        self.assertEqual(builder_usd.joints[0][0].dofs_offset, 0)
        self.assertEqual(builder_usd.joints[0][0].bid_B, 0)
        self.assertEqual(builder_usd.joints[0][0].bid_F, 1)
        self.assertEqual(len(builder_usd.joints[0][0].q_j_min), 1)
        self.assertEqual(len(builder_usd.joints[0][0].q_j_max), 1)
        self.assertEqual(len(builder_usd.joints[0][0].tau_j_max), 1)
        self.assertEqual(builder_usd.joints[0][0].q_j_min, [-0.5 * math.pi])
        self.assertEqual(builder_usd.joints[0][0].q_j_max, [0.5 * math.pi])

    def test_import_joint_revolute_actuated(self):
        """Test importing a actuated revolute joint with limits from a USD file"""
        usd_asset_filename = get_kamino_testing_asset("joints/test_joint_revolute_actuated.usda")
        importer = USDImporter()
        builder_usd: ModelBuilderKamino = importer.import_from(source=usd_asset_filename)
        # Check the loaded contents
        self.assertEqual(builder_usd.num_bodies, 2)
        self.assertEqual(builder_usd.num_joints, 1)
        self.assertEqual(builder_usd.joints[0][0].act_type, JointActuationType.FORCE)
        self.assertEqual(builder_usd.joints[0][0].dof_type, JointDoFType.REVOLUTE)
        self.assertEqual(builder_usd.joints[0][0].wid, 0)
        self.assertEqual(builder_usd.joints[0][0].jid, 0)
        self.assertEqual(builder_usd.joints[0][0].bilateral_cts_offset, 0)
        self.assertEqual(builder_usd.joints[0][0].dofs_offset, 0)
        self.assertEqual(builder_usd.joints[0][0].bid_B, 0)
        self.assertEqual(builder_usd.joints[0][0].bid_F, 1)
        self.assertEqual(len(builder_usd.joints[0][0].q_j_min), 1)
        self.assertEqual(len(builder_usd.joints[0][0].q_j_max), 1)
        self.assertEqual(len(builder_usd.joints[0][0].tau_j_max), 1)
        self.assertEqual(builder_usd.joints[0][0].q_j_min, [-0.5 * math.pi])
        self.assertEqual(builder_usd.joints[0][0].q_j_max, [0.5 * math.pi])
        self.assertEqual(builder_usd.joints[0][0].tau_j_max, [100.0])

    def test_import_joint_prismatic_passive_unary(self):
        """Test importing a passive prismatic joint with limits from a USD file"""
        usd_asset_filename = get_kamino_testing_asset("joints/test_joint_prismatic_passive_unary.usda")
        importer = USDImporter()
        builder_usd: ModelBuilderKamino = importer.import_from(source=usd_asset_filename)
        # Check the loaded contents
        self.assertEqual(builder_usd.num_bodies, 1)
        self.assertEqual(builder_usd.num_joints, 1)
        self.assertEqual(builder_usd.joints[0][0].act_type, JointActuationType.PASSIVE)
        self.assertEqual(builder_usd.joints[0][0].dof_type, JointDoFType.PRISMATIC)
        self.assertEqual(builder_usd.joints[0][0].wid, 0)
        self.assertEqual(builder_usd.joints[0][0].jid, 0)
        self.assertEqual(builder_usd.joints[0][0].bilateral_cts_offset, 0)
        self.assertEqual(builder_usd.joints[0][0].dofs_offset, 0)
        self.assertEqual(builder_usd.joints[0][0].bid_B, -1)
        self.assertEqual(builder_usd.joints[0][0].bid_F, 0)
        self.assertEqual(len(builder_usd.joints[0][0].q_j_min), 1)
        self.assertEqual(len(builder_usd.joints[0][0].q_j_max), 1)
        self.assertEqual(len(builder_usd.joints[0][0].tau_j_max), 1)
        self.assertEqual(builder_usd.joints[0][0].q_j_min, [-1.0])
        self.assertEqual(builder_usd.joints[0][0].q_j_max, [1.0])

    def test_import_joint_prismatic_passive(self):
        """Test importing a passive prismatic joint with limits from a USD file"""
        usd_asset_filename = get_kamino_testing_asset("joints/test_joint_prismatic_passive.usda")
        importer = USDImporter()
        builder_usd: ModelBuilderKamino = importer.import_from(source=usd_asset_filename)
        # Check the loaded contents
        self.assertEqual(builder_usd.num_bodies, 2)
        self.assertEqual(builder_usd.num_joints, 1)
        self.assertEqual(builder_usd.joints[0][0].act_type, JointActuationType.PASSIVE)
        self.assertEqual(builder_usd.joints[0][0].dof_type, JointDoFType.PRISMATIC)
        self.assertEqual(builder_usd.joints[0][0].wid, 0)
        self.assertEqual(builder_usd.joints[0][0].jid, 0)
        self.assertEqual(builder_usd.joints[0][0].bilateral_cts_offset, 0)
        self.assertEqual(builder_usd.joints[0][0].dofs_offset, 0)
        self.assertEqual(builder_usd.joints[0][0].bid_B, 0)
        self.assertEqual(builder_usd.joints[0][0].bid_F, 1)
        self.assertEqual(len(builder_usd.joints[0][0].q_j_min), 1)
        self.assertEqual(len(builder_usd.joints[0][0].q_j_max), 1)
        self.assertEqual(len(builder_usd.joints[0][0].tau_j_max), 1)
        self.assertEqual(builder_usd.joints[0][0].q_j_min, [-1.0])
        self.assertEqual(builder_usd.joints[0][0].q_j_max, [1.0])

    def test_import_joint_prismatic_actuated(self):
        """Test importing a actuated prismatic joint with limits from a USD file"""
        usd_asset_filename = get_kamino_testing_asset("joints/test_joint_prismatic_actuated.usda")
        importer = USDImporter()
        builder_usd: ModelBuilderKamino = importer.import_from(source=usd_asset_filename)
        # Check the loaded contents
        self.assertEqual(builder_usd.num_bodies, 2)
        self.assertEqual(builder_usd.num_joints, 1)
        self.assertEqual(builder_usd.joints[0][0].act_type, JointActuationType.FORCE)
        self.assertEqual(builder_usd.joints[0][0].dof_type, JointDoFType.PRISMATIC)
        self.assertEqual(builder_usd.joints[0][0].wid, 0)
        self.assertEqual(builder_usd.joints[0][0].jid, 0)
        self.assertEqual(builder_usd.joints[0][0].bilateral_cts_offset, 0)
        self.assertEqual(builder_usd.joints[0][0].dofs_offset, 0)
        self.assertEqual(builder_usd.joints[0][0].bid_B, 0)
        self.assertEqual(builder_usd.joints[0][0].bid_F, 1)
        self.assertEqual(len(builder_usd.joints[0][0].q_j_min), 1)
        self.assertEqual(len(builder_usd.joints[0][0].q_j_max), 1)
        self.assertEqual(len(builder_usd.joints[0][0].tau_j_max), 1)
        self.assertEqual(builder_usd.joints[0][0].q_j_min, [-1.0])
        self.assertEqual(builder_usd.joints[0][0].q_j_max, [1.0])
        self.assertEqual(builder_usd.joints[0][0].tau_j_max, [100.0])

    def test_import_joint_spherical_unary(self):
        """Test importing a passive spherical joint with limits from a USD file"""
        usd_asset_filename = get_kamino_testing_asset("joints/test_joint_spherical_unary.usda")
        importer = USDImporter()
        builder_usd: ModelBuilderKamino = importer.import_from(source=usd_asset_filename)
        # Check the loaded contents
        self.assertEqual(builder_usd.num_bodies, 1)
        self.assertEqual(builder_usd.num_joints, 1)
        self.assertEqual(builder_usd.joints[0][0].act_type, JointActuationType.PASSIVE)
        self.assertEqual(builder_usd.joints[0][0].dof_type, JointDoFType.SPHERICAL)
        self.assertEqual(builder_usd.joints[0][0].wid, 0)
        self.assertEqual(builder_usd.joints[0][0].jid, 0)
        self.assertEqual(builder_usd.joints[0][0].bilateral_cts_offset, 0)
        self.assertEqual(builder_usd.joints[0][0].dofs_offset, 0)
        self.assertEqual(builder_usd.joints[0][0].bid_B, -1)
        self.assertEqual(builder_usd.joints[0][0].bid_F, 0)
        self.assertEqual(len(builder_usd.joints[0][0].q_j_min), 3)
        self.assertEqual(len(builder_usd.joints[0][0].q_j_max), 3)
        self.assertEqual(len(builder_usd.joints[0][0].tau_j_max), 3)
        self.assertEqual(builder_usd.joints[0][0].q_j_min, [JOINT_QMIN, JOINT_QMIN, JOINT_QMIN])
        self.assertEqual(builder_usd.joints[0][0].q_j_max, [JOINT_QMAX, JOINT_QMAX, JOINT_QMAX])

    def test_import_joint_spherical(self):
        """Test importing a passive spherical joint with limits from a USD file"""
        usd_asset_filename = get_kamino_testing_asset("joints/test_joint_spherical.usda")
        importer = USDImporter()
        builder_usd: ModelBuilderKamino = importer.import_from(source=usd_asset_filename)
        # Check the loaded contents
        self.assertEqual(builder_usd.num_bodies, 2)
        self.assertEqual(builder_usd.num_joints, 1)
        self.assertEqual(builder_usd.joints[0][0].act_type, JointActuationType.PASSIVE)
        self.assertEqual(builder_usd.joints[0][0].dof_type, JointDoFType.SPHERICAL)
        self.assertEqual(builder_usd.joints[0][0].wid, 0)
        self.assertEqual(builder_usd.joints[0][0].jid, 0)
        self.assertEqual(builder_usd.joints[0][0].bilateral_cts_offset, 0)
        self.assertEqual(builder_usd.joints[0][0].dofs_offset, 0)
        self.assertEqual(builder_usd.joints[0][0].bid_B, 0)
        self.assertEqual(builder_usd.joints[0][0].bid_F, 1)
        self.assertEqual(len(builder_usd.joints[0][0].q_j_min), 3)
        self.assertEqual(len(builder_usd.joints[0][0].q_j_max), 3)
        self.assertEqual(len(builder_usd.joints[0][0].tau_j_max), 3)
        self.assertEqual(builder_usd.joints[0][0].q_j_min, [JOINT_QMIN, JOINT_QMIN, JOINT_QMIN])
        self.assertEqual(builder_usd.joints[0][0].q_j_max, [JOINT_QMAX, JOINT_QMAX, JOINT_QMAX])

    ###
    # Joints based on specializations of UsdPhysicsD6Joint
    ###

    def test_import_joint_cylindrical_passive_unary(self):
        """Test importing a passive cylindrical joint with limits from a USD file"""
        usd_asset_filename = get_kamino_testing_asset("joints/test_joint_cylindrical_passive_unary.usda")
        importer = USDImporter()
        builder_usd: ModelBuilderKamino = importer.import_from(source=usd_asset_filename)
        # Check the loaded contents
        self.assertEqual(builder_usd.num_bodies, 1)
        self.assertEqual(builder_usd.num_joints, 1)
        self.assertEqual(builder_usd.joints[0][0].act_type, JointActuationType.PASSIVE)
        self.assertEqual(builder_usd.joints[0][0].dof_type, JointDoFType.CYLINDRICAL)
        self.assertEqual(builder_usd.joints[0][0].wid, 0)
        self.assertEqual(builder_usd.joints[0][0].jid, 0)
        self.assertEqual(builder_usd.joints[0][0].bilateral_cts_offset, 0)
        self.assertEqual(builder_usd.joints[0][0].dofs_offset, 0)
        self.assertEqual(builder_usd.joints[0][0].bid_B, -1)
        self.assertEqual(builder_usd.joints[0][0].bid_F, 0)
        self.assertEqual(len(builder_usd.joints[0][0].q_j_min), 2)
        self.assertEqual(len(builder_usd.joints[0][0].q_j_max), 2)
        self.assertEqual(len(builder_usd.joints[0][0].tau_j_max), 2)
        self.assertEqual(builder_usd.joints[0][0].q_j_min, [-1, JOINT_QMIN])
        self.assertEqual(builder_usd.joints[0][0].q_j_max, [1, JOINT_QMAX])

    def test_import_joint_cylindrical_passive(self):
        """Test importing a passive cylindrical joint with limits from a USD file"""
        usd_asset_filename = get_kamino_testing_asset("joints/test_joint_cylindrical_passive.usda")
        importer = USDImporter()
        builder_usd: ModelBuilderKamino = importer.import_from(source=usd_asset_filename)
        # Check the loaded contents
        self.assertEqual(builder_usd.num_bodies, 2)
        self.assertEqual(builder_usd.num_joints, 1)
        self.assertEqual(builder_usd.joints[0][0].act_type, JointActuationType.PASSIVE)
        self.assertEqual(builder_usd.joints[0][0].dof_type, JointDoFType.CYLINDRICAL)
        self.assertEqual(builder_usd.joints[0][0].wid, 0)
        self.assertEqual(builder_usd.joints[0][0].jid, 0)
        self.assertEqual(builder_usd.joints[0][0].bilateral_cts_offset, 0)
        self.assertEqual(builder_usd.joints[0][0].dofs_offset, 0)
        self.assertEqual(builder_usd.joints[0][0].bid_B, 0)
        self.assertEqual(builder_usd.joints[0][0].bid_F, 1)
        self.assertEqual(len(builder_usd.joints[0][0].q_j_min), 2)
        self.assertEqual(len(builder_usd.joints[0][0].q_j_max), 2)
        self.assertEqual(len(builder_usd.joints[0][0].tau_j_max), 2)
        self.assertEqual(builder_usd.joints[0][0].q_j_min, [-1, JOINT_QMIN])
        self.assertEqual(builder_usd.joints[0][0].q_j_max, [1, JOINT_QMAX])

    def test_import_joint_cylindrical_actuated(self):
        """Test importing a actuated cylindrical joint with limits from a USD file"""
        usd_asset_filename = get_kamino_testing_asset("joints/test_joint_cylindrical_actuated.usda")
        importer = USDImporter()
        builder_usd: ModelBuilderKamino = importer.import_from(source=usd_asset_filename)
        # Check the loaded contents
        self.assertEqual(builder_usd.num_bodies, 2)
        self.assertEqual(builder_usd.num_joints, 1)
        self.assertEqual(builder_usd.joints[0][0].act_type, JointActuationType.FORCE)
        self.assertEqual(builder_usd.joints[0][0].dof_type, JointDoFType.CYLINDRICAL)
        self.assertEqual(builder_usd.joints[0][0].wid, 0)
        self.assertEqual(builder_usd.joints[0][0].jid, 0)
        self.assertEqual(builder_usd.joints[0][0].bilateral_cts_offset, 0)
        self.assertEqual(builder_usd.joints[0][0].dofs_offset, 0)
        self.assertEqual(builder_usd.joints[0][0].bid_B, 0)
        self.assertEqual(builder_usd.joints[0][0].bid_F, 1)
        self.assertEqual(len(builder_usd.joints[0][0].q_j_min), 2)
        self.assertEqual(len(builder_usd.joints[0][0].q_j_max), 2)
        self.assertEqual(len(builder_usd.joints[0][0].tau_j_max), 2)
        self.assertEqual(builder_usd.joints[0][0].q_j_min, [-1, JOINT_QMIN])
        self.assertEqual(builder_usd.joints[0][0].q_j_max, [1, JOINT_QMAX])
        self.assertEqual(builder_usd.joints[0][0].tau_j_max, [100.0, 200.0])

    def test_import_joint_universal_passive_unary(self):
        """Test importing a passive universal joint with limits from a USD file"""
        usd_asset_filename = get_kamino_testing_asset("joints/test_joint_universal_passive_unary.usda")
        importer = USDImporter()
        builder_usd: ModelBuilderKamino = importer.import_from(source=usd_asset_filename)
        # Check the loaded contents
        self.assertEqual(builder_usd.num_bodies, 1)
        self.assertEqual(builder_usd.num_joints, 1)
        self.assertEqual(builder_usd.joints[0][0].act_type, JointActuationType.PASSIVE)
        self.assertEqual(builder_usd.joints[0][0].dof_type, JointDoFType.UNIVERSAL)
        self.assertEqual(builder_usd.joints[0][0].wid, 0)
        self.assertEqual(builder_usd.joints[0][0].jid, 0)
        self.assertEqual(builder_usd.joints[0][0].bilateral_cts_offset, 0)
        self.assertEqual(builder_usd.joints[0][0].dofs_offset, 0)
        self.assertEqual(builder_usd.joints[0][0].bid_B, -1)
        self.assertEqual(builder_usd.joints[0][0].bid_F, 0)
        self.assertEqual(len(builder_usd.joints[0][0].q_j_min), 2)
        self.assertEqual(len(builder_usd.joints[0][0].q_j_max), 2)
        self.assertEqual(len(builder_usd.joints[0][0].tau_j_max), 2)
        self.assertEqual(builder_usd.joints[0][0].q_j_min, [-0.5 * math.pi, -0.5 * math.pi])
        self.assertEqual(builder_usd.joints[0][0].q_j_max, [0.5 * math.pi, 0.5 * math.pi])

    def test_import_joint_universal_passive(self):
        """Test importing a passive universal joint with limits from a USD file"""
        usd_asset_filename = get_kamino_testing_asset("joints/test_joint_universal_passive.usda")
        importer = USDImporter()
        builder_usd: ModelBuilderKamino = importer.import_from(source=usd_asset_filename)
        # Check the loaded contents
        self.assertEqual(builder_usd.num_bodies, 2)
        self.assertEqual(builder_usd.num_joints, 1)
        self.assertEqual(builder_usd.joints[0][0].act_type, JointActuationType.PASSIVE)
        self.assertEqual(builder_usd.joints[0][0].dof_type, JointDoFType.UNIVERSAL)
        self.assertEqual(builder_usd.joints[0][0].wid, 0)
        self.assertEqual(builder_usd.joints[0][0].jid, 0)
        self.assertEqual(builder_usd.joints[0][0].bilateral_cts_offset, 0)
        self.assertEqual(builder_usd.joints[0][0].dofs_offset, 0)
        self.assertEqual(builder_usd.joints[0][0].bid_B, 0)
        self.assertEqual(builder_usd.joints[0][0].bid_F, 1)
        self.assertEqual(len(builder_usd.joints[0][0].q_j_min), 2)
        self.assertEqual(len(builder_usd.joints[0][0].q_j_max), 2)
        self.assertEqual(len(builder_usd.joints[0][0].tau_j_max), 2)
        self.assertEqual(builder_usd.joints[0][0].q_j_min, [-0.5 * math.pi, -0.5 * math.pi])
        self.assertEqual(builder_usd.joints[0][0].q_j_max, [0.5 * math.pi, 0.5 * math.pi])

    def test_import_joint_universal_actuated(self):
        """Test importing a actuated universal joint with limits from a USD file"""
        usd_asset_filename = get_kamino_testing_asset("joints/test_joint_universal_actuated.usda")
        importer = USDImporter()
        builder_usd: ModelBuilderKamino = importer.import_from(source=usd_asset_filename)

        # Check the loaded contents
        self.assertEqual(builder_usd.num_bodies, 2)
        self.assertEqual(builder_usd.num_joints, 1)
        self.assertEqual(builder_usd.joints[0][0].act_type, JointActuationType.FORCE)
        self.assertEqual(builder_usd.joints[0][0].dof_type, JointDoFType.UNIVERSAL)
        self.assertEqual(builder_usd.joints[0][0].wid, 0)
        self.assertEqual(builder_usd.joints[0][0].jid, 0)
        self.assertEqual(builder_usd.joints[0][0].bilateral_cts_offset, 0)
        self.assertEqual(builder_usd.joints[0][0].dofs_offset, 0)
        self.assertEqual(builder_usd.joints[0][0].bid_B, 0)
        self.assertEqual(builder_usd.joints[0][0].bid_F, 1)
        self.assertEqual(len(builder_usd.joints[0][0].q_j_min), 2)
        self.assertEqual(len(builder_usd.joints[0][0].q_j_max), 2)
        self.assertEqual(len(builder_usd.joints[0][0].tau_j_max), 2)
        self.assertEqual(builder_usd.joints[0][0].q_j_min, [-0.5 * math.pi, -0.5 * math.pi])
        self.assertEqual(builder_usd.joints[0][0].q_j_max, [0.5 * math.pi, 0.5 * math.pi])
        self.assertEqual(builder_usd.joints[0][0].tau_j_max, [100.0, 200.0])

    def test_import_joint_cartesian_passive_unary(self):
        """Test importing a passive cylindrical joint with limits from a USD file"""
        usd_asset_filename = get_kamino_testing_asset("joints/test_joint_cartesian_passive_unary.usda")
        importer = USDImporter()
        builder_usd: ModelBuilderKamino = importer.import_from(source=usd_asset_filename)

        # Check the loaded contents
        self.assertEqual(builder_usd.num_bodies, 1)
        self.assertEqual(builder_usd.num_joints, 1)
        self.assertEqual(builder_usd.joints[0][0].act_type, JointActuationType.PASSIVE)
        self.assertEqual(builder_usd.joints[0][0].dof_type, JointDoFType.CARTESIAN)
        self.assertEqual(builder_usd.joints[0][0].wid, 0)
        self.assertEqual(builder_usd.joints[0][0].jid, 0)
        self.assertEqual(builder_usd.joints[0][0].bilateral_cts_offset, 0)
        self.assertEqual(builder_usd.joints[0][0].dofs_offset, 0)
        self.assertEqual(builder_usd.joints[0][0].bid_B, -1)
        self.assertEqual(builder_usd.joints[0][0].bid_F, 0)
        self.assertEqual(len(builder_usd.joints[0][0].q_j_min), 3)
        self.assertEqual(len(builder_usd.joints[0][0].q_j_max), 3)
        self.assertEqual(len(builder_usd.joints[0][0].tau_j_max), 3)
        self.assertEqual(builder_usd.joints[0][0].q_j_min, [-10.0, -20.0, -30.0])
        self.assertEqual(builder_usd.joints[0][0].q_j_max, [10.0, 20.0, 30.0])

    def test_import_joint_cartesian_passive(self):
        """Test importing a passive cylindrical joint with limits from a USD file"""
        usd_asset_filename = get_kamino_testing_asset("joints/test_joint_cartesian_passive.usda")
        importer = USDImporter()
        builder_usd: ModelBuilderKamino = importer.import_from(source=usd_asset_filename)

        # Check the loaded contents
        self.assertEqual(builder_usd.num_bodies, 2)
        self.assertEqual(builder_usd.num_joints, 1)
        self.assertEqual(builder_usd.joints[0][0].act_type, JointActuationType.PASSIVE)
        self.assertEqual(builder_usd.joints[0][0].dof_type, JointDoFType.CARTESIAN)
        self.assertEqual(builder_usd.joints[0][0].wid, 0)
        self.assertEqual(builder_usd.joints[0][0].jid, 0)
        self.assertEqual(builder_usd.joints[0][0].bilateral_cts_offset, 0)
        self.assertEqual(builder_usd.joints[0][0].dofs_offset, 0)
        self.assertEqual(builder_usd.joints[0][0].bid_B, 0)
        self.assertEqual(builder_usd.joints[0][0].bid_F, 1)
        self.assertEqual(len(builder_usd.joints[0][0].q_j_min), 3)
        self.assertEqual(len(builder_usd.joints[0][0].q_j_max), 3)
        self.assertEqual(len(builder_usd.joints[0][0].tau_j_max), 3)
        self.assertEqual(builder_usd.joints[0][0].q_j_min, [-10.0, -20.0, -30.0])
        self.assertEqual(builder_usd.joints[0][0].q_j_max, [10.0, 20.0, 30.0])

    def test_import_joint_cartesian_actuated(self):
        """Test importing a actuated cylindrical joint with limits from a USD file"""
        usd_asset_filename = get_kamino_testing_asset("joints/test_joint_cartesian_actuated.usda")
        importer = USDImporter()
        builder_usd: ModelBuilderKamino = importer.import_from(source=usd_asset_filename)

        # Check the loaded contents
        self.assertEqual(builder_usd.num_bodies, 2)
        self.assertEqual(builder_usd.num_joints, 1)
        self.assertEqual(builder_usd.joints[0][0].act_type, JointActuationType.FORCE)
        self.assertEqual(builder_usd.joints[0][0].dof_type, JointDoFType.CARTESIAN)
        self.assertEqual(builder_usd.joints[0][0].wid, 0)
        self.assertEqual(builder_usd.joints[0][0].jid, 0)
        self.assertEqual(builder_usd.joints[0][0].bilateral_cts_offset, 0)
        self.assertEqual(builder_usd.joints[0][0].dofs_offset, 0)
        self.assertEqual(builder_usd.joints[0][0].bid_B, 0)
        self.assertEqual(builder_usd.joints[0][0].bid_F, 1)
        self.assertEqual(len(builder_usd.joints[0][0].q_j_min), 3)
        self.assertEqual(len(builder_usd.joints[0][0].q_j_max), 3)
        self.assertEqual(len(builder_usd.joints[0][0].tau_j_max), 3)
        self.assertEqual(builder_usd.joints[0][0].q_j_min, [-10.0, -20.0, -30.0])
        self.assertEqual(builder_usd.joints[0][0].q_j_max, [10.0, 20.0, 30.0])
        self.assertEqual(builder_usd.joints[0][0].tau_j_max, [100.0, 200.0, 300.0])

    ###
    # Joints based on UsdPhysicsD6Joint
    ###

    def test_import_joint_d6_revolute_passive(self):
        """Test importing a passive revolute joint with limits from a USD file"""
        usd_asset_filename = get_kamino_testing_asset("joints/test_joint_d6_revolute_passive.usda")
        importer = USDImporter()
        builder_usd: ModelBuilderKamino = importer.import_from(source=usd_asset_filename)
        # Check the loaded contents
        self.assertEqual(builder_usd.num_bodies, 2)
        self.assertEqual(builder_usd.num_joints, 1)
        self.assertEqual(builder_usd.joints[0][0].act_type, JointActuationType.PASSIVE)
        self.assertEqual(builder_usd.joints[0][0].dof_type, JointDoFType.REVOLUTE)
        self.assertEqual(builder_usd.joints[0][0].wid, 0)
        self.assertEqual(builder_usd.joints[0][0].jid, 0)
        self.assertEqual(builder_usd.joints[0][0].bilateral_cts_offset, 0)
        self.assertEqual(builder_usd.joints[0][0].dofs_offset, 0)
        self.assertEqual(builder_usd.joints[0][0].bid_B, 0)
        self.assertEqual(builder_usd.joints[0][0].bid_F, 1)
        self.assertEqual(len(builder_usd.joints[0][0].q_j_min), 1)
        self.assertEqual(len(builder_usd.joints[0][0].q_j_max), 1)
        self.assertEqual(len(builder_usd.joints[0][0].tau_j_max), 1)
        self.assertEqual(builder_usd.joints[0][0].q_j_min, [-math.pi])
        self.assertEqual(builder_usd.joints[0][0].q_j_max, [math.pi])

    def test_import_joint_d6_revolute_actuated(self):
        """Test importing a actuated revolute joint with limits from a USD file"""
        usd_asset_filename = get_kamino_testing_asset("joints/test_joint_d6_revolute_actuated.usda")
        importer = USDImporter()
        builder_usd: ModelBuilderKamino = importer.import_from(source=usd_asset_filename)
        # Check the loaded contents
        self.assertEqual(builder_usd.num_bodies, 2)
        self.assertEqual(builder_usd.num_joints, 1)
        self.assertEqual(builder_usd.joints[0][0].act_type, JointActuationType.FORCE)
        self.assertEqual(builder_usd.joints[0][0].dof_type, JointDoFType.REVOLUTE)
        self.assertEqual(builder_usd.joints[0][0].wid, 0)
        self.assertEqual(builder_usd.joints[0][0].jid, 0)
        self.assertEqual(builder_usd.joints[0][0].bilateral_cts_offset, 0)
        self.assertEqual(builder_usd.joints[0][0].dofs_offset, 0)
        self.assertEqual(builder_usd.joints[0][0].bid_B, 0)
        self.assertEqual(builder_usd.joints[0][0].bid_F, 1)
        self.assertEqual(len(builder_usd.joints[0][0].q_j_min), 1)
        self.assertEqual(len(builder_usd.joints[0][0].q_j_max), 1)
        self.assertEqual(len(builder_usd.joints[0][0].tau_j_max), 1)
        self.assertEqual(builder_usd.joints[0][0].q_j_min, [-math.pi])
        self.assertEqual(builder_usd.joints[0][0].q_j_max, [math.pi])
        self.assertEqual(builder_usd.joints[0][0].tau_j_max, [100.0])

    def test_import_joint_d6_prismatic_passive(self):
        """Test importing a passive prismatic joint with limits from a USD file"""
        usd_asset_filename = get_kamino_testing_asset("joints/test_joint_d6_prismatic_passive.usda")
        importer = USDImporter()
        builder_usd: ModelBuilderKamino = importer.import_from(source=usd_asset_filename)
        # Check the loaded contents
        self.assertEqual(builder_usd.num_bodies, 2)
        self.assertEqual(builder_usd.num_joints, 1)
        self.assertEqual(builder_usd.joints[0][0].act_type, JointActuationType.PASSIVE)
        self.assertEqual(builder_usd.joints[0][0].dof_type, JointDoFType.PRISMATIC)
        self.assertEqual(builder_usd.joints[0][0].wid, 0)
        self.assertEqual(builder_usd.joints[0][0].jid, 0)
        self.assertEqual(builder_usd.joints[0][0].bilateral_cts_offset, 0)
        self.assertEqual(builder_usd.joints[0][0].dofs_offset, 0)
        self.assertEqual(builder_usd.joints[0][0].bid_B, 0)
        self.assertEqual(builder_usd.joints[0][0].bid_F, 1)
        self.assertEqual(len(builder_usd.joints[0][0].q_j_min), 1)
        self.assertEqual(len(builder_usd.joints[0][0].q_j_max), 1)
        self.assertEqual(len(builder_usd.joints[0][0].tau_j_max), 1)
        self.assertEqual(builder_usd.joints[0][0].q_j_min, [-10.0])
        self.assertEqual(builder_usd.joints[0][0].q_j_max, [10.0])

    def test_import_joint_d6_prismatic_actuated(self):
        """Test importing a actuated prismatic joint with limits from a USD file"""
        usd_asset_filename = get_kamino_testing_asset("joints/test_joint_d6_prismatic_actuated.usda")
        importer = USDImporter()
        builder_usd: ModelBuilderKamino = importer.import_from(source=usd_asset_filename)
        # Check the loaded contents
        self.assertEqual(builder_usd.num_bodies, 2)
        self.assertEqual(builder_usd.num_joints, 1)
        self.assertEqual(builder_usd.joints[0][0].act_type, JointActuationType.FORCE)
        self.assertEqual(builder_usd.joints[0][0].dof_type, JointDoFType.PRISMATIC)
        self.assertEqual(builder_usd.joints[0][0].wid, 0)
        self.assertEqual(builder_usd.joints[0][0].jid, 0)
        self.assertEqual(builder_usd.joints[0][0].bilateral_cts_offset, 0)
        self.assertEqual(builder_usd.joints[0][0].dofs_offset, 0)
        self.assertEqual(builder_usd.joints[0][0].bid_B, 0)
        self.assertEqual(builder_usd.joints[0][0].bid_F, 1)
        self.assertEqual(len(builder_usd.joints[0][0].q_j_min), 1)
        self.assertEqual(len(builder_usd.joints[0][0].q_j_max), 1)
        self.assertEqual(len(builder_usd.joints[0][0].tau_j_max), 1)
        self.assertEqual(builder_usd.joints[0][0].q_j_min, [-10.0])
        self.assertEqual(builder_usd.joints[0][0].q_j_max, [10.0])
        self.assertEqual(builder_usd.joints[0][0].tau_j_max, [100.0])

    def test_import_joint_d6_cylindrical_passive(self):
        """Test importing a passive cylindrical joint with limits from a USD file"""
        usd_asset_filename = get_kamino_testing_asset("joints/test_joint_d6_cylindrical_passive.usda")
        importer = USDImporter()
        builder_usd: ModelBuilderKamino = importer.import_from(source=usd_asset_filename)
        # Check the loaded contents
        self.assertEqual(builder_usd.num_bodies, 2)
        self.assertEqual(builder_usd.num_joints, 1)
        self.assertEqual(builder_usd.joints[0][0].act_type, JointActuationType.PASSIVE)
        self.assertEqual(builder_usd.joints[0][0].dof_type, JointDoFType.CYLINDRICAL)
        self.assertEqual(builder_usd.joints[0][0].wid, 0)
        self.assertEqual(builder_usd.joints[0][0].jid, 0)
        self.assertEqual(builder_usd.joints[0][0].bilateral_cts_offset, 0)
        self.assertEqual(builder_usd.joints[0][0].dofs_offset, 0)
        self.assertEqual(builder_usd.joints[0][0].bid_B, 0)
        self.assertEqual(builder_usd.joints[0][0].bid_F, 1)
        self.assertEqual(len(builder_usd.joints[0][0].q_j_min), 2)
        self.assertEqual(len(builder_usd.joints[0][0].q_j_max), 2)
        self.assertEqual(len(builder_usd.joints[0][0].tau_j_max), 2)
        self.assertEqual(builder_usd.joints[0][0].q_j_min, [-1.0, JOINT_QMIN])
        self.assertEqual(builder_usd.joints[0][0].q_j_max, [1.0, JOINT_QMAX])

    def test_import_joint_d6_cylindrical_actuated(self):
        """Test importing a actuated cylindrical joint with limits from a USD file"""
        usd_asset_filename = get_kamino_testing_asset("joints/test_joint_d6_cylindrical_actuated.usda")
        importer = USDImporter()
        builder_usd: ModelBuilderKamino = importer.import_from(source=usd_asset_filename)
        # Check the loaded contents
        self.assertEqual(builder_usd.num_bodies, 2)
        self.assertEqual(builder_usd.num_joints, 1)
        self.assertEqual(builder_usd.joints[0][0].act_type, JointActuationType.FORCE)
        self.assertEqual(builder_usd.joints[0][0].dof_type, JointDoFType.CYLINDRICAL)
        self.assertEqual(builder_usd.joints[0][0].wid, 0)
        self.assertEqual(builder_usd.joints[0][0].jid, 0)
        self.assertEqual(builder_usd.joints[0][0].bilateral_cts_offset, 0)
        self.assertEqual(builder_usd.joints[0][0].dofs_offset, 0)
        self.assertEqual(builder_usd.joints[0][0].bid_B, 0)
        self.assertEqual(builder_usd.joints[0][0].bid_F, 1)
        self.assertEqual(len(builder_usd.joints[0][0].q_j_min), 2)
        self.assertEqual(len(builder_usd.joints[0][0].q_j_max), 2)
        self.assertEqual(len(builder_usd.joints[0][0].tau_j_max), 2)
        self.assertEqual(builder_usd.joints[0][0].q_j_min, [-1.0, JOINT_QMIN])
        self.assertEqual(builder_usd.joints[0][0].q_j_max, [1.0, JOINT_QMAX])
        self.assertEqual(builder_usd.joints[0][0].tau_j_max, [100.0, 200.0])

    def test_import_joint_d6_universal_passive(self):
        """Test importing a passive universal joint with limits from a USD file"""
        usd_asset_filename = get_kamino_testing_asset("joints/test_joint_d6_universal_passive.usda")
        importer = USDImporter()
        builder_usd: ModelBuilderKamino = importer.import_from(source=usd_asset_filename)
        # Check the loaded contents
        self.assertEqual(builder_usd.num_bodies, 2)
        self.assertEqual(builder_usd.num_joints, 1)
        self.assertEqual(builder_usd.joints[0][0].act_type, JointActuationType.PASSIVE)
        self.assertEqual(builder_usd.joints[0][0].dof_type, JointDoFType.UNIVERSAL)
        self.assertEqual(builder_usd.joints[0][0].wid, 0)
        self.assertEqual(builder_usd.joints[0][0].jid, 0)
        self.assertEqual(builder_usd.joints[0][0].bilateral_cts_offset, 0)
        self.assertEqual(builder_usd.joints[0][0].dofs_offset, 0)
        self.assertEqual(builder_usd.joints[0][0].bid_B, 0)
        self.assertEqual(builder_usd.joints[0][0].bid_F, 1)
        self.assertEqual(len(builder_usd.joints[0][0].q_j_min), 2)
        self.assertEqual(len(builder_usd.joints[0][0].q_j_max), 2)
        self.assertEqual(len(builder_usd.joints[0][0].tau_j_max), 2)
        self.assertEqual(builder_usd.joints[0][0].q_j_min, [-0.5 * math.pi, -0.5 * math.pi])
        self.assertEqual(builder_usd.joints[0][0].q_j_max, [0.5 * math.pi, 0.5 * math.pi])

    def test_import_joint_d6_universal_actuated(self):
        """Test importing a actuated universal joint with limits from a USD file"""
        usd_asset_filename = get_kamino_testing_asset("joints/test_joint_d6_universal_actuated.usda")
        importer = USDImporter()
        builder_usd: ModelBuilderKamino = importer.import_from(source=usd_asset_filename)
        # Check the loaded contents
        self.assertEqual(builder_usd.num_bodies, 2)
        self.assertEqual(builder_usd.num_joints, 1)
        self.assertEqual(builder_usd.joints[0][0].act_type, JointActuationType.FORCE)
        self.assertEqual(builder_usd.joints[0][0].dof_type, JointDoFType.UNIVERSAL)
        self.assertEqual(builder_usd.joints[0][0].wid, 0)
        self.assertEqual(builder_usd.joints[0][0].jid, 0)
        self.assertEqual(builder_usd.joints[0][0].bilateral_cts_offset, 0)
        self.assertEqual(builder_usd.joints[0][0].dofs_offset, 0)
        self.assertEqual(builder_usd.joints[0][0].bid_B, 0)
        self.assertEqual(builder_usd.joints[0][0].bid_F, 1)
        self.assertEqual(len(builder_usd.joints[0][0].q_j_min), 2)
        self.assertEqual(len(builder_usd.joints[0][0].q_j_max), 2)
        self.assertEqual(len(builder_usd.joints[0][0].tau_j_max), 2)
        self.assertEqual(builder_usd.joints[0][0].q_j_min, [-0.5 * math.pi, -0.5 * math.pi])
        self.assertEqual(builder_usd.joints[0][0].q_j_max, [0.5 * math.pi, 0.5 * math.pi])
        self.assertEqual(builder_usd.joints[0][0].tau_j_max, [100.0, 200.0])

    def test_import_joint_d6_cartesian_passive(self):
        """Test importing a passive cartesian joint with limits from a USD file"""
        usd_asset_filename = get_kamino_testing_asset("joints/test_joint_d6_cartesian_passive.usda")
        importer = USDImporter()
        builder_usd: ModelBuilderKamino = importer.import_from(source=usd_asset_filename)
        # Check the loaded contents
        self.assertEqual(builder_usd.num_bodies, 2)
        self.assertEqual(builder_usd.num_joints, 1)
        self.assertEqual(builder_usd.joints[0][0].act_type, JointActuationType.PASSIVE)
        self.assertEqual(builder_usd.joints[0][0].dof_type, JointDoFType.CARTESIAN)
        self.assertEqual(builder_usd.joints[0][0].wid, 0)
        self.assertEqual(builder_usd.joints[0][0].jid, 0)
        self.assertEqual(builder_usd.joints[0][0].bilateral_cts_offset, 0)
        self.assertEqual(builder_usd.joints[0][0].dofs_offset, 0)
        self.assertEqual(builder_usd.joints[0][0].bid_B, 0)
        self.assertEqual(builder_usd.joints[0][0].bid_F, 1)
        self.assertEqual(len(builder_usd.joints[0][0].q_j_min), 3)
        self.assertEqual(len(builder_usd.joints[0][0].q_j_max), 3)
        self.assertEqual(len(builder_usd.joints[0][0].tau_j_max), 3)
        self.assertEqual(builder_usd.joints[0][0].q_j_min, [-10.0, -20.0, -30.0])
        self.assertEqual(builder_usd.joints[0][0].q_j_max, [10.0, 20.0, 30.0])

    def test_importjoint__d6_cartesian_actuated(self):
        """Test importing a actuated cartesian joint with limits from a USD file"""
        usd_asset_filename = get_kamino_testing_asset("joints/test_joint_d6_cartesian_actuated.usda")
        importer = USDImporter()
        builder_usd: ModelBuilderKamino = importer.import_from(source=usd_asset_filename)
        # Check the loaded contents
        self.assertEqual(builder_usd.num_bodies, 2)
        self.assertEqual(builder_usd.num_joints, 1)
        self.assertEqual(builder_usd.joints[0][0].act_type, JointActuationType.FORCE)
        self.assertEqual(builder_usd.joints[0][0].dof_type, JointDoFType.CARTESIAN)
        self.assertEqual(builder_usd.joints[0][0].wid, 0)
        self.assertEqual(builder_usd.joints[0][0].jid, 0)
        self.assertEqual(builder_usd.joints[0][0].bilateral_cts_offset, 0)
        self.assertEqual(builder_usd.joints[0][0].dofs_offset, 0)
        self.assertEqual(builder_usd.joints[0][0].bid_B, 0)
        self.assertEqual(builder_usd.joints[0][0].bid_F, 1)
        self.assertEqual(len(builder_usd.joints[0][0].q_j_min), 3)
        self.assertEqual(len(builder_usd.joints[0][0].q_j_max), 3)
        self.assertEqual(len(builder_usd.joints[0][0].tau_j_max), 3)
        self.assertEqual(builder_usd.joints[0][0].q_j_min, [-10.0, -20.0, -30.0])
        self.assertEqual(builder_usd.joints[0][0].q_j_max, [10.0, 20.0, 30.0])
        self.assertEqual(builder_usd.joints[0][0].tau_j_max, [100.0, 200.0, 300.0])

    def test_import_joint_d6_spherical_passive(self):
        """Test importing a passive spherical joint with limits from a USD file"""
        usd_asset_filename = get_kamino_testing_asset("joints/test_joint_d6_spherical_passive.usda")
        importer = USDImporter()
        builder_usd: ModelBuilderKamino = importer.import_from(source=usd_asset_filename)
        # Check the loaded contents
        self.assertEqual(builder_usd.num_bodies, 2)
        self.assertEqual(builder_usd.num_joints, 1)
        self.assertEqual(builder_usd.joints[0][0].act_type, JointActuationType.PASSIVE)
        self.assertEqual(builder_usd.joints[0][0].dof_type, JointDoFType.SPHERICAL)
        self.assertEqual(builder_usd.joints[0][0].wid, 0)
        self.assertEqual(builder_usd.joints[0][0].jid, 0)
        self.assertEqual(builder_usd.joints[0][0].bilateral_cts_offset, 0)
        self.assertEqual(builder_usd.joints[0][0].dofs_offset, 0)
        self.assertEqual(builder_usd.joints[0][0].bid_B, 0)
        self.assertEqual(builder_usd.joints[0][0].bid_F, 1)
        self.assertEqual(len(builder_usd.joints[0][0].q_j_min), 3)
        self.assertEqual(len(builder_usd.joints[0][0].q_j_max), 3)
        self.assertEqual(len(builder_usd.joints[0][0].tau_j_max), 3)
        self.assertEqual(builder_usd.joints[0][0].q_j_min, [-math.pi, -math.pi, -math.pi])
        self.assertEqual(builder_usd.joints[0][0].q_j_max, [math.pi, math.pi, math.pi])

    def test_import_joint_d6_spherical_actuated(self):
        """Test importing a actuated spherical joint with limits from a USD file"""
        usd_asset_filename = get_kamino_testing_asset("joints/test_joint_d6_spherical_actuated.usda")
        importer = USDImporter()
        builder_usd: ModelBuilderKamino = importer.import_from(source=usd_asset_filename)
        # Check the loaded contents
        self.assertEqual(builder_usd.num_bodies, 2)
        self.assertEqual(builder_usd.num_joints, 1)
        self.assertEqual(builder_usd.joints[0][0].act_type, JointActuationType.FORCE)
        self.assertEqual(builder_usd.joints[0][0].dof_type, JointDoFType.SPHERICAL)
        self.assertEqual(builder_usd.joints[0][0].wid, 0)
        self.assertEqual(builder_usd.joints[0][0].jid, 0)
        self.assertEqual(builder_usd.joints[0][0].bilateral_cts_offset, 0)
        self.assertEqual(builder_usd.joints[0][0].dofs_offset, 0)
        self.assertEqual(builder_usd.joints[0][0].bid_B, 0)
        self.assertEqual(builder_usd.joints[0][0].bid_F, 1)
        self.assertEqual(len(builder_usd.joints[0][0].q_j_min), 3)
        self.assertEqual(len(builder_usd.joints[0][0].q_j_max), 3)
        self.assertEqual(len(builder_usd.joints[0][0].tau_j_max), 3)
        self.assertEqual(builder_usd.joints[0][0].q_j_min, [-math.pi, -math.pi, -math.pi])
        self.assertEqual(builder_usd.joints[0][0].q_j_max, [math.pi, math.pi, math.pi])
        self.assertEqual(builder_usd.joints[0][0].tau_j_max, [100.0, 200.0, 300.0])

    ###
    # Primitive geometries/shapes
    ###

    def test_import_geom_capsule(self):
        """Test importing a body with geometric primitive capsule shape from a USD file"""
        usd_asset_filename = get_kamino_testing_asset("geoms/test_geom_capsule.usda")
        importer = USDImporter()
        builder_usd: ModelBuilderKamino = importer.import_from(source=usd_asset_filename)

        # Check the loaded contents
        self.assertEqual(builder_usd.num_bodies, 1)
        self.assertEqual(builder_usd.num_joints, 0)
        self.assertEqual(builder_usd.num_geoms, 2)

        # Visual geoms are loaded first
        self.assertEqual(builder_usd.geoms[0][0].wid, 0)
        self.assertEqual(builder_usd.geoms[0][0].gid, 0)
        self.assertEqual(builder_usd.geoms[0][0].body, 0)
        shape = builder_usd.shapes[builder_usd.geoms[0][0].uid]
        self.assertEqual(shape.type, GeoType.CAPSULE)
        self.assertAlmostEqual(shape.radius, 0.2)
        self.assertAlmostEqual(shape.half_height, 1.65)
        self.assertEqual(builder_usd.geoms[0][0].mid, -1)
        self.assertEqual(builder_usd.geoms[0][0].group, 0)
        self.assertEqual(builder_usd.geoms[0][0].collides, 0)
        self.assertEqual(builder_usd.geoms[0][0].max_contacts, 0)

        # Collidable geoms are loaded after visual geoms
        self.assertEqual(builder_usd.geoms[0][1].wid, 0)
        self.assertEqual(builder_usd.geoms[0][1].gid, 1)
        self.assertEqual(builder_usd.geoms[0][1].body, 0)
        shape = builder_usd.shapes[builder_usd.geoms[0][1].uid]
        self.assertEqual(shape.type, GeoType.CAPSULE)
        self.assertAlmostEqual(shape.radius, 0.1)
        self.assertAlmostEqual(shape.half_height, 1.1)
        self.assertEqual(builder_usd.geoms[0][1].mid, 0)
        self.assertEqual(builder_usd.geoms[0][1].group, 1)
        self.assertEqual(builder_usd.geoms[0][1].collides, 1)
        self.assertEqual(builder_usd.geoms[0][1].max_contacts, 10)

    def test_import_geom_cone(self):
        """Test importing a body with geometric primitive cone shape from a USD file"""
        usd_asset_filename = get_kamino_testing_asset("geoms/test_geom_cone.usda")
        importer = USDImporter()
        builder_usd: ModelBuilderKamino = importer.import_from(source=usd_asset_filename)

        # Check the loaded contents
        self.assertEqual(builder_usd.num_bodies, 1)
        self.assertEqual(builder_usd.num_joints, 0)
        self.assertEqual(builder_usd.num_geoms, 2)

        # Visual geoms are loaded first
        self.assertEqual(builder_usd.geoms[0][0].wid, 0)
        self.assertEqual(builder_usd.geoms[0][0].gid, 0)
        self.assertEqual(builder_usd.geoms[0][0].body, 0)
        shape = builder_usd.shapes[builder_usd.geoms[0][0].uid]
        self.assertEqual(shape.type, GeoType.CONE)
        self.assertAlmostEqual(shape.radius, 0.2)
        self.assertAlmostEqual(shape.half_height, 1.65)
        self.assertEqual(builder_usd.geoms[0][0].mid, -1)
        self.assertEqual(builder_usd.geoms[0][0].group, 0)
        self.assertEqual(builder_usd.geoms[0][0].collides, 0)
        self.assertEqual(builder_usd.geoms[0][0].max_contacts, 0)

        # Collidable geoms are loaded after visual geoms
        self.assertEqual(builder_usd.geoms[0][1].wid, 0)
        self.assertEqual(builder_usd.geoms[0][1].gid, 1)
        self.assertEqual(builder_usd.geoms[0][1].body, 0)
        shape = builder_usd.shapes[builder_usd.geoms[0][1].uid]
        self.assertEqual(shape.type, GeoType.CONE)
        self.assertAlmostEqual(shape.radius, 0.1)
        self.assertAlmostEqual(shape.half_height, 1.1)
        self.assertEqual(builder_usd.geoms[0][1].mid, 0)
        self.assertEqual(builder_usd.geoms[0][1].group, 1)
        self.assertEqual(builder_usd.geoms[0][1].collides, 1)
        self.assertEqual(builder_usd.geoms[0][1].max_contacts, 10)

    def test_import_geom_cylinder(self):
        """Test importing a body with geometric primitive cylinder shape from a USD file"""
        usd_asset_filename = get_kamino_testing_asset("geoms/test_geom_cylinder.usda")
        importer = USDImporter()
        builder_usd: ModelBuilderKamino = importer.import_from(source=usd_asset_filename)

        # Check the loaded contents
        self.assertEqual(builder_usd.num_bodies, 1)
        self.assertEqual(builder_usd.num_joints, 0)
        self.assertEqual(builder_usd.num_geoms, 2)

        # Visual geoms are loaded first
        self.assertEqual(builder_usd.geoms[0][0].wid, 0)
        self.assertEqual(builder_usd.geoms[0][0].gid, 0)
        self.assertEqual(builder_usd.geoms[0][0].body, 0)
        shape = builder_usd.shapes[builder_usd.geoms[0][0].uid]
        self.assertEqual(shape.type, GeoType.CYLINDER)
        self.assertAlmostEqual(shape.radius, 0.2)
        self.assertAlmostEqual(shape.half_height, 1.65)
        self.assertEqual(builder_usd.geoms[0][0].mid, -1)
        self.assertEqual(builder_usd.geoms[0][0].group, 0)
        self.assertEqual(builder_usd.geoms[0][0].collides, 0)
        self.assertEqual(builder_usd.geoms[0][0].max_contacts, 0)

        # Collidable geoms are loaded after visual geoms
        self.assertEqual(builder_usd.geoms[0][1].wid, 0)
        self.assertEqual(builder_usd.geoms[0][1].gid, 1)
        self.assertEqual(builder_usd.geoms[0][1].body, 0)
        shape = builder_usd.shapes[builder_usd.geoms[0][1].uid]
        self.assertEqual(shape.type, GeoType.CYLINDER)
        self.assertAlmostEqual(shape.radius, 0.1)
        self.assertAlmostEqual(shape.half_height, 1.1)
        self.assertEqual(builder_usd.geoms[0][1].mid, 0)
        self.assertEqual(builder_usd.geoms[0][1].group, 1)
        self.assertEqual(builder_usd.geoms[0][1].collides, 1)
        self.assertEqual(builder_usd.geoms[0][1].max_contacts, 10)

    def test_import_geom_sphere(self):
        """Test importing a body with geometric primitive sphere shape from a USD file"""
        usd_asset_filename = get_kamino_testing_asset("geoms/test_geom_sphere.usda")
        importer = USDImporter()
        builder_usd: ModelBuilderKamino = importer.import_from(source=usd_asset_filename)

        # Check the loaded contents
        self.assertEqual(builder_usd.num_bodies, 1)
        self.assertEqual(builder_usd.num_joints, 0)
        self.assertEqual(builder_usd.num_geoms, 2)

        # Visual geoms are loaded first
        self.assertEqual(builder_usd.geoms[0][0].wid, 0)
        self.assertEqual(builder_usd.geoms[0][0].gid, 0)
        self.assertEqual(builder_usd.geoms[0][0].body, 0)
        shape = builder_usd.shapes[builder_usd.geoms[0][0].uid]
        self.assertEqual(shape.type, GeoType.SPHERE)
        self.assertAlmostEqual(shape.radius, 0.22)
        self.assertEqual(builder_usd.geoms[0][0].mid, -1)
        self.assertEqual(builder_usd.geoms[0][0].group, 0)
        self.assertEqual(builder_usd.geoms[0][0].collides, 0)
        self.assertEqual(builder_usd.geoms[0][0].max_contacts, 0)

        # Collidable geoms are loaded after visual geoms
        self.assertEqual(builder_usd.geoms[0][1].wid, 0)
        self.assertEqual(builder_usd.geoms[0][1].gid, 1)
        self.assertEqual(builder_usd.geoms[0][1].body, 0)
        shape = builder_usd.shapes[builder_usd.geoms[0][1].uid]
        self.assertEqual(shape.type, GeoType.SPHERE)
        self.assertAlmostEqual(shape.radius, 0.11)
        self.assertEqual(builder_usd.geoms[0][1].mid, 0)
        self.assertEqual(builder_usd.geoms[0][1].group, 1)
        self.assertEqual(builder_usd.geoms[0][1].collides, 1)
        self.assertEqual(builder_usd.geoms[0][1].max_contacts, 10)

    def test_import_geom_ellipsoid(self):
        """Test importing a body with geometric primitive ellipsoid shape from a USD file"""
        usd_asset_filename = get_kamino_testing_asset("geoms/test_geom_ellipsoid.usda")
        importer = USDImporter()
        builder_usd: ModelBuilderKamino = importer.import_from(source=usd_asset_filename)

        # Check the loaded contents
        self.assertEqual(builder_usd.num_bodies, 1)
        self.assertEqual(builder_usd.num_joints, 0)
        self.assertEqual(builder_usd.num_geoms, 2)

        # Visual geoms are loaded first
        self.assertEqual(builder_usd.geoms[0][0].wid, 0)
        self.assertEqual(builder_usd.geoms[0][0].gid, 0)
        self.assertEqual(builder_usd.geoms[0][0].body, 0)
        shape = builder_usd.shapes[builder_usd.geoms[0][0].uid]
        self.assertEqual(shape.type, GeoType.ELLIPSOID)
        self.assertAlmostEqual(shape.rx, 0.22)
        self.assertAlmostEqual(shape.ry, 0.33)
        self.assertAlmostEqual(shape.rz, 0.44)
        self.assertEqual(builder_usd.geoms[0][0].mid, -1)
        self.assertEqual(builder_usd.geoms[0][0].group, 0)
        self.assertEqual(builder_usd.geoms[0][0].collides, 0)
        self.assertEqual(builder_usd.geoms[0][0].max_contacts, 0)

        # Collidable geoms are loaded after visual geoms
        self.assertEqual(builder_usd.geoms[0][1].wid, 0)
        self.assertEqual(builder_usd.geoms[0][1].gid, 1)
        self.assertEqual(builder_usd.geoms[0][1].body, 0)
        shape = builder_usd.shapes[builder_usd.geoms[0][1].uid]
        self.assertEqual(shape.type, GeoType.ELLIPSOID)
        self.assertAlmostEqual(shape.rx, 0.11)
        self.assertAlmostEqual(shape.ry, 0.22)
        self.assertAlmostEqual(shape.rz, 0.33)
        self.assertEqual(builder_usd.geoms[0][1].mid, 0)
        self.assertEqual(builder_usd.geoms[0][1].group, 1)
        self.assertEqual(builder_usd.geoms[0][1].collides, 1)
        self.assertEqual(builder_usd.geoms[0][1].max_contacts, 10)

    def test_import_geom_box(self):
        """Test importing a body with geometric primitive box shape from a USD file"""
        usd_asset_filename = get_kamino_testing_asset("geoms/test_geom_box.usda")
        importer = USDImporter()
        builder_usd: ModelBuilderKamino = importer.import_from(source=usd_asset_filename)

        # Check the loaded contents
        self.assertEqual(builder_usd.num_bodies, 1)
        self.assertEqual(builder_usd.num_joints, 0)
        self.assertEqual(builder_usd.num_geoms, 2)

        # Visual geoms are loaded first
        self.assertEqual(builder_usd.geoms[0][0].wid, 0)
        self.assertEqual(builder_usd.geoms[0][0].gid, 0)
        self.assertEqual(builder_usd.geoms[0][0].body, 0)
        shape = builder_usd.shapes[builder_usd.geoms[0][0].uid]
        self.assertEqual(shape.type, GeoType.BOX)
        self.assertAlmostEqual(shape.hx, 0.111)
        self.assertAlmostEqual(shape.hy, 0.222)
        self.assertAlmostEqual(shape.hz, 0.333)
        self.assertEqual(builder_usd.geoms[0][0].mid, -1)
        self.assertEqual(builder_usd.geoms[0][0].group, 0)
        self.assertEqual(builder_usd.geoms[0][0].collides, 0)
        self.assertEqual(builder_usd.geoms[0][0].max_contacts, 0)

        # Collidable geoms are loaded after visual geoms
        self.assertEqual(builder_usd.geoms[0][1].wid, 0)
        self.assertEqual(builder_usd.geoms[0][1].gid, 1)
        self.assertEqual(builder_usd.geoms[0][1].body, 0)
        shape = builder_usd.shapes[builder_usd.geoms[0][1].uid]
        self.assertEqual(shape.type, GeoType.BOX)
        self.assertAlmostEqual(shape.hx, 0.11)
        self.assertAlmostEqual(shape.hy, 0.22)
        self.assertAlmostEqual(shape.hz, 0.33)
        self.assertEqual(builder_usd.geoms[0][1].mid, 0)
        self.assertEqual(builder_usd.geoms[0][1].group, 1)
        self.assertEqual(builder_usd.geoms[0][1].collides, 1)
        self.assertEqual(builder_usd.geoms[0][1].max_contacts, 10)

    ###
    # Basic models
    ###

    def test_import_basic_box_on_plane(self):
        """Test importing the basic box_on_plane model from a USD file"""

        # Construct a builder from imported USD asset
        usd_asset_filename = get_kamino_basics_asset("box_on_plane.usda")
        importer = USDImporter()
        builder_usd: ModelBuilderKamino = importer.import_from(
            source=usd_asset_filename, load_static_geometry=False, load_materials=False
        )

        # Construct a reference builder using the basics generators
        builder_ref = basics.build_box_on_plane(ground=False)

        # Check the loaded contents against the reference builder
        assert_builders_equal(self, builder_usd, builder_ref, skip_materials=True)

    def test_import_basic_box_pendulum(self):
        """Test importing the basic box_pendulum model from a USD file"""

        # Construct a builder from imported USD asset
        usd_asset_filename = get_kamino_basics_asset("box_pendulum.usda")
        importer = USDImporter()
        builder_usd: ModelBuilderKamino = importer.import_from(
            source=usd_asset_filename, load_static_geometry=False, load_materials=False
        )

        # Construct a reference builder using the basics generators
        builder_ref = basics.build_box_pendulum(ground=False)

        # Check the loaded contents against the reference builder
        assert_builders_equal(self, builder_usd, builder_ref, skip_materials=True)

    def test_import_basic_boxes_hinged(self):
        """Test importing the basic boxes_hinged model from a USD file"""

        # Construct a builder from imported USD asset
        usd_asset_filename = get_kamino_basics_asset("boxes_hinged.usda")
        importer = USDImporter()
        builder_usd: ModelBuilderKamino = importer.import_from(
            source=usd_asset_filename, load_static_geometry=False, load_materials=False
        )

        # Construct a reference builder using the basics generators
        builder_ref = basics.build_boxes_hinged(ground=False)

        # Check the loaded contents against the reference builder
        assert_builders_equal(self, builder_usd, builder_ref, skip_colliders=True, skip_materials=True)

    def test_import_basic_boxes_nunchaku(self):
        """Test importing the basic boxes_nunchaku model from a USD file"""

        # Construct a builder from imported USD asset
        usd_asset_filename = get_kamino_basics_asset("boxes_nunchaku.usda")
        importer = USDImporter()
        builder_usd: ModelBuilderKamino = importer.import_from(
            source=usd_asset_filename, load_static_geometry=False, load_materials=False
        )

        # Construct a reference builder using the basics generators
        builder_ref = basics.build_boxes_nunchaku(ground=False)

        # Check the loaded contents against the reference builder
        assert_builders_equal(self, builder_usd, builder_ref, skip_colliders=True, skip_materials=True)

    def test_import_basic_boxes_fourbar(self):
        """Test importing the basic boxes_fourbar model from a USD file"""

        # Construct a builder from imported USD asset
        usd_asset_filename = get_kamino_basics_asset("boxes_fourbar.usda")
        importer = USDImporter()
        builder_usd: ModelBuilderKamino = importer.import_from(
            source=usd_asset_filename, load_static_geometry=False, load_materials=False
        )

        # Construct a reference builder using the basics generators
        builder_ref = basics.build_boxes_fourbar(ground=False)

        # Check the loaded contents against the reference builder
        assert_builders_equal(self, builder_usd, builder_ref, skip_materials=True)

    def test_import_basic_cartpole(self):
        """Test importing the basic cartpole model from a USD file"""

        # Construct a builder from imported USD asset
        usd_asset_filename = get_kamino_basics_asset("cartpole.usda")
        importer = USDImporter()
        builder_usd: ModelBuilderKamino = importer.import_from(
            source=usd_asset_filename, load_static_geometry=True, load_materials=False
        )

        # Construct a reference builder using the basics generators
        builder_ref = basics.build_cartpole(z_offset=0.0, ground=False)

        # Check the loaded contents against the reference builder
        assert_builders_equal(self, builder_usd, builder_ref, skip_materials=True)

    ###
    # Reference models
    ###

    def test_import_model_dr_testmech(self):
        """Test importing the `DR Test Mechanism` example model with all joint types from a USD file"""
        print("")  # Add a newline for better readability

        # Load the DR Test Mechanism model from the `newton-assets` repository
        asset_path = newton.utils.download_asset("disneyresearch")
        model_asset_file = str(asset_path / "dr_testmech" / "usd" / "dr_testmech.usda")
        importer = USDImporter()
        builder_usd: ModelBuilderKamino = importer.import_from(source=model_asset_file)

        # Check the loaded contents
        self.assertEqual(builder_usd.num_bodies, 10)
        self.assertEqual(builder_usd.num_joints, 14)
        self.assertEqual(builder_usd.num_geoms, 10)
        self.assertEqual(builder_usd.num_materials, 1)
        self.assertEqual(builder_usd.joints[0][0].act_type, JointActuationType.PASSIVE)
        self.assertEqual(builder_usd.joints[0][0].dof_type, JointDoFType.FIXED)
        self.assertEqual(builder_usd.joints[0][1].act_type, JointActuationType.FORCE)
        self.assertEqual(builder_usd.joints[0][1].dof_type, JointDoFType.REVOLUTE)
        self.assertEqual(builder_usd.joints[0][2].act_type, JointActuationType.PASSIVE)
        self.assertEqual(builder_usd.joints[0][2].dof_type, JointDoFType.SPHERICAL)
        self.assertEqual(builder_usd.joints[0][3].act_type, JointActuationType.PASSIVE)
        self.assertEqual(builder_usd.joints[0][3].dof_type, JointDoFType.UNIVERSAL)
        self.assertEqual(builder_usd.joints[0][4].act_type, JointActuationType.PASSIVE)
        self.assertEqual(builder_usd.joints[0][4].dof_type, JointDoFType.SPHERICAL)
        self.assertEqual(builder_usd.joints[0][5].act_type, JointActuationType.PASSIVE)
        self.assertEqual(builder_usd.joints[0][5].dof_type, JointDoFType.REVOLUTE)
        self.assertEqual(builder_usd.joints[0][6].act_type, JointActuationType.PASSIVE)
        self.assertEqual(builder_usd.joints[0][6].dof_type, JointDoFType.UNIVERSAL)
        self.assertEqual(builder_usd.joints[0][7].act_type, JointActuationType.PASSIVE)
        self.assertEqual(builder_usd.joints[0][7].dof_type, JointDoFType.SPHERICAL)
        self.assertEqual(builder_usd.joints[0][8].act_type, JointActuationType.PASSIVE)
        self.assertEqual(builder_usd.joints[0][8].dof_type, JointDoFType.CYLINDRICAL)
        self.assertEqual(builder_usd.joints[0][9].act_type, JointActuationType.PASSIVE)
        self.assertEqual(builder_usd.joints[0][9].dof_type, JointDoFType.REVOLUTE)
        self.assertEqual(builder_usd.joints[0][10].act_type, JointActuationType.PASSIVE)
        self.assertEqual(builder_usd.joints[0][10].dof_type, JointDoFType.PRISMATIC)
        self.assertEqual(builder_usd.joints[0][11].act_type, JointActuationType.PASSIVE)
        self.assertEqual(builder_usd.joints[0][11].dof_type, JointDoFType.FIXED)
        self.assertEqual(builder_usd.joints[0][12].act_type, JointActuationType.PASSIVE)
        self.assertEqual(builder_usd.joints[0][12].dof_type, JointDoFType.SPHERICAL)
        self.assertEqual(builder_usd.joints[0][13].act_type, JointActuationType.PASSIVE)
        self.assertEqual(builder_usd.joints[0][13].dof_type, JointDoFType.CARTESIAN)

    def test_import_model_dr_legs(self):
        """Test importing the `DR Legs` example model from a USD file"""
        print("")  # Add a newline for better readability

        # Load the default DR Legs model from the `newton-assets` repository
        asset_path = newton.utils.download_asset("disneyresearch")
        model_asset_file = str(asset_path / "dr_legs" / "usd" / "dr_legs.usda")
        importer = USDImporter()
        builder_usd: ModelBuilderKamino = importer.import_from(source=model_asset_file)

        # Check the loaded contents
        self.assertEqual(builder_usd.num_bodies, 31)
        self.assertEqual(builder_usd.num_joints, 37)
        self.assertEqual(builder_usd.num_geoms, 81)

    def test_import_model_dr_legs_with_boxes(self):
        """Test importing the `DR Legs` example model from a USD file"""
        print("")  # Add a newline for better readability

        # Load the primitives-only DR Legs model from the `newton-assets` repository
        asset_path = newton.utils.download_asset("disneyresearch")
        model_asset_file = str(asset_path / "dr_legs" / "usd" / "dr_legs_with_boxes.usda")
        importer = USDImporter()
        builder_usd: ModelBuilderKamino = importer.import_from(source=model_asset_file)

        # Check the loaded contents
        self.assertEqual(builder_usd.num_bodies, 31)
        self.assertEqual(builder_usd.num_joints, 37)
        self.assertEqual(builder_usd.num_geoms, 3)

    def test_import_model_dr_legs_with_meshes_and_boxes(self):
        """Test importing the `DR Legs` example model from a USD file"""
        print("")  # Add a newline for better readability

        # Load the primitives-plus-meshes DR Legs model from the `newton-assets` repository
        asset_path = newton.utils.download_asset("disneyresearch")
        model_asset_file = str(asset_path / "dr_legs" / "usd" / "dr_legs_with_meshes_and_boxes.usda")
        importer = USDImporter()
        builder_usd: ModelBuilderKamino = importer.import_from(source=model_asset_file)

        # Check the loaded contents
        self.assertEqual(builder_usd.num_bodies, 31)
        self.assertEqual(builder_usd.num_joints, 37)
        self.assertEqual(builder_usd.num_geoms, 84)

    @unittest.skipUnless(USD_AVAILABLE, "Requires usd-core")
    def test_hide_collision_shapes_is_body_aware(self):
        """Hide colliders only on bodies that already have viewport-drawn visual geometry."""
        from pxr import Gf, Usd, UsdGeom, UsdPhysics

        stage = Usd.Stage.CreateInMemory()
        UsdGeom.SetStageUpAxis(stage, UsdGeom.Tokens.z)
        UsdPhysics.Scene.Define(stage, "/physicsScene")

        def add_body(path: str, pos: tuple[float, float, float], *, with_visual: bool) -> None:
            xform = UsdGeom.Xform.Define(stage, path)
            xform.AddTranslateOp().Set(Gf.Vec3d(*pos))
            UsdPhysics.RigidBodyAPI.Apply(xform.GetPrim())
            mass = UsdPhysics.MassAPI.Apply(xform.GetPrim())
            mass.CreateMassAttr(1.0)
            mass.CreateDiagonalInertiaAttr(Gf.Vec3f(1.0, 1.0, 1.0))
            cube = UsdGeom.Cube.Define(stage, f"{path}/CollisionBox")
            UsdPhysics.CollisionAPI.Apply(cube.GetPrim())
            cube.CreateSizeAttr(1.0)
            if with_visual:
                sphere = UsdGeom.Sphere.Define(stage, f"{path}/VisualSphere")
                sphere.CreateRadiusAttr(0.3)

        add_body("/BodyWithVisuals", (0.0, 0.0, 1.0), with_visual=True)
        add_body("/BodyWithoutVisuals", (2.0, 0.0, 1.0), with_visual=False)

        def collider_visible(builder: ModelBuilderKamino, body_name: str) -> bool:
            for geom in builder.all_geoms:
                if body_name in geom.name and "CollisionBox" in geom.name:
                    return bool(geom.flags & ShapeFlags.VISIBLE)
            self.fail(f"Missing collider for {body_name}")

        builder_default = USDImporter().import_from(stage, load_materials=False)
        self.assertTrue(collider_visible(builder_default, "BodyWithVisuals"))
        self.assertTrue(collider_visible(builder_default, "BodyWithoutVisuals"))

        builder_hidden = USDImporter().import_from(stage, load_materials=False, hide_collision_shapes=True)
        self.assertFalse(collider_visible(builder_hidden, "BodyWithVisuals"))
        self.assertTrue(collider_visible(builder_hidden, "BodyWithoutVisuals"))

    def _only_mesh_data(self, builder: ModelBuilderKamino):
        """Return the ``Mesh`` data of the builder's single mesh shape."""
        meshes = [shape.data for shape in builder.shapes.values() if hasattr(shape, "data")]
        self.assertEqual(len(meshes), 1)
        return meshes[0]

    @staticmethod
    def _define_mesh_quad(stage, path: str):
        """Define a unit quad mesh, returning the UsdGeom.Mesh."""
        from pxr import Gf, UsdGeom, UsdPhysics

        xform = UsdGeom.Xform.Define(stage, path)
        UsdPhysics.RigidBodyAPI.Apply(xform.GetPrim())
        mass = UsdPhysics.MassAPI.Apply(xform.GetPrim())
        mass.CreateMassAttr(1.0)
        mass.CreateDiagonalInertiaAttr(Gf.Vec3f(1.0, 1.0, 1.0))

        mesh = UsdGeom.Mesh.Define(stage, f"{path}/Mesh")
        UsdPhysics.CollisionAPI.Apply(mesh.GetPrim())
        mesh.CreatePointsAttr([Gf.Vec3f(0, 0, 0), Gf.Vec3f(1, 0, 0), Gf.Vec3f(1, 1, 0), Gf.Vec3f(0, 1, 0)])
        mesh.CreateFaceVertexIndicesAttr([0, 1, 2, 3])
        mesh.CreateFaceVertexCountsAttr([4])
        return mesh

    @unittest.skipUnless(USD_AVAILABLE, "Requires usd-core")
    def test_import_mesh_with_declared_but_unauthored_normals(self):
        """Import a mesh whose normals attribute is declared without a value.

        ``CreateNormalsAttr()`` leaves ``IsDefined()`` true while ``Get()`` returns
        ``None``, so guarding on ``IsDefined()`` alone used to pass ``None`` through to
        ``Mesh`` and raise ``cannot reshape array of size 1 into shape (3)``.
        """
        from pxr import Usd, UsdGeom, UsdPhysics

        stage = Usd.Stage.CreateInMemory()
        UsdGeom.SetStageUpAxis(stage, UsdGeom.Tokens.z)
        UsdPhysics.Scene.Define(stage, "/physicsScene")

        mesh = self._define_mesh_quad(stage, "/Body")
        mesh.CreateNormalsAttr()  # declared, never authored
        self.assertTrue(mesh.GetNormalsAttr().IsDefined())
        self.assertIsNone(mesh.GetNormalsAttr().Get())

        builder = USDImporter().import_from(stage, load_materials=False)

        mesh_data = self._only_mesh_data(builder)
        self.assertIsNone(mesh_data.normals)
        # The quad is fan-triangulated into two triangles.
        self.assertEqual(len(mesh_data.indices), 6)

    @unittest.skipUnless(USD_AVAILABLE, "Requires usd-core")
    def test_import_mesh_prefers_primvars_normals(self):
        """Read normals from ``primvars:normals`` in preference to the mesh attribute."""
        from pxr import Gf, Sdf, Usd, UsdGeom, UsdPhysics

        stage = Usd.Stage.CreateInMemory()
        UsdGeom.SetStageUpAxis(stage, UsdGeom.Tokens.z)
        UsdPhysics.Scene.Define(stage, "/physicsScene")

        mesh = self._define_mesh_quad(stage, "/Body")
        primvar = UsdGeom.PrimvarsAPI(mesh.GetPrim()).CreatePrimvar(
            "normals", Sdf.ValueTypeNames.Normal3fArray, UsdGeom.Tokens.vertex
        )
        primvar.Set([Gf.Vec3f(0, 0, 1)] * 4)

        builder = USDImporter().import_from(stage, load_materials=False)

        normals = self._only_mesh_data(builder).normals
        self.assertIsNotNone(normals)
        np.testing.assert_allclose(normals, np.tile([0.0, 0.0, 1.0], (4, 1)), atol=1e-6)


class TestUSDKaminoSceneAPIImport(unittest.TestCase):
    def setUp(self):
        if not test_context.setup_done:
            setup_tests(clear_cache=False)
        self.default_device = wp.get_device(test_context.device)
        self.verbose = test_context.verbose  # Set to True for verbose output

        # Set debug-level logging to print verbose test output to console
        if self.verbose:
            print("\n")  # Add newline before test output for better readability
            msg.set_log_level(msg.LogLevel.DEBUG)
        else:
            msg.reset_log_level()

    def tearDown(self):
        self.default_device = None
        if self.verbose:
            msg.reset_log_level()

    def generate_single_body_usd_import(self, scene: str = "") -> Model:
        from pxr import Usd

        usd_text = (
            "#usda 1.0\n\n"
            + scene
            + """def Xform "box"
{
    def Scope "RigidBodies"
    {
        def Xform "box_body" (
            prepend apiSchemas = ["PhysicsRigidBodyAPI", "PhysicsMassAPI"]
        )
        {
            # Body Frame
            quatf xformOp:orient = (1, 0, 0, 0)
            double3 xformOp:translate = (0.0, 0.0, 0.1)
            uniform token[] xformOpOrder = ["xformOp:translate", "xformOp:orient"]

            # Body Velocities
            vector3f physics:linearVelocity = (0, 0, 0)
            vector3f physics:angularVelocity = (0, 0, 0)

            # Mass Properties
            float physics:mass = 1.0
            float3 physics:diagonalInertia = (0.01, 0.01, 0.01)
            point3f physics:centerOfMass = (0, 0, 0)
            quatf physics:principalAxes = (1, 0, 0, 0)

            def Scope "Geometry"
            {
                def Cube "box_geom" (
                    prepend apiSchemas = ["PhysicsCollisionAPI"]
                )
                {
                    float3[] extent = [(-1, -1, -1), (1, 1, 1)]

                    float3 xformOp:scale = (0.1, 0.1, 0.1)
                    quatf xformOp:orient = (1, 0, 0, 0)
                    double3 xformOp:translate = (0, 0, 0)
                    uniform token[] xformOpOrder = ["xformOp:translate", "xformOp:orient", "xformOp:scale"]
                }
            }
        }
    }
}
"""
        )

        stage = Usd.Stage.CreateInMemory()
        stage.GetRootLayer().ImportFromString(usd_text)

        builder = ModelBuilder()
        SolverKamino.register_custom_attributes(builder)

        builder.add_usd(stage)

        model = builder.finalize()
        return model

    @unittest.skipUnless(USD_AVAILABLE, "Requires usd-core")
    def test_01_kamino_scene_api_import_no_scene(self):
        """Check that custom attributes are set with the right type."""

        model = self.generate_single_body_usd_import()

        self.assertTrue(hasattr(model, "kamino"))
        kamino_attr = model.kamino

        # Check existence and type of attributes
        self.assertTrue(
            hasattr(kamino_attr, "padmm_warmstarting") and isinstance(kamino_attr.padmm_warmstarting[0], str)
        )
        self.assertTrue(
            hasattr(kamino_attr, "padmm_use_acceleration")
            and isinstance(kamino_attr.padmm_use_acceleration.numpy()[0], np.bool_)
        )
        self.assertTrue(hasattr(kamino_attr, "joint_correction") and isinstance(kamino_attr.joint_correction[0], str))

        self.assertTrue(
            hasattr(kamino_attr, "constraints_use_preconditioning")
            and isinstance(kamino_attr.constraints_use_preconditioning.numpy()[0], np.bool_)
        )
        self.assertTrue(
            hasattr(kamino_attr, "constraints_alpha")
            and isinstance(kamino_attr.constraints_alpha.numpy()[0], np.floating)
        )
        self.assertTrue(
            hasattr(kamino_attr, "constraints_beta")
            and isinstance(kamino_attr.constraints_beta.numpy()[0], np.floating)
        )
        self.assertTrue(
            hasattr(kamino_attr, "constraints_gamma")
            and isinstance(kamino_attr.constraints_gamma.numpy()[0], np.floating)
        )

        self.assertTrue(
            hasattr(kamino_attr, "padmm_primal_tolerance")
            and isinstance(kamino_attr.padmm_primal_tolerance.numpy()[0], np.floating)
        )
        self.assertTrue(
            hasattr(kamino_attr, "padmm_dual_tolerance")
            and isinstance(kamino_attr.padmm_dual_tolerance.numpy()[0], np.floating)
        )
        self.assertTrue(
            hasattr(kamino_attr, "padmm_complementarity_tolerance")
            and isinstance(kamino_attr.padmm_complementarity_tolerance.numpy()[0], np.floating)
        )
        self.assertTrue(
            hasattr(kamino_attr, "max_solver_iterations")
            and isinstance(kamino_attr.max_solver_iterations.numpy()[0], np.integer)
        )

        # Compare attribute values to KaminoSceneAPI defaults
        self.assertEqual(kamino_attr.padmm_warmstarting[0], "containers")
        self.assertEqual(bool(kamino_attr.padmm_use_acceleration.numpy()[0]), True)
        self.assertEqual(kamino_attr.joint_correction[0], "twopi")

        self.assertEqual(bool(kamino_attr.constraints_use_preconditioning.numpy()[0]), True)
        self.assertAlmostEqual(kamino_attr.constraints_alpha.numpy()[0], 0.01)
        self.assertAlmostEqual(kamino_attr.constraints_beta.numpy()[0], 0.01)
        self.assertAlmostEqual(kamino_attr.constraints_gamma.numpy()[0], 0.01)

        self.assertAlmostEqual(kamino_attr.padmm_primal_tolerance.numpy()[0], 1e-6)
        self.assertAlmostEqual(kamino_attr.padmm_dual_tolerance.numpy()[0], 1e-6)
        self.assertAlmostEqual(kamino_attr.padmm_complementarity_tolerance.numpy()[0], 1e-6)
        self.assertEqual(kamino_attr.max_solver_iterations.numpy()[0], -1)

    @unittest.skipUnless(USD_AVAILABLE, "Requires usd-core")
    def test_02_kamino_scene_api_import_full_scene(self):
        """Check that values defined in USD are properly imported."""

        model = self.generate_single_body_usd_import("""
def PhysicsScene "PhysicsScene" (
    prepend apiSchemas = ["NewtonKaminoSceneAPI"]
)
{
    uniform int newton:maxSolverIterations = 10
    uniform float newton:kamino:padmm:primalTolerance = 0.1
    uniform float newton:kamino:padmm:dualTolerance = 0.2
    uniform float newton:kamino:padmm:complementarityTolerance = 0.3
    uniform token newton:kamino:padmm:warmstarting = "none"
    uniform bool newton:kamino:padmm:useAcceleration = false
    uniform bool newton:kamino:constraints:usePreconditioning = false
    uniform float newton:kamino:constraints:alpha = 0.4
    uniform float newton:kamino:constraints:beta = 0.5
    uniform float newton:kamino:constraints:gamma = 0.6
    uniform token newton:kamino:jointCorrection = "continuous"
}
""")

        self.assertTrue(hasattr(model, "kamino"))
        kamino_attr = model.kamino
        self.assertEqual(kamino_attr.padmm_warmstarting[0], "none")
        self.assertEqual(bool(kamino_attr.padmm_use_acceleration.numpy()[0]), False)
        self.assertEqual(kamino_attr.joint_correction[0], "continuous")

        self.assertEqual(bool(kamino_attr.constraints_use_preconditioning.numpy()[0]), False)
        self.assertAlmostEqual(kamino_attr.constraints_alpha.numpy()[0], 0.4)
        self.assertAlmostEqual(kamino_attr.constraints_beta.numpy()[0], 0.5)
        self.assertAlmostEqual(kamino_attr.constraints_gamma.numpy()[0], 0.6)

        self.assertAlmostEqual(kamino_attr.padmm_primal_tolerance.numpy()[0], 0.1)
        self.assertAlmostEqual(kamino_attr.padmm_dual_tolerance.numpy()[0], 0.2)
        self.assertAlmostEqual(kamino_attr.padmm_complementarity_tolerance.numpy()[0], 0.3)
        self.assertEqual(kamino_attr.max_solver_iterations.numpy()[0], 10)

    @unittest.skipUnless(USD_AVAILABLE, "Requires usd-core")
    def test_03_kamino_scene_api_import_faulty_scenes(self):
        """Check that faulty string attributes raise an error."""

        with self.assertRaises(ValueError):
            self.generate_single_body_usd_import("""
def PhysicsScene "PhysicsScene" (
    prepend apiSchemas = ["NewtonKaminoSceneAPI"]
)
{
    uniform token newton:kamino:padmm:warmstarting = "non"
}
""")

        with self.assertRaises(ValueError):
            self.generate_single_body_usd_import("""
def PhysicsScene "PhysicsScene" (
    prepend apiSchemas = ["NewtonKaminoSceneAPI"]
)
{
    uniform token newton:kamino:jointCorrection = "discrete"
}
""")

    @unittest.skipUnless(USD_AVAILABLE, "Requires usd-core")
    def test_04_kamino_scene_api_import_full_scene_config(self):
        """Check that values defined in USD are properly imported."""

        model = self.generate_single_body_usd_import("""
def PhysicsScene "PhysicsScene" (
    prepend apiSchemas = ["NewtonKaminoSceneAPI"]
)
{
    uniform int newton:maxSolverIterations = 10
    uniform float newton:kamino:padmm:primalTolerance = 0.1
    uniform float newton:kamino:padmm:dualTolerance = 0.2
    uniform float newton:kamino:padmm:complementarityTolerance = 0.3
    uniform token newton:kamino:padmm:warmstarting = "none"
    uniform bool newton:kamino:padmm:useAcceleration = false
    uniform bool newton:kamino:constraints:usePreconditioning = false
    uniform float newton:kamino:constraints:alpha = 0.4
    uniform float newton:kamino:constraints:beta = 0.5
    uniform float newton:kamino:constraints:gamma = 0.6
    uniform token newton:kamino:jointCorrection = "continuous"
}
""")
        config = SolverKamino.Config.from_model(model)

        self.assertEqual(config.rotation_correction, "continuous")

        self.assertEqual(config.dynamics.preconditioning, False)

        self.assertAlmostEqual(config.constraints.alpha, 0.4)
        self.assertAlmostEqual(config.constraints.beta, 0.5)
        self.assertAlmostEqual(config.constraints.gamma, 0.6)

        self.assertEqual(config.padmm.max_iterations, 10)
        self.assertAlmostEqual(config.padmm.primal_tolerance, 0.1)
        self.assertAlmostEqual(config.padmm.dual_tolerance, 0.2)
        self.assertAlmostEqual(config.padmm.compl_tolerance, 0.3)
        self.assertEqual(config.padmm.use_acceleration, False)
        self.assertEqual(config.padmm.warmstart_mode, "none")

    @unittest.skipUnless(USD_AVAILABLE, "Requires usd-core")
    def test_05_kamino_scene_api_import_full_scene_solver(self):
        """Check that values defined in USD are properly imported."""

        model = self.generate_single_body_usd_import("""
def PhysicsScene "PhysicsScene" (
    prepend apiSchemas = ["NewtonKaminoSceneAPI"]
)
{
    uniform int newton:maxSolverIterations = 10
    uniform float newton:kamino:padmm:primalTolerance = 0.1
    uniform float newton:kamino:padmm:dualTolerance = 0.2
    uniform float newton:kamino:padmm:complementarityTolerance = 0.3
    uniform token newton:kamino:padmm:warmstarting = "none"
    uniform bool newton:kamino:padmm:useAcceleration = false
    uniform bool newton:kamino:constraints:usePreconditioning = false
    uniform float newton:kamino:constraints:alpha = 0.4
    uniform float newton:kamino:constraints:beta = 0.5
    uniform float newton:kamino:constraints:gamma = 0.6
    uniform token newton:kamino:jointCorrection = "continuous"
}
""")

        solver = SolverKamino(model)
        config = solver._solver_kamino.config

        self.assertEqual(config.rotation_correction, "continuous")

        self.assertAlmostEqual(config.constraints.alpha, 0.4)
        self.assertAlmostEqual(config.constraints.beta, 0.5)
        self.assertAlmostEqual(config.constraints.gamma, 0.6)

        self.assertEqual(config.dynamics.preconditioning, False)

        self.assertEqual(config.padmm.max_iterations, 10)
        self.assertAlmostEqual(config.padmm.primal_tolerance, 0.1)
        self.assertAlmostEqual(config.padmm.dual_tolerance, 0.2)
        self.assertAlmostEqual(config.padmm.compl_tolerance, 0.3)
        self.assertEqual(config.padmm.use_acceleration, False)
        self.assertEqual(config.padmm.warmstart_mode, "none")


###
# Test execution
###

if __name__ == "__main__":
    # Test setup
    setup_tests()

    # Run all tests
    unittest.main(verbosity=2)

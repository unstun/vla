# SPDX-FileCopyrightText: Copyright (c) 2025 The Newton Developers
# SPDX-License-Identifier: Apache-2.0

"""SDF-based hydroelastic contact generation.

This module implements hydroelastic contact modeling between shapes represented
by Signed Distance Fields (SDFs). Hydroelastic contacts model compliant surfaces
where contact force is distributed over a contact patch rather than point contacts.

**Pipeline Overview:**

1. **Broadphase**: OBB intersection tests between SDF shape pairs
2. **Octree Refinement**: Hierarchical subdivision (8x8x8 → 4x4x4 → 2x2x2 → voxels)
   to find iso-voxels where the zero-isosurface between SDFs exists
3. **Marching Cubes**: Extract contact surface triangles from iso-voxels
4. **Contact Generation**: Generate contacts at triangle centroids with force
   proportional to penetration depth and surface area
5. **Contact Reduction**: Reduce contacts via ``HydroelasticContactReduction``

**Usage:**

Configure shapes with ``ShapeConfig(is_hydroelastic=True, kh=1e9)`` and
pass :class:`HydroelasticSDF.Config` to the collision pipeline.

See Also:
    :class:`HydroelasticSDF.Config`: Configuration options for this module.
    :class:`HydroelasticContactReduction`: Contact reduction for hydroelastic contacts.
"""

from __future__ import annotations

import warnings
from copy import copy
from dataclasses import dataclass
from typing import Any

import numpy as np
import warp as wp

from newton._src.core.types import MAXVAL, Devicelike

from ..sim.builder import ShapeFlags
from ..sim.model import Model
from .collision_core import sat_box_intersection
from .contact_data import ContactData
from .contact_reduction import get_slot
from .contact_reduction_global import (
    CONTACT_ID_BITS,
    GlobalContactReducerData,
    decode_oct,
    encode_oct,
    make_contact_key,
)
from .contact_reduction_hydroelastic import (
    EPS_SMALL,
    HydroelasticContactReduction,
    HydroelasticReductionConfig,
    export_hydroelastic_contact_to_buffer,
)
from .hashtable import hashtable_find_or_insert
from .sdf_mc import (
    MC_DEGENERATE_N_SQ_EPS,
    MC_EDGE_VAL_DIFF_EPS,
    get_mc_tables,
    get_triangle_fraction,
)
from .sdf_texture import (
    TextureSDFData,
    _texture_sample_sdf_at_voxel_paired,
    _texture_sample_sdf_at_voxel_scalar,
    _texture_sample_sdf_paired,
    _texture_sample_sdf_scalar,
    _texture_sample_sdf_zfiltered,
)
from .utils import scan_with_total

vec8f = wp.types.vector(length=8, dtype=wp.float32)
PRE_PRUNE_MAX_PENETRATING = 2

# Marching cubes emits at most 5 triangles per voxel, so ``tid * 5 + fi``
# uniquely identifies a generated face.  That value is used both as the
# reduction fingerprint and as the contact sort sub-key.
MAX_MC_FACES_PER_VOXEL = 5

# Keep the texture-heavy count kernel small enough for multiple resident blocks.
HYDRO_COUNT_BLOCK_DIM = 128
# The generation kernel carries more per-thread marching-cubes state; using one
# CUDA warp per block avoids the occupancy loss of the default launch size.
HYDRO_GENERATE_BLOCK_DIM = 32


@wp.func_native("""
#if defined(__CUDA_ARCH__)
float result;
asm("rsqrt.approx.ftz.f32 %0, %1;" : "=f"(result) : "f"(value));
return result;
#else
return 1.0f / sqrtf(value);
#endif
""")
def _hydro_rsqrt_approx(value: float) -> float:
    """Return a fast approximate reciprocal square root."""
    ...


# Contact sort sub-keys reserve bit 22 for hydroelastic anchor contacts and bit
# 0 for the normal/voxel reduction source. Face fingerprints are shifted left
# by one during export, so they must stay below bit 21.
_MAX_FACE_FINGERPRINT = 0x200000
_MAX_DETERMINISTIC_ISO_VOXELS = _MAX_FACE_FINGERPRINT // MAX_MC_FACES_PER_VOXEL

# Empirical per-level bounds relative to the narrow-band subgrids of the SDF
# traversed by each pair. Hydroelastic traversal must inspect the full dense
# grid for deep contacts, but surviving refinement work follows a surface and
# scales with the sparse narrow band rather than the grid volume.
_ISO_REFINEMENT_MULTIPLIERS = (8, 32, 128, 256)

# Marching cubes commonly emits more than one face from an iso voxel. The
# theoretical maximum is five, but two provides useful headroom for ordinary
# contact surfaces without making all face-storage allocations five times the
# already conservative voxel capacity.
_FACE_CONTACTS_PER_ISO_VOXEL = 2


class _MarginContactAreaUnset:
    """Mark an omitted deprecated margin contact area."""

    def __repr__(self) -> str:
        return "_DEPRECATED_MARGIN_CONTACT_AREA_UNSET"


_DEPRECATED_MARGIN_CONTACT_AREA_UNSET: Any = _MarginContactAreaUnset()


@wp.func
def classify_hydroelastic_contact(pair_separation: wp.float32, gap_sum: wp.float32) -> wp.int32:
    """Classify pair separation as penetrating (-1), speculative (0), or outside (1)."""
    if pair_separation < 0.0:
        return wp.int32(-1)
    return wp.int32(pair_separation > gap_sum)


@wp.func
def _map_shape_texture_sdf_data(
    sdf_data: wp.array[TextureSDFData],
    shape_sdf_index: wp.array[wp.int32],
    out_shape_sdf_data: wp.array[TextureSDFData],
    shape_idx: int,
):
    sdf_idx = shape_sdf_index[shape_idx]
    if sdf_idx < 0:
        out_shape_sdf_data[shape_idx].sdf_box_lower = wp.vec3(0.0, 0.0, 0.0)
        out_shape_sdf_data[shape_idx].sdf_box_upper = wp.vec3(0.0, 0.0, 0.0)
        out_shape_sdf_data[shape_idx].voxel_size = wp.vec3(0.0, 0.0, 0.0)
        out_shape_sdf_data[shape_idx].voxel_radius = 0.0
        out_shape_sdf_data[shape_idx].num_subgrids = 0
        out_shape_sdf_data[shape_idx].scale_baked = False
    else:
        out_shape_sdf_data[shape_idx] = sdf_data[sdf_idx]


@wp.kernel(enable_backward=False)
def map_shape_texture_sdf_data_kernel(
    sdf_data: wp.array[TextureSDFData],
    shape_sdf_index: wp.array[wp.int32],
    shape_transform: wp.array[wp.transform],
    out_shape_sdf_data: wp.array[TextureSDFData],
    out_shape_transform_inverse: wp.array[wp.transform],
):
    """Map texture SDF data and cache inverse world transforms per shape."""
    shape_idx = wp.tid()
    _map_shape_texture_sdf_data(sdf_data, shape_sdf_index, out_shape_sdf_data, shape_idx)
    out_shape_transform_inverse[shape_idx] = wp.transform_inverse(shape_transform[shape_idx])


@wp.kernel(enable_backward=False)
def cache_shape_texture_sdf_data_kernel(
    sdf_data: wp.array[TextureSDFData],
    shape_sdf_index: wp.array[wp.int32],
    out_shape_sdf_data: wp.array[TextureSDFData],
):
    """Map finalized texture SDF descriptors to shapes."""
    shape_idx = wp.tid()
    _map_shape_texture_sdf_data(sdf_data, shape_sdf_index, out_shape_sdf_data, shape_idx)


@wp.kernel(enable_backward=False)
def cache_shape_transform_inverse_kernel(
    shape_transform: wp.array[wp.transform],
    out_shape_transform_inverse: wp.array[wp.transform],
):
    """Cache inverse world transforms per shape."""
    shape_idx = wp.tid()
    out_shape_transform_inverse[shape_idx] = wp.transform_inverse(shape_transform[shape_idx])


@wp.func
def int_to_vec3f(x: wp.int32, y: wp.int32, z: wp.int32):
    return wp.vec3f(float(x), float(y), float(z))


@wp.func
def _mc_corner_offset(corner_idx: int) -> wp.vec3i:
    """Return the canonical marching-cubes offset for a corner index."""
    lower_idx = corner_idx & 3
    x = (lower_idx ^ (lower_idx >> 1)) & 1
    y = (corner_idx >> 1) & 1
    z = (corner_idx >> 2) & 1
    return wp.vec3i(x, y, z)


@wp.func
def get_effective_stiffness(k_a: wp.float32, k_b: wp.float32) -> wp.float32:
    """Compute effective stiffness for two materials in series."""
    denom = k_a + k_b
    if denom <= 0.0:
        return 0.0
    return (k_a * k_b) / denom


@wp.struct
class LinearPressureData:
    """Default pressure-callback state: a per-shape stiffness array.

    Backs the linear hydroelastic law ``pressure = -kh * signed_depth``
    used by :func:`linear_pressure`.
    """

    shape_kh: wp.array[wp.float32]
    """Per-shape stiffness coefficient (typically ``Model.shape_material_kh``)."""


@wp.func
def linear_pressure(signed_depth: wp.float32, shape_idx: wp.int32, data: LinearPressureData) -> wp.float32:
    """Default linear pressure law ``pressure = -kh * signed_depth``.

    Defined for any ``signed_depth`` so the iso-pressure surface evaluation
    stays continuous across the patch boundary. Returns a non-negative value
    when penetrating (``signed_depth < 0``) and a non-positive extrapolation
    otherwise; only the difference of pressures across shapes drives the
    marching-cubes interpolation, so the extrapolation must remain monotone
    non-increasing in ``signed_depth``.
    """
    return -data.shape_kh[shape_idx] * signed_depth


@wp.func
def _extract_mc_corner_pair(corner_vals: vec8f, corner_sdf_vals: vec8f, corner_idx: int) -> wp.vec2f:
    """Select one marching-cubes value/depth pair without local-memory indexing."""
    select_low = (corner_idx & 1) == 0
    select_mid = (corner_idx & 2) == 0
    select_high = (corner_idx & 4) == 0
    pair_01 = wp.where(
        select_low,
        wp.vec2f(corner_vals[0], corner_sdf_vals[0]),
        wp.vec2f(corner_vals[1], corner_sdf_vals[1]),
    )
    pair_23 = wp.where(
        select_low,
        wp.vec2f(corner_vals[2], corner_sdf_vals[2]),
        wp.vec2f(corner_vals[3], corner_sdf_vals[3]),
    )
    pair_45 = wp.where(
        select_low,
        wp.vec2f(corner_vals[4], corner_sdf_vals[4]),
        wp.vec2f(corner_vals[5], corner_sdf_vals[5]),
    )
    pair_67 = wp.where(
        select_low,
        wp.vec2f(corner_vals[6], corner_sdf_vals[6]),
        wp.vec2f(corner_vals[7], corner_sdf_vals[7]),
    )
    pair_03 = wp.where(select_mid, pair_01, pair_23)
    pair_47 = wp.where(select_mid, pair_45, pair_67)
    return wp.where(select_high, pair_03, pair_47)


@wp.func
def mc_calc_face_texture(
    flat_edge_verts_table: wp.array[wp.vec2ub],
    tri_range_start: wp.int32,
    corner_vals: vec8f,
    corner_adjusted_sdf: vec8f,
    corner_other_adjusted_sdf: vec8f,
    sdf_a: TextureSDFData,
    x_id: wp.int32,
    y_id: wp.int32,
    z_id: wp.int32,
    edge_clamp_min: wp.float32,
    edge_clamp_max: wp.float32,
) -> tuple[float, float, wp.vec3, wp.vec3, float, float, wp.mat33f]:
    """Extract a triangle face from a marching cubes voxel using texture SDF.

    Vertex positions are returned in the SDF's local coordinate space.

    ``edge_clamp_min`` / ``edge_clamp_max`` clamp the edge-interpolation
    parameter ``t`` to ``[edge_clamp_min, edge_clamp_max]``.  Pass
    ``(0.0, 1.0)`` to disable.  See
    :attr:`HydroelasticSDF.Config.mc_edge_clamp_min`.
    """
    face_verts = wp.mat33f()
    vert_adjusted_sdf = wp.vec3f()
    vert_pair_separation = wp.vec3f()
    num_inside = wp.int32(0)
    for vi in range(3):
        edge_verts = wp.vec2i(flat_edge_verts_table[tri_range_start + vi])
        v_idx_from = edge_verts[0]
        v_idx_to = edge_verts[1]
        corner_from = _extract_mc_corner_pair(corner_vals, corner_adjusted_sdf, v_idx_from)
        corner_to = _extract_mc_corner_pair(corner_vals, corner_adjusted_sdf, v_idx_to)
        corner_sdfs_from = _extract_mc_corner_pair(corner_adjusted_sdf, corner_other_adjusted_sdf, v_idx_from)
        corner_sdfs_to = _extract_mc_corner_pair(corner_adjusted_sdf, corner_other_adjusted_sdf, v_idx_to)
        val_0 = corner_from[0]
        val_1 = corner_to[0]

        p_0 = wp.vec3f(_mc_corner_offset(v_idx_from))
        p_1 = wp.vec3f(_mc_corner_offset(v_idx_to))
        val_diff = wp.float32(val_1 - val_0)
        if wp.abs(val_diff) < MC_EDGE_VAL_DIFF_EPS:
            t = float(0.5)
        else:
            # Clamp t away from cube corners to prevent vertex collapse when
            # corner values are near zero (e.g. at SDF ridge boundaries where
            # both shapes share the same nearest face).  Without the clamp,
            # t close to 0 or 1 places multiple vertices at the same corner,
            # producing degenerate (zero-area) triangles.
            t = wp.clamp((0.0 - val_0) / val_diff, edge_clamp_min, edge_clamp_max)
        p = p_0 + t * (p_1 - p_0)
        vol_idx = p + int_to_vec3f(x_id, y_id, z_id)
        local_pos = sdf_a.sdf_box_lower + wp.cw_mul(vol_idx, sdf_a.voxel_size)
        face_verts[vi] = local_pos
        adjusted_sdf_from = corner_sdfs_from[0]
        adjusted_sdf_to = corner_sdfs_to[0]
        other_adjusted_sdf_from = corner_sdfs_from[1]
        other_adjusted_sdf_to = corner_sdfs_to[1]
        adjusted_sdf = adjusted_sdf_from + t * (adjusted_sdf_to - adjusted_sdf_from)
        other_adjusted_sdf = other_adjusted_sdf_from + t * (other_adjusted_sdf_to - other_adjusted_sdf_from)
        pair_separation = adjusted_sdf + other_adjusted_sdf
        vert_adjusted_sdf[vi] = adjusted_sdf
        vert_pair_separation[vi] = pair_separation
        if pair_separation < 0.0:
            num_inside += 1

    n = wp.cross(face_verts[1] - face_verts[0], face_verts[2] - face_verts[0])
    n_sq = wp.dot(n, n)
    if n_sq < MC_DEGENERATE_N_SQ_EPS:
        # Degenerate triangle — return zero area with a valid (non-NaN) normal.
        geometric_area = 0.0
        normal = wp.vec3(0.0, 0.0, 1.0)
    else:
        inv_n_len = _hydro_rsqrt_approx(n_sq)
        normal = n * inv_n_len
        geometric_area = (n_sq * inv_n_len) * 0.5
    center = (face_verts[0] + face_verts[1] + face_verts[2]) / 3.0
    adjusted_sdf = (vert_adjusted_sdf[0] + vert_adjusted_sdf[1] + vert_adjusted_sdf[2]) / 3.0
    pair_separation = (vert_pair_separation[0] + vert_pair_separation[1] + vert_pair_separation[2]) / 3.0
    force_area = geometric_area * get_triangle_fraction(vert_pair_separation, num_inside)
    return force_area, geometric_area, normal, center, adjusted_sdf, pair_separation, face_verts


class HydroelasticSDF:
    """Hydroelastic contact generation with SDF-based collision detection.

    .. experimental::

        ``HydroelasticSDF`` and the underlying SDF storage on
        :class:`~newton.Model` may change without notice.

    This class implements hydroelastic contact modeling between shapes represented
    by Signed Distance Fields (SDFs). It uses an octree-based broadphase to identify
    potentially colliding regions, then applies marching cubes to extract the
    zero-isosurface where both SDFs intersect. Contact points are generated at
    triangle centroids on this isosurface, with contact forces proportional to
    penetration depth and represented area.

    The collision pipeline consists of:
        1. Broadphase: Identifies overlapping OBBs of SDF between shape pairs
        2. Octree refinement: Hierarchically subdivides blocks to find iso-voxels
        3. Marching cubes: Extracts contact surface triangles from iso-voxels
        4. Contact generation: Computes contact points, normals, depths, and areas
        5. Optional contact reduction: Bins and reduces contacts per shape pair

    Args:
        num_shape_pairs: Maximum number of hydroelastic shape pairs to process.
        total_num_tiles: Total number of dense SDF blocks traversed across all
            hydroelastic shape pairs. Each pair traverses only its finer SDF,
            so this is the sum over pairs of that grid's block count.
        total_num_active_tiles: Total number of narrow-band SDF blocks across
            the same traversal grids, used to size refinement buffers.
        shape_material_kh: Hydroelastic stiffness coefficient for each shape.
        n_shapes: Total number of shapes in the simulation.
        config: Configuration options controlling buffer sizes, contact reduction,
            and other behavior. Defaults to :class:`HydroelasticSDF.Config`.
        device: Warp device for GPU computation.
        writer_func: Callback for writing decoded contact data.
        deterministic: Whether to make hydroelastic accumulation and contact
            allocation reproducible across runs on the same GPU architecture.
            Must be chosen at construction because it changes code generation.

    Note:
        Instances are typically created internally when constructing a
        :class:`~newton.CollisionPipeline` rather than constructed directly.
        The pipeline automatically extracts the required SDF data and shape
        information from the simulation :class:`~newton.Model`.

        Contact IDs are packed into 32-bit integers using 9 bits per voxel axis coordinate.
        For SDF grids larger than 512 voxels per axis, contact ID collisions may occur,
        which can affect contact matching accuracy for warm-starting physics solvers.

    See Also:
        :class:`HydroelasticSDF.Config`: Configuration options for this class.
    """

    @dataclass
    class Config:
        """Controls properties of SDF hydroelastic collision handling."""

        reduce_contacts: bool = True
        """Whether to reduce contacts to a smaller representative set per shape pair.
        When False, all generated contacts are passed through without reduction."""
        pre_prune_contacts: bool = True
        """Whether to perform local-first face compaction during generation.
        This mode avoids global hashtable traffic in the hot generation loop and
        writes a smaller contact set to the buffer before the normal reduce pass.
        Only active when ``reduce_contacts`` is True."""
        buffer_fraction: float = 1.0
        """Fraction applied to default hydroelastic buffer estimates. Range: (0, 1].

        This scales pre-allocated broadphase, iso-refinement, and face-contact
        buffers from their default estimated capacities before applying stage
        multipliers. Lower values reduce memory usage and may cause overflows in
        dense scenes. Overflows are bounds-safe and emit warnings; increase this
        value when warnings appear. In deterministic mode, the final iso-voxel
        capacity has a hard fingerprint-safe limit that buffer fractions and
        multipliers cannot raise. If that limit overflows, reduce the SDF
        resolution or disable deterministic mode.
        """
        buffer_mult_broad: int = 1
        """Multiplier for the preallocated broadphase buffer that stores overlapping
        block pairs. Increase only if a broadphase overflow warning is issued."""
        buffer_mult_iso: int = 1
        """Multiplier for preallocated iso-surface extraction buffers used during
        hierarchical octree refinement (subblocks and voxels). Increase only if an iso buffer overflow warning is issued.
        The final voxel buffer remains subject to the deterministic fingerprint-safe limit."""
        buffer_mult_contact: int = 1
        """Multiplier for the preallocated face contact buffer that stores contact
        positions, normals, depths, and areas. Increase only if a face contact overflow warning is issued."""
        contact_buffer_fraction: float = 0.5
        """Fraction of the face contact buffer to allocate when ``reduce_contacts`` is True.
        The reduce kernel selects winners from whatever fits in the buffer, so a smaller
        buffer trades off coverage for memory savings.
        Range: (0, 1]. Only applied when ``reduce_contacts`` is enabled; ignored otherwise."""
        contact_reduction_hashtable_size_factor: float = 0.25
        """Multiplier applied to the hydroelastic contact reduction hashtable size.
        Increase this if reduction hashtable fill/failure warnings appear. Must be positive."""
        grid_size: int = 256 * 8 * 128
        """Grid size for contact handling. Can be tuned for performance."""
        output_contact_surface: bool = False
        """Whether to output hydroelastic contact surface vertices for visualization."""
        normal_matching: bool = True
        """Whether to rotate reduced contact normals so their weighted sum aligns with
        the aggregate force direction. Only active when reduce_contacts is True."""
        anchor_contact: bool = False
        """Whether to add an anchor contact at the center of pressure for each normal bin.
        The anchor contact helps preserve moment balance. Only active when reduce_contacts is True."""
        moment_matching: bool = False
        """Whether to adjust per-contact friction scales so that the maximum
        friction moment per normal bin is preserved between reduced and
        unreduced contacts. Automatically enables ``anchor_contact``.
        Only active when reduce_contacts is True."""
        margin_contact_area: float = _DEPRECATED_MARGIN_CONTACT_AREA_UNSET
        """Deprecated speculative-contact area [m^2] retained for compatibility.

        .. deprecated:: 1.6

            This setting still controls speculative-contact activation
            stiffness during the deprecation period.
        """
        pressure_func: Any = None
        """Optional Warp function defining ``pressure = f(signed_depth, shape_idx, data)``.

        The contact surface is the locus where ``pressure_a == pressure_b``.
        Signature:

        .. code-block:: python

            @wp.func
            def my_pressure(signed_depth: wp.float32, shape_idx: wp.int32, data: MyData) -> wp.float32:
                ...

        Invoked at every sampled point — including non-penetrating ones
        (``signed_depth >= 0``) — by both the iso-voxel pruning kernel
        (:func:`count_iso_voxels_block`) and the marching-cubes corner
        evaluation (:func:`mc_iterate_voxel_vertices`). The callback must
        therefore be finite and monotone non-increasing in ``signed_depth``
        over its full domain, and should extend continuously into the thin
        non-contact region. Do not clip ``signed_depth >= 0`` to zero pressure:
        when two shapes have different stiffnesses, the pressure-balance
        surface can pass through that outside region, and a flat zero segment
        can move or remove the iso-pressure crossing. Returning NaN or
        undefined values for ``signed_depth >= 0`` will corrupt the prune
        intervals and the marching-cubes interpolation that locates the
        iso-pressure surface.
        When ``None`` the default :func:`linear_pressure` is used.
        """
        pressure_data: Any = None
        """Optional ``wp.struct`` instance carrying state for :attr:`pressure_func`.

        When both :attr:`pressure_func` and :attr:`pressure_data` are ``None``,
        a default :class:`LinearPressureData` containing
        ``Model.shape_material_kh`` is constructed automatically. If a custom
        :attr:`pressure_func` is provided, a matching ``wp.struct`` instance
        must also be supplied here; otherwise construction raises
        ``ValueError``. If a custom data struct stores finalized model arrays
        such as ``Model.shape_material_kh``, create the model first with
        ``ModelBuilder.finalize()``, then assign those arrays to
        ``pressure_data`` before constructing :class:`HydroelasticSDF` or
        :class:`~newton.CollisionPipeline`. The ``shape_idx`` argument passed
        to :attr:`pressure_func` uses the finalized model's shape indexing.
        """
        mc_edge_clamp_min: float = 0.02
        """Lower bound for the marching-cubes edge interpolation parameter
        (``t`` clamped to ``[mc_edge_clamp_min, 1 - mc_edge_clamp_min]``).

        Range: ``[0.0, 0.5]``.  The default of ``0.02`` prevents vertex
        collapse at SDF ridge boundaries, where multiple triangle vertices
        would otherwise land on the same cube corner.  Set to ``0.0`` for
        the most faithful contact-surface dynamics — recommended for
        threading-style scenarios like ``nut_bolt_hydro`` where the surface
        bias measurably damps the contact response."""

        def __post_init__(self):
            if self.margin_contact_area is _DEPRECATED_MARGIN_CONTACT_AREA_UNSET:
                self.margin_contact_area = 1.0e-2
            else:
                warnings.warn(
                    "HydroelasticSDF.Config.margin_contact_area is deprecated; remove this setting.",
                    DeprecationWarning,
                    stacklevel=2,
                )
            # NaN fails both bounds (NaN comparisons return False) and lands here too.
            if not (0.0 <= float(self.mc_edge_clamp_min) <= 0.5):
                raise ValueError(
                    f"HydroelasticSDF.Config.mc_edge_clamp_min must be in [0.0, 0.5], got {self.mc_edge_clamp_min}"
                )
            if not float(self.contact_reduction_hashtable_size_factor) > 0.0:
                raise ValueError(
                    "HydroelasticSDF.Config.contact_reduction_hashtable_size_factor "
                    f"must be > 0.0, got {self.contact_reduction_hashtable_size_factor}"
                )

    @dataclass
    class ContactSurfaceData:
        """
        Data container for hydroelastic contact surface visualization.

        Contains the vertex arrays and metadata needed for rendering
        the contact surface triangles from hydroelastic collision detection.
        """

        contact_surface_point: wp.array[wp.vec3f]
        """World-space positions of contact surface triangle vertices (3 per face)."""
        contact_surface_depth: wp.array[wp.float32]
        """Margin-relative pair separation [m] at each face centroid."""
        contact_surface_shape_pair: wp.array[wp.vec2i]
        """Shape pair indices (shape_a, shape_b) for each face."""
        face_contact_count: wp.array[wp.int32]
        """Array containing the number of face contacts."""
        max_num_face_contacts: int
        """Maximum number of face contacts (buffer size)."""

    def __init__(
        self,
        num_shape_pairs: int,
        total_num_tiles: int,
        total_num_active_tiles: int,
        shape_material_kh: wp.array[wp.float32],
        n_shapes: int,
        config: HydroelasticSDF.Config | None = None,
        device: Devicelike | None = None,
        writer_func: Any = None,
        deterministic: bool = False,
        paired_samples: bool = True,
    ) -> None:
        if config is None:
            config = HydroelasticSDF.Config()
        if deterministic and config.pre_prune_contacts:
            # Pre-pruning keeps a per-thread top-K of faces, so which faces reach
            # the contact buffer depends on how voxels are distributed over threads.
            # Deterministic mode is the supported way to ask for reproducibility,
            # so this is silent; the cost is documented on ``pre_prune_contacts``
            # and in the deterministic-collisions section of the collision docs.
            # Avoid reconstructing the dataclass: doing so would make an omitted
            # deprecated field look explicitly supplied and emit a spurious warning.
            config = copy(config)
            config.pre_prune_contacts = False

        self.config = config
        self.deterministic = deterministic
        if device is None:
            device = wp.get_device()
        self.device = device

        self.shape_material_kh = shape_material_kh
        self.paired_samples = paired_samples

        self.n_shapes = n_shapes
        self.max_num_shape_pairs = num_shape_pairs
        self.total_num_tiles = total_num_tiles
        self.total_num_active_tiles = total_num_active_tiles

        frac = float(self.config.buffer_fraction)
        if frac <= 0.0 or frac > 1.0:
            raise ValueError(f"HydroelasticSDF.Config.buffer_fraction must be in (0, 1], got {frac}")
        contact_frac = float(self.config.contact_buffer_fraction)
        if contact_frac <= 0.0 or contact_frac > 1.0:
            raise ValueError(f"HydroelasticSDF.Config.contact_buffer_fraction must be in (0, 1], got {contact_frac}")

        self.max_num_blocks_broad = max(
            int(self.total_num_tiles * self.config.buffer_mult_broad * frac),
            64,
        )
        # Output buffer sizes for each octree level (subblocks 8x8x8 -> 4x4x4 -> 2x2x2 -> voxels)
        refinement_base = self.config.buffer_mult_iso * self.total_num_active_tiles * frac
        iso_max_dims = [max(int(mult * refinement_base), 64) for mult in _ISO_REFINEMENT_MULTIPLIERS]
        if deterministic:
            # A face fingerprint is ``voxel_id * MAX_MC_FACES_PER_VOXEL + face_id``.
            # Bound the final refinement buffer so every generated face remains
            # below the anchor bit reserved by deterministic contact sort keys.
            iso_max_dims[3] = min(iso_max_dims[3], _MAX_DETERMINISTIC_ISO_VOXELS)
        self.iso_max_dims = tuple(iso_max_dims)
        self.max_num_iso_voxels = self.iso_max_dims[3]
        # Input buffer sizes for each octree level
        self.input_sizes = (self.max_num_blocks_broad, *self.iso_max_dims[:3])

        with wp.ScopedDevice(device):
            self.num_shape_pairs_array = wp.full((1,), self.max_num_shape_pairs, dtype=wp.int32)

            # Allocate buffers for octree traversal (broadphase + 4 refinement levels)
            self.iso_buffer_counts = [wp.zeros((1,), dtype=wp.int32) for _ in range(5)]
            # Scratch buffers are per-level to avoid scanning the worst-case
            # size at all refinement levels during graph-captured execution.
            self.iso_buffer_prefix_scratch = [wp.zeros(level_input, dtype=wp.int32) for level_input in self.input_sizes]
            self.iso_buffer_num_scratch = [wp.zeros(level_input, dtype=wp.int32) for level_input in self.input_sizes]
            self.iso_subblock_idx_scratch = [wp.zeros(level_input, dtype=wp.uint8) for level_input in self.input_sizes]
            self.iso_buffer_records = [wp.empty((self.max_num_blocks_broad,), dtype=wp.vec3ui)] + [
                wp.empty((self.iso_max_dims[i],), dtype=wp.vec3ui) for i in range(4)
            ]
            self.normalized_shape_pairs = wp.empty((self.max_num_shape_pairs,), dtype=wp.vec2i)

            # Aliases for commonly accessed final buffers
            self.block_broad_collide_count = self.iso_buffer_counts[0]
            self.iso_voxel_count = self.iso_buffer_counts[4]
            self.iso_voxel_records = self.iso_buffer_records[4]

            # Broadphase buffers
            self.block_start_prefix = wp.zeros((self.max_num_shape_pairs,), dtype=wp.int32)
            self.num_blocks_per_pair = wp.zeros((self.max_num_shape_pairs,), dtype=wp.int32)
            self.block_broad_collide_records = self.iso_buffer_records[0]

            # Face contacts written directly to GlobalContactReducer (no intermediate buffers)
            # When pre-pruning is active, far fewer contacts reach the buffer so we
            # scale down by contact_buffer_fraction to save memory.
            face_contact_budget = config.buffer_mult_contact * _FACE_CONTACTS_PER_ISO_VOXEL * self.max_num_iso_voxels
            if config.reduce_contacts and config.pre_prune_contacts:
                face_contact_budget = face_contact_budget * config.contact_buffer_fraction
            self.max_num_face_contacts = max(int(face_contact_budget), 64)
            if deterministic:
                max_det_contacts = (1 << int(CONTACT_ID_BITS)) - 1
                # Contact IDs cannot represent a larger deterministic buffer.
                # Bound the conservative estimate; runtime overflow reporting
                # still catches a scene that genuinely reaches this limit.
                self.max_num_face_contacts = min(self.max_num_face_contacts, max_det_contacts)
            self.grid_size = min(self.config.grid_size, self.max_num_face_contacts)

            if self.config.output_contact_surface:
                # stores the point and depth of the contact surface vertex
                self.iso_vertex_point = wp.empty((3 * self.max_num_face_contacts,), dtype=wp.vec3f)
                self.iso_vertex_depth = wp.empty((self.max_num_face_contacts,), dtype=wp.float32)
                self.iso_vertex_shape_pair = wp.empty((self.max_num_face_contacts,), dtype=wp.vec2i)
            else:
                self.iso_vertex_point = wp.empty((0,), dtype=wp.vec3f)
                self.iso_vertex_depth = wp.empty((0,), dtype=wp.float32)
                self.iso_vertex_shape_pair = wp.empty((0,), dtype=wp.vec2i)

            self.mc_tables = get_mc_tables(device)

            # Placeholder empty arrays for kernel parameters unused in no-prune mode
            self._empty_vec3 = wp.empty((0,), dtype=wp.vec3, device=device)
            self._empty_vec3i = wp.empty((0,), dtype=wp.vec3i, device=device)

            # Pre-allocate per-shape SDF data buffer used in launch() so that
            # no wp.empty() call occurs during CUDA graph capture (#1616).
            self._shape_sdf_data = wp.empty(n_shapes, dtype=TextureSDFData, device=device)
            self._shape_transform_inverse = wp.empty(n_shapes, dtype=wp.transform, device=device)

            # Resolve the pressure callback. Defaults to the linear hydroelastic
            # law backed by ``shape_material_kh`` so behavior is unchanged when
            # the user does not supply one. ``pressure_func`` and
            # ``pressure_data`` must be supplied together; supplying only one
            # is a configuration error rather than silently dropped.
            if self.config.pressure_func is None:
                if self.config.pressure_data is not None:
                    raise ValueError("HydroelasticSDF.Config.pressure_func must be provided when pressure_data is set.")
                self.pressure_func = linear_pressure
                self.pressure_data = LinearPressureData()
                self.pressure_data.shape_kh = shape_material_kh
            else:
                if self.config.pressure_data is None:
                    raise ValueError("HydroelasticSDF.Config.pressure_data must be provided when pressure_func is set.")
                self.pressure_func = self.config.pressure_func
                self.pressure_data = self.config.pressure_data

            self.count_iso_voxels_block_integer_kernel = create_count_iso_voxels_block_kernel(
                self.pressure_func, True, self.paired_samples
            )
            self.count_iso_voxel_children_kernel = create_count_iso_voxel_children_kernel(
                self.pressure_func, False, self.paired_samples
            )
            self.count_iso_voxel_children_integer_kernel = create_count_iso_voxel_children_kernel(
                self.pressure_func, True, self.paired_samples
            )

            self.generate_contacts_kernel = get_generate_contacts_kernel(
                output_vertices=self.config.output_contact_surface,
                pre_prune=self.config.reduce_contacts and self.config.pre_prune_contacts,
                reduce_contacts=self.config.reduce_contacts,
                deterministic_reduction=self.deterministic and self.config.reduce_contacts,
                pressure_func=self.pressure_func,
                mc_edge_clamp_min=self.config.mc_edge_clamp_min,
                paired_samples=self.paired_samples,
            )

            if self.config.reduce_contacts:
                # Use HydroelasticContactReduction for efficient hashtable-based contact reduction
                # The reducer uses spatial extremes + max-depth per normal bin + voxel-based slots
                reduction_config = HydroelasticReductionConfig(
                    normal_matching=self.config.normal_matching,
                    anchor_contact=self.config.anchor_contact,
                    moment_matching=self.config.moment_matching,
                    margin_contact_area=self.config.margin_contact_area,
                    hashtable_size_factor=self.config.contact_reduction_hashtable_size_factor,
                )
                self.contact_reduction = HydroelasticContactReduction(
                    capacity=self.max_num_face_contacts,
                    device=device,
                    writer_func=writer_func,
                    config=reduction_config,
                    deterministic=self.deterministic,
                )
                self.decode_contacts_kernel = None
            else:
                # No reduction - create a simple reducer for buffer storage and decode kernel
                self.contact_reduction = HydroelasticContactReduction(
                    capacity=self.max_num_face_contacts,
                    device=device,
                    writer_func=writer_func,
                    config=HydroelasticReductionConfig(
                        margin_contact_area=self.config.margin_contact_area,
                        hashtable_size_factor=self.config.contact_reduction_hashtable_size_factor,
                    ),
                    deterministic=self.deterministic,
                    enable_reduction=False,
                )
                self.decode_contacts_kernel = get_decode_contacts_kernel(
                    self.config.margin_contact_area,
                    writer_func,
                )

        self._host_warning_poll_interval = 120
        self._launch_counter = 0

    def _prepare_shape_sdf_data(
        self, texture_sdf_data: wp.array[TextureSDFData], shape_sdf_index: wp.array[wp.int32]
    ) -> None:
        """Cache finalized per-shape texture SDF descriptors."""
        wp.launch(
            kernel=cache_shape_texture_sdf_data_kernel,
            dim=shape_sdf_index.shape[0],
            inputs=[texture_sdf_data, shape_sdf_index],
            outputs=[self._shape_sdf_data],
            device=self.device,
            record_tape=False,
        )

    def _validate_deterministic(self, deterministic: bool) -> None:
        """Raise if ``deterministic`` disagrees with the mode chosen at construction.

        Lets :class:`~newton.geometry.NarrowPhase` reject a pre-built instance
        whose determinism setting does not match the pipeline's.
        """
        if deterministic != self.deterministic:
            raise ValueError(
                "Hydroelastic determinism must be selected when HydroelasticSDF is constructed "
                "because it changes the generated kernels and reducer layout."
            )

    @classmethod
    def _from_model(
        cls,
        model: Model,
        config: HydroelasticSDF.Config | None = None,
        writer_func: Any = None,
        deterministic: bool = False,
    ) -> HydroelasticSDF | None:
        """Create HydroelasticSDF from a model.

        Args:
            model: The simulation model.
            config: Optional configuration for hydroelastic collision handling.
            writer_func: Optional writer function for decoding contacts.
            deterministic: Whether to enable deterministic hydroelastic kernels.

        Returns:
            HydroelasticSDF instance, or None if no hydroelastic shape pairs exist.
        """
        shape_flags = model.shape_flags.numpy()

        # Check if any shapes have hydroelastic flag.
        is_hydroelastic = (shape_flags & int(ShapeFlags.HYDROELASTIC)) != 0
        if not is_hydroelastic.any():
            return None

        shape_pairs = model.shape_contact_pairs.numpy().reshape(-1, 2)
        num_hydroelastic_pairs = int(
            np.count_nonzero(is_hydroelastic[shape_pairs[:, 0]] & is_hydroelastic[shape_pairs[:, 1]])
        )

        if num_hydroelastic_pairs == 0:
            return None

        shape_sdf_index = model._shape_sdf_index.numpy()
        texture_sdf_data = model._texture_sdf_data.numpy()
        shape_scale = model.shape_scale.numpy()
        coarse_textures = model._texture_sdf_coarse_textures

        # Get indices of shapes that can collide and are hydroelastic
        hydroelastic_indices = [
            i
            for i in range(model.shape_count)
            if (shape_flags[i] & ShapeFlags.COLLIDE_SHAPES) and (shape_flags[i] & ShapeFlags.HYDROELASTIC)
        ]

        for idx in hydroelastic_indices:
            sdf_idx = int(shape_sdf_index[idx])
            if sdf_idx < 0:
                raise ValueError(f"Hydroelastic shape {idx} requires SDF data but has no attached/generated SDF.")
            if sdf_idx >= len(coarse_textures) or coarse_textures[sdf_idx] is None:
                raise ValueError(
                    f"Hydroelastic shape {idx} requires texture SDF data but its attached/generated SDF has none. "
                    "Build the SDF with mesh.build_sdf() before using hydroelastic contacts."
                )
            if not texture_sdf_data[sdf_idx]["scale_baked"]:
                sx, sy, sz = shape_scale[idx]
                if not (np.isclose(sx, 1.0) and np.isclose(sy, 1.0) and np.isclose(sz, 1.0)):
                    raise ValueError(
                        f"Hydroelastic shape {idx} uses non-unit scale but its SDF is not scale-baked. "
                        "Build a scale-baked SDF for hydroelastic use."
                    )

        # Count the grids that the broadphase actually traverses. Each pair
        # walks only its finer SDF and samples the other SDF at those points.
        total_num_tiles = 0
        total_num_active_tiles = 0
        hydroelastic_pairs = shape_pairs[is_hydroelastic[shape_pairs[:, 0]] & is_hydroelastic[shape_pairs[:, 1]]]
        for shape_a, shape_b in hydroelastic_pairs:
            sdf_idx_a = int(shape_sdf_index[shape_a])
            sdf_idx_b = int(shape_sdf_index[shape_b])
            # Match broadphase_collision_pairs_count(): equal-resolution pairs
            # retain shape B as the traversal grid.
            sdf_idx = sdf_idx_b
            if texture_sdf_data[sdf_idx_b]["voxel_radius"] > texture_sdf_data[sdf_idx_a]["voxel_radius"]:
                sdf_idx = sdf_idx_a
            tex = coarse_textures[sdf_idx]
            total_num_tiles += (tex.width - 1) * (tex.height - 1) * (tex.depth - 1)
            total_num_active_tiles += int(texture_sdf_data[sdf_idx]["num_subgrids"])

        return cls(
            num_shape_pairs=num_hydroelastic_pairs,
            total_num_tiles=total_num_tiles,
            total_num_active_tiles=total_num_active_tiles,
            shape_material_kh=model.shape_material_kh,
            n_shapes=model.shape_count,
            config=config,
            device=model.device,
            writer_func=writer_func,
            deterministic=deterministic,
            paired_samples=model._sdf_texture_paired_samples,
        )

    def get_contact_surface(self) -> ContactSurfaceData | None:
        """Get hydroelastic :class:`ContactSurfaceData` for visualization.

        Returns:
            A :class:`ContactSurfaceData` instance containing vertex arrays and metadata for rendering,
            or None if :attr:`~newton.geometry.HydroelasticSDF.Config.output_contact_surface` is False.
        """
        if not self.config.output_contact_surface:
            return None
        return self.ContactSurfaceData(
            contact_surface_point=self.iso_vertex_point,
            contact_surface_depth=self.iso_vertex_depth,
            contact_surface_shape_pair=self.iso_vertex_shape_pair,
            face_contact_count=self.contact_reduction.contact_count,
            max_num_face_contacts=self.max_num_face_contacts,
        )

    def launch(
        self,
        texture_sdf_data: wp.array[TextureSDFData],
        shape_sdf_index: wp.array[wp.int32],
        shape_data: wp.array[wp.vec4],
        shape_transform: wp.array[wp.transform],
        shape_gap: wp.array[wp.float32],
        shape_collision_aabb_lower: wp.array[wp.vec3],
        shape_collision_aabb_upper: wp.array[wp.vec3],
        shape_voxel_resolution: wp.array[wp.vec3i],
        shape_pairs_sdf_sdf: wp.array[wp.vec2i],
        shape_pairs_sdf_sdf_count: wp.array[wp.int32],
        writer_data: Any,
        shape_sdf_data_prepared: bool = False,
    ) -> None:
        """Run the full hydroelastic collision pipeline.

        All internal kernel launches use ``record_tape=False`` so that this
        method is safe to call inside a :class:`warp.Tape` context.

        Args:
            texture_sdf_data: Compact texture SDF table.
            shape_sdf_index: Per-shape SDF index into texture_sdf_data.
            shape_data: Per-shape ``(scale_x, scale_y, scale_z, margin)`` values;
                scale is dimensionless and margin is [m].
            shape_transform: World transforms for each shape.
            shape_gap: Per-shape contact gap (detection threshold) for each shape.
            shape_collision_aabb_lower: Per-shape collision AABB lower bounds.
            shape_collision_aabb_upper: Per-shape collision AABB upper bounds.
            shape_voxel_resolution: Per-shape voxel grid resolution.
            shape_pairs_sdf_sdf: Pairs of shape indices to check for collision.
            shape_pairs_sdf_sdf_count: Number of valid shape pairs.
            writer_data: Contact data writer for output.
            shape_sdf_data_prepared: Whether finalized per-shape SDF descriptors were cached upstream.
        """
        shape_sdf_data = self._shape_sdf_data
        shape_transform_inverse = self._shape_transform_inverse
        if shape_sdf_data_prepared:
            wp.launch(
                kernel=cache_shape_transform_inverse_kernel,
                dim=shape_transform.shape[0],
                inputs=[shape_transform],
                outputs=[shape_transform_inverse],
                device=self.device,
                record_tape=False,
            )
        else:
            wp.launch(
                kernel=map_shape_texture_sdf_data_kernel,
                dim=shape_sdf_index.shape[0],
                inputs=[texture_sdf_data, shape_sdf_index, shape_transform],
                outputs=[shape_sdf_data, shape_transform_inverse],
                device=self.device,
                record_tape=False,
            )

        self._broadphase_sdfs(
            shape_sdf_data,
            shape_transform,
            shape_pairs_sdf_sdf,
            shape_pairs_sdf_sdf_count,
        )

        self._find_iso_voxels(shape_sdf_data, shape_data, shape_transform, shape_transform_inverse, shape_gap)

        self._generate_contacts(shape_sdf_data, shape_data, shape_transform, shape_transform_inverse, shape_gap)

        if self.config.reduce_contacts:
            self._reduce_decode_contacts(
                shape_transform,
                shape_collision_aabb_lower,
                shape_collision_aabb_upper,
                shape_voxel_resolution,
                shape_gap,
                writer_data,
            )
        else:
            self._decode_contacts(
                shape_transform,
                shape_gap,
                writer_data,
            )

        wp.launch(
            kernel=verify_collision_step,
            dim=[1],
            inputs=[
                self.block_broad_collide_count,
                self.max_num_blocks_broad,
                self.iso_buffer_counts[1],
                self.iso_max_dims[0],
                self.iso_buffer_counts[2],
                self.iso_max_dims[1],
                self.iso_buffer_counts[3],
                self.iso_max_dims[2],
                self.iso_voxel_count,
                self.max_num_iso_voxels,
                self.contact_reduction.contact_count,
                self.max_num_face_contacts,
                writer_data.contact_count,
                writer_data.contact_max,
                self.contact_reduction.reducer.ht_insert_failures,
            ],
            device=self.device,
            record_tape=False,
        )

        # Poll infrequently to avoid per-step host sync overhead while still surfacing
        # dropped-contact conditions outside stdout-captured environments.
        self._launch_counter += 1
        if self._launch_counter % self._host_warning_poll_interval == 0:
            hashtable_failures = int(self.contact_reduction.reducer.ht_insert_failures.numpy()[0])
            if hashtable_failures > 0:
                warnings.warn(
                    "Hydroelastic reduction dropped contacts due to hashtable insert "
                    f"failures ({hashtable_failures}). Increase rigid_contact_max "
                    "and/or HydroelasticSDF.Config.contact_reduction_hashtable_size_factor.",
                    RuntimeWarning,
                    stacklevel=2,
                )

    def _broadphase_sdfs(
        self,
        shape_sdf_data: wp.array[TextureSDFData],
        shape_transform: wp.array[wp.transform],
        shape_pairs_sdf_sdf: wp.array[wp.vec2i],
        shape_pairs_sdf_sdf_count: wp.array[wp.int32],
    ) -> None:
        # Test collisions between OBB of SDFs
        wp.launch(
            kernel=broadphase_collision_pairs_count,
            dim=[self.max_num_shape_pairs],
            inputs=[
                shape_transform,
                shape_sdf_data,
                shape_pairs_sdf_sdf,
                shape_pairs_sdf_sdf_count,
            ],
            outputs=[
                self.num_blocks_per_pair,
                self.normalized_shape_pairs,
            ],
            device=self.device,
            record_tape=False,
        )

        scan_with_total(
            self.num_blocks_per_pair,
            self.block_start_prefix,
            self.num_shape_pairs_array,
            self.block_broad_collide_count,
        )

        wp.launch(
            kernel=broadphase_collision_pairs_scatter,
            dim=[self.grid_size],
            inputs=[
                self.grid_size,
                self.block_broad_collide_count,
                self.block_start_prefix,
                self.normalized_shape_pairs,
                shape_pairs_sdf_sdf_count,
                shape_sdf_data,
                self.max_num_blocks_broad,
            ],
            outputs=[
                self.block_broad_collide_records,
            ],
            device=self.device,
            record_tape=False,
        )

    def _find_iso_voxels(
        self,
        shape_sdf_data: wp.array[TextureSDFData],
        shape_data: wp.array[wp.vec4],
        shape_transform: wp.array[wp.transform],
        shape_transform_inverse: wp.array[wp.transform],
        shape_gap: wp.array[wp.float32],
    ) -> None:
        # Find voxels which contain the isosurface between the shapes using octree-like pruning.
        # We do this by computing the difference between sdfs at the voxel/subblock center and comparing it to the voxel/subblock radius.
        # The check is first performed for subblocks of size (8 x 8 x 8), then (4 x 4 x 4), then (2 x 2 x 2), and finally for each voxel.
        for i, (subblock_size, n_blocks) in enumerate([(8, 1), (4, 2), (2, 2), (1, 2)]):
            if n_blocks == 2:
                # Eight lanes evaluate one parent's children while retaining the
                # existing parent mask, prefix scan, and ordered scatter.
                count_kernel = (
                    self.count_iso_voxel_children_integer_kernel
                    if subblock_size % 2 == 0
                    else self.count_iso_voxel_children_kernel
                )
                count_grid_size = max(
                    HYDRO_COUNT_BLOCK_DIM,
                    (self.grid_size // HYDRO_COUNT_BLOCK_DIM) * HYDRO_COUNT_BLOCK_DIM,
                )
                count_inputs = [
                    count_grid_size,
                    self.iso_buffer_counts[i],
                    shape_sdf_data,
                    shape_data,
                    shape_transform,
                    shape_transform_inverse,
                    self.pressure_data,
                    self.iso_buffer_records[i],
                    self.normalized_shape_pairs,
                    shape_gap,
                    subblock_size,
                    self.input_sizes[i],
                ]
            else:
                count_kernel = self.count_iso_voxels_block_integer_kernel
                count_grid_size = self.grid_size
                count_inputs = [
                    count_grid_size,
                    self.iso_buffer_counts[i],
                    shape_sdf_data,
                    shape_data,
                    shape_transform,
                    shape_transform_inverse,
                    self.pressure_data,
                    self.iso_buffer_records[i],
                    self.normalized_shape_pairs,
                    shape_gap,
                    subblock_size,
                    n_blocks,
                    self.input_sizes[i],
                ]
            wp.launch(
                kernel=count_kernel,
                dim=[count_grid_size],
                inputs=count_inputs,
                outputs=[
                    self.iso_buffer_num_scratch[i],
                    self.iso_subblock_idx_scratch[i],
                ],
                device=self.device,
                block_dim=HYDRO_COUNT_BLOCK_DIM,
                record_tape=False,
            )

            scan_with_total(
                self.iso_buffer_num_scratch[i],
                self.iso_buffer_prefix_scratch[i],
                self.iso_buffer_counts[i],
                self.iso_buffer_counts[i + 1],
            )

            wp.launch(
                kernel=scatter_iso_subblock,
                dim=[self.grid_size],
                inputs=[
                    self.grid_size,
                    self.iso_buffer_counts[i],
                    self.iso_buffer_prefix_scratch[i],
                    self.iso_subblock_idx_scratch[i],
                    self.iso_buffer_records[i],
                    subblock_size,
                    self.input_sizes[i],
                    self.iso_max_dims[i],
                ],
                outputs=[
                    self.iso_buffer_records[i + 1],
                ],
                device=self.device,
                record_tape=False,
            )

    def _generate_contacts(
        self,
        shape_sdf_data: wp.array[TextureSDFData],
        shape_data: wp.array[wp.vec4],
        shape_transform: wp.array[wp.transform],
        shape_transform_inverse: wp.array[wp.transform],
        shape_gap: wp.array[wp.float32],
        shape_local_aabb_lower: wp.array | None = None,
        shape_local_aabb_upper: wp.array | None = None,
        shape_voxel_resolution: wp.array | None = None,
    ) -> None:
        """Generate marching cubes contacts and write directly to the contact buffer.

        Single pass: compute cube state and immediately write faces to reducer buffer.
        When pre-pruning is active the extra AABB/voxel-resolution arrays must be
        provided so the kernel can populate the hashtable and gate buffer writes.
        """
        self.contact_reduction.clear()
        reducer_data = self.contact_reduction.get_data_struct()

        # Placeholder arrays for the pre-prune parameters when not used
        if shape_local_aabb_lower is None:
            shape_local_aabb_lower = self._empty_vec3
        if shape_local_aabb_upper is None:
            shape_local_aabb_upper = self._empty_vec3
        if shape_voxel_resolution is None:
            shape_voxel_resolution = self._empty_vec3i

        wp.launch(
            kernel=self.generate_contacts_kernel,
            dim=[self.grid_size],
            inputs=[
                self.grid_size,
                self.iso_voxel_count,
                shape_sdf_data,
                shape_data,
                shape_transform,
                shape_transform_inverse,
                self.pressure_data,
                self.iso_voxel_records,
                self.normalized_shape_pairs,
                self.mc_tables[0],
                self.mc_tables[4],
                shape_gap,
                self.max_num_iso_voxels,
                reducer_data,
                shape_local_aabb_lower,
                shape_local_aabb_upper,
                shape_voxel_resolution,
            ],
            outputs=[
                self.iso_vertex_point,
                self.iso_vertex_depth,
                self.iso_vertex_shape_pair,
            ],
            block_dim=HYDRO_GENERATE_BLOCK_DIM,
            device=self.device,
            record_tape=False,
        )

    def _decode_contacts(
        self,
        shape_transform: wp.array[wp.transform],
        shape_gap: wp.array[wp.float32],
        writer_data: Any,
    ) -> None:
        """Decode hydroelastic contacts without reduction.

        Contacts are already in the buffer (written by _generate_contacts).
        This method exports all contacts directly without any reduction.
        """
        wp.launch(
            kernel=self.decode_contacts_kernel,
            dim=[self.grid_size],
            inputs=[
                self.grid_size,
                self.contact_reduction.contact_count,
                self.shape_material_kh,
                shape_transform,
                shape_gap,
                self.contact_reduction.reducer.position_depth,
                self.contact_reduction.reducer.normal,
                self.contact_reduction.reducer.shape_pairs,
                self.contact_reduction.reducer.contact_fingerprints,
                self.contact_reduction.reducer.contact_area,
                self.contact_reduction.reducer.contact_pressure,
                self.max_num_face_contacts,
            ],
            outputs=[writer_data],
            device=self.device,
            record_tape=False,
        )

    def _reduce_decode_contacts(
        self,
        shape_transform: wp.array[wp.transform],
        shape_collision_aabb_lower: wp.array[wp.vec3],
        shape_collision_aabb_upper: wp.array[wp.vec3],
        shape_voxel_resolution: wp.array[wp.vec3i],
        shape_gap: wp.array[wp.float32],
        writer_data: Any,
    ) -> None:
        """Reduce buffered contacts and export the winners.

        Runs the reduction kernel to populate the hashtable (spatial extremes,
        max-depth, voxel bins) and accumulate aggregates, then exports the
        winning contacts via the writer function.
        """
        self.contact_reduction.reduce(
            shape_material_k_hydro=self.shape_material_kh,
            shape_transform=shape_transform,
            shape_collision_aabb_lower=shape_collision_aabb_lower,
            shape_collision_aabb_upper=shape_collision_aabb_upper,
            shape_voxel_resolution=shape_voxel_resolution,
            grid_size=self.grid_size,
        )
        self.contact_reduction.export(
            shape_material_k_hydro=self.shape_material_kh,
            shape_gap=shape_gap,
            shape_transform=shape_transform,
            writer_data=writer_data,
            grid_size=self.grid_size,
        )


@wp.func
def shape_subgrid_dims(sdf: TextureSDFData) -> wp.vec3i:
    """Number of subgrids per axis for an SDF shape.

    The coarse texture stores SDF samples at every subgrid corner, so each
    axis has ``num_subgrids + 1`` corner texels.  The hydroelastic broadphase
    visits every subgrid (no narrow-band filter), so this is also the number
    of broadphase blocks per shape.
    """
    return wp.vec3i(
        sdf.coarse_texture.width - 1,
        sdf.coarse_texture.height - 1,
        sdf.coarse_texture.depth - 1,
    )


@wp.func
def pack_hydro_voxel_record(coords: wp.vec3us, pair_idx: wp.int32) -> wp.vec3ui:
    packed_xy = wp.uint32(coords[0]) | (wp.uint32(coords[1]) << wp.uint32(16))
    return wp.vec3ui(packed_xy, wp.uint32(coords[2]), wp.uint32(pair_idx))


@wp.func
def unpack_hydro_voxel_coords(record: wp.vec3ui) -> wp.vec3us:
    return wp.vec3us(
        wp.uint16(record[0] & wp.uint32(0xFFFF)),
        wp.uint16(record[0] >> wp.uint32(16)),
        wp.uint16(record[1]),
    )


@wp.kernel(enable_backward=False)
def broadphase_collision_pairs_count(
    shape_transform: wp.array[wp.transform],
    shape_sdf_data: wp.array[TextureSDFData],
    shape_pairs_sdf_sdf: wp.array[wp.vec2i],
    shape_pairs_sdf_sdf_count: wp.array[wp.int32],
    # outputs
    thread_num_blocks: wp.array[wp.int32],
    normalized_shape_pairs: wp.array[wp.vec2i],
):
    tid = wp.tid()
    if tid >= shape_pairs_sdf_sdf_count[0]:
        thread_num_blocks[tid] = 0
        return

    pair = shape_pairs_sdf_sdf[tid]
    shape_a = pair[0]
    shape_b = pair[1]
    sdf_a = shape_sdf_data[shape_a]
    sdf_b = shape_sdf_data[shape_b]
    half_extents_a = 0.5 * (sdf_a.sdf_box_upper - sdf_a.sdf_box_lower)
    half_extents_b = 0.5 * (sdf_b.sdf_box_upper - sdf_b.sdf_box_lower)

    center_offset_a = 0.5 * (sdf_a.sdf_box_lower + sdf_a.sdf_box_upper)
    center_offset_b = 0.5 * (sdf_b.sdf_box_lower + sdf_b.sdf_box_upper)

    world_transform_a = shape_transform[shape_a]
    world_transform_b = shape_transform[shape_b]

    # Apply center offset to transforms (since SAT assumes centered boxes)
    centered_transform_a = wp.transform_multiply(world_transform_a, wp.transform(center_offset_a, wp.quat_identity()))
    centered_transform_b = wp.transform_multiply(world_transform_b, wp.transform(center_offset_b, wp.quat_identity()))

    does_collide = sat_box_intersection(centered_transform_a, half_extents_a, centered_transform_b, half_extents_b)

    # Keep the finer SDF as shape B for all traversal records.
    if sdf_b.voxel_radius > sdf_a.voxel_radius:
        shape_a, shape_b = shape_b, shape_a
        sdf_b = sdf_a
    normalized_shape_pairs[tid] = wp.vec2i(shape_a, shape_b)

    dims_b = shape_subgrid_dims(sdf_b)
    num_blocks = dims_b[0] * dims_b[1] * dims_b[2]

    if does_collide:
        thread_num_blocks[tid] = num_blocks
    else:
        thread_num_blocks[tid] = 0


@wp.kernel(enable_backward=False)
def broadphase_collision_pairs_scatter(
    grid_size: int,
    block_broad_collide_count: wp.array[wp.int32],
    block_start_prefix: wp.array[wp.int32],
    normalized_shape_pairs: wp.array[wp.vec2i],
    shape_pairs_sdf_sdf_count: wp.array[wp.int32],
    shape_sdf_data: wp.array[TextureSDFData],
    max_num_blocks_broad: int,
    # outputs
    block_broad_collide_records: wp.array[wp.vec3ui],
):
    offset = wp.tid()
    total_blocks = wp.min(block_broad_collide_count[0], max_num_blocks_broad)
    pair_count = wp.min(shape_pairs_sdf_sdf_count[0], block_start_prefix.shape[0])
    if pair_count == 0:
        return

    for block_tid in range(offset, total_blocks, grid_size):
        # Binary search: find rightmost pair_idx where prefix[pair_idx] <= block_tid
        lo = int(0)
        hi = int(pair_count - 1)
        while lo < hi:
            mid = (lo + hi + 1) // 2
            if block_start_prefix[mid] <= block_tid:
                lo = mid
            else:
                hi = mid - 1
        pair_idx = lo

        pair = normalized_shape_pairs[pair_idx]
        shape_b = pair[1]
        sdf_b = shape_sdf_data[shape_b]

        block_in_pair = block_tid - block_start_prefix[pair_idx]

        # Decode the (bx, by, bz) subgrid index from the linear block_in_pair.
        # Layout matches the host-side row-major layout: bz outer, by middle,
        # bx inner, matching build_sparse_sdf_from_mesh().
        dims_b = shape_subgrid_dims(sdf_b)
        plane = dims_b[0] * dims_b[1]
        bz = block_in_pair // plane
        rem = block_in_pair - bz * plane
        by = rem // dims_b[0]
        bx = rem - by * dims_b[0]
        sgs = wp.int32(sdf_b.subgrid_size)

        coords = wp.vec3us(wp.uint16(bx * sgs), wp.uint16(by * sgs), wp.uint16(bz * sgs))
        block_broad_collide_records[block_tid] = pack_hydro_voxel_record(coords, pair_idx)


@wp.func
def encode_coords_8(x: wp.int32, y: wp.int32, z: wp.int32) -> wp.uint8:
    # Encode 3D coordinates in range [0, 1] per axis into a single 8-bit integer
    return wp.uint8(1) << (wp.uint8(x) + wp.uint8(y) * wp.uint8(2) + wp.uint8(z) * wp.uint8(4))


@wp.func
def decode_coords_8(bit_pos: wp.uint8) -> wp.vec3ub:
    # Decode bit position back to 3D coordinates
    return wp.vec3ub(
        bit_pos & wp.uint8(1), (bit_pos >> wp.uint8(1)) & wp.uint8(1), (bit_pos >> wp.uint8(2)) & wp.uint8(1)
    )


def create_count_iso_voxels_block_kernel(pressure_func: Any, integer_center: bool, paired_samples: bool):
    """Specialize voxel counting to a pressure callback and center sampling mode.

    The subblock prune uses interval arithmetic on the user-supplied
    ``pressure_func`` to bound how much ``p_a - p_b`` can change across a
    subblock of radius ``r``. Each SDF is 1-Lipschitz in space so ``phi`` lies
    in ``[phi_c - r, phi_c + r]``; assuming ``pressure_func`` is monotone
    non-increasing in ``signed_depth`` (deeper penetration => higher pressure),
    the per-shape pressure interval is ``[p(phi_c + r), p(phi_c - r)]``. We
    skip subblocks where these intervals can't overlap.

    Args:
        pressure_func: Monotonic pressure callback to evaluate.
        integer_center: Whether every subblock center lies on an integer voxel.
        paired_samples: Whether the generated kernel reads paired-X or scalar SDF texture storage.
    """

    sample_sdf = _texture_sample_sdf_zfiltered if paired_samples else _texture_sample_sdf_scalar
    sample_sdf_at_voxel = _texture_sample_sdf_at_voxel_paired if paired_samples else _texture_sample_sdf_at_voxel_scalar

    @wp.kernel(enable_backward=False)
    def count_iso_voxels_block(
        grid_size: int,
        in_buffer_collide_count: wp.array[int],
        shape_sdf_data: wp.array[TextureSDFData],
        shape_data: wp.array[wp.vec4],
        shape_transform: wp.array[wp.transform],
        shape_transform_inverse: wp.array[wp.transform],
        pressure_data: Any,
        in_buffer_collide_records: wp.array[wp.vec3ui],
        normalized_shape_pairs: wp.array[wp.vec2i],
        shape_gap: wp.array[wp.float32],
        subblock_size: int,
        n_blocks: int,
        max_input_buffer_size: int,
        # outputs
        iso_subblock_counts: wp.array[wp.int32],
        iso_subblock_idx: wp.array[wp.uint8],
    ):
        # checks if the isosurface between shapes a and b lies inside the subblock (iterating over subblocks of b).
        # if so, write the subblock coordinates to the output.
        offset = wp.tid()
        num_items = wp.min(in_buffer_collide_count[0], max_input_buffer_size)
        for tid in range(offset, num_items, grid_size):
            record = in_buffer_collide_records[tid]
            pair_idx = wp.int32(record[2])
            pair = normalized_shape_pairs[pair_idx]
            shape_a = pair[0]
            shape_b = pair[1]

            sdf_data_a = shape_sdf_data[shape_a]
            sdf_data_b = shape_sdf_data[shape_b]

            X_ws_b = shape_transform[shape_b]

            gap_a = shape_gap[shape_a]
            gap_b = shape_gap[shape_b]
            gap_sum = gap_a + gap_b
            margin_a = shape_data[shape_a][3]
            margin_b = shape_data[shape_b][3]

            voxel_radius = sdf_data_b.voxel_radius
            r = float(subblock_size) * voxel_radius

            # get global voxel coordinates
            bc = unpack_hydro_voxel_coords(record)

            X_b_to_a = wp.transform_multiply(shape_transform_inverse[shape_a], X_ws_b)

            num_iso_subblocks = wp.int32(0)
            subblock_idx = wp.uint8(0)
            for x_local in range(n_blocks):
                for y_local in range(n_blocks):
                    for z_local in range(n_blocks):
                        x_global = wp.vec3i(bc) + wp.vec3i(x_local, y_local, z_local) * subblock_size

                        # lookup distances at subblock center
                        x_center = wp.vec3f(x_global) + wp.vec3f(0.5 * float(subblock_size))
                        local_pos_b = sdf_data_b.sdf_box_lower + wp.cw_mul(x_center, sdf_data_b.voxel_size)
                        point_a = wp.transform_point(X_b_to_a, local_pos_b)
                        if wp.static(integer_center):
                            center_i = x_global + wp.vec3i(subblock_size // 2)
                            vb = wp.static(sample_sdf_at_voxel)(
                                sdf_data_b,
                                center_i[0],
                                center_i[1],
                                center_i[2],
                            )
                        else:
                            vb = wp.static(sample_sdf)(sdf_data_b, local_pos_b)
                        va = wp.static(sample_sdf)(sdf_data_a, point_a)
                        is_valid = not (wp.isnan(vb) or wp.isnan(va))
                        effective_va = va - margin_a
                        effective_vb = vb - margin_b
                        if not is_valid or effective_va + effective_vb > 2.0 * r + gap_sum:
                            continue

                        # Bound p_a, p_b across the subblock using monotonicity of
                        # pressure_func in signed_depth (assumed non-increasing) and
                        # the 1-Lipschitz spatial bound phi in [phi_c - r, phi_c + r].
                        # The per-shape pressure interval is
                        # [pressure_func(phi_c + r), pressure_func(phi_c - r)]. Skip
                        # when these intervals cannot intersect, since then the iso-
                        # pressure surface ``p_a == p_b`` cannot lie inside the
                        # subblock. Evaluated for every subblock (not only the
                        # both-penetrating case) so the prune stays consistent with
                        # the iso-surface definition used in marching cubes.
                        pa_lo = pressure_func(effective_va + r, shape_a, pressure_data)
                        pa_hi = pressure_func(effective_va - r, shape_a, pressure_data)
                        pb_lo = pressure_func(effective_vb + r, shape_b, pressure_data)
                        pb_hi = pressure_func(effective_vb - r, shape_b, pressure_data)
                        skip = pa_hi < pb_lo or pb_hi < pa_lo

                        if skip:
                            continue
                        num_iso_subblocks += 1
                        subblock_idx |= encode_coords_8(x_local, y_local, z_local)

            iso_subblock_counts[tid] = num_iso_subblocks
            iso_subblock_idx[tid] = subblock_idx

    return count_iso_voxels_block


def create_count_iso_voxel_children_kernel(pressure_func: Any, integer_center: bool, paired_samples: bool):
    """Create a kernel that evaluates each parent's eight children cooperatively.

    Args:
        pressure_func: Monotonic pressure callback to evaluate.
        integer_center: Whether every subblock center lies on an integer voxel.
        paired_samples: Whether the generated kernel reads paired-X or scalar SDF texture storage.

    Returns:
        The specialized child-evaluation kernel.
    """
    sample_sdf = _texture_sample_sdf_zfiltered if paired_samples else _texture_sample_sdf_scalar
    sample_sdf_at_voxel = _texture_sample_sdf_at_voxel_paired if paired_samples else _texture_sample_sdf_at_voxel_scalar

    @wp.kernel(enable_backward=False)
    def count_iso_voxel_children(
        grid_size: int,
        in_buffer_collide_count: wp.array[int],
        shape_sdf_data: wp.array[TextureSDFData],
        shape_data: wp.array[wp.vec4],
        shape_transform: wp.array[wp.transform],
        shape_transform_inverse: wp.array[wp.transform],
        pressure_data: Any,
        in_buffer_collide_records: wp.array[wp.vec3ui],
        normalized_shape_pairs: wp.array[wp.vec2i],
        shape_gap: wp.array[wp.float32],
        subblock_size: int,
        max_input_buffer_size: int,
        iso_subblock_counts: wp.array[wp.int32],
        iso_subblock_idx: wp.array[wp.uint8],
    ):
        lane = wp.tid() % wp.block_dim()
        child_idx = lane & 7
        parent_lane = lane >> 3
        parents_per_block = wp.block_dim() >> 3
        parent_base = (wp.tid() // wp.block_dim()) * parents_per_block
        parent_stride = (grid_size // wp.block_dim()) * parents_per_block
        num_items = wp.min(in_buffer_collide_count[0], max_input_buffer_size)
        child_kept = wp.tile_zeros(shape=(HYDRO_COUNT_BLOCK_DIM,), dtype=wp.int32, storage="shared")

        while parent_base < num_items:
            tid = parent_base + parent_lane
            keep = False
            if tid < num_items:
                record = in_buffer_collide_records[tid]
                pair_idx = wp.int32(record[2])
                pair = normalized_shape_pairs[pair_idx]
                shape_a = pair[0]
                shape_b = pair[1]
                sdf_data_a = shape_sdf_data[shape_a]
                sdf_data_b = shape_sdf_data[shape_b]
                X_ws_b = shape_transform[shape_b]
                gap_a = shape_gap[shape_a]
                gap_b = shape_gap[shape_b]
                gap_sum = gap_a + gap_b
                margin_a = shape_data[shape_a][3]
                margin_b = shape_data[shape_b][3]
                voxel_radius = sdf_data_b.voxel_radius
                r = float(subblock_size) * voxel_radius
                bc = unpack_hydro_voxel_coords(record)
                X_b_to_a = wp.transform_multiply(shape_transform_inverse[shape_a], X_ws_b)

                x_local = child_idx & 1
                y_local = (child_idx >> 1) & 1
                z_local = (child_idx >> 2) & 1
                x_global = wp.vec3i(bc) + wp.vec3i(x_local, y_local, z_local) * subblock_size
                x_center = wp.vec3f(x_global) + wp.vec3f(0.5 * float(subblock_size))
                local_pos_b = sdf_data_b.sdf_box_lower + wp.cw_mul(x_center, sdf_data_b.voxel_size)
                point_a = wp.transform_point(X_b_to_a, local_pos_b)
                if wp.static(integer_center):
                    center_i = x_global + wp.vec3i(subblock_size // 2)
                    vb = wp.static(sample_sdf_at_voxel)(sdf_data_b, center_i[0], center_i[1], center_i[2])
                else:
                    vb = wp.static(sample_sdf)(sdf_data_b, local_pos_b)
                va = wp.static(sample_sdf)(sdf_data_a, point_a)
                is_valid = not (wp.isnan(vb) or wp.isnan(va))
                effective_va = va - margin_a
                effective_vb = vb - margin_b
                if is_valid and effective_va + effective_vb <= 2.0 * r + gap_sum:
                    pa_lo = pressure_func(effective_va + r, shape_a, pressure_data)
                    pa_hi = pressure_func(effective_va - r, shape_a, pressure_data)
                    pb_lo = pressure_func(effective_vb + r, shape_b, pressure_data)
                    pb_hi = pressure_func(effective_vb - r, shape_b, pressure_data)
                    keep = not (pa_hi < pb_lo or pb_hi < pa_lo)

            wp.tile_scatter_masked(child_kept, lane, wp.int32(keep), True)

            if child_idx == 0 and tid < num_items:
                count = wp.int32(0)
                mask = wp.uint8(0)
                for i in range(8):
                    if wp.tile_extract(child_kept, lane + i) != 0:
                        count += 1
                        mask |= wp.uint8(1) << wp.uint8(i)
                iso_subblock_counts[tid] = count
                iso_subblock_idx[tid] = mask

            parent_base += parent_stride

    return count_iso_voxel_children


@wp.kernel(enable_backward=False)
def scatter_iso_subblock(
    grid_size: int,
    in_iso_subblock_count: wp.array[int],
    in_iso_subblock_prefix: wp.array[int],
    in_iso_subblock_idx: wp.array[wp.uint8],
    in_iso_subblock_records: wp.array[wp.vec3ui],
    subblock_size: int,
    max_input_buffer_size: int,
    max_num_iso_subblocks: int,
    # outputs
    out_iso_subblock_records: wp.array[wp.vec3ui],
):
    offset = wp.tid()
    num_items = wp.min(in_iso_subblock_count[0], max_input_buffer_size)
    for tid in range(offset, num_items, grid_size):
        write_idx = in_iso_subblock_prefix[tid]
        subblock_idx = in_iso_subblock_idx[tid]
        record = in_iso_subblock_records[tid]
        pair_idx = wp.int32(record[2])
        bc = unpack_hydro_voxel_coords(record)
        if write_idx >= max_num_iso_subblocks:
            continue
        for i in range(8):
            bit_pos = wp.uint8(i)
            if (subblock_idx >> bit_pos) & wp.uint8(1) and not write_idx >= max_num_iso_subblocks:
                local_coords = wp.vec3us(decode_coords_8(bit_pos))
                global_coords = bc + local_coords * wp.uint16(subblock_size)
                out_iso_subblock_records[write_idx] = pack_hydro_voxel_record(global_coords, pair_idx)
                write_idx += 1


def create_mc_iterate_voxel_vertices_func(pressure_func: Any, paired_samples: bool):
    """Specialize voxel iteration to a pressure callback and texture layout.

    Args:
        pressure_func: Pressure callback used to locate the iso-pressure surface.
        paired_samples: Whether the generated function reads paired-X or scalar SDF texture storage.

    Returns:
        The specialized voxel-iteration function.
    """
    sample_sdf = _texture_sample_sdf_paired if paired_samples else _texture_sample_sdf_scalar
    sample_sdf_at_voxel = _texture_sample_sdf_at_voxel_paired if paired_samples else _texture_sample_sdf_at_voxel_scalar

    @wp.func
    def mc_iterate_voxel_vertices(
        x_id: wp.int32,
        y_id: wp.int32,
        z_id: wp.int32,
        sdf_data: TextureSDFData,
        sdf_other_data: TextureSDFData,
        X_ws: wp.transform,
        X_sw_other: wp.transform,
        shape_self: wp.int32,
        shape_other: wp.int32,
        margin_self: wp.float32,
        margin_other: wp.float32,
        pressure_data: Any,
        gap_sum: wp.float32,
    ):
        """Iterate over the vertices of a voxel and return the cube index, corner values, and whether any vertices are inside the shape."""
        cube_idx = wp.uint8(0)
        any_verts_inside_gap = False
        corner_vals = vec8f()
        corner_sdf_self = vec8f()
        corner_sdf_other = vec8f()

        X_a_to_b = wp.transform_multiply(X_sw_other, X_ws)
        # Reuse the affine base and axis steps instead of rotating all eight corners.
        voxel_base_a = sdf_data.sdf_box_lower + wp.cw_mul(
            wp.vec3(float(x_id), float(y_id), float(z_id)), sdf_data.voxel_size
        )
        point_b_base = wp.transform_point(X_a_to_b, voxel_base_a)
        point_b_step_x = wp.transform_vector(X_a_to_b, wp.vec3(sdf_data.voxel_size[0], 0.0, 0.0))
        point_b_step_y = wp.transform_vector(X_a_to_b, wp.vec3(0.0, sdf_data.voxel_size[1], 0.0))
        point_b_step_z = wp.transform_vector(X_a_to_b, wp.vec3(0.0, 0.0, sdf_data.voxel_size[2]))

        for i in range(8):
            corner_offset = _mc_corner_offset(i)
            x = x_id + corner_offset.x
            y = y_id + corner_offset.y
            z = z_id + corner_offset.z

            point_b = (
                point_b_base
                + float(corner_offset.x) * point_b_step_x
                + float(corner_offset.y) * point_b_step_y
                + float(corner_offset.z) * point_b_step_z
            )
            valA = wp.static(sample_sdf_at_voxel)(sdf_data, x, y, z)
            valB = wp.static(sample_sdf)(sdf_other_data, point_b)

            is_valid = not (wp.isnan(valA) or wp.isnan(valB))
            if not is_valid:
                return wp.uint8(0), corner_vals, corner_sdf_self, corner_sdf_other, False, False

            effective_sdf_self = valA - margin_self
            effective_sdf_other = valB - margin_other

            # Iso-pressure surface: the contact patch is the locus where
            # ``p_self == p_other``. Evaluate ``pressure_func`` at every
            # corner (penetrating or not) so corner_vals stays continuous
            # across the patch boundary; this is what guarantees the MC
            # interpolation ``t = -v0 / (v1 - v0)`` produces the right
            # vertex along edges that span penetrating/non-penetrating
            # corners. ``pressure_func`` is required to be defined and
            # monotone non-increasing in ``signed_depth`` over its full
            # range, not just for ``signed_depth < 0``.
            p_self = pressure_func(effective_sdf_self, shape_self, pressure_data)
            p_other = pressure_func(effective_sdf_other, shape_other, pressure_data)
            v_diff = p_other - p_self

            corner_vals[i] = v_diff
            corner_sdf_self[i] = effective_sdf_self
            corner_sdf_other[i] = effective_sdf_other

            if v_diff < 0.0:
                cube_idx |= wp.uint8(1) << wp.uint8(i)

            if effective_sdf_self + effective_sdf_other <= gap_sum:
                any_verts_inside_gap = True

        return cube_idx, corner_vals, corner_sdf_self, corner_sdf_other, any_verts_inside_gap, True

    return mc_iterate_voxel_vertices


# =============================================================================
# Contact decode kernel (no reduction)
# =============================================================================


def get_decode_contacts_kernel(
    margin_contact_area: float,
    writer_func: Any = None,
):
    """Create a kernel that decodes hydroelastic contacts without reduction.

    This kernel is used when reduce_contacts=False. It exports all generated
    contacts directly to the writer without any spatial reduction. Pressure is
    read from the contact buffer after being evaluated once during generation.

    Args:
        margin_contact_area: Deprecated compatibility area [m^2] for speculative
            contact activation stiffness.
        writer_func: Warp function for writing decoded contacts.

    Returns:
        A warp kernel that can be launched to decode all contacts.
    """

    @wp.kernel(enable_backward=False)
    def decode_contacts_kernel(
        grid_size: int,
        contact_count: wp.array[int],
        shape_material_kh: wp.array[wp.float32],
        shape_transform: wp.array[wp.transform],
        shape_gap: wp.array[wp.float32],
        position_depth: wp.array[wp.vec4],
        normal: wp.array[wp.vec2],  # Octahedral-encoded
        shape_pairs: wp.array[wp.vec2i],
        contact_fingerprints: wp.array[wp.int32],
        contact_area: wp.array[wp.float32],
        contact_pressure: wp.array[wp.float32],
        max_num_face_contacts: int,
        # outputs
        writer_data: Any,
    ):
        """Decode all hydroelastic contacts without reduction.

        Uses grid stride loop to process all contacts in the buffer.
        """
        offset = wp.tid()
        num_contacts = wp.min(contact_count[0], max_num_face_contacts)

        # Calculate how many contacts this thread will process
        my_contact_count = 0
        if offset < num_contacts:
            my_contact_count = (num_contacts - 1 - offset) // grid_size + 1

        if my_contact_count == 0:
            return

        # Single atomic to reserve all slots for this thread (no rollback)
        my_base_index = wp.atomic_add(writer_data.contact_count, 0, my_contact_count)

        # Write contacts using reserved range
        local_idx = int(0)
        for tid in range(offset, num_contacts, grid_size):
            output_index = my_base_index + local_idx
            local_idx += 1

            if output_index >= writer_data.contact_max:
                continue

            contact_id = tid + 1
            pair = shape_pairs[contact_id]
            shape_a = pair[0]
            shape_b = pair[1]

            transform_b = shape_transform[shape_b]

            pd = position_depth[contact_id]
            pos = wp.vec3(pd[0], pd[1], pd[2])
            depth = pd[3]
            contact_normal = decode_oct(normal[contact_id])

            normal_world = wp.transform_vector(transform_b, contact_normal)
            pos_world = wp.transform_point(transform_b, pos)

            # Sum per-shape gaps for pairwise contact detection threshold
            gap_a = shape_gap[shape_a]
            gap_b = shape_gap[shape_b]
            gap_sum = gap_a + gap_b

            area = contact_area[contact_id]
            face_pressure = contact_pressure[contact_id]

            # Hydroelastic force per face: F = area * pressure (Elandt et al.
            # 2019). The stored distance is the margin-relative pair
            # separation, so:
            #     c_stiffness = area * pressure / |pair_separation|
            # gives F_solver = area * p_face exactly, for any pressure law and
            # any (kh_a, kh_b) pair. Pressure is evaluated during generation
            # and cached separately from pair separation.
            if depth < 0.0:
                c_stiffness = area * face_pressure / wp.max(-depth, EPS_SMALL)
            else:
                k_a = shape_material_kh[shape_a]
                k_b = shape_material_kh[shape_b]
                c_stiffness = wp.static(margin_contact_area) * get_effective_stiffness(k_a, k_b)

            # Create ContactData for the writer function
            contact_data = ContactData()
            contact_data.contact_point_center = pos_world
            contact_data.contact_normal_a_to_b = normal_world
            contact_data.contact_distance = depth
            contact_data.radius_eff_a = 0.0
            contact_data.radius_eff_b = 0.0
            contact_data.margin_a = 0.0
            contact_data.margin_b = 0.0
            contact_data.shape_a = shape_a
            contact_data.shape_b = shape_b
            contact_data.gap_sum = gap_sum
            contact_data.contact_stiffness = c_stiffness
            # ``tid`` is a buffer slot handed out by an atomic during generation,
            # so it varies between runs; the fingerprint is the marching-cubes
            # voxel and face index and is stable.
            contact_data.sort_sub_key = contact_fingerprints[contact_id]

            writer_func(contact_data, writer_data, output_index)

    return decode_contacts_kernel


# =============================================================================
# Contact generation kernels
# =============================================================================


def get_generate_contacts_kernel(
    output_vertices: bool,
    pre_prune: bool = False,
    reduce_contacts: bool = True,
    deterministic_reduction: bool = False,
    pressure_func: Any = None,
    mc_edge_clamp_min: float = 0.02,
    paired_samples: bool = True,
):
    """Create kernel for hydroelastic contact generation.

    This is a merged kernel that computes cube state and immediately writes
    faces to the reducer buffer in a single pass, eliminating intermediate
    storage for cube indices and corner values.

    A separate ``reduce_hydroelastic_contacts_kernel`` then runs on the
    buffer to populate the hashtable and select representative contacts.

    When ``pre_prune`` is enabled, this kernel applies a local-first compaction
    rule before writing contacts:
    - keep top-K penetrating faces by area*|depth| (K=2)
    - keep at most one non-penetrating fallback face (closest to penetration)

    All penetrating faces always contribute to aggregate force terms (via
    hashtable entries) regardless of whether they are later pruned from
    buffer writes. This ensures aggregate stiffness/normal/anchor fidelity.

    Args:
        output_vertices: Whether to output contact surface vertices for visualization.
        pre_prune: Whether to perform local-first face compaction.
        reduce_contacts: Whether generated contacts are reduced before export.
        deterministic_reduction: Whether aggregate accumulation is deferred
            to the deterministic reduction phase, which sums in fixed point so
            the result does not depend on contact ordering.
        pressure_func: Warp function defining the per-shape pressure law used
            to locate the iso-pressure surface. Required.
        mc_edge_clamp_min: Lower bound for the marching-cubes edge
            interpolation parameter; see
            :attr:`HydroelasticSDF.Config.mc_edge_clamp_min`.
        paired_samples: Whether the generated kernel reads paired-X or scalar SDF texture storage.

    Returns:
        generate_contacts_kernel: Warp kernel for contact generation.
    """

    if pressure_func is None:
        raise ValueError("get_generate_contacts_kernel requires a non-None pressure_func.")

    mc_iterate = create_mc_iterate_voxel_vertices_func(pressure_func, paired_samples)
    edge_clamp_min = float(mc_edge_clamp_min)
    edge_clamp_max = float(1.0 - mc_edge_clamp_min)

    @wp.kernel(enable_backward=False)
    def generate_contacts_kernel(
        grid_size: int,
        iso_voxel_count: wp.array[wp.int32],
        shape_sdf_data: wp.array[TextureSDFData],
        shape_data: wp.array[wp.vec4],
        shape_transform: wp.array[wp.transform],
        shape_transform_inverse: wp.array[wp.transform],
        pressure_data: Any,
        iso_voxel_records: wp.array[wp.vec3ui],
        normalized_shape_pairs: wp.array[wp.vec2i],
        tri_range_table: wp.array[wp.int32],
        flat_edge_verts_table: wp.array[wp.vec2ub],
        shape_gap: wp.array[wp.float32],
        max_num_iso_voxels: int,
        reducer_data: GlobalContactReducerData,
        # Unused — kept for signature compatibility with prior callers
        _shape_local_aabb_lower: wp.array[wp.vec3],
        _shape_local_aabb_upper: wp.array[wp.vec3],
        _shape_voxel_resolution: wp.array[wp.vec3i],
        # Outputs for visualization (optional)
        iso_vertex_point: wp.array[wp.vec3f],
        iso_vertex_depth: wp.array[wp.float32],
        iso_vertex_shape_pair: wp.array[wp.vec2i],
    ):
        """Generate marching cubes contacts and write to GlobalContactReducer."""
        offset = wp.tid()
        num_voxels = wp.min(iso_voxel_count[0], max_num_iso_voxels)
        for tid in range(offset, num_voxels, grid_size):
            record = iso_voxel_records[tid]
            pair_idx = wp.int32(record[2])
            pair = normalized_shape_pairs[pair_idx]
            shape_a = pair[0]
            shape_b = pair[1]

            sdf_data_a = shape_sdf_data[shape_a]
            sdf_data_b = shape_sdf_data[shape_b]

            transform_inverse_a = shape_transform_inverse[shape_a]
            transform_b = shape_transform[shape_b]

            iso_coords = unpack_hydro_voxel_coords(record)

            gap_a = shape_gap[shape_a]
            gap_b = shape_gap[shape_b]
            gap_sum = gap_a + gap_b
            margin_a = shape_data[shape_a][3]
            margin_b = shape_data[shape_b][3]

            x_id = wp.int32(iso_coords.x)
            y_id = wp.int32(iso_coords.y)
            z_id = wp.int32(iso_coords.z)

            # Compute cube state (marching cubes lookup)
            cube_idx, corner_vals, corner_sdf_self, corner_sdf_other, any_verts_inside, all_verts_valid = wp.static(
                mc_iterate
            )(
                x_id,
                y_id,
                z_id,
                sdf_data_b,
                sdf_data_a,
                transform_b,
                transform_inverse_a,
                shape_b,
                shape_a,
                margin_b,
                margin_a,
                pressure_data,
                gap_sum,
            )

            range_idx = wp.int32(cube_idx)
            tri_range_start = tri_range_table[range_idx]
            tri_range_end = tri_range_table[range_idx + 1]
            num_verts = tri_range_end - tri_range_start

            num_faces = num_verts // 3

            if not any_verts_inside or not all_verts_valid:
                num_faces = 0

            if num_faces == 0:
                continue

            X_ws_b = transform_b

            # Generate faces and locally compact candidates before writing to the
            # global contact buffer (reduces atomics and downstream reduction load).
            # Retain encoded normals because export writes that representation
            # directly, shortening each winner by one long-lived scalar.
            best_pen0_valid = int(0)
            best_pen0_score = float(-MAXVAL)
            best_pen0_depth = float(0.0)
            best_pen0_area = float(0.0)
            best_pen0_pressure = float(0.0)
            best_pen0_fingerprint = int(0)
            best_pen0_normal = wp.vec2(0.0, 0.0)
            best_pen0_center = wp.vec3(0.0, 0.0, 0.0)
            best_pen0_v0 = wp.vec3(0.0, 0.0, 0.0)
            best_pen0_v1 = wp.vec3(0.0, 0.0, 0.0)
            best_pen0_v2 = wp.vec3(0.0, 0.0, 0.0)

            best_pen1_valid = int(0)
            best_pen1_score = float(-MAXVAL)
            best_pen1_depth = float(0.0)
            best_pen1_area = float(0.0)
            best_pen1_pressure = float(0.0)
            best_pen1_fingerprint = int(0)
            best_pen1_normal = wp.vec2(0.0, 0.0)
            best_pen1_center = wp.vec3(0.0, 0.0, 0.0)
            best_pen1_v0 = wp.vec3(0.0, 0.0, 0.0)
            best_pen1_v1 = wp.vec3(0.0, 0.0, 0.0)
            best_pen1_v2 = wp.vec3(0.0, 0.0, 0.0)

            best_nonpen_valid = int(0)
            best_nonpen_depth = float(MAXVAL)
            best_nonpen_area = float(0.0)
            best_nonpen_fingerprint = int(0)
            best_nonpen_normal = wp.vec2(0.0, 0.0)
            best_nonpen_center = wp.vec3(0.0, 0.0, 0.0)
            best_nonpen_v0 = wp.vec3(0.0, 0.0, 0.0)
            best_nonpen_v1 = wp.vec3(0.0, 0.0, 0.0)
            best_nonpen_v2 = wp.vec3(0.0, 0.0, 0.0)
            for fi in range(num_faces):
                face_fingerprint = tid * MAX_MC_FACES_PER_VOXEL + fi
                force_area, geometric_area, normal, face_center, adjusted_sdf_shape_b, pair_separation, face_verts = (
                    mc_calc_face_texture(
                        flat_edge_verts_table,
                        tri_range_start + 3 * fi,
                        corner_vals,
                        corner_sdf_self,
                        corner_sdf_other,
                        sdf_data_b,
                        x_id,
                        y_id,
                        z_id,
                        wp.static(edge_clamp_min),
                        wp.static(edge_clamp_max),
                    )
                )
                if geometric_area <= 0.0:
                    continue
                if classify_hydroelastic_contact(pair_separation, gap_sum) > 0:
                    continue
                face_pressure = float(0.0)
                if pair_separation < 0.0:
                    # On the iso-pressure surface ``p_a == p_b``, so evaluating
                    # either side at its own margin-adjusted depth is equivalent.
                    # Speculative contacts use material stiffness and do not need
                    # pressure, avoiding an otherwise unused callback evaluation.
                    face_pressure = wp.max(
                        wp.static(pressure_func)(adjusted_sdf_shape_b, shape_b, pressure_data),
                        0.0,
                    )
                # Accumulate stats per normal bin
                if pair_separation < 0.0 and wp.static(reduce_contacts and not deterministic_reduction):
                    bin_id = get_slot(normal)
                    key = make_contact_key(shape_a, shape_b, bin_id)
                    entry_idx = hashtable_find_or_insert(key, reducer_data.ht_keys, reducer_data.ht_active_slots)
                    if entry_idx >= 0:
                        force_weight = force_area * face_pressure
                        wp.atomic_add(reducer_data.agg_force, entry_idx, force_weight * normal)
                        wp.atomic_add(reducer_data.weighted_pos_sum, entry_idx, force_weight * face_center)
                        wp.atomic_add(reducer_data.weight_sum, entry_idx, force_weight)
                        # Pressure-law-agnostic geometric depth-volume used for the
                        # direction-reliability gate during reduction/export.
                        wp.atomic_add(
                            reducer_data.agg_depth_volume,
                            entry_idx,
                            (force_area * (-pair_separation)) * normal,
                        )
                    else:
                        wp.atomic_add(reducer_data.ht_insert_failures, 0, 1)

                if wp.static(not pre_prune):
                    stored_area = geometric_area
                    if pair_separation < 0.0:
                        stored_area = force_area
                    contact_id = export_hydroelastic_contact_to_buffer(
                        shape_a,
                        shape_b,
                        face_center,
                        normal,
                        pair_separation,
                        stored_area,
                        face_pressure,
                        tid * MAX_MC_FACES_PER_VOXEL + fi,
                        reducer_data,
                    )
                    if wp.static(output_vertices) and contact_id >= 0:
                        buffer_idx = contact_id - 1
                        for vi in range(3):
                            iso_vertex_point[3 * buffer_idx + vi] = wp.transform_point(X_ws_b, face_verts[vi])
                        iso_vertex_depth[buffer_idx] = pair_separation
                        iso_vertex_shape_pair[buffer_idx] = pair
                    continue

                # Local-first compaction: keep top-K penetrating faces by force
                # magnitude (area * pressure). Under a non-linear pressure law
                # this is no longer the same as area * |depth|, and ranking by
                # force keeps the contacts that contribute most to agg_force.
                if pair_separation < 0.0:
                    score = force_area * face_pressure
                    if best_pen0_valid == 0 or score > best_pen0_score:
                        # Shift slot0 -> slot1
                        best_pen1_valid = best_pen0_valid
                        best_pen1_score = best_pen0_score
                        best_pen1_depth = best_pen0_depth
                        best_pen1_area = best_pen0_area
                        best_pen1_pressure = best_pen0_pressure
                        best_pen1_fingerprint = best_pen0_fingerprint
                        best_pen1_normal = best_pen0_normal
                        best_pen1_center = best_pen0_center
                        best_pen1_v0 = best_pen0_v0
                        best_pen1_v1 = best_pen0_v1
                        best_pen1_v2 = best_pen0_v2

                        best_pen0_valid = int(1)
                        best_pen0_score = score
                        best_pen0_depth = pair_separation
                        best_pen0_area = force_area
                        best_pen0_pressure = face_pressure
                        best_pen0_fingerprint = face_fingerprint
                        best_pen0_normal = encode_oct(normal)
                        best_pen0_center = face_center
                        best_pen0_v0 = face_verts[0]
                        best_pen0_v1 = face_verts[1]
                        best_pen0_v2 = face_verts[2]
                    elif wp.static(PRE_PRUNE_MAX_PENETRATING > 1):
                        if best_pen1_valid == 0 or score > best_pen1_score:
                            best_pen1_valid = int(1)
                            best_pen1_score = score
                            best_pen1_depth = pair_separation
                            best_pen1_area = force_area
                            best_pen1_pressure = face_pressure
                            best_pen1_fingerprint = face_fingerprint
                            best_pen1_normal = encode_oct(normal)
                            best_pen1_center = face_center
                            best_pen1_v0 = face_verts[0]
                            best_pen1_v1 = face_verts[1]
                            best_pen1_v2 = face_verts[2]
                else:
                    # Defer non-penetrating contact and keep only the closest one.
                    if pair_separation < best_nonpen_depth:
                        best_nonpen_valid = int(1)
                        best_nonpen_depth = pair_separation
                        best_nonpen_area = geometric_area
                        best_nonpen_fingerprint = face_fingerprint
                        best_nonpen_normal = encode_oct(normal)
                        best_nonpen_center = face_center
                        best_nonpen_v0 = face_verts[0]
                        best_nonpen_v1 = face_verts[1]
                        best_nonpen_v2 = face_verts[2]

            if wp.static(pre_prune):
                # Batched reservation: one atomic for all kept contacts.
                keep_count = int(0)
                if best_pen0_valid == 1:
                    keep_count = keep_count + 1
                if wp.static(PRE_PRUNE_MAX_PENETRATING > 1):
                    if best_pen1_valid == 1:
                        keep_count = keep_count + 1
                if best_nonpen_valid == 1:
                    keep_count = keep_count + 1

                if keep_count > 0:
                    base = wp.atomic_add(reducer_data.contact_count, 0, keep_count)
                    if base < reducer_data.capacity:
                        out_idx = base

                        if best_pen0_valid == 1 and out_idx < reducer_data.capacity:
                            contact_id = out_idx + 1
                            reducer_data.position_depth[contact_id] = wp.vec4(
                                best_pen0_center[0], best_pen0_center[1], best_pen0_center[2], best_pen0_depth
                            )
                            reducer_data.normal[contact_id] = best_pen0_normal
                            reducer_data.shape_pairs[contact_id] = wp.vec2i(shape_a, shape_b)
                            reducer_data.contact_area[contact_id] = best_pen0_area
                            reducer_data.contact_pressure[contact_id] = best_pen0_pressure
                            reducer_data.contact_fingerprints[contact_id] = best_pen0_fingerprint
                            if wp.static(output_vertices):
                                iso_vertex_point[3 * out_idx + 0] = wp.transform_point(X_ws_b, best_pen0_v0)
                                iso_vertex_point[3 * out_idx + 1] = wp.transform_point(X_ws_b, best_pen0_v1)
                                iso_vertex_point[3 * out_idx + 2] = wp.transform_point(X_ws_b, best_pen0_v2)
                                iso_vertex_depth[out_idx] = best_pen0_depth
                                iso_vertex_shape_pair[out_idx] = pair
                            out_idx = out_idx + 1

                        if wp.static(PRE_PRUNE_MAX_PENETRATING > 1):
                            if best_pen1_valid == 1 and out_idx < reducer_data.capacity:
                                contact_id = out_idx + 1
                                reducer_data.position_depth[contact_id] = wp.vec4(
                                    best_pen1_center[0], best_pen1_center[1], best_pen1_center[2], best_pen1_depth
                                )
                                reducer_data.normal[contact_id] = best_pen1_normal
                                reducer_data.shape_pairs[contact_id] = wp.vec2i(shape_a, shape_b)
                                reducer_data.contact_area[contact_id] = best_pen1_area
                                reducer_data.contact_pressure[contact_id] = best_pen1_pressure
                                reducer_data.contact_fingerprints[contact_id] = best_pen1_fingerprint
                                if wp.static(output_vertices):
                                    iso_vertex_point[3 * out_idx + 0] = wp.transform_point(X_ws_b, best_pen1_v0)
                                    iso_vertex_point[3 * out_idx + 1] = wp.transform_point(X_ws_b, best_pen1_v1)
                                    iso_vertex_point[3 * out_idx + 2] = wp.transform_point(X_ws_b, best_pen1_v2)
                                    iso_vertex_depth[out_idx] = best_pen1_depth
                                    iso_vertex_shape_pair[out_idx] = pair
                                out_idx = out_idx + 1

                        if best_nonpen_valid == 1 and out_idx < reducer_data.capacity:
                            contact_id = out_idx + 1
                            reducer_data.position_depth[contact_id] = wp.vec4(
                                best_nonpen_center[0], best_nonpen_center[1], best_nonpen_center[2], best_nonpen_depth
                            )
                            reducer_data.normal[contact_id] = best_nonpen_normal
                            reducer_data.shape_pairs[contact_id] = wp.vec2i(shape_a, shape_b)
                            reducer_data.contact_area[contact_id] = best_nonpen_area
                            reducer_data.contact_pressure[contact_id] = 0.0
                            reducer_data.contact_fingerprints[contact_id] = best_nonpen_fingerprint
                            if wp.static(output_vertices):
                                iso_vertex_point[3 * out_idx + 0] = wp.transform_point(X_ws_b, best_nonpen_v0)
                                iso_vertex_point[3 * out_idx + 1] = wp.transform_point(X_ws_b, best_nonpen_v1)
                                iso_vertex_point[3 * out_idx + 2] = wp.transform_point(X_ws_b, best_nonpen_v2)
                                iso_vertex_depth[out_idx] = best_nonpen_depth
                                iso_vertex_shape_pair[out_idx] = pair

    return generate_contacts_kernel


# =============================================================================
# Verification kernel
# =============================================================================


@wp.kernel(enable_backward=False)
def verify_collision_step(
    num_broad_collide: wp.array[int],
    max_num_broad_collide: int,
    num_iso_subblocks_0: wp.array[int],
    max_num_iso_subblocks_0: int,
    num_iso_subblocks_1: wp.array[int],
    max_num_iso_subblocks_1: int,
    num_iso_subblocks_2: wp.array[int],
    max_num_iso_subblocks_2: int,
    num_iso_voxels: wp.array[int],
    max_num_iso_voxels: int,
    face_contact_count: wp.array[int],
    max_face_contact_count: int,
    contact_count: wp.array[int],
    max_contact_count: int,
    ht_insert_failures: wp.array[int],
):
    # Checks if any buffer overflowed in any stage of the collision pipeline.
    has_overflow = False
    if num_broad_collide[0] > max_num_broad_collide:
        wp.printf(
            "  [hydroelastic] broad phase overflow: %d > %d. Increase buffer_fraction or buffer_mult_broad.\n",
            num_broad_collide[0],
            max_num_broad_collide,
        )
        has_overflow = True
    if num_iso_subblocks_0[0] > max_num_iso_subblocks_0:
        wp.printf(
            "  [hydroelastic] iso subblock L0 overflow: %d > %d. Increase buffer_fraction or buffer_mult_iso.\n",
            num_iso_subblocks_0[0],
            max_num_iso_subblocks_0,
        )
        has_overflow = True
    if num_iso_subblocks_1[0] > max_num_iso_subblocks_1:
        wp.printf(
            "  [hydroelastic] iso subblock L1 overflow: %d > %d. Increase buffer_fraction or buffer_mult_iso.\n",
            num_iso_subblocks_1[0],
            max_num_iso_subblocks_1,
        )
        has_overflow = True
    if num_iso_subblocks_2[0] > max_num_iso_subblocks_2:
        wp.printf(
            "  [hydroelastic] iso subblock L2 overflow: %d > %d. Increase buffer_fraction or buffer_mult_iso.\n",
            num_iso_subblocks_2[0],
            max_num_iso_subblocks_2,
        )
        has_overflow = True
    if num_iso_voxels[0] > max_num_iso_voxels:
        wp.printf(
            "  [hydroelastic] iso voxel overflow: %d > %d. Increase buffer_fraction or buffer_mult_iso.\n",
            num_iso_voxels[0],
            max_num_iso_voxels,
        )
        has_overflow = True
    if face_contact_count[0] > max_face_contact_count:
        wp.printf(
            "  [hydroelastic] face contact overflow: %d > %d. Increase buffer_fraction or buffer_mult_contact.\n",
            face_contact_count[0],
            max_face_contact_count,
        )
        has_overflow = True
    if contact_count[0] > max_contact_count:
        wp.printf(
            "  [hydroelastic] rigid contact output overflow: %d > %d. Increase rigid_contact_max.\n",
            contact_count[0],
            max_contact_count,
        )
        has_overflow = True
    if ht_insert_failures[0] > 0:
        wp.printf(
            "  [hydroelastic] reduction hashtable full: %d insert failures. "
            "Increase contact_reduction_hashtable_size_factor or rigid_contact_max.\n",
            ht_insert_failures[0],
        )
        has_overflow = True

    if has_overflow:
        wp.printf(
            "Warning: Hydroelastic buffers overflowed; some contacts may be dropped. "
            "Increase HydroelasticSDF.Config.buffer_fraction and/or per-stage buffer multipliers.\n",
        )

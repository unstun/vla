# SPDX-FileCopyrightText: Copyright (c) 2025 The Newton Developers
# SPDX-License-Identifier: Apache-2.0

"""Provides definitions of core joint types & containers"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import IntEnum

import numpy as np
import warp as wp
from warp._src.types import Any, Int, Vector

from .....core.types import MAXVAL, override
from .....sim import JointTargetMode, JointType
from .math import FLOAT32_MAX
from .types import (
    ArrayLike,
    Descriptor,
    mat63f,
    vec1f,
    vec1i,
    vec5i,
    vec6f,
    vec6i,
    vec7f,
)

###
# Module interface
###

__all__ = [
    "DofActuationPath",
    "JointActuationType",
    "JointCorrectionMode",
    "JointDescriptor",
    "JointDoFType",
    "JointsData",
    "JointsModel",
]


###
# Module configs
###

wp.set_module_options({"enable_backward": False})


###
# Constants
###


JOINT_QMIN: float = -MAXVAL
""" Sentinel value indicating the minimum joint coordinate limit."""

JOINT_QMAX: float = MAXVAL
""" Sentinel value indicating the maximum joint coordinate limit."""

JOINT_DQMAX: float = 1e6
""" Sentinel value indicating the maximum joint velocity limit."""

JOINT_TAUMAX: float = 1e6
"""
Sentinel matching the Newton ``ModelBuilder`` default ``effort_limit``.

Values at or above this threshold are treated as unbounded for implicit-PD
effort-row allocation (equivalent to ``inf`` for :func:`_has_effort_cts`).
"""


###
# Enumerations
###


class JointActuationType(IntEnum):
    """
    An enumeration of the joint actuation types.
    """

    PASSIVE = 0
    """Passive joint type, i.e. not actuated."""

    FORCE = 1
    """Force-controlled joint type, i.e. actuated by set of joint-space forces and/or torques."""

    POSITION = 2
    """Position-controlled joint type, i.e. actuated by set of joint-space coordinate targets."""

    VELOCITY = 3
    """Velocity-controlled joint type, i.e. actuated by set of joint-space velocity targets."""

    POSITION_VELOCITY = 4
    """Position-velocity-controlled joint type, i.e. actuated by set of joint-space coordinate and velocity targets."""

    POSITION_VELOCITY_FORCE = 5
    """
    Position + velocity + force-controlled joint type, i.e. actuated
    by set of joint-space coordinate, velocity, and force targets.
    """

    @override
    def __str__(self):
        """Returns a string representation of the joint actuation type."""
        return f"JointActuationType.{self.name} ({self.value})"

    @override
    def __repr__(self):
        """Returns a string representation of the joint actuation type."""
        return self.__str__()

    @staticmethod
    def to_newton(act_type: JointActuationType) -> JointTargetMode:
        """
        Converts a `JointActuationType` to the corresponding `JointTargetMode`.

        Args:
            act_type: The joint actuation type to convert.

        Returns:
            The corresponding Newton joint target mode.

        Raises:
            ValueError: if the joint actuation type is not supported.
        """
        _MAP_TO_NEWTON: dict[JointActuationType, JointTargetMode | None] = {
            JointActuationType.PASSIVE: JointTargetMode.NONE,
            JointActuationType.FORCE: JointTargetMode.EFFORT,
            JointActuationType.POSITION: JointTargetMode.POSITION,
            JointActuationType.VELOCITY: JointTargetMode.VELOCITY,
            JointActuationType.POSITION_VELOCITY: JointTargetMode.POSITION_VELOCITY,
            # No direct mapping to a single Newton target mode since it
            # involves both position/velocity targets and force targets
            JointActuationType.POSITION_VELOCITY_FORCE: None,
        }
        target_mode = _MAP_TO_NEWTON.get(act_type, None)
        if target_mode is None:
            raise ValueError(f"Unsupported joint actuation type for conversion to Newton joint target mode: {act_type}")
        return target_mode

    @staticmethod
    def from_newton(target_mode: JointTargetMode) -> JointActuationType:
        """
        Converts a `JointTargetMode` to the corresponding `JointActuationType`.

        Args:
            target_mode: The Newton joint target mode to convert.

        Returns:
            The corresponding joint actuation type.

        Raises:
            ValueError: if the Newton joint target mode is not supported.
        """
        _MAP_FROM_NEWTON: dict[JointTargetMode, JointActuationType] = {
            JointTargetMode.NONE: JointActuationType.PASSIVE,
            JointTargetMode.EFFORT: JointActuationType.FORCE,
            JointTargetMode.POSITION: JointActuationType.POSITION,
            JointTargetMode.VELOCITY: JointActuationType.VELOCITY,
            JointTargetMode.POSITION_VELOCITY: JointActuationType.POSITION_VELOCITY,
        }
        act_type = _MAP_FROM_NEWTON.get(target_mode, None)
        if act_type is None:
            raise ValueError(f"Unsupported joint target mode for conversion to joint actuation type: {target_mode}")
        return act_type

    @staticmethod
    @wp.func
    def from_newton_wp(target_mode: int) -> int:
        """
        Converts a Newton `JointTargetMode` to the corresponding Kamino
        `JointActuationType`.

        Note:
            This is the warp-compatible equivalent to `from_newton()`.

        Args:
            type: The Newton target mode to convert, see `JointTargetMode`.

        Returns:
            The corresponding joint actuation type (see `JointActuationType`),
            or -1 if the target mode is not supported.
        """
        if target_mode == JointTargetMode.NONE:
            return JointActuationType.PASSIVE
        if target_mode == JointTargetMode.EFFORT:
            return JointActuationType.FORCE
        if target_mode == JointTargetMode.POSITION:
            return JointActuationType.POSITION
        if target_mode == JointTargetMode.VELOCITY:
            return JointActuationType.VELOCITY
        if target_mode == JointTargetMode.POSITION_VELOCITY:
            return JointActuationType.POSITION_VELOCITY

        # Return invalid actuation mode
        return -1

    @staticmethod
    def aggregate(dof_act_types: list[JointActuationType]) -> JointActuationType:
        """Returns the coarse joint-level actuation classification.

        Per-DoF actuation types are authoritative for dynamics and control. This
        aggregate is used where Kamino needs only to distinguish passive joints
        from actuated joints, such as forward kinematics and layout bookkeeping.
        """
        return max(dof_act_types, default=JointActuationType.PASSIVE)

    @staticmethod
    @wp.func
    def aggregate_wp(
        dof_start: int,
        dof_end: int,
        dof_act_types: wp.array[wp.int32],
    ) -> int:
        """
        Returns the joint-level aggregate of per-DoF actuation types.

        Note:
            This is the warp-compatible equivalent to ``aggregate()``.

        Args:
            dof_start: Start index into ``dof_act_types`` (inclusive).
            dof_end: End index into ``dof_act_types`` (exclusive).
            dof_act_types: Kamino per-DoF actuation types, see ``JointActuationType``.

        Returns:
            The aggregated joint actuation type (see ``JointActuationType``).
        """
        aggregate = int(JointActuationType.PASSIVE)
        for dof in range(dof_start, dof_end):
            aggregate = max(aggregate, dof_act_types[dof])
        return aggregate

    @staticmethod
    @wp.func
    def aggregate_from_newton_wp(
        dof_start: int,
        dof_end: int,
        target_mode: wp.array[wp.int32],
    ) -> int:
        """
        Returns the joint-level aggregate of per-DoF Newton target modes.

        Args:
            dof_start: Start index into ``target_mode`` (inclusive).
            dof_end: End index into ``target_mode`` (exclusive).
            target_mode: Newton per-DoF joint target modes, see ``JointTargetMode``.

        Returns:
            The aggregated joint actuation type (see ``JointActuationType``),
            or ``-1`` if any target mode is not supported.
        """
        aggregate = int(JointActuationType.PASSIVE)
        for dof in range(dof_start, dof_end):
            act_type = JointActuationType.from_newton_wp(target_mode[dof])
            if act_type < 0:
                return -1
            aggregate = max(aggregate, act_type)
        return aggregate


class DofActuationPath(IntEnum):
    """
    An enumeration of inferred per-DoF actuation routing paths.

    A path is derived from the DoF actuation type, armature, damping, implicit-PD
    gains, and effort limit; it is not configured independently.
    """

    BODY_WRENCHES = 0
    """Explicit ``tau_j`` applied through body wrenches, normally for ``FORCE`` actuation."""

    DYNAMIC_CTS = 1
    """Joint dynamics path for armature, damping, or unbounded implicit PD."""

    EFFORT_CTS = 2
    """Bounded implicit-PD path that enforces the DoF effort limit."""

    @override
    def __str__(self):
        """Returns a string representation of the DoF actuation path."""
        return f"DofActuationPath.{self.name} ({self.value})"

    @override
    def __repr__(self):
        """Returns a string representation of the DoF actuation path."""
        return self.__str__()


def _has_implicit_pd(act_type: int, k_p: float, k_d: float) -> bool:
    """Returns whether an axis has an active implicit-PD controller."""
    if act_type == JointActuationType.VELOCITY:
        return k_d > 0.0
    return act_type in (
        JointActuationType.POSITION,
        JointActuationType.POSITION_VELOCITY,
        JointActuationType.POSITION_VELOCITY_FORCE,
    ) and (k_p > 0.0 or k_d > 0.0)


def _has_missing_implicit_pd_gains(act_type: int, k_p: float, k_d: float) -> bool:
    """Returns whether an implicit-PD actuation type has no effective gain."""
    if act_type == JointActuationType.VELOCITY:
        return k_d == 0.0
    return (
        act_type
        in (
            JointActuationType.POSITION,
            JointActuationType.POSITION_VELOCITY,
            JointActuationType.POSITION_VELOCITY_FORCE,
        )
        and k_p == 0.0
        and k_d == 0.0
    )


def _validate_implicit_pd_gains(act_type: JointActuationType, k_p: float, k_d: float, *, label: str) -> None:
    """Raises if an implicit-PD actuation type has no effective gain."""
    if _has_missing_implicit_pd_gains(act_type, k_p, k_d):
        raise ValueError(f"Invalid implicit-PD actuation: {act_type.name} requires a non-zero gain ({label}).")


def _is_bounded_effort_limit(tau_max: float) -> bool:
    """Return whether ``tau_max`` denotes a user-authored bounded effort limit."""
    return np.isfinite(tau_max) and tau_max < JOINT_TAUMAX


def _has_effort_cts(act_type: int, k_p: float, k_d: float, tau_max: float) -> bool:
    """Returns whether an axis requires a bounded implicit-PD row."""
    return _has_implicit_pd(act_type, k_p, k_d) and _is_bounded_effort_limit(tau_max)


def _has_unbounded_implicit_pd(act_type: int, k_p: float, k_d: float, tau_max: float) -> bool:
    """Returns whether an axis has unbounded implicit-PD (no finite effort bound)."""
    return _has_implicit_pd(act_type, k_p, k_d) and not _is_bounded_effort_limit(tau_max)


def _has_dynamic_cts(act_type: int, k_p: float, k_d: float, tau_max: float, armature: float, damping: float) -> bool:
    """Returns whether an axis requires a dynamic row."""
    return armature > 0.0 or damping > 0.0 or _has_unbounded_implicit_pd(act_type, k_p, k_d, tau_max)


def _has_friction_cts(dof_type: JointDoFType, f_j: float) -> bool:
    """Returns whether an axis has a Coulomb-friction constraint row."""
    return dof_type != JointDoFType.FREE and f_j > 0.0


@wp.func
def has_implicit_pd_wp(act_type: int, k_p: float, k_d: float) -> bool:
    """Warp-compatible implicit-PD classification for one joint DoF."""
    if act_type == JointActuationType.VELOCITY:
        return k_d > 0.0
    return (
        act_type == JointActuationType.POSITION
        or act_type == JointActuationType.POSITION_VELOCITY
        or act_type == JointActuationType.POSITION_VELOCITY_FORCE
    ) and (k_p > 0.0 or k_d > 0.0)


@wp.func
def is_bounded_effort_limit_wp(tau_max: float) -> bool:
    """Return whether ``tau_max`` denotes a user-authored bounded effort limit."""
    # Checking against JOINT_TAUMAX is important, because the Newton ModelBuilder will insert
    # JOINT_TAUMAX as a default value if no effort limit is specified.
    return wp.isfinite(tau_max) and tau_max < JOINT_TAUMAX


@wp.func
def has_effort_cts_wp(act_type: int, k_p: float, k_d: float, tau_max: float) -> bool:
    """Returns whether one joint DoF requires a bounded implicit-PD row."""
    return has_implicit_pd_wp(act_type, k_p, k_d) and is_bounded_effort_limit_wp(tau_max)


@wp.func
def has_unbounded_implicit_pd_wp(act_type: int, k_p: float, k_d: float, tau_max: float) -> bool:
    """Returns whether one joint DoF has unbounded implicit-PD (no finite effort bound)."""
    return has_implicit_pd_wp(act_type, k_p, k_d) and not is_bounded_effort_limit_wp(tau_max)


@wp.func
def has_dynamic_cts_wp(act_type: int, k_p: float, k_d: float, tau_max: float, armature: float, damping: float) -> bool:
    """Returns whether one joint DoF requires a dynamic row."""
    return armature > 0.0 or damping > 0.0 or has_unbounded_implicit_pd_wp(act_type, k_p, k_d, tau_max)


@wp.func
def has_friction_cts_wp(dof_type: int, f_j: float) -> bool:
    """Returns whether one joint DoF has a Coulomb-friction constraint row."""
    return dof_type != JointDoFType.FREE and f_j > 0.0


class JointCorrectionMode(IntEnum):
    """
    An enumeration of the correction modes applicable to rotational joint coordinates.
    """

    TWOPI = 0
    """
    Rotational joint coordinates are computed to always lie within ``[-2*pi, 2*pi]``.
    This is the default correction mode for all joints with rotational DoFs.
    """

    CONTINUOUS = 1
    """
    Rotational joint coordinates are continuously accumulated and thus unbounded.
    This means that joint coordinates can increase/decrease indefinitely over time,
    but are limited to numerical precision limits (i.e. ``[JOINT_QMIN, JOINT_QMAX]``).
    """

    NONE = -1
    """
    No joint coordinate correction is applied.
    Rotational joint coordinates are computed to lie within ``[-pi, pi]``.
    """

    @property
    def bound(self) -> float:
        """
        Returns the numerical bound imposed by the correction mode.
        """
        if self.value == self.TWOPI:
            return float(wp.tau)  # Note: wp.tau is 2 * pi
        elif self.value == self.CONTINUOUS:
            return float(JOINT_QMAX)
        elif self.value == self.NONE:
            return float(wp.pi)
        else:
            raise ValueError(f"Unknown joint correction mode: {self.value}")

    @classmethod
    def from_string(cls, s: str) -> JointCorrectionMode:
        """Converts a string to a JointCorrectionMode enum value."""
        try:
            return cls[s.upper()]
        except KeyError as e:
            raise ValueError(f"Invalid JointCorrectionMode: {s}. Valid options are: {[e.name for e in cls]}") from e

    @override
    def __str__(self):
        """Returns a string representation of the joint correction mode."""
        return f"JointCorrectionMode.{self.name} ({self.value})"

    @override
    def __repr__(self):
        """Returns a string representation of the joint correction mode."""
        return self.__str__()

    @staticmethod
    def parse_usd_attribute(value: str, context: dict[str, Any] | None = None) -> str:
        """Parse joint correction option imported from USD, following the KaminoSceneAPI schema."""
        if not isinstance(value, str):
            raise TypeError("Parser expects input of type 'str'.")
        mapping = {"none": "none", "twopi": "twopi", "continuous": "continuous"}
        lower_value = value.lower().strip()
        if lower_value not in mapping:
            raise ValueError(f"Joint correction parameter '{value}' is not a valid option.")
        return mapping[lower_value]


@wp.func
def _axis_rotmatn_from_vec3f(vec: wp.vec3f) -> wp.mat33f:
    n = wp.norm_l2(vec)
    assert n >= 1e-12, "Joint axis cannot have near-zero length"
    ax = vec / n
    dominant = wp.int32(wp.argmax(wp.abs(ax)))
    ref = wp.vec3f(0.0, 0.0, 0.0)
    ref[(dominant + 2) % 3] = 1.0
    ay = wp.cross(ref, ax)
    ay = wp.normalize(ay)
    az = wp.cross(ax, ay)
    return wp.matrix_from_cols(ax, ay, az)


class JointDoFType(IntEnum):
    """
    An enumeration of the supported joint Degrees-of-Freedom (DoF) types.

    Joint "DoFs" are defined as the local directions of admissible motion, and
    thus  always equal `num_dofs = 6 - num_cts`, where `6` are the number of
    DoFs for unconstrained rigid motions in SE(3) and `num_cts` is the number
    of bilateral equality constraints imposed by the joint. Thus DoFs can be
    intuited as corresponding to the velocity-level description of the motion.

    Joint "coordinates" are defined as the variables used to parameterize the
    space of configurations (i.e. translations and rotations) admissible by
    the joint. Thus, the number of coordinates `num_coords` is generally not
    equal to the number of DoFs `num_dofs`, i.e. `num_coords != num_dofs`,
    since joints may use redundant or non-minimal parameterizations. For example,
    a spherical joint has `num_dofs = 3` underlying DoFs (at velocity-level),
    yet it is commonly parameterized using a 4D unit-quaternion, i.e.
    `num_coords = 4` at configuration-level.

    This class also provides property methods to query the number of:
    - Generalized coordinates
    - Degrees of Freedom (DoFs)
    - Equality constraints

    Conventions:
    - Each joint connects a Base body `B` to a Follower body `F`.
    - The relative motion of body `F' w.r.t. body `B` defines the positive direction of the joint's DoFs.
    - Mixed linear/angular vectors follow Newton's ``(linear, angular)`` ordering; translational entries
      before rotational entries.
    - `R_x`, `R_y`, `R_z`: denote rotational DoFs about the local x, y, z axes respectively.
    - `T_x`, `T_y`, `T_z`: denote translational DoFs along the local x, y, z axes respectively.
    - Joints are indexed by `j`, and we often employ the subscript notation `*_j`.
    - `c_j` | `num_coords`: denote the number of generalized coordinates defined by joint `j`.
    - `d_j` | `num_dofs`: denote the number of DoFs defined by joint `j`.
    - `e_j` | `num_dynamic_cts`: denote the number of dynamic equality constraints imposed by joint `j`.
    - `f_j` | `num_kinematic_cts`: denote the number of kinematic equality constraints imposed by joint `j`.
    """

    FREE = 0
    """
    A 6-DoF free-floating joint, with translational + rotational DoFs
    along {`T_x`, `T_y`, `T_z`, `R_x`, `R_y`, `R_z`}.

    Coordinates:
        7D transform: 3D position + 4D unit quaternion
    DoFs:
        6D twist: 3D linear velocity + 3D angular velocity
    Constraints:
        None
    """

    REVOLUTE = 1
    """
    A 1-DoF revolute joint, with rotational DoF along {`R_x`}.

    Coordinates:
        1D angle: {`R_x`}
    DoFs:
        1D angular velocity: {`R_x`}
    Constraints:
        5D vector: {`T_x`, `T_y`, `T_z`, `R_y`, `R_z`}
    """

    PRISMATIC = 2
    """
    A 1-DoF prismatic joint, with translational DoF along {`T_x`}.

    Coordinates:
        1D distance: {`T_x`}
    DoFs:
        1D linear velocity: {`T_x`}
    Constraints:
        5D vector: {`T_y`, `T_z`, `R_x`, `R_y`, `R_z`}
    """

    CYLINDRICAL = 3
    """
    A 2-DoF cylindrical joint, with translational + rotational DoFs along {`T_x`, `R_x`}.

    Coordinates:
        2D vector of distance {`T_x`} + angle {`R_x`}
    DoFs:
        2D vector of linear velocity {`T_x`} + angular velocity {`R_x`}
    """

    # TODO: Add support for PLANAR joints with 2D linear DOFS along {`T_x`, `T_y`}
    # and 1D angular DOF along {`R_z`}, with constraints for {`T_z`, `R_x`, `R_y`}

    UNIVERSAL = 4
    """
    A 2-DoF universal joint, with rotational DoFs along {`R_x`, `R_y`}.

    This universal joint is implemented as being equivalent to two consecutive
    revolute joints, rotating an intermediate (virtual) body about `R_x` w.r.t
    the Base body `B`, then rotating the Follower body `F` about `R_y` of the
    intermediate body. Thus, this implementation necessarily assumes the first
    rotation is always about `R_x` followed by the rotation about `R_y`.

    Coordinates:
        2D angles: {`R_x`, `R_y`}
    DoFs:
        2D angular velocities: {`R_x`, `R_y`}
    Constraints:
        4D vector: {`T_x`, `T_y`, `T_z`, `R_z`}
    """

    SPHERICAL = 5
    """
    A 3-DoF spherical joint, with rotational DoFs along {`R_x`, `R_y`, `R_z`}.

    Coordinates:
        4D unit-quaternion to parameterize {`R_x`, `R_y`, `R_z`}
    DoFs:
        3D angular velocities: {`R_x`, `R_y`, `R_z`}
    Constraints:
        3D vector: {`T_x`, `T_y`, `T_z`}
    """

    CARTESIAN = 6
    """
    A 3-DoF Cartesian joint, with translational DoFs along {`T_x`, `T_y`, `T_z`}.

    Coordinates:
        3D distances: {`T_x`, `T_y`, `T_z`}
    DoFs:
        3D linear velocities: {`T_x`, `T_y`, `T_z`}
    Constraints:
        3D vector: {`R_x`, `R_y`, `R_z`}
    """

    FIXED = 7
    """
    A 0-DoF fixed joint, fully constraining the relative motion between the connected bodies.

    Coordinates:
        None
    DoFs:
        None
    Constraints:
        6D vector: {`T_x`, `T_y`, `T_z`, `R_x`, `R_y`, `R_z`}
    """

    GIMBAL = 8
    """
    A 3-DoF rotational D6 joint using three intrinsic Euler coordinates.

    Coordinates:
        3D vector of angles about the configured axes, applied in authored
        order with later axes transported through earlier rotations.
    DoFs:
        3D vector of intrinsic Euler rates.
    Constraints:
        3D vector: {`T_x`, `T_y`, `T_z`}
    """

    GIMBAL_LEFT_HANDED = 9
    """
    A 3-DoF rotational D6 joint whose configured axes form a left-handed
    orthonormal triple.

    This has the same storage layout as :attr:`GIMBAL`. Its third coordinate
    and rate are expressed about the authored third axis, which is opposite to
    the canonical right-handed joint-frame axis.
    """

    ###
    # Operations
    ###

    @override
    def __str__(self):
        """Returns a string representation of the joint DoF type."""
        return f"JointDoFType.{self.name} ({self.value})"

    @override
    def __repr__(self):
        """Returns a string representation of the joint DoF type."""
        return self.__str__()

    @property
    def is_pure_three_dof_rotation(self) -> bool:
        """Whether the joint has exactly three rotational DoFs."""
        return self in (JointDoFType.SPHERICAL, JointDoFType.GIMBAL, JointDoFType.GIMBAL_LEFT_HANDED)

    @property
    def num_coords(self) -> int:
        """
        Returns the number of generalized coordinates defined by the joint DoF type.
        """
        if self.value == self.FREE:
            return 7  # 3D position + 4D quaternion
        elif self.value == self.REVOLUTE:
            return 1  # 1D angle
        elif self.value == self.PRISMATIC:
            return 1  # 1D distance
        elif self.value == self.CYLINDRICAL:
            return 2  # 2D vector of distance + angle
        elif self.value == self.UNIVERSAL:
            return 2  # 2D angles
        elif self.value == self.SPHERICAL:
            return 4  # 4D unit-quaternion
        elif self.value == self.GIMBAL or self.value == self.GIMBAL_LEFT_HANDED:
            return 3  # 3D intrinsic Euler angles
        elif self.value == self.CARTESIAN:
            return 3  # 3D distances
        elif self.value == self.FIXED:
            return 0  # None
        else:
            raise ValueError(f"Unknown joint DoF type: {self.value}")

    @property
    def num_dofs(self) -> int:
        """
        Returns the number of DoFs defined by the joint DoF type.
        """
        if self.value == self.FREE:
            return 6  # 3D linear velocity + 3D angular velocity
        elif self.value == self.REVOLUTE:
            return 1  # 1D angular velocity
        elif self.value == self.PRISMATIC:
            return 1  # 1D linear velocity
        elif self.value == self.CYLINDRICAL:
            return 2  # 1D linear velocity + 1D angular velocity
        elif self.value == self.UNIVERSAL:
            return 2  # 2D angular velocities
        elif self.value == self.SPHERICAL:
            return 3  # 3D angular velocities
        elif self.value == self.GIMBAL or self.value == self.GIMBAL_LEFT_HANDED:
            return 3  # 3D intrinsic Euler rates
        elif self.value == self.CARTESIAN:
            return 3  # 3D linear velocities
        elif self.value == self.FIXED:
            return 0  # None
        else:
            raise ValueError(f"Unknown joint DoF type: {self.value}")

    @property
    def num_cts(self) -> int:
        """
        Returns the number of constraints defined by the joint DoF type.
        """
        if self.value == self.FREE:
            return 0  # None
        elif self.value == self.REVOLUTE:
            return 5  # 5D vector for `{T_x, T_y, T_z, R_y, R_z}`
        elif self.value == self.PRISMATIC:
            return 5  # 5D vector for `{T_x, T_y, T_z, R_y, R_z}`
        elif self.value == self.CYLINDRICAL:
            return 4  # 4D vector for `{T_x, T_y, R_y, R_z}`
        elif self.value == self.UNIVERSAL:
            return 4  # 4D vector for `{R_x, R_y, R_z, R_w}`
        elif self.value == self.SPHERICAL:
            return 3  # 3D vector for `{R_x, R_y, R_z}`
        elif self.value == self.GIMBAL or self.value == self.GIMBAL_LEFT_HANDED:
            return 3  # 3D vector for `{T_x, T_y, T_z}`
        elif self.value == self.CARTESIAN:
            return 3  # 3D vector for `{T_x, T_y, T_z}`
        elif self.value == self.FIXED:
            return 6  # 6D vector for `{T_x, T_y, T_z, R_x, R_y, R_z}`
        else:
            raise ValueError(f"Unknown joint DoF type: {self.value}")

    @property
    def cts_axes(self) -> Vector[Any, Int]:
        """
        Returns the indices of the joint's constraint axes.
        """
        if self.value == self.FREE:
            return []  # Empty vector (TODO: wp.constant(vec0i()))
        if self.value == self.REVOLUTE:
            return wp.constant(vec5i(0, 1, 2, 4, 5))
        elif self.value == self.PRISMATIC:
            return wp.constant(vec5i(1, 2, 3, 4, 5))
        elif self.value == self.CYLINDRICAL:
            return wp.constant(wp.vec4i(1, 2, 4, 5))
        elif self.value == self.UNIVERSAL:
            return wp.constant(wp.vec4i(0, 1, 2, 5))
        elif self.value == self.SPHERICAL:
            return wp.constant(wp.vec3i(0, 1, 2))
        elif self.value == self.GIMBAL or self.value == self.GIMBAL_LEFT_HANDED:
            return wp.constant(wp.vec3i(0, 1, 2))
        elif self.value == self.CARTESIAN:
            return wp.constant(wp.vec3i(3, 4, 5))
        elif self.value == self.FIXED:
            return wp.constant(vec6i(0, 1, 2, 3, 4, 5))
        else:
            raise ValueError(f"Unknown joint DoF type: {self.value}")

    @property
    def dofs_axes(self) -> Vector[Any, Int]:
        """
        Returns the indices of the joint's DoF axes.
        """
        if self.value == self.FREE:
            return wp.constant(vec6i(0, 1, 2, 3, 4, 5))
        if self.value == self.REVOLUTE:
            return wp.constant(vec1i(3))
        elif self.value == self.PRISMATIC:
            return wp.constant(vec1i(0))
        elif self.value == self.CYLINDRICAL:
            return wp.constant(wp.vec2i(0, 3))
        elif self.value == self.UNIVERSAL:
            return wp.constant(wp.vec2i(3, 4))
        elif self.value == self.SPHERICAL:
            return wp.constant(wp.vec3i(3, 4, 5))
        elif self.value == self.GIMBAL or self.value == self.GIMBAL_LEFT_HANDED:
            return wp.constant(wp.vec3i(3, 4, 5))
        elif self.value == self.CARTESIAN:
            return wp.constant(wp.vec3i(0, 1, 2))
        elif self.value == self.FIXED:
            return []  # Empty vector (TODO: wp.constant(vec0i()))
        else:
            raise ValueError(f"Unknown joint DoF type: {self.value}")

    @property
    def coords_storage_type(self) -> Any:
        """
        Returns the data type required to store the joint's generalized coordinates.
        """
        if self.value == self.FREE:
            return vec7f
        elif self.value == self.REVOLUTE:
            return vec1f
        elif self.value == self.PRISMATIC:
            return vec1f
        elif self.value == self.CYLINDRICAL:
            return wp.vec2f
        elif self.value == self.UNIVERSAL:
            return wp.vec2f
        elif self.value == self.SPHERICAL:
            return wp.vec4f
        elif self.value == self.GIMBAL or self.value == self.GIMBAL_LEFT_HANDED:
            return wp.vec3f
        elif self.value == self.CARTESIAN:
            return wp.vec3f
        elif self.value == self.FIXED:
            return None
        else:
            raise ValueError(f"Unknown joint DoF type: {self.value}")

    @property
    def coords_physical_type(self) -> Any:
        """
        Returns the data type required to represent the joint's generalized coordinates.
        """
        if self.value == self.FREE:
            return wp.transformf
        elif self.value == self.REVOLUTE:
            return vec1f
        elif self.value == self.PRISMATIC:
            return vec1f
        elif self.value == self.CYLINDRICAL:
            return wp.vec2f
        elif self.value == self.UNIVERSAL:
            return wp.vec2f
        elif self.value == self.SPHERICAL:
            return wp.quatf
        elif self.value == self.GIMBAL or self.value == self.GIMBAL_LEFT_HANDED:
            return wp.vec3f
        elif self.value == self.CARTESIAN:
            return wp.vec3f
        elif self.value == self.FIXED:
            return None
        else:
            raise ValueError(f"Unknown joint DoF type: {self.value}")

    @property
    def reference_coords(self) -> list[float]:
        """
        Returns the joint's generalized coordinates in its neutral position.
        """
        if self.value == self.FREE:
            return [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0]
        elif self.value == self.REVOLUTE:
            return [0.0]
        elif self.value == self.PRISMATIC:
            return [0.0]
        elif self.value == self.CYLINDRICAL:
            return [0.0, 0.0]
        elif self.value == self.UNIVERSAL:
            return [0.0, 0.0]
        elif self.value == self.SPHERICAL:
            return [0.0, 0.0, 0.0, 1.0]
        elif self.value == self.GIMBAL or self.value == self.GIMBAL_LEFT_HANDED:
            return [0.0, 0.0, 0.0]
        elif self.value == self.CARTESIAN:
            return [0.0, 0.0, 0.0]
        elif self.value == self.FIXED:
            return []
        else:
            raise ValueError(f"Unknown joint DoF type: {self.value}")

    def coords_bound(self, correction: JointCorrectionMode) -> list[float]:
        """
        Returns a list of numeric bounds for the generalized coordinates,
        of the joint DoF type, imposed by the specified correction mode.
        """
        rotation_bound = correction.bound

        if self.value == self.FREE:
            return [JOINT_QMAX] * 7
        elif self.value == self.REVOLUTE:
            return [rotation_bound]
        elif self.value == self.PRISMATIC:
            return [JOINT_QMAX]
        elif self.value == self.CYLINDRICAL:
            return [JOINT_QMAX, rotation_bound]
        elif self.value == self.UNIVERSAL:
            return [rotation_bound, rotation_bound]
        elif self.value == self.SPHERICAL:
            return [JOINT_QMAX] * 4
        elif self.value == self.GIMBAL or self.value == self.GIMBAL_LEFT_HANDED:
            return [rotation_bound] * 3
        elif self.value == self.CARTESIAN:
            return [JOINT_QMAX] * 3
        elif self.value == self.FIXED:
            return []
        else:
            raise ValueError(f"Unknown joint DoF type: {self.value}")

    @staticmethod
    def to_newton(dof_type: JointDoFType) -> JointType:
        """
        Converts a `JointDoFType` to the corresponding `JointType`.

        Args:
            dof_type: The joint DoF type to convert.

        Returns:
            The corresponding Newton joint type.

        Raises:
            ValueError: if the joint dof type is not supported.
        """
        _MAP_TO_NEWTON: dict[JointDoFType, JointType] = {
            # All trivially supported DoF types map directly
            # to their corresponding Newton joint types
            JointDoFType.FREE: JointType.FREE,
            JointDoFType.REVOLUTE: JointType.REVOLUTE,
            JointDoFType.PRISMATIC: JointType.PRISMATIC,
            JointDoFType.SPHERICAL: JointType.BALL,
            JointDoFType.GIMBAL: JointType.D6,
            JointDoFType.GIMBAL_LEFT_HANDED: JointType.D6,
            JointDoFType.FIXED: JointType.FIXED,
            # All kamino-specific joint types map to D6
            JointDoFType.CARTESIAN: JointType.D6,
            JointDoFType.CYLINDRICAL: JointType.D6,
            JointDoFType.UNIVERSAL: JointType.D6,
        }
        joint_type = _MAP_TO_NEWTON.get(dof_type, None)
        if joint_type is None:
            raise ValueError(f"Unsupported joint DoF type for conversion to Newton joint type: {dof_type}")
        return joint_type

    @staticmethod
    def from_newton(
        type: JointType,
        q_count: int,
        qd_count: int,
        dof_dim: tuple[int, int],
        limit_lower: np.ndarray,
        limit_upper: np.ndarray,
        dof_axes: np.ndarray | None = None,
    ) -> JointDoFType:
        """
        Converts a `JointType` to the corresponding `JointDoFType`.

        Args:
            type: The Newton joint type to convert.
            q_count: The Newton coordinates count for this joint.
            qd_count: The Newton dofs count for this joint.
            dof_dim: The Newton dof dimension (linear/angular dof counts) for this joint.
            limit_lower: The lower position limits from Newton for this joint (in dof space).
            limit_upper: The upper position limits from Newton for this joint (in dof space).
            dof_axes: The Newton joint axes, used to distinguish gimbal handedness.

        Returns:
            The corresponding joint DoF type.

        Raises:
            ValueError: if the Newton joint type is not supported.
        """
        # First try directly mapping the trivially supported types
        _MAP_TO_KAMINO: dict[JointType, JointDoFType | None] = {
            JointType.FREE: JointDoFType.FREE,
            JointType.REVOLUTE: JointDoFType.REVOLUTE,
            JointType.PRISMATIC: JointDoFType.PRISMATIC,
            JointType.BALL: JointDoFType.SPHERICAL,
            JointType.FIXED: JointDoFType.FIXED,
            # NOTE: D6 joints require special handling
            # to infer the corresponding DoF type
            JointType.D6: None,
        }
        dof_type = _MAP_TO_KAMINO.get(type, None)
        if dof_type is not None:
            return dof_type

        # If the type is not directly supported, attempt to infer the DoF type based on the number of DoFs
        if dof_type is None or type == JointType.D6:
            # Ensure that q_count and qd_count are provided for inference
            if q_count is None or qd_count is None:
                raise ValueError("q_count and qd_count must be provided for inference of unsupported joint types.")

            # Ensure dof_dim is provided for inference
            if dof_dim is None or not isinstance(dof_dim, tuple) or len(dof_dim) != 2:
                raise ValueError(
                    "dof_dim must be provided as a tuple of length 2 for inference of unsupported joint types."
                )

            # Ensure the limits are provided for inference
            if limit_lower is None or limit_upper is None:
                raise ValueError(
                    "limit_lower and limit_upper must be provided for inference of unsupported joint types."
                )
            if not isinstance(limit_lower, np.ndarray) or not isinstance(limit_upper, np.ndarray):
                raise TypeError(
                    "limit_lower and limit_upper must be numpy arrays for inference of unsupported joint types."
                )
            if limit_lower.shape != limit_upper.shape:
                raise ValueError(
                    f"limit_lower and limit_upper must have the same shape, got: "
                    f"limit_lower.shape: {limit_lower.shape}, limit_upper.shape: {limit_upper.shape}."
                )
            if limit_lower.shape[0] != qd_count or limit_upper.shape[0] != qd_count:
                raise ValueError(
                    f"The length of limit_lower and limit_upper must match qd_count ({qd_count}), got:"
                    f"\n  limit_lower: {limit_lower} (shape={limit_lower.shape})"
                    f"\n  limit_upper: {limit_upper} (shape={limit_upper.shape})"
                )

            # Map to the DoF type based on the dimensions of the joint
            if q_count == 0 and qd_count == 0 and dof_dim == (0, 0):
                dof_type = JointDoFType.FIXED
            elif q_count == 1 and qd_count == 1 and dof_dim == (1, 0):
                dof_type = JointDoFType.PRISMATIC
            elif q_count == 1 and qd_count == 1 and dof_dim == (0, 1):
                dof_type = JointDoFType.REVOLUTE
            elif q_count == 2 and qd_count == 2 and dof_dim == (0, 2):
                dof_type = JointDoFType.UNIVERSAL
            elif q_count == 2 and qd_count == 2 and dof_dim == (1, 1):
                dof_type = JointDoFType.CYLINDRICAL
            elif q_count == 3 and qd_count == 3 and dof_dim == (3, 0):
                dof_type = JointDoFType.CARTESIAN
            elif q_count == 3 and qd_count == 3 and dof_dim == (0, 3):
                if (
                    dof_axes is not None
                    and dof_axes.shape == (3, 3)
                    and np.all(np.isfinite(dof_axes))
                    and np.dot(np.cross(dof_axes[0], dof_axes[1]), dof_axes[2]) < 0.0
                ):
                    dof_type = JointDoFType.GIMBAL_LEFT_HANDED
                else:
                    dof_type = JointDoFType.GIMBAL
            elif q_count == 4 and qd_count == 3 and dof_dim == (0, 3):
                dof_type = JointDoFType.SPHERICAL
            elif q_count == 7 and qd_count == 6:
                if np.any(limit_lower <= JOINT_QMIN) or np.any(limit_upper >= JOINT_QMAX):
                    dof_type = JointDoFType.FREE
                else:
                    raise ValueError(
                        f"Unsupported joint type with 7 coordinates and 6 DoFs but unrecognized limits:\n"
                        f"\n  limit_lower: {limit_lower}"
                        f"\n  limit_upper: {limit_upper}"
                    )
            else:
                raise ValueError(
                    f"Unsupported joint type with:"
                    f"\n  type: {type}"
                    f"\n  dof_dim: {dof_dim}"
                    f"\n  q_count: {q_count}"
                    f"\n  qd_count: {qd_count}"
                    f"\n  limit_lower: {limit_lower}"
                    f"\n  limit_upper: {limit_upper}"
                )

        # Return the inferred DoF type
        return dof_type

    @staticmethod
    @wp.func
    def from_newton_wp(
        joint_type: int,
        q_count: int,
        qd_count: int,
        dof_dim: wp.vec2i,
        limit_lower: vec6f,
        limit_upper: vec6f,
        dof_axes: mat63f,
    ) -> wp.int32:
        """
        Converts a Newton `JointType` to the corresponding Kamino `JointDoFType`.

        Note:
            This is the warp-compatible equivalent to `from_newton()`.

        Args:
            joint_type: The Newton joint type to convert, see `JointType`.
            q_count: The Newton coordinates count for this joint.
            qd_count: The Newton dofs count for this joint.
            dof_dim: The Newton dof dimension (linear/angular dof counts) for this joint.
            limit_lower: The lower position limits from Newton for this joint (in dof space).
            limit_upper: The upper position limits from Newton for this joint (in dof space).
            dof_axes: The Newton joint axes, used to distinguish gimbal handedness.

        Returns:
            The corresponding joint DoF type, or -1 if the joint type is not
            supported.
        """
        # First try directly mapping the trivially supported types
        if joint_type == JointType.PRISMATIC:
            return JointDoFType.PRISMATIC
        elif joint_type == JointType.REVOLUTE:
            return JointDoFType.REVOLUTE
        elif joint_type == JointType.BALL:
            return JointDoFType.SPHERICAL
        elif joint_type == JointType.FIXED:
            return JointDoFType.FIXED
        elif joint_type == JointType.FREE:
            return JointDoFType.FREE

        # If the type is not directly supported, attempt to infer the DoF type based
        # on the dimensions of the joint and number of DoFs.
        if q_count == 0 and qd_count == 0 and dof_dim == wp.vec2i(0, 0):
            return JointDoFType.FIXED
        elif q_count == 1 and qd_count == 1 and dof_dim == wp.vec2i(1, 0):
            return JointDoFType.PRISMATIC
        elif q_count == 1 and qd_count == 1 and dof_dim == wp.vec2i(0, 1):
            return JointDoFType.REVOLUTE
        elif q_count == 2 and qd_count == 2 and dof_dim == wp.vec2i(0, 2):
            return JointDoFType.UNIVERSAL
        elif q_count == 2 and qd_count == 2 and dof_dim == wp.vec2i(1, 1):
            return JointDoFType.CYLINDRICAL
        elif q_count == 3 and qd_count == 3 and dof_dim == wp.vec2i(3, 0):
            return JointDoFType.CARTESIAN
        elif q_count == 3 and qd_count == 3 and dof_dim == wp.vec2i(0, 3):
            if wp.dot(wp.cross(dof_axes[0], dof_axes[1]), dof_axes[2]) < 0.0:
                return JointDoFType.GIMBAL_LEFT_HANDED
            return JointDoFType.GIMBAL
        elif q_count == 4 and qd_count == 3 and dof_dim == wp.vec2i(0, 3):
            return JointDoFType.SPHERICAL
        elif q_count == 7 and qd_count == 6:
            for i in range(qd_count):
                if limit_lower[i] <= JOINT_QMIN or limit_upper[i] >= JOINT_QMAX:
                    return JointDoFType.FREE
            # Unsupported joint type with 7 coordinates and 6 DoFs but unrecognized limits
            return -1

        # Return invalid DoF type
        return -1

    @staticmethod
    @wp.func
    def num_coords_wp(dof_type: int) -> int:
        """
        Returns the number of generalized coordinates defined by the joint DoF type.

        Note:
            This is the warp-compatible equivalent to `num_coords`.

        Returns:
            The number of coordinates for the given type, or `-1` if the DoF type is
            invalid.
        """
        if dof_type == JointDoFType.FREE:
            return 7  # 3D position + 4D quaternion
        elif dof_type == JointDoFType.REVOLUTE:
            return 1  # 1D angle
        elif dof_type == JointDoFType.PRISMATIC:
            return 1  # 1D distance
        elif dof_type == JointDoFType.CYLINDRICAL:
            return 2  # 2D vector of distance + angle
        elif dof_type == JointDoFType.UNIVERSAL:
            return 2  # 2D angles
        elif dof_type == JointDoFType.SPHERICAL:
            return 4  # 4D unit-quaternion
        elif dof_type == JointDoFType.GIMBAL or dof_type == JointDoFType.GIMBAL_LEFT_HANDED:
            return 3  # 3D intrinsic Euler angles
        elif dof_type == JointDoFType.CARTESIAN:
            return 3  # 3D distances
        elif dof_type == JointDoFType.FIXED:
            return 0  # None
        return -1

    @staticmethod
    @wp.func
    def num_dofs_wp(dof_type: int) -> int:
        """
        Returns the number of DoFs defined by the joint DoF type.

        Note:
            This is the warp-compatible equivalent to `num_dofs`.

        Returns:
            The number of DoFs for the given type, or `-1` if the DoF type is
            invalid.
        """
        if dof_type == JointDoFType.FREE:
            return 6  # 3D linear velocity + 3D angular velocity
        elif dof_type == JointDoFType.REVOLUTE:
            return 1  # 1D angular velocity
        elif dof_type == JointDoFType.PRISMATIC:
            return 1  # 1D linear velocity
        elif dof_type == JointDoFType.CYLINDRICAL:
            return 2  # 1D linear velocity + 1D angular velocity
        elif dof_type == JointDoFType.UNIVERSAL:
            return 2  # 2D angular velocities
        elif dof_type == JointDoFType.SPHERICAL:
            return 3  # 3D angular velocities
        elif dof_type == JointDoFType.GIMBAL or dof_type == JointDoFType.GIMBAL_LEFT_HANDED:
            return 3  # 3D intrinsic Euler rates
        elif dof_type == JointDoFType.CARTESIAN:
            return 3  # 3D linear velocities
        elif dof_type == JointDoFType.FIXED:
            return 0  # None
        return -1

    @staticmethod
    @wp.func
    def num_cts_wp(dof_type: int) -> int:
        """
        Returns the number of constraints defined by the joint DoF type.

        Note:
            This is the warp-compatible equivalent to `num_cts`.

        Returns:
            The number of constraints for the given type, or `-1` if the DoF type is
            invalid.
        """
        if dof_type == JointDoFType.FREE:
            return 0  # None
        elif dof_type == JointDoFType.REVOLUTE:
            return 5  # 5D vector for `{T_x, T_y, T_z, R_y, R_z}`
        elif dof_type == JointDoFType.PRISMATIC:
            return 5  # 5D vector for `{T_x, T_y, T_z, R_y, R_z}`
        elif dof_type == JointDoFType.CYLINDRICAL:
            return 4  # 4D vector for `{T_x, T_y, R_y, R_z}`
        elif dof_type == JointDoFType.UNIVERSAL:
            return 4  # 4D vector for `{R_x, R_y, R_z, R_w}`
        elif dof_type == JointDoFType.SPHERICAL:
            return 3  # 3D vector for `{R_x, R_y, R_z}`
        elif dof_type == JointDoFType.GIMBAL or dof_type == JointDoFType.GIMBAL_LEFT_HANDED:
            return 3  # 3D vector for `{T_x, T_y, T_z}`
        elif dof_type == JointDoFType.CARTESIAN:
            return 3  # 3D vector for `{T_x, T_y, T_z}`
        elif dof_type == JointDoFType.FIXED:
            return 6  # 6D vector for `{T_x, T_y, T_z, R_x, R_y, R_z}`
        return -1

    @staticmethod
    @wp.func
    def dofs_axis_wp(dof_type: int, axis: int) -> int:
        """
        Returns the spatial twist component for a joint-local DoF axis.

        Note:
            This is the warp-compatible equivalent to ``dofs_axes[axis]``.

        Args:
            dof_type: The joint DoF type.
            axis: Joint-local DoF index.

        Returns:
            Spatial twist component index in ``[0, 5]``.
        """
        if dof_type == JointDoFType.FREE:
            return axis
        if dof_type == JointDoFType.REVOLUTE:
            return 3
        if dof_type == JointDoFType.PRISMATIC:
            return 0
        if dof_type == JointDoFType.CYLINDRICAL:
            return wp.where(axis == 0, 0, 3)
        if dof_type == JointDoFType.UNIVERSAL:
            return 3 + axis
        if dof_type == JointDoFType.SPHERICAL:
            return 3 + axis
        if dof_type == JointDoFType.GIMBAL or dof_type == JointDoFType.GIMBAL_LEFT_HANDED:
            return 3 + axis
        if dof_type == JointDoFType.CARTESIAN:
            return axis
        if dof_type == JointDoFType.FIXED:
            return -1
        return -1

    @staticmethod
    @wp.func
    def axes_matrix_from_joint_type(
        dof_type: int,
        dof_axes: mat63f,
    ) -> wp.mat33f:
        """
        Returns the joint axes rotation matrix `R_axis_j` for the
        specified joint DoF type, based on the provided DoF axes.

        Args:
            dof_type: The joint DoF type for which to compute the axes matrix.
            dof_axes: A 2D array of shape `(6, 3)`, of which the initial block of
                shape `(num_dofs, 3)` contains the local axes of the joint's
                DoFs in the order they are defined.

        Returns:
            The joint axes rotation matrix `R_axis_j` if applicable, or the
            identity matrix if the joint type does not require an axes matrix.
        """
        # Initialize the joint axes rotation matrix to identity by default
        R_axis_j = wp.identity(3, dtype=wp.float32)

        # Determine the joint axes matrix based on the DoF type and axes
        if dof_type == JointDoFType.FIXED:
            pass  # R_axis_j is already set to identity
        elif dof_type == JointDoFType.REVOLUTE:
            R_axis_j = _axis_rotmatn_from_vec3f(dof_axes[0])
        elif dof_type == JointDoFType.PRISMATIC:
            R_axis_j = _axis_rotmatn_from_vec3f(dof_axes[0])
        elif dof_type == JointDoFType.CYLINDRICAL:
            R_axis_j = _axis_rotmatn_from_vec3f(dof_axes[0])
        elif dof_type == JointDoFType.UNIVERSAL:
            ax = dof_axes[0]
            ay = dof_axes[1]
            az = wp.cross(ax, ay)
            R_axis_j = wp.matrix_from_cols(ax, ay, az)
        elif dof_type == JointDoFType.SPHERICAL:
            R_axis_j = wp.matrix_from_cols(dof_axes[0], dof_axes[1], dof_axes[2])
        elif dof_type == JointDoFType.GIMBAL or dof_type == JointDoFType.GIMBAL_LEFT_HANDED:
            R_axis_j = wp.matrix_from_cols(dof_axes[0], dof_axes[1], wp.cross(dof_axes[0], dof_axes[1]))
        elif dof_type == JointDoFType.CARTESIAN:
            R_axis_j = wp.matrix_from_cols(dof_axes[0], dof_axes[1], dof_axes[2])
        elif dof_type == JointDoFType.FREE:
            assert wp.norm_l2(dof_axes[0] - dof_axes[3]) < 1e-6, "Linear and rotational axes for free joint must match"
            assert wp.norm_l2(dof_axes[1] - dof_axes[4]) < 1e-6, "Linear and rotational axes for free joint must match"
            assert wp.norm_l2(dof_axes[2] - dof_axes[5]) < 1e-6, "Linear and rotational axes for free joint must match"
            R_axis_j = wp.matrix_from_cols(dof_axes[0], dof_axes[1], dof_axes[2])

        # Return the computed joint axes rotation matrix
        return R_axis_j


###
# Containers
###


@dataclass
class JointDescriptor(Descriptor):
    """
    A container to describe a single joint in the model builder.
    """

    ###
    # Attributes
    ###

    dof_act_types: list[JointActuationType] = field(default_factory=list)
    """
    Actuation type of each joint DoF.

    This is the authoritative actuation representation for the joint. Its
    length must equal :attr:`num_dofs`. :attr:`act_type` is a derived coarse
    passive-versus-actuated classification for forward kinematics and layout
    bookkeeping.
    """

    fk_act_flag: int = -1
    """
    Integer flag indicating whether this joint should be considered actuated (1) or passive (0) by the
    Forward Kinematics solver, or to infer this from `act_type` (-1).

    Actuating more joints in FK than in dynamics can be used, e.g., to make the FK problem well-posed for
    under-actuated systems.
    Note that all actuator types are treated equally in FK (only passive vs actuated matters).
    """

    dof_type: JointDoFType = JointDoFType.FREE
    """DoF type of the joint."""

    bid_B: int = -1
    """
    The Base body index of the joint (-1 for world, >=0 for bodies).
    Defaults to `-1`, indicating that the joint has not been assigned a base body.
    """

    bid_F: int = -1
    """
    The Follower body index of the joint (must always be >=0 to index a body).
    Defaults to `-1`, indicating that the joint has not been assigned a follower body.
    """

    B_r_Bj: wp.vec3f = field(default_factory=wp.vec3f)
    """The relative position of the joint in the base body coordinates."""

    F_r_Fj: wp.vec3f = field(default_factory=wp.vec3f)
    """The relative position of the joint in the follower body coordinates."""

    X_Bj: wp.mat33f = field(default_factory=wp.mat33f)
    """The orientation of the joint frame on the base body, in the base body coordinates."""

    X_Fj: wp.mat33f | None = None
    """
    The orientation of the joint frame on the follower body, in the follower body coordinates.

    If not provided, defaults to `X_Bj`.
    """

    q_j_min: ArrayLike | float | None = None
    """
    Minimum DoF limits of the joint.

    If `None`, then no limits are applied to the joint DoFs,
    and the maximum limits default to `-inf` for lower limits.

    If specified as a single float value, it will
    be applied uniformly to all DoFs of the joint.

    If specified as a type conforming to the `ArrayLike`
    union, then the number of elements must equal number of
    DoFs of the joint, i.e. `num_dofs = dof_type.num_dofs`.

    For rotational DoFs, limits are expected in radians,
    while for translational DoFs, limits are expected in
    the same units as the world units.

    **Warning**:
    These limits are dimensioned according to the number of `num_dofs`,
    even though joint coordinates are actually dimensioned according to
    `num_coords`. This is because some joints (e.g. SPHERICAL) may use
    redundant or non-minimal parameterizations at configuration-level.
    In order to support configuration-level limits regardless of the
    underlying parameterization, a mapping is performed in the solver
    that translates the limits from DoF space to coordinate space.
    """

    q_j_max: ArrayLike | float | None = None
    """
    Maximum DoF limits of the joint.

    If `None`, then no limits are applied to the joint DoFs,
    and the maximum limits default to `-inf` for lower limits.

    If specified as a single float value, it will
    be applied uniformly to all DoFs of the joint.

    If specified as a type conforming to the `ArrayLike`
    union, then the number of elements must equal number of
    DoFs of the joint, i.e. `num_dofs = dof_type.num_dofs`.

    **Warning**:
    These limits are dimensioned according to the number of `num_dofs`,
    even though joint coordinates are actually dimensioned according to
    `num_coords`. This is because some joints (e.g. SPHERICAL) may use
    redundant or non-minimal parameterizations at configuration-level.
    In order to support configuration-level limits regardless of the
    underlying parameterization, a mapping is performed in the solver
    that translates the limits from DoF space to coordinate space.
    """

    dq_j_max: ArrayLike | float | None = None
    """
    Maximum velocity limits of the joint.

    If `None`, then no limits are applied
    to the joint's generalized velocities.

    If specified as a single float value, it will
    be applied uniformly to all DoFs of the joint.

    If specified as a type conforming to the `ArrayLike`
    union, then the number of elements must equal number of
    DoFs of the joint, i.e. `num_dofs = dof_type.num_dofs`.
    """

    tau_j_max: ArrayLike | float | None = None
    """
    Maximum effort (i.e. generalized force) limits of the joint.

    If ``None``, defaults to :data:`JOINT_TAUMAX` (unbounded). Values at or above
    :data:`JOINT_TAUMAX` are treated as unbounded for implicit-PD effort-row
    allocation, matching the Newton ``ModelBuilder`` default sentinel.

    If specified as a single float value, it will
    be applied uniformly to all DoFs of the joint.

    If specified as a type conforming to the `ArrayLike`
    union, then the number of elements must equal number of
    DoFs of the joint, i.e. `num_dofs = dof_type.num_dofs`.
    """

    a_j: ArrayLike | float | None = None
    """
    Internal inertia of the joint (a.k.a. joint armature),
    used for implicit integration of joint dynamics.

    This represents effects like rotor inertia of rotary motors,
    potentially transferred over a transmission, and compounding
    the inertia of the gearbox. This is often referred to as so
    called "reflected inertia" of an actuator as seen at the joint.

    If specified as a type conforming to the `ArrayLike`
    union, then the number of elements must equal number of
    DoFs of the joint, i.e. `num_dofs = dof_type.num_dofs`.

    Defaults to `[0.0] * num_dofs` if not specified, indicating
    that the joint has no internal inertia and is thus massless.
    """

    b_j: ArrayLike | float | None = None
    """
    Internal damping of the joint used for implicit integration of joint dynamics.

    This represents effects like viscous friction in rotary motors,
    potentially transferred over a transmission, and compounding
    the friction of the gearbox.

    If specified as a type conforming to the `ArrayLike`
    union, then the number of elements must equal number of
    DoFs of the joint, i.e. `num_dofs = dof_type.num_dofs`.

    Defaults to `[0.0] * num_dofs` if not specified, indicating
    that the joint has no internal damping and is thus frictionless.
    """

    f_j: ArrayLike | float | None = None
    """
    Coulomb friction force or torque along each joint DoF [N, N·m].

    Each translational DoF uses a force [N], and each rotational DoF uses a torque [N·m].
    Accepts `ArrayLike`, `float`, or `None`.

    If specified as a type conforming to the `ArrayLike` union, then the
    number of elements must equal the number of DoFs of the joint, i.e.
    `num_dofs = dof_type.num_dofs`.

    Defaults to zero. Positive values allocate a bounded-multiplier constraint row
    for every DoF of the joint. Friction on free joints is ignored.
    """

    k_p_j: ArrayLike | float | None = None
    """
    Implicit PD-control proportional gain.

    If specified as a type conforming to the `ArrayLike`
    union, then the number of elements must equal number of
    DoFs of the joint, i.e. `num_dofs = dof_type.num_dofs`.

    Defaults to `[0.0] * num_dofs` if not specified, indicating
    that the joint has no implicit proportional gain.
    """

    k_d_j: ArrayLike | float | None = None
    """
    Implicit PD-control derivative gain.

    If specified as a type conforming to the `ArrayLike`
    union, then the number of elements must equal number of
    DoFs of the joint, i.e. `num_dofs = dof_type.num_dofs`.

    Defaults to `[0.0] * num_dofs` if not specified, indicating
    that the joint has no implicit derivative gain.
    """

    ###
    # Metadata - to be set by the WorldDescriptor when added
    ###

    wid: int = -1
    """
    Index of the world to which the joint belongs.
    Defaults to `-1`, indicating that the joint has not yet been added to a world.
    """

    jid: int = -1
    """
    Index of the joint w.r.t. its world.
    Defaults to `-1`, indicating that the joint has not yet been added to a world.
    """

    coords_offset: int = -1
    """
    Index offset of this joint's coordinates among
    all joint coordinates in the world it belongs to.
    """

    dofs_offset: int = -1
    """
    Index offset of this joint's DoFs among
    all joint DoFs in the world it belongs to.
    """

    passive_coords_offset: int = -1
    """
    Index offset of this joint's passive coordinates among all
    passive joint coordinates in the world it belongs to.
    """

    passive_dofs_offset: int = -1
    """
    Index offset of this joint's passive DoFs among all
    passive joint DoFs in the world it belongs to.
    """

    actuated_coords_offset: int = -1
    """
    Index offset of this joint's actuated coordinates among
    all actuated joint coordinates in the world it belongs to.
    """

    actuated_dofs_offset: int = -1
    """
    Index offset of this joint's actuated DoFs among
    all actuated joint DoFs in the world it belongs to.
    """

    bilateral_cts_offset: int = -1
    """
    Index offset of this joint's bilateral constraints among all bilateral
    joint constraints (kinematic + dynamic) in the world it belongs to.
    """

    dynamic_cts_offset: int = -1
    """
    Index offset of this joint's dynamic constraints among all
    dynamic joint constraints in the world it belongs to.
    """

    kinematic_cts_offset: int = -1
    """
    Index offset of this joint's kinematic constraints among all
    kinematic joint constraints in the world it belongs to.
    """

    bounded_cts_offset: int = -1
    """
    Index offset of this joint's bounded-multiplier rows among all
    bounded-multiplier constraints in its world.
    """

    friction_cts_offset: int = -1
    """
    Index offset of this joint's friction rows among all
    Coulomb joint friction constraints in its world.
    """

    effort_cts_offset: int = -1
    """
    Index offset of this joint's effort-limit implicit-PD rows among all
    effort-limit implicit-PD constraints in its world.
    """

    ###
    # Properties
    ###

    @property
    def num_coords(self) -> int:
        """
        Returns the number of coordinates for this joint.
        """
        return self.dof_type.num_coords

    @property
    def num_dofs(self) -> int:
        """
        Returns the number of DoFs for this joint.
        """
        return self.dof_type.num_dofs

    @property
    def num_passive_coords(self) -> int:
        """
        Returns the number of passive coordinates for this joint.
        """
        return self.dof_type.num_coords if self.is_passive else 0

    @property
    def num_passive_dofs(self) -> int:
        """
        Returns the number of passive DoFs for this joint.
        """
        return self.dof_type.num_dofs if self.is_passive else 0

    @property
    def num_actuated_coords(self) -> int:
        """
        Returns the number of actuated coordinates for this joint.
        """
        return self.dof_type.num_coords if self.is_actuated else 0

    @property
    def num_actuated_dofs(self) -> int:
        """
        Returns the number of actuated DoFs for this joint.
        """
        return self.dof_type.num_dofs if self.is_actuated else 0

    @property
    def num_bilateral_cts(self) -> int:
        """
        Returns the total number of bilateral constraints introduced by this joint.
        """
        return self.num_dynamic_cts + self.num_kinematic_cts

    @property
    def num_dynamic_cts(self) -> int:
        """
        Returns the number of dynamic constraints introduced by this joint.
        """
        return len(self.dynamic_cts_axes())

    @property
    def num_kinematic_cts(self) -> int:
        """
        Returns the number of kinematic constraints introduced by this joint.
        """
        return self.dof_type.num_cts

    @property
    def num_bounded_cts(self) -> int:
        """Returns the number of bounded-multiplier constraint rows introduced by this joint."""
        return self.num_friction_cts + self.num_effort_cts

    @property
    def num_friction_cts(self) -> int:
        """Returns the number of Coulomb joint friction rows introduced by this joint."""
        return len(self.friction_cts_axes())

    @property
    def num_effort_cts(self) -> int:
        """Returns the number of effort-limit implicit-PD rows."""
        return len(self.effort_cts_axes())

    @property
    def is_binary(self) -> bool:
        """
        Returns whether the joint is binary (i.e. connected to two bodies).
        """
        return self.bid_B != -1 and self.bid_F != -1

    @property
    def is_unary(self) -> bool:
        """
        Returns whether the joint is unary (i.e. connected to the world).
        """
        return self.bid_B == -1 or self.bid_F == -1

    @property
    def act_type(self) -> JointActuationType:
        """
        Returns the joint-level passive-versus-actuated classification.

        The aggregate is not used for per-DoF control or dynamics.
        """
        return JointActuationType.aggregate(self.dof_act_types)

    @property
    def is_passive(self) -> bool:
        """
        Returns whether the joint is passive.
        """
        return self.act_type == JointActuationType.PASSIVE

    @property
    def is_actuated(self) -> bool:
        """
        Returns whether the joint is actuated.
        """
        return self.act_type > JointActuationType.PASSIVE

    def dynamic_cts_axes(self) -> list[int]:
        """
        Returns sorted local DoF axes with joint dynamics.
        """
        return [axis for axis in range(self.num_dofs) if self._has_dynamic_cts(axis)]

    def friction_cts_axes(self) -> list[int]:
        """
        Returns sorted local DoF axes with Coulomb friction.
        """
        return [axis for axis in range(self.num_dofs) if self._has_friction_cts(axis)]

    def effort_cts_axes(self) -> list[int]:
        """
        Returns sorted local DoF axes with bounded implicit actuation.
        """
        return [axis for axis in range(self.num_dofs) if self._has_effort_cts(axis)]

    def dof_act_paths(self) -> list[DofActuationPath]:
        """
        Returns the inferred per-DoF actuation routing for this joint.
        """
        return [self._actuation_path(axis) for axis in range(self.num_dofs)]

    def has_base_body(self, bid: int) -> bool:
        """
        Returns whether the joint has assigned the specified body as Base.

        The body index `bid` must be given w.r.t the world.
        """
        return self.bid_B == bid

    def has_follower_body(self, bid: int) -> bool:
        """
        Returns whether the joint has assigned the specified body as Follower.

        The body index `bid` must be given w.r.t the world.
        """
        return self.bid_F == bid

    def is_connected_to_body(self, bid: int) -> bool:
        """
        Returns whether the joint is connected to the specified body.

        The body index `bid` must be given w.r.t the world.
        """
        return self.has_base_body(bid) or self.has_follower_body(bid)

    ###
    # Operations
    ###

    def __post_init__(self):
        """Post-initialization processing to validate and set up joint limits."""
        # Ensure base descriptor post-init is called first
        # NOTE: This ensures that the UID is properly set before proceeding
        super().__post_init__()

        if len(self.dof_act_types) != self.num_dofs:
            raise ValueError(f"Invalid per-DoF actuation type length: {len(self.dof_act_types)} != {self.num_dofs}")
        if not all(isinstance(act_type, JointActuationType) for act_type in self.dof_act_types):
            raise TypeError("Invalid per-DoF actuation type. Must be `JointActuationType`.")
        self.dof_act_types = list(self.dof_act_types)

        # Check if DoF type + actuation type are compatible
        if self.dof_type == JointDoFType.FREE and self.is_binary:
            raise ValueError(f"Invalid joint: FREE joints cannot be binary (name={self.name}, uid={self.uid}).")
        if self.act_type == JointActuationType.FORCE and self.dof_type == JointDoFType.FIXED:
            raise ValueError(f"Invalid joint: FIXED joints cannot be actuated (name={self.name}, uid={self.uid}).")
        # Default the follower-side joint frame to the base-side one, which
        # is the convention for joints with aligned base/follower frames.
        if self.X_Fj is None:
            self.X_Fj = wp.mat33f(self.X_Bj)

        # Set default values for joint limits if not provided
        self.q_j_min = self._check_dofs_array(self.q_j_min, self.num_dofs, float(JOINT_QMIN))
        self.q_j_max = self._check_dofs_array(self.q_j_max, self.num_dofs, float(JOINT_QMAX))
        self.dq_j_max = self._check_dofs_array(self.dq_j_max, self.num_dofs, float(JOINT_DQMAX))
        self.tau_j_max = self._check_dofs_array(self.tau_j_max, self.num_dofs, float(JOINT_TAUMAX))

        # Set default values for internal inertia, damping, and implicit PD gains if not provided
        self.a_j = self._check_dofs_array(self.a_j, self.num_dofs, 0.0)
        self.b_j = self._check_dofs_array(self.b_j, self.num_dofs, 0.0)
        self.f_j = self._check_dofs_array(self.f_j, self.num_dofs, 0.0)
        self.k_p_j = self._check_dofs_array(self.k_p_j, self.num_dofs, 0.0)
        self.k_d_j = self._check_dofs_array(self.k_d_j, self.num_dofs, 0.0)

        # Validate that the specified parameters are valid
        self._check_parameter_values()
        for axis, act_type in enumerate(self.dof_act_types):
            _validate_implicit_pd_gains(
                act_type, self.k_p_j[axis], self.k_d_j[axis], label=f"name={self.name}, uid={self.uid}, DoF={axis}"
            )

        # Check if DoF type + dynamic/implicit PD settings are compatible.
        if self.dof_type == JointDoFType.FREE and (self.num_dynamic_cts > 0 or self.num_effort_cts > 0):
            raise ValueError(
                f"Invalid joint: FREE joints cannot have dynamic or implicit PD DoFs (name={self.name}, uid={self.uid})."
            )
        # TODO: Add support for missing multi-DOF joint types in the future.
        # Ensure that only revolute and prismatic joints are dynamically constrained
        supported_implicit_joint_types = (
            JointDoFType.REVOLUTE,
            JointDoFType.PRISMATIC,
            JointDoFType.GIMBAL,
            JointDoFType.GIMBAL_LEFT_HANDED,
        )
        if (
            self.num_dynamic_cts > 0 or self.num_effort_cts > 0
        ) and self.dof_type not in supported_implicit_joint_types:
            raise ValueError(
                "Invalid joint: Kamino currently supports dynamic/implicit joints "
                f"for REVOLUTE, PRISMATIC, or GIMBAL types (name={self.name}, uid={self.uid})."
            )

    @override
    def __repr__(self):
        """Returns a human-readable string representation of the JointDescriptor."""
        return (
            f"JointDescriptor(\n"
            f"name: {self.name},\n"
            f"uid: {self.uid},\n"
            "----------------------------------------------\n"
            f"act_type: {self.act_type},\n"
            f"dof_act_types: {self.dof_act_types},\n"
            f"fk_act_flag: {self.fk_act_flag},\n"
            f"dof_type: {self.dof_type},\n"
            "----------------------------------------------\n"
            f"bid_B: {self.bid_B},\n"
            f"bid_F: {self.bid_F},\n"
            "----------------------------------------------\n"
            f"B_r_Bj: {self.B_r_Bj},\n"
            f"F_r_Fj: {self.F_r_Fj},\n"
            f"X_Bj:\n{self.X_Bj},\n"
            f"X_Fj:\n{self.X_Fj},\n"
            "----------------------------------------------\n"
            f"q_j_min: {self.q_j_min},\n"
            f"q_j_max: {self.q_j_max},\n"
            f"dq_j_max: {self.dq_j_max},\n"
            f"tau_j_max: {self.tau_j_max}\n"
            "----------------------------------------------\n"
            f"a_j: {self.a_j},\n"
            f"b_j: {self.b_j},\n"
            f"f_j: {self.f_j},\n"
            f"k_p_j: {self.k_p_j},\n"
            f"k_d_j: {self.k_d_j},\n"
            "----------------------------------------------\n"
            f"wid: {self.wid},\n"
            f"jid: {self.jid},\n"
            "----------------------------------------------\n"
            f"num_coords: {self.num_coords},\n"
            f"num_dofs: {self.num_dofs},\n"
            f"num_dynamic_cts: {self.num_dynamic_cts},\n"
            f"num_kinematic_cts: {self.num_kinematic_cts},\n"
            "----------------------------------------------\n"
            f"coords_offset: {self.coords_offset},\n"
            f"dofs_offset: {self.dofs_offset},\n"
            f"dynamic_cts_offset: {self.dynamic_cts_offset},\n"
            f"kinematic_cts_offset: {self.kinematic_cts_offset},\n"
            "----------------------------------------------\n"
            f"passive_coords_offset: {self.passive_coords_offset},\n"
            f"passive_dofs_offset: {self.passive_dofs_offset},\n"
            f"actuated_coords_offset: {self.actuated_coords_offset},\n"
            f"actuated_dofs_offset: {self.actuated_dofs_offset},\n"
            f")"
        )

    ###
    # Operations - Internal
    ###

    def _has_dynamic_cts(self, axis: int) -> bool:
        """Returns whether an axis has a dynamic constraint row."""
        return _has_dynamic_cts(
            self.dof_act_types[axis],
            self.k_p_j[axis],
            self.k_d_j[axis],
            self.tau_j_max[axis],
            self.a_j[axis],
            self.b_j[axis],
        )

    def _has_friction_cts(self, axis: int) -> bool:
        """Returns whether an axis has a Coulomb-friction constraint row."""
        return _has_friction_cts(self.dof_type, self.f_j[axis])

    def _has_effort_cts(self, axis: int) -> bool:
        """Returns whether an axis has bounded implicit-PD actuation."""
        return _has_effort_cts(self.dof_act_types[axis], self.k_p_j[axis], self.k_d_j[axis], self.tau_j_max[axis])

    def _actuation_path(self, axis: int) -> DofActuationPath:
        """Returns the actuation routing path for an axis."""
        if self._has_effort_cts(axis):
            return DofActuationPath.EFFORT_CTS
        elif self._has_dynamic_cts(axis):
            return DofActuationPath.DYNAMIC_CTS
        else:
            return DofActuationPath.BODY_WRENCHES

    @staticmethod
    def _check_dofs_array(
        x: ArrayLike | float | None,
        size: int,
        default: float = float(FLOAT32_MAX),
    ) -> list[float]:
        """
        Processes a specified limit value to ensure it is a list of floats.

        Notes:
        - If the input is None, a list of default values is returned.
        - If the input is a single float, it is converted to a list of the specified length.
        - If the input is an empty list, a list of default values is returned.
        - If the input is a non-empty list, it is validated to ensure it
            contains only floats and matches the specified length.

        Args:
            x: The DOF array to be processed.
            size: The number of degrees of freedom to determine the length of the output list.
            default: The default value to use if DOF array is None or an empty list.

        Returns:
            The processed list of DOF values.

        Raises:
            ValueError: If the length of the DOF array does not match num_dofs.
            TypeError: If the DOF array contains non-float types.
        """
        if x is None:
            return [float(default) for _ in range(size)]

        if isinstance(x, (int, float, np.floating)):
            return [x] * size

        if isinstance(x, ArrayLike):
            if len(x) == 0:
                return [float(default) for _ in range(size)]

            if len(x) != size:
                raise ValueError(f"Invalid DOF array length: {len(x)} != {size}")

            if all(isinstance(x, (float, np.floating)) for x in x):
                return x
            else:
                raise TypeError(f"Unsupported DOF array type: {type(x)!r}; expected float, iterable of floats, or None")

    def _check_parameter_values(self):
        """
        Validates the joint parameters to ensure they are consistent and within expected ranges.

        Raises:
            ValueError: If any of the joint parameters are invalid, such as:
                - q_j_min >= q_j_max for any DoF
                - dq_j_max <= 0 for any DoF
                - tau_j_max <= 0 for any DoF
                - a_j < 0 for any DoF
                - b_j < 0 for any DoF
                - k_p_j < 0 for any DoF
                - k_d_j < 0 for any DoF
        """
        for i in range(self.num_dofs):
            if self.q_j_min[i] >= self.q_j_max[i]:
                raise ValueError(
                    f"Invalid joint limits: q_j_min[{i}] >= q_j_max[{i}] (name={self.name}, uid={self.uid})."
                )
            if self.dq_j_max[i] <= 0:
                raise ValueError(
                    f"Invalid joint velocity limit: dq_j_max[{i}] <= 0 (name={self.name}, uid={self.uid})."
                )
            if self.tau_j_max[i] <= 0:
                raise ValueError(f"Invalid joint effort limit: tau_j_max[{i}] <= 0 (name={self.name}, uid={self.uid}).")
            if self.a_j[i] < 0:
                raise ValueError(f"Invalid joint armature: a_j[{i}] < 0 (name={self.name}, uid={self.uid}).")
            if self.b_j[i] < 0:
                raise ValueError(f"Invalid joint damping: b_j[{i}] < 0 (name={self.name}, uid={self.uid}).")
            if self.f_j[i] < 0:
                raise ValueError(f"Invalid joint friction: f_j[{i}] < 0 (name={self.name}, uid={self.uid}).")
            if self.k_p_j[i] < 0:
                raise ValueError(f"Invalid joint proportional gain: k_p_j[{i}] < 0 (name={self.name}, uid={self.uid}).")
            if self.k_d_j[i] < 0:
                raise ValueError(f"Invalid joint derivative gain: k_d_j[{i}] < 0 (name={self.name}, uid={self.uid}).")


@dataclass
class JointsModel:
    """
    An SoA-based container to hold time-invariant model data of joints.
    """

    ###
    # Meta-Data
    ###

    num_joints: int = 0
    """Total number of joints in the model (host-side)."""

    label: list[str] | None = None
    """
    A list containing the label of each joint entity.
    Length of ``num_joints``.
    """

    ###
    # Identifiers
    ###

    wid: wp.array[wp.int32] | None = None
    """
    Index each the world in which each joint is defined.
    Shape of ``(num_joints,)``.
    """

    jid: wp.array[wp.int32] | None = None
    """
    Index of each joint w.r.t the world.
    Shape of ``(num_joints,)``.
    """

    ###
    # Parameterization
    ###

    dof_type: wp.array[wp.int32] | None = None
    """
    Joint DoF type ID of each joint.
    Shape of ``(num_joints,)``.
    """

    act_type: wp.array[wp.int32] | None = None
    """
    Derived aggregate actuation type ID of each joint.

    Each value is the maximum actuation type across the corresponding
    :attr:`dof_act_types` slice.

    Shape of ``(num_joints,)``.
    """

    dof_act_types: wp.array[wp.int32] | None = None
    """
    Actuation type ID of each joint DoF.

    This is the authoritative per-DoF actuation representation.
    Shape of ``(sum_of_num_joint_dofs,)``.
    """

    dof_act_paths: wp.array[wp.int32] | None = None
    """
    Per-DoF actuation routing consumed by dynamics and wrench kernels.

    Each entry is a :class:`DofActuationPath` value declaring whether
    actuation for the DoF is applied through body wrenches, a dynamic row,
    or an effort row.

    Shape of ``(sum_of_num_joint_dofs,)``.
    """

    fk_act_flag: wp.array[wp.int32] | None = None
    """
    Integer flag per joint, indicating whether it should be considered actuated (1) or passive (0) by the
    Forward Kinematics solver, or to infer this from `act_type` (-1).
    Shape of ``(num_joints,)`` if set; else considered to be -1 for all joints.

    Actuating more joints in FK than in dynamics can be used, e.g., to make the FK problem well-posed for
    under-actuated systems.
    Note that all actuator types are treated equally in FK (only passive vs actuated matters).
    """

    bid_B: wp.array[wp.int32] | None = None
    """
    Base body index of each joint w.r.t the model.
    Equals `-1` for world, `>=0` for bodies.
    Shape of ``(num_joints,)``.
    """

    bid_F: wp.array[wp.int32] | None = None
    """
    Follower body index of each joint w.r.t the model.
    Equals `-1` for world, `>=0` for bodies.
    Shape of ``(num_joints,)``.
    """

    B_r_Bj: wp.array[wp.vec3f] | None = None
    """
    Relative position of the joint, expressed in and w.r.t the base body coordinate frame.
    Shape of ``(num_joints,)``.
    """

    F_r_Fj: wp.array[wp.vec3f] | None = None
    """
    Relative position of the joint, expressed in and w.r.t the follower body coordinate frame.
    Shape of ``(num_joints,)``.
    """

    X_Bj: wp.array[wp.mat33f] | None = None
    """
    Orientation of the joint frame on the base body, expressed in the base body coordinate frame.
    Shape of ``(num_joints,)``.
    """

    X_Fj: wp.array[wp.mat33f] | None = None
    """
    Orientation of the joint frame on the follower body, expressed in the follower body coordinate frame.
    Shape of ``(num_joints,)``.
    """

    ###
    # Limits
    ###

    q_j_min: wp.array[wp.float32] | None = None
    """
    Minimum (a.k.a. lower) joint DoF limits of each joint (as flat array).

    Although applying to joint coordinates, limits are dimensioned
    according to the number of DoFs of each joint, as the number of limits
    depends on the intrinsic number of DoFs, not on its (possibly redundant,
    e.g. for spherical joints) parameterization into coordinates.

    Shape of ``(sum_of_num_joint_dofs,)``.
    """

    q_j_max: wp.array[wp.float32] | None = None
    """
    Maximum (a.k.a. upper) joint DoF limits of each joint (as flat array).

    Although applying to joint coordinates, limits are dimensioned
    according to the number of DoFs of each joint, as the number of limits
    depends on the intrinsic number of DoFs, not on its (possibly redundant,
    e.g. for spherical joints) parameterization into coordinates.

    Shape of ``(sum_of_num_joint_dofs,)``.
    """

    dq_j_max: wp.array[wp.float32] | None = None
    """
    Maximum joint velocity limits of each joint (as flat array).
    Shape of ``(sum_of_num_joint_dofs,)``.
    """

    tau_j_max: wp.array[wp.float32] | None = None
    """
    Maximum joint torque limits of each joint (as flat array).
    Shape of ``(sum_of_num_joint_dofs,)``.
    """

    ###
    # Dynamics
    ###

    a_j: wp.array[wp.float32] | None = None
    """
    Internal inertia of each joint (as flat array), used for implicit integration of joint dynamics.
    Shape of ``(sum_of_num_joint_dofs,)``.
    """

    b_j: wp.array[wp.float32] | None = None
    """
    Internal damping of each joint (as flat array) used for implicit integration of joint dynamics.
    Shape of ``(sum_of_num_joint_dofs,)``.
    """

    f_j: wp.array[wp.float32] | None = None
    """
    Coulomb friction force or torque of each joint DoF [N, N·m].

    Each translational DoF uses a force [N], and each rotational DoF uses a torque [N·m].
    Shape of ``(sum_of_num_joint_dofs,)``.
    """

    k_p_j: wp.array[wp.float32] | None = None
    """
    Implicit PD-control proportional gain of each joint (as flat array).
    Shape of ``(sum_of_num_joint_dofs,)``.
    """

    k_d_j: wp.array[wp.float32] | None = None
    """
    Implicit PD-control derivative gain of each joint (as flat array).
    Shape of ``(sum_of_num_joint_dofs,)``.
    """

    ###
    # Initial State
    ###

    q_j_0: wp.array[wp.float32] | None = None
    """
    The initial coordinates of each joint (as flat array),
    indicating the "rest" or "neutral" position of each joint.

    These are used for resetting joint positions when multi-turn
    correction for revolute DoFs is enabled in the simulation.

    Shape of ``(sum_of_num_joint_coords,)``.
    """

    dq_j_0: wp.array[wp.float32] | None = None
    """
    The initial velocities of each joint (as flat array),
    indicating the "rest" or "neutral" velocity of each joint.

    These are used for resetting joint velocities when multi-turn
    correction for revolute DoFs is enabled in the simulation.

    Shape of ``(sum_of_num_joint_dofs,)``.
    """

    ###
    # Metadata
    ###

    num_coords: wp.array[wp.int32] | None = None
    """
    Number of coordinates of each joint.
    Shape of ``(num_joints,)``.
    """

    num_dofs: wp.array[wp.int32] | None = None
    """
    Number of DoFs of each joint.
    Shape of ``(num_joints,)``.
    """

    # TODO: Consider making this a wp.vec2i containing
    # both dynamic and kinematic constraint counts
    num_bilateral_cts: wp.array[wp.int32] | None = None
    """
    Number of bilateral constraints of each joint (dynamic + kinematic).
    Shape of ``(num_joints,)``.
    """

    num_dynamic_cts: wp.array[wp.int32] | None = None
    """
    Number of dynamic constraints of each joint.
    Shape of ``(num_joints,)``.
    """

    num_kinematic_cts: wp.array[wp.int32] | None = None
    """
    Number of kinematic constraints of each joint.
    Shape of ``(num_joints,)``.
    """

    num_bounded_cts: wp.array[wp.int32] | None = None
    """Number of bounded-multiplier rows of each joint."""

    num_friction_cts: wp.array[wp.int32] | None = None
    """Number of Coulomb joint friction rows of each joint."""

    num_effort_cts: wp.array[wp.int32] | None = None
    """Number of effort-limit implicit-PD rows of each joint."""

    coords_offset: wp.array[wp.int32] | None = None
    """
    Index offset of each joint's coordinates block, in model-wide
    flattened joint coordinates arrays.

    Used to index into joint-specific blocks of:
    - array of initial joint generalized coordinates :attr:`JointsModel.q_j_0`
    - array of joint generalized coordinates :attr:`JointsData.q_j`
    - array of previous joint generalized coordinates :attr:`JointsData.q_j_p`

    Shape of ``(num_joints + 1,)``.

    The last entry is the total coordinates count, so that the per-joint
    coordinates count is encoded as ``coords_offset[j+1] - coords_offset[j]``.
    """

    dofs_offset: wp.array[wp.int32] | None = None
    """
    Index offset of each joint's DoFs block, in model-wide
    flattened joint DoFs arrays.

    Used to index into joint-specific blocks of:
    - array of initial joint generalized velocities :attr:`JointsModel.dq_j_0`
    - array of joint generalized velocities :attr:`JointsData.dq_j`
    - array of joint generalized forces :attr:`JointsData.tau_j`

    Shape of ``(num_joints + 1,)``.

    The last entry is the total DoFs count, so that the per-joint
    DoFs count is encoded as ``dofs_offset[j+1] - dofs_offset[j]``.
    """

    passive_coords_offset: wp.array[wp.int32] | None = None
    """
    Index offset of each joint's passive coordinates block, in model-wide
    flattened passive joint coordinates arrays.

    Shape of ``(num_joints + 1,)``.

    The last entry is the total passive coordinates count, so that the per-joint
    passive coordinates count is encoded as ``passive_coords_offset[j+1] - passive_coords_offset[j]``.
    """

    passive_dofs_offset: wp.array[wp.int32] | None = None
    """
    Index offset of each joint's passive DoFs block, in model-wide
    flattened passive joint DoFs arrays.

    Shape of ``(num_joints + 1,)``.

    The last entry is the total passive DoFs count, so that the per-joint
    passive DoFs count is encoded as ``passive_dofs_offset[j+1] - passive_dofs_offset[j]``.
    """

    actuated_coords_offset: wp.array[wp.int32] | None = None
    """
    Index offset of each joint's actuated coordinates block, in model-wide
    flattened actuated joint coordinates arrays.

    Shape of ``(num_joints + 1,)``.

    The last entry is the total actuated coordinates count, so that the per-joint
    actuated coordinates count is encoded as ``actuated_coords_offset[j+1] - actuated_coords_offset[j]``.
    """

    actuated_dofs_offset: wp.array[wp.int32] | None = None
    """
    Index offset of each joint's actuated DoFs block, in model-wide
    flattened actuated joint DoFs arrays.

    Shape of ``(num_joints + 1,)``.

    The last entry is the total actuated DoFs count, so that the per-joint
    actuated DoFs count is encoded as ``actuated_dofs_offset[j+1] - actuated_dofs_offset[j]``.
    """

    bilateral_cts_offset: wp.array[wp.int32] | None = None
    """
    Index offset of each joint's bilateral constraints block, in model-wide
    flattened joint constraints arrays (dynamic + kinematic).

    Shape of ``(num_joints + 1,)``.

    The last entry is the total joint constraints count, so that the per-joint
    constraints count is encoded as ``bilateral_cts_offset[j+1] - bilateral_cts_offset[j]``.
    """

    dynamic_cts_offset: wp.array[wp.int32] | None = None
    """
    Index offset of each joint's dynamic constraints block, in model-wide
    flattened joint dynamic constraints arrays.

    Used to index into joint-specific blocks of:
    - array of effective joint-space inertia :attr:`JointsData.m_j`
    - array of joint-space damping :attr:`JointsData.b_j`
    - array of joint-space P gains :attr:`JointsData.k_p_j`
    - array of joint-space D gains :attr:`JointsData.k_d_j`

    Shape of ``(num_joints + 1,)``.

    The last entry is the total joint dynamic constraints count, so that the per-joint
    dynamic constraints count is encoded as ``dynamic_cts_offset[j+1] - dynamic_cts_offset[j]``.
    """

    kinematic_cts_offset: wp.array[wp.int32] | None = None
    """
    Index offset of each joint's kinematic constraints block, in model-wide
    flattened joint kinematic constraints arrays.

    Used to index into joint-specific blocks of:
    - array of joint constraint residuals :attr:`JointsData.r_j`
    - array of joint constraint residual time-derivatives :attr:`JointsData.dr_j`

    Shape of ``(num_joints + 1,)``.

    The last entry is the total joint kinematic constraints count, so that the per-joint
    kinematic constraints count is encoded as ``kinematic_cts_offset[j+1] - kinematic_cts_offset[j]``.
    """

    bounded_cts_offset: wp.array[wp.int32] | None = None
    """
    Index offset of each joint's bounded-multiplier constraints block, in model-wide
    flattened joint bounded constraints arrays.

    Shape of ``(num_joints + 1,)``.

    The last entry is the total joint bounded-multiplier constraints count, so that the per-joint
    bounded constraints count is encoded as ``bounded_cts_offset[j+1] - bounded_cts_offset[j]``.
    """

    friction_cts_offset: wp.array[wp.int32] | None = None
    """
    Index offset of each joint's friction constraints block, in model-wide
    flattened Coulomb joint friction constraints arrays.

    Shape of ``(num_joints + 1,)``.

    The last entry is the total joint friction constraints count, so that the per-joint
    friction constraints count is encoded as ``friction_cts_offset[j+1] - friction_cts_offset[j]``.
    """

    effort_cts_offset: wp.array[wp.int32] | None = None
    """
    Index offset of each joint's effort-limit implicit-PD constraints block, in model-wide
    flattened joint effort constraints arrays.

    Shape of ``(num_joints + 1,)``.

    The last entry is the total joint effort constraints count, so that the per-joint
    effort constraints count is encoded as ``effort_cts_offset[j+1] - effort_cts_offset[j]``.
    """

    dynamic_cts_axis: wp.array[wp.int32] | None = None
    """
    Joint-local DoF axis of each dynamic constraint row, in model-wide
    flattened joint dynamic constraints arrays.

    Shape of ``(sum_of_num_dynamic_joint_cts,)``.
    """

    friction_cts_axis: wp.array[wp.int32] | None = None
    """
    Joint-local DoF axis of each Coulomb-friction constraint row, in model-wide
    flattened joint Coulomb-friction constraints arrays.

    Shape of ``(sum_of_num_friction_cts,)``.
    """

    effort_cts_axis: wp.array[wp.int32] | None = None
    """
    Joint-local DoF axis of each effort-limit implicit-PD row, in model-wide
    flattened joint effort constraints arrays.

    Shape of ``(sum_of_num_effort_cts,)``.
    """

    dynamic_cts_offset_total_cts: wp.array[wp.int32] | None = None
    """
    Index offset of each joint's dynamic constraints block, in model-wide
    flattened total constraints arrays (joints + bounded + limits + contacts).

    Shape of ``(num_joints,)``.
    """

    kinematic_cts_offset_total_cts: wp.array[wp.int32] | None = None
    """
    Index offset of each joint's kinematic constraints block, in model-wide
    flattened total constraints arrays (joints + bounded + limits + contacts).

    Shape of ``(num_joints,)``.
    """

    friction_cts_offset_total_cts: wp.array[wp.int32] | None = None
    """
    Index offset of each joint's friction constraints block, in model-wide
    flattened total constraints arrays (joints + bounded + limits + contacts).

    Shape of ``(num_joints,)``.
    """

    effort_cts_offset_total_cts: wp.array[wp.int32] | None = None
    """
    Index offset of each joint's effort constraints block, in model-wide
    flattened total constraints arrays (joints + bounded + limits + contacts).

    Shape of ``(num_joints,)``.
    """


@dataclass
class JointsData:
    """
    An SoA-based container to hold time-varying data of a joint system.
    """

    num_joints: int = 0
    """Total number of joints in the model (host-side)."""

    ###
    # State
    ###

    p_j: wp.array[wp.transformf] | None = None
    """
    Array of joint frame pose transforms in world coordinates.
    Shape of ``(num_joints,)``.
    """

    q_j: wp.array[wp.float32] | None = None
    """
    Flat array of generalized coordinates of the joints.
    Shape of ``(sum_of_num_joint_coords,)``.
    """

    q_j_p: wp.array[wp.float32] | None = None
    """
    Flat array of previous generalized coordinates of the joints.
    Shape of ``(sum_of_num_joint_coords,)``.
    """

    dq_j: wp.array[wp.float32] | None = None
    """
    Flat array of generalized velocities of the joints.
    Shape of ``(sum_of_num_joint_dofs,)``.
    """

    tau_j: wp.array[wp.float32] | None = None
    """
    Flat array of generalized forces of the joints.
    Shape of ``(sum_of_num_joint_dofs,)``.
    """

    ###
    # Constraints
    ###

    r_j: wp.array[wp.float32] | None = None
    """
    Flat array of joint kinematic constraint residuals.

    To access the constraint residuals of a specific world `w` use:
    - to get the start index: ``model.info.joint_kinematic_cts_offset[w]``
    - to get the size: ``model.info.num_joint_kinematic_cts[w]``

    Shape of ``(sum_of_num_kinematic_joint_cts,)``.
    """

    dr_j: wp.array[wp.float32] | None = None
    """
    Flat array of joint kinematic constraint residual time-derivatives.

    To access the constraint residuals of a specific world `w` use:
    - to get the start index: ``model.info.joint_kinematic_cts_offset[w]``
    - to get the size: ``model.info.num_joint_kinematic_cts[w]``

    Shape of ``(sum_of_num_kinematic_joint_cts,)``.
    """

    lambda_kin_j: wp.array[wp.float32] | None = None
    """
    Flat array of joint kinematic constraint Lagrange multipliers.

    To access the constraint multipliers of a specific world ``w`` use:
    - to get the start index: ``model.info.joint_kinematic_cts_offset[w]``
    - to get the size: ``model.info.num_joint_kinematic_cts[w]``

    To access the multipliers of a specific joint ``j`` use ``model.joints.kinematic_cts_offset[j]``
    as the start index. The per-joint row count is
    ``model.joints.kinematic_cts_offset[j + 1] - model.joints.kinematic_cts_offset[j]``.

    Shape of ``(sum_of_num_kinematic_joint_cts,)``.
    """

    lambda_dyn_j: wp.array[wp.float32] | None = None
    """
    Flat array of joint dynamic constraint Lagrange multipliers.

    To access the constraint multipliers of a specific world ``w`` use:
    - to get the start index: ``model.info.joint_dynamic_cts_offset[w]``
    - to get the size: ``model.info.num_joint_dynamic_cts[w]``

    To access the multipliers of a specific joint ``j`` use ``model.joints.dynamic_cts_offset[j]``
    as the start index. The per-joint row count is
    ``model.joints.dynamic_cts_offset[j + 1] - model.joints.dynamic_cts_offset[j]``.

    Shape of ``(sum_of_num_dynamic_joint_cts,)``.
    """

    lambda_f_j: wp.array[wp.float32] | None = None
    """
    Flat array of Coulomb joint friction Lagrange multipliers.

    To access the multipliers of a specific joint ``j`` use ``model.joints.friction_cts_offset[j]``
    as the start index. The per-joint row count is
    ``model.joints.friction_cts_offset[j + 1] - model.joints.friction_cts_offset[j]``.

    Shape of ``(sum_of_num_friction_cts,)``.
    """

    lambda_tau_j: wp.array[wp.float32] | None = None
    """
    Flat array of effort-limit implicit-PD Lagrange multipliers [N or N·m].

    To access the multipliers of a specific joint ``j`` use ``model.joints.effort_cts_offset[j]``
    as the start index. The per-joint row count is
    ``model.joints.effort_cts_offset[j + 1] - model.joints.effort_cts_offset[j]``.

    Shape of ``(sum_of_num_effort_cts,)``.
    """

    ###
    # Dynamics
    ###

    m_j: wp.array[wp.float32] | None = None
    """
    Internal effective inertia of each joint (as flat array),
    used for implicit integration of joint dynamics.

    Let ``m_j_0 := a_j + dt * b_j``, where ``dt`` is the simulation time step.
    Unbounded implicit PD is included with passive armature and damping in the
    joint dynamics constraint. The actuation type determines the remaining terms:

    - ``PASSIVE`` or ``FORCE``: ``m_j := m_j_0``
    - ``VELOCITY``: ``m_j := m_j_0 + dt * k_d_j``
    - ``POSITION``, ``POSITION_VELOCITY``, or ``POSITION_VELOCITY_FORCE``:
      ``m_j := m_j_0 + dt * k_d_j + dt^2 * k_p_j``

    Joint dynamics sharing an axis with an effort-limit implicit-PD constraint are passive and
    use ``m_j := m_j_0``.

    A non-zero minimum mass is enforced to avoid a
    division-by-zero failure.

    Shape of ``(sum_of_num_dynamic_joint_cts,)``.
    """

    inv_m_j: wp.array[wp.float32] | None = None
    """
    Internal effective inverse inertia of each joint (as flat
    array), used for implicit integration of joint dynamics.

    ``inv_m_j := 1 / m_j``, computed element-wise.

    Note that all ``inv_m_j>0`` due to a minimum non-zero mass
    being enforced.

    Shape of ``(sum_of_num_dynamic_joint_cts,)``.
    """

    dq_b_j: wp.array[wp.float32] | None = None
    """
    The velocity bias of the joint dynamic constraints (as flat array).

    Each joint has local actuation and PD control dynamics:
    ```
    m_j * dq_j^{+} = h_j
    ```
    and is contributes to the dynamics of the system through the constraint equation:
    ```
    dq_j^{+} = J_q_j * u^{+}
    ```

    where ``dq_j^{-}`` and ``dq_j^{+}`` are the pre- and post-event joint-space
    velocities, and ``u^{+}`` are the post-event generalized velocities of the
    system computed implicitly as a result of solving the forward dynamics problem
    with the joint dynamic constraints. `J_q_j` is the block of the joint-space
    projection Jacobian matrix corresponding to the rows of DoFs of joint `j`.

    This results in the following dynamic constraint equation for each joint `j`:
    ```
    dq_j^{+} + m_j^{-1} * lambda_q_j = m_j^{-1} * h_j
    dq_j^{+} + m_j^{-1} * lambda_q_j = dq_b_j
    J_q_j * u^{+} + m_j^{-1} * lambda_q_j = dq_b_j
    ```
    and thus the velocity bias term of the joint-space dynamics of each joint `j` is computed as:
    ```
    h_j := a_j * dq_j^{-} + dt * tau_j_tot
    dq_b_j := inv_m_j * h_j
    ```
    For unbounded implicit PD, the joint dynamics constraint includes
    ``tau_j_tot`` according to the actuation type:

    - ``PASSIVE``: ``tau_j``
    - ``FORCE``: ``tau_j + tau_j_ff``
    - ``POSITION``: ``tau_j + k_p_j * (q_j_ref - q_j^{-})``
    - ``VELOCITY``: ``tau_j + k_d_j * dq_j_ref``
    - ``POSITION_VELOCITY``:
      ``tau_j + k_p_j * (q_j_ref - q_j^{-}) + k_d_j * dq_j_ref``
    - ``POSITION_VELOCITY_FORCE``:
      ``tau_j + tau_j_ff + k_p_j * (q_j_ref - q_j^{-}) + k_d_j * dq_j_ref``

    For bounded implicit PD, the effort-limit constraint supplies the actuator
    contribution and ``tau_j_tot := 0`` in the passive joint dynamics constraint.

    For ``POSITION``, the ``dt * k_d_j`` term in :attr:`m_j` supplies derivative
    damping toward zero velocity without consuming ``dq_j_ref``.

    Shape of ``(sum_of_num_dynamic_joint_cts,)``.
    """

    inv_m_a: wp.array[wp.float32] | None = None
    """
    Inverse effective actuator inertia of each effort-limit implicit-PD row
    [1/(N·s), 1/(N·m·s)].

    ``inv_m_a := 1 / m_a`` with ``m_a = dt * k_d_j`` for
    ``VELOCITY`` actuation and ``m_a = dt * k_d_j + dt^2 * k_p_j``
    otherwise. A non-zero minimum ``m_a`` is enforced to avoid
    division by zero.

    Shape of ``(sum_of_num_effort_cts,)``.
    """

    dq_b_a: wp.array[wp.float32] | None = None
    """
    Velocity bias of each effort-limit implicit-PD row [m/s, rad/s].

    ``dq_b_a := inv_m_a * dt * tau_j_tot``, where ``tau_j_tot`` includes
    ``tau_j``, the feed-forward command when selected, and the position and
    velocity reference terms for the DoF actuation type.

    Shape of ``(sum_of_num_effort_cts,)``.
    """

    bound_a: wp.array[wp.float32] | None = None
    """
    Impulse bound of each effort-limit implicit-PD row [N·s, N·m·s].

    ``bound_a := dt * tau_j_max``. Effort rows are allocated only when the
    DoF participates in implicit PD with a finite ``tau_j_max``.

    Shape of ``(sum_of_num_effort_cts,)``.
    """

    ###
    # Reference State
    ###

    q_j_ref: wp.array[wp.float32] | None = None
    """
    Array of reference generalized joint coordinates for implicit PD control.
    Shape of ``(sum_of_num_joint_coords,)``.
    """

    dq_j_ref: wp.array[wp.float32] | None = None
    """
    Array of reference generalized joint velocities for implicit PD control.
    Shape of ``(sum_of_num_joint_dofs,)``.
    """

    tau_j_ref: wp.array[wp.float32] | None = None
    """
    Array of reference feed-forward generalized joint forces for implicit PD control.
    Shape of ``(sum_of_num_joint_dofs,)``.
    """

    ###
    # Per-Body Wrenches
    ###

    j_w_j: wp.array[wp.spatial_vectorf] | None = None
    """
    Total wrench applied by each joint, expressed
    in and about the corresponding joint frame.
    Its direction follows the convention that
    joints act on the follower by the base body.
    This is the sum of :attr:`j_w_a_j`, :attr:`j_w_c_j`,
    :attr:`j_w_f_j`, and :attr:`j_w_l_j`.
    Shape of ``(num_joints,)``.
    """

    j_w_a_j: wp.array[wp.spatial_vectorf] | None = None
    """
    Actuation wrench applied by each joint, expressed
    in and about the corresponding joint frame.
    Its direction is defined by the convention that positive wrenches
    in the joint frame are those inducing a positive change in the
    twist of the follower body relative to the base body.
    Shape of ``(num_joints,)``.
    """

    j_w_c_j: wp.array[wp.spatial_vectorf] | None = None
    """
    Bilateral constraint wrench applied by each joint, expressed
    in and about the corresponding joint frame.
    This includes the dynamic and kinematic constraint reactions only.
    Its direction is defined by the convention that positive wrenches
    in the joint frame are those inducing a positive change in the
    twist of the follower body relative to the base body.
    Shape of ``(num_joints,)``.
    """

    j_w_f_j: wp.array[wp.spatial_vectorf] | None = None
    """
    Joint friction wrench applied by each joint, expressed
    in and about the corresponding joint frame.
    Its direction is defined by the convention that positive wrenches
    in the joint frame are those inducing a positive change in the
    twist of the follower body relative to the base body.
    Shape of ``(num_joints,)``.
    """

    j_w_l_j: wp.array[wp.spatial_vectorf] | None = None
    """
    Joint-limit wrench applied by each joint, expressed
    in and about the corresponding joint frame.
    Its direction is defined by the convention that positive wrenches
    in the joint frame are those inducing a positive change in the
    twist of the follower body relative to the base body.
    Shape of ``(num_joints,)``.
    """

    ###
    # Operations
    ###

    def reset_state(self, q_j_0: wp.array[wp.float32] | None = None):
        """
        Resets all generalized joint coordinates to either zero or the provided
        reference coordinates and all generalized joint velocities to zero.
        """
        if q_j_0 is not None:
            if q_j_0.size != self.q_j.size:
                raise ValueError(f"Invalid size of q_j_0: {q_j_0.size}. Expected: {self.q_j.size}.")
            wp.copy(self.q_j, q_j_0)
            wp.copy(self.q_j_p, q_j_0)
        else:
            self.q_j.zero_()
            self.q_j_p.zero_()
        self.dq_j.zero_()
        self.lambda_f_j.zero_()
        self.lambda_tau_j.zero_()

    def reset_references(
        self,
        q_j_ref: wp.array[wp.float32] | None = None,
        dq_j_ref: wp.array[wp.float32] | None = None,
        joints: JointsModel | None = None,
    ):
        """
        Resets all reference coordinates and velocities to either the provided reference values,
        or the initial values stored in the model.

        Args:
            q_j_ref: New reference joint coordinates to set.
            dq_j_ref: New reference joint velocities to set.
            joints: Joints model, to read initial joint coords/velocities to use as reference if not provided.
        """
        if q_j_ref is None and joints is None:
            raise ValueError("Either q_j_ref or joints must be provided to reset reference coordinates.")
        if dq_j_ref is None and joints is None:
            raise ValueError("Either dq_j_ref or joints must be provided to reset reference velocities.")

        if q_j_ref is not None:
            if q_j_ref.size != self.q_j_ref.size:
                raise ValueError(f"Invalid size of q_j_ref: {q_j_ref.size}. Expected: {self.q_j_ref.size}.")
            wp.copy(self.q_j_ref, q_j_ref)
        else:
            wp.copy(self.q_j_ref, joints.q_j_0)

        if dq_j_ref is not None:
            if dq_j_ref.size != self.dq_j_ref.size:
                raise ValueError(f"Invalid size of dq_j_ref: {dq_j_ref.size}. Expected: {self.dq_j_ref.size}.")
            wp.copy(self.dq_j_ref, dq_j_ref)
        else:
            wp.copy(self.dq_j_ref, joints.dq_j_0)

    def clear_residuals(self):
        """
        Resets all joint state variables to zero.
        """
        self.r_j.zero_()
        self.dr_j.zero_()

    def clear_constraint_reactions(self):
        """
        Resets all joint constraint reactions to zero.
        """
        self.lambda_kin_j.zero_()
        self.lambda_dyn_j.zero_()
        self.lambda_f_j.zero_()
        self.lambda_tau_j.zero_()

    def clear_actuation_forces(self):
        """
        Resets all joint actuation forces to zero.
        """
        self.tau_j.zero_()

    def clear_wrenches(self):
        """
        Resets all joint wrenches to zero.
        """
        if self.j_w_j is not None:
            self.j_w_j.zero_()
            self.j_w_c_j.zero_()
            self.j_w_f_j.zero_()
            self.j_w_a_j.zero_()
            self.j_w_l_j.zero_()

    def clear_all(self):
        """
        Resets all joint state variables, constraint reactions,
        actuation forces, and wrenches to zero.
        """
        self.clear_residuals()
        self.clear_constraint_reactions()
        self.clear_actuation_forces()
        self.clear_wrenches()

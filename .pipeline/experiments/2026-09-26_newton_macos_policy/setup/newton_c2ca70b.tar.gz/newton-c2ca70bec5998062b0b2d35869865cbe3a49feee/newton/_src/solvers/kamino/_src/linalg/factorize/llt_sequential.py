# SPDX-FileCopyrightText: Copyright (c) 2025 The Newton Developers
# SPDX-License-Identifier: Apache-2.0

"""KAMINO: Linear Algebra: Sequential LLT (i.e. Cholesky) factorization w/o intra-parallelism"""

from __future__ import annotations

import warp as wp

from ...core.math import FLOAT32_EPS

###
# Module interface
###

__all__ = [
    "llt_sequential_factorize",
    "llt_sequential_solve",
    "llt_sequential_solve_inplace",
]


###
# Module configs
###

wp.set_module_options({"enable_backward": False, "default_grid_stride": False})


###
# Kernels
###


@wp.kernel
def _llt_sequential_factorize(
    # Inputs:
    dim_in: wp.array[wp.int32],
    mio_in: wp.array[wp.int32],
    A_in: wp.array[wp.float32],
    # Outputs:
    L_out: wp.array[wp.float32],
):
    # Retrieve the thread index
    tid = wp.tid()

    # Retrieve the matrix start offset and dimension
    mio = mio_in[tid]
    n = dim_in[tid]

    # Compute the Cholesky factorization sequentially
    for i in range(n):
        m_i = mio + n * i
        m_ii = m_i + i
        A_ii = A_in[m_ii]
        for j in range(i + 1):
            m_j = mio + n * j
            m_jj = m_j + j
            m_ij = m_i + j
            A_ij = A_in[m_ij]
            L_jj = L_out[m_jj]
            sum = wp.float32(0.0)
            for k in range(j):
                m_ik = m_i + k
                m_jk = m_j + k
                sum += L_out[m_ik] * L_out[m_jk]
            if i == j:
                L_out[m_ij] = wp.sqrt(wp.max(A_ii - sum, FLOAT32_EPS))
            else:
                L_out[m_ij] = (A_ij - sum) / L_jj


@wp.kernel
def _llt_sequential_solve(
    # Inputs:
    dim_in: wp.array[wp.int32],
    mio_in: wp.array[wp.int32],
    vio_in: wp.array[wp.int32],
    L_in: wp.array[wp.float32],
    b_in: wp.array[wp.float32],
    # Outputs:
    y_out: wp.array[wp.float32],
    x_out: wp.array[wp.float32],
):
    # Retrieve the thread index
    tid = wp.tid()

    # Retrieve the start offsets and problem dimension
    mio = mio_in[tid]
    vio = vio_in[tid]
    n = dim_in[tid]

    # Forward substitution to solve L * y = b
    for i in range(n):
        m_i = mio + n * i
        m_ii = m_i + i
        L_ii = L_in[m_ii]
        sum_i = b_in[vio + i]
        for j in range(i):
            m_ij = m_i + j
            sum_i -= L_in[m_ij] * y_out[vio + j]
        y_out[vio + i] = sum_i / L_ii

    # Backward substitution to solve L^T * x = y
    for i in range(n - 1, -1, -1):
        m_i = mio + n * i
        m_ii = m_i + i
        LT_ii = L_in[m_ii]
        sum_i = y_out[vio + i]
        for j in range(i + 1, n):
            m_ji = mio + n * j + i
            sum_i -= L_in[m_ji] * x_out[vio + j]
        x_out[vio + i] = sum_i / LT_ii


@wp.kernel
def _llt_sequential_solve_inplace(
    # Inputs:
    dim_in: wp.array[wp.int32],
    mio_in: wp.array[wp.int32],
    vio_in: wp.array[wp.int32],
    L_in: wp.array[wp.float32],
    x_inout: wp.array[wp.float32],
):
    # Retrieve the thread index
    tid = wp.tid()

    # Retrieve the start offsets and problem dimension
    mio = mio_in[tid]
    vio = vio_in[tid]
    n = dim_in[tid]

    # Forward substitution to solve L * y = b
    for i in range(n):
        m_i = mio + n * i
        m_ii = m_i + i
        L_ii = L_in[m_ii]
        sum_i = x_inout[vio + i]
        for j in range(i):
            m_ij = m_i + j
            sum_i -= L_in[m_ij] * x_inout[vio + j]
        x_inout[vio + i] = sum_i / L_ii

    # Backward substitution to solve L^T * x = y
    for i in range(n - 1, -1, -1):
        m_i = mio + n * i
        m_ii = m_i + i
        LT_ii = L_in[m_ii]
        sum_i = x_inout[vio + i]
        for j in range(i + 1, n):
            m_ji = mio + n * j + i
            sum_i -= L_in[m_ji] * x_inout[vio + j]
        x_inout[vio + i] = sum_i / LT_ii


###
# Launchers
###


def llt_sequential_factorize(
    num_blocks: int,
    dim: wp.array[wp.int32],
    mio: wp.array[wp.int32],
    A: wp.array[wp.float32],
    L: wp.array[wp.float32],
):
    """
    Launches the sequential Cholesky factorization kernel for a block partitioned matrix.

    Args:
        num_blocks: The number of matrix blocks to process.
        dim: An array of shape `(num_blocks,)` containing the dimensions of each matrix block.
        mio: An array of shape `(num_blocks,)` containing the start indices of each matrix block.
        A: The flat input array containing the input matrix blocks to be factorized.
        L: The flat output array containing the Cholesky factorization of each matrix block.
    """
    wp.launch(
        kernel=_llt_sequential_factorize,
        dim=num_blocks,
        inputs=[dim, mio, A, L],
        device=A.device,
    )


def llt_sequential_solve(
    num_blocks: int,
    dim: wp.array[wp.int32],
    mio: wp.array[wp.int32],
    vio: wp.array[wp.int32],
    L: wp.array[wp.float32],
    b: wp.array[wp.float32],
    y: wp.array[wp.float32],
    x: wp.array[wp.float32],
):
    """
    Launches the sequential solve kernel using the Cholesky factorization of a block partitioned matrix.

    Args:
        num_blocks: The number of matrix blocks to process.
        dim: An array of shape `(num_blocks,)` containing the dimensions of each matrix block.
        mio: An array of shape `(num_blocks,)` containing the start indices of each matrix block.
        vio: An array of shape `(num_blocks,)` containing the start indices of each vector block.
        L: The flat input array containing the Cholesky factorization of each matrix block.
        b: The flat input array containing the stacked right-hand side vectors.
        y: The output array where the intermediate result will be stored.
        x: The output array where the solution to the linear system `A @ x = b` will be stored.
    """
    wp.launch(
        kernel=_llt_sequential_solve,
        dim=num_blocks,
        inputs=[dim, mio, vio, L, b, y, x],
        device=L.device,
    )


def llt_sequential_solve_inplace(
    num_blocks: int,
    dim: wp.array[wp.int32],
    mio: wp.array[wp.int32],
    vio: wp.array[wp.int32],
    L: wp.array[wp.float32],
    x: wp.array[wp.float32],
):
    """
    Launches the sequential in-place solve kernel using the Cholesky factorization of a block partitioned matrix.

    Args:
        num_blocks: The number of matrix blocks to process.
        dim: An array of shape `(num_blocks,)` containing the dimensions of each matrix block.
        mio: An array of shape `(num_blocks,)` containing the start indices of each matrix block.
        vio: An array of shape `(num_blocks,)` containing the start indices of each vector block.
        L: The flat input array containing the Cholesky factorization of each matrix block.
        x: The array where the solution to the linear system `A @ x = b` will be stored in-place.
    """
    wp.launch(
        kernel=_llt_sequential_solve_inplace,
        dim=num_blocks,
        inputs=[dim, mio, vio, L, x],
        device=L.device,
    )

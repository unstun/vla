# SPDX-FileCopyrightText: Copyright (c) 2025 The Newton Developers
# SPDX-License-Identifier: Apache-2.0

from __future__ import annotations

import warnings
from collections.abc import Sequence
from typing import Any, Literal

import numpy as np
import warp as wp

from ..sim.builder import ModelBuilder
from ..sim.enums import JointType


def clamp_imported_opacity(value: float, source: str) -> float | None:
    """Clamp display-only importer data without failing the model import."""
    opacity = float(value)
    if not np.isfinite(opacity):
        warnings.warn(f"Ignoring non-finite opacity {opacity!r} from {source}.", stacklevel=2)
        return None
    clamped_opacity = float(np.clip(opacity, 0.0, 1.0))
    if clamped_opacity != opacity:
        warnings.warn(
            f"Clamping opacity {opacity!r} from {source} to {clamped_opacity!r}.",
            stacklevel=2,
        )
    return clamped_opacity


def string_to_warp(value: str, warp_dtype: Any, default: Any = None) -> Any:
    """
    Parse a Warp value from a string. This is useful for parsing values from XML files.
    For example, "1.0 2.0 3.0" will be parsed as wp.vec3(1.0, 2.0, 3.0).

    If fewer values are provided than expected for vector/matrix types, the remaining
    values will be filled from the default value if provided.

    Raises:
        ValueError: If the dtype is invalid.

    Args:
        value: The string value to parse.
        warp_dtype: The Warp dtype to parse the value as.
        default: Optional default value to use for padding incomplete vectors/matrices.

    Returns:
        The parsed Warp value.
    """

    def get_vector(scalar_type: Any):
        return [scalar_type(x) for x in value.split()]

    def get_bool(tok: str) -> bool:
        # just casting string to bool is not enough, we need to actually evaluate the
        # falsey values
        s = tok.strip().lower()
        if s in {"1", "true", "t", "yes", "y"}:
            return True
        if s in {"0", "false", "f", "no", "n"}:
            return False
        # fall back to numeric interpretation if provided
        try:
            return bool(int(float(s)))
        except Exception as e:
            raise ValueError(f"Unable to parse boolean value: {tok}") from e

    if wp.types.type_is_quaternion(warp_dtype):
        parsed_values = get_vector(float)
        # Pad with default values if necessary
        expected_length = 4  # Quaternions always have 4 components
        if len(parsed_values) < expected_length and default is not None:
            if hasattr(default, "__len__"):
                default_values = [default[i] for i in range(len(default))]
            else:
                default_values = [default] * expected_length
            parsed_values.extend(default_values[len(parsed_values) : expected_length])
        return warp_dtype(*parsed_values)
    if wp.types.type_is_int(warp_dtype):
        return warp_dtype(int(value))
    if wp.types.type_is_float(warp_dtype):
        return warp_dtype(float(value))
    if warp_dtype is wp.bool or warp_dtype is bool:
        return warp_dtype(get_bool(value))
    if warp_dtype is str:
        return value  # String values are used as-is
    if wp.types.type_is_vector(warp_dtype) or wp.types.type_is_matrix(warp_dtype):
        scalar_type = warp_dtype._wp_scalar_type_
        parsed_values = None
        if wp.types.type_is_int(scalar_type):
            parsed_values = get_vector(int)
        elif wp.types.type_is_float(scalar_type):
            parsed_values = get_vector(float)
        elif scalar_type is wp.bool or scalar_type is bool:
            parsed_values = get_vector(bool)
        else:
            raise ValueError(f"Unable to parse vector/matrix value: {value} as {warp_dtype}.")

        # Pad with default values if necessary
        expected_length = warp_dtype._length_
        if len(parsed_values) < expected_length and default is not None:
            # Extract default values and pad
            if hasattr(default, "__len__"):
                default_values = [default[i] for i in range(len(default))]
            else:
                default_values = [default] * expected_length
            parsed_values.extend(default_values[len(parsed_values) : expected_length])

        return warp_dtype(*parsed_values)
    raise ValueError(f"Invalid dtype: {warp_dtype}. Must be a valid Warp dtype or str.")


def parse_custom_attributes(
    dictlike: dict[str, str],
    custom_attributes: Sequence[ModelBuilder.CustomAttribute],
    parsing_mode: Literal["usd", "mjcf", "urdf"],
    context: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """
    Parse custom attributes from a dictionary.

    Args:
        dictlike: The dictionary (or XML element) to parse the custom attributes from. This object behaves like a string-valued dictionary that implements the ``get`` method and returns the value for the given key.
        custom_attributes: The custom attributes to parse. This is a sequence of :class:`ModelBuilder.CustomAttribute` objects.
        parsing_mode: The parsing mode to use. This can be "usd", "mjcf", or "urdf". It determines which attribute name and value transformer to use.
        context: Optional context dictionary passed to the value transformer. Can contain parsing-time information such as ``use_degrees`` or ``joint_type``.

    Returns:
        A dictionary of the parsed custom attributes. The keys are the custom attribute keys :attr:`ModelBuilder.CustomAttribute.key`
        and the values are the parsed values. Only attributes that were explicitly specified in the source are included
        in the output dict. Unspecified attributes are not included, allowing defaults to be filled in during model finalization.
    """
    out = {}
    for attr in custom_attributes:
        transformer = None
        name = None
        if parsing_mode == "mjcf":
            name = attr.mjcf_attribute_name
            transformer = attr.mjcf_value_transformer
        elif parsing_mode == "urdf":
            name = attr.urdf_attribute_name
            transformer = attr.urdf_value_transformer
        elif parsing_mode == "usd":
            name = attr.usd_attribute_name
            transformer = attr.usd_value_transformer
        if transformer is None:

            def transform(
                x: str, _context: dict[str, Any] | None, dtype: Any = attr.dtype, default: Any = attr.default
            ) -> Any:
                return string_to_warp(x, dtype, default)

            transformer = transform

        if name is None:
            name = attr.name
        dict_value = dictlike.get(name)
        if dict_value is not None:
            value = transformer(dict_value, context)
            if value is None:
                # Treat None as "undefined" so defaults are applied later.
                continue
            out[attr.key] = value
    return out


def sanitize_xml_content(source: str) -> str:
    # Strip leading whitespace and byte-order marks
    xml_content = source.strip()
    # Remove BOM if present
    if xml_content.startswith("\ufeff"):
        xml_content = xml_content[1:]
    # Remove leading XML comments
    while xml_content.strip().startswith("<!--"):
        end_comment = xml_content.find("-->")
        if end_comment != -1:
            xml_content = xml_content[end_comment + 3 :].strip()
        else:
            break
    xml_content = xml_content.strip()
    return xml_content


def sanitize_name(name: str) -> str:
    """Sanitize a name for use as a key in the ModelBuilder.

    Replaces characters that are invalid in USD paths (e.g., "-") with underscores.

    Args:
        name: The name string to sanitize.

    Returns:
        The sanitized name with invalid characters replaced by underscores.
    """
    return name.replace("-", "_")


def should_show_collider(
    force_show_colliders: bool,
    model_has_visual_shapes: bool,
    parse_visuals_as_colliders: bool = False,
) -> bool:
    """Determine whether collision shapes should have the VISIBLE flag.

    Collision shapes are shown (VISIBLE flag) when explicitly forced, when
    visual shapes are used as colliders, or when the imported model has no
    visual shapes. Otherwise, collision shapes get only COLLIDE_SHAPES and are
    controlled by the viewer's "Show Collision" toggle.

    Args:
        force_show_colliders: User explicitly wants collision shapes visible.
        model_has_visual_shapes: Whether the current import has visual (non-collision) shapes.
        parse_visuals_as_colliders: Whether visual geometry is repurposed as collision geometry.

    Returns:
        True if the collision shape should carry the VISIBLE flag; False if it should
        be hidden by default and only revealed via the viewer's "Show Collision" toggle.
    """
    return force_show_colliders or parse_visuals_as_colliders or not model_has_visual_shapes


def collapse_massless_fixed_root_joints(
    builder: ModelBuilder,
    joint_indices: Sequence[int],
    root_joint_indices: Sequence[int] | None = None,
) -> None:
    """Collapse massless fixed-root chains below imported free root joints.

    Args:
        builder: The :class:`ModelBuilder` containing the imported joints.
        joint_indices: Joint indices created by the current import.
        root_joint_indices: Optional subset of ``joint_indices`` that should be
            considered articulation roots.
    """
    imported_joint_indices = set(joint_indices)
    if root_joint_indices is None:
        root_joint_indices = [
            joint_idx
            for joint_idx in joint_indices
            if builder.joint_type[joint_idx] == JointType.FREE and builder.joint_parent[joint_idx] == -1
        ]

    fixed_joint_indices_to_collapse: set[int] = set()
    for root_joint_idx in root_joint_indices:
        if root_joint_idx not in imported_joint_indices:
            continue
        if builder.joint_type[root_joint_idx] != JointType.FREE or builder.joint_parent[root_joint_idx] != -1:
            continue

        root_body = builder.joint_child[root_joint_idx]
        if root_body < 0 or builder.body_mass[root_body] > 0.0:
            continue

        massless_chain_parents = {root_body}
        while True:
            added_joint = False
            for joint_idx in joint_indices:
                if joint_idx in fixed_joint_indices_to_collapse:
                    continue
                if builder.joint_type[joint_idx] != JointType.FIXED:
                    continue
                if builder.joint_parent[joint_idx] not in massless_chain_parents:
                    continue

                fixed_joint_indices_to_collapse.add(joint_idx)
                child = builder.joint_child[joint_idx]
                if child >= 0 and builder.body_mass[child] <= 0.0:
                    massless_chain_parents.add(child)
                added_joint = True

            if not added_joint:
                break

    if not fixed_joint_indices_to_collapse:
        return

    fixed_joint_indices_to_keep = {
        joint_idx
        for joint_idx in range(builder.joint_count)
        if builder.joint_type[joint_idx] == JointType.FIXED and joint_idx not in fixed_joint_indices_to_collapse
    }
    builder.collapse_fixed_joints(joints_to_keep=fixed_joint_indices_to_keep)


def is_xml_content(source: str) -> bool:
    """Check if a string appears to be XML content rather than a file path.

    Uses the presence of XML angle brackets which are required for any XML
    content and practically never appear in file paths.

    Args:
        source: String to check

    Returns:
        True if the string appears to be XML content, False if it looks like a file path
    """
    return any(char in source for char in "<>")

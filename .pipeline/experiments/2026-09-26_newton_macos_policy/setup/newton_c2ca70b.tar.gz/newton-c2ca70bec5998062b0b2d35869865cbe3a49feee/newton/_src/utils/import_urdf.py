# SPDX-FileCopyrightText: Copyright (c) 2025 The Newton Developers
# SPDX-License-Identifier: Apache-2.0

from __future__ import annotations

import os
import tempfile
import warnings
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Literal
from urllib.parse import unquote, urlsplit

import numpy as np
import warp as wp

from ..core import Axis, AxisType, quat_between_axes
from ..core.types import Transform
from ..geometry import Mesh, ShapeFlags
from ..sim import ModelBuilder
from ..sim.enums import JointTargetMode
from ..sim.model import Model
from .import_utils import (
    clamp_imported_opacity,
    collapse_massless_fixed_root_joints,
    parse_custom_attributes,
    sanitize_xml_content,
    should_show_collider,
)
from .mesh import load_meshes_from_file
from .texture import load_texture
from .topology import topological_sort

AttributeFrequency = Model.AttributeFrequency


# Optional dependency for robust URI resolution
try:
    from resolve_robotics_uri_py import resolve_robotics_uri
except ImportError:
    resolve_robotics_uri = None


def _download_file(dst, url: str) -> None:
    import requests

    with requests.get(url, stream=True, timeout=10) as response:
        response.raise_for_status()
        for chunk in response.iter_content(chunk_size=8192):
            dst.write(chunk)


def download_asset_tmpfile(url: str):
    """Download a file into a NamedTemporaryFile.
    A closed NamedTemporaryFile is returned. It must be deleted by the caller."""
    urlpath = unquote(urlsplit(url).path)
    file_od = tempfile.NamedTemporaryFile("wb", suffix=os.path.splitext(urlpath)[1], delete=False)
    _download_file(file_od, url)
    file_od.close()

    return file_od


def parse_urdf(
    builder: ModelBuilder,
    source: str,
    *,
    xform: Transform | None = None,
    floating: bool | None = None,
    base_joint: dict | None = None,
    parent_body: int = -1,
    scale: float = 1.0,
    hide_visuals: bool = False,
    parse_visuals_as_colliders: bool = False,
    up_axis: AxisType = Axis.Z,
    force_show_colliders: bool = False,
    enable_self_collisions: bool = True,
    ignore_inertial_definitions: bool = False,
    joint_ordering: Literal["bfs", "dfs"] | None = "dfs",
    bodies_follow_joint_ordering: bool = True,
    collapse_fixed_joints: bool = False,
    collapse_massless_fixed_root: bool = False,
    mesh_maxhullvert: int | None = None,
    force_position_velocity_actuation: bool = False,
    override_root_xform: bool = False,
):
    """
    Parses a URDF file and adds the bodies and joints to the given ModelBuilder.

    Args:
        builder: The :class:`ModelBuilder` to add the bodies and joints to.
        source: The filename of the URDF file to parse, or the URDF XML string content.
        xform: The transform to apply to the root body. If None, the transform is set to identity.
        override_root_xform: If ``True``, the articulation root's world-space
            transform is replaced by ``xform`` instead of being composed with it,
            preserving only the internal structure (relative body positions). Useful
            for cloning articulations at explicit positions. When a ``base_joint`` is
            specified, ``xform`` is applied as the full parent transform (including
            rotation) rather than splitting position/rotation. Not intended for
            sources containing multiple articulations, as all roots would be placed
            at the same ``xform``. Defaults to ``False``.
        floating: Controls the base joint type for the root body.

            - ``None`` (default): Uses format-specific default (creates a FIXED joint for URDF).
            - ``True``: Creates a FREE joint with 6 DOF (3 translation + 3 rotation). Only valid when
              ``parent_body == -1`` since FREE joints must connect to world frame.
            - ``False``: Creates a FIXED joint (0 DOF).

            Cannot be specified together with ``base_joint``.
        base_joint: Custom joint specification for connecting the root body to the world
            (or to ``parent_body`` if specified). This parameter enables hierarchical composition with
            custom mobility. Dictionary with joint parameters as accepted by
            :meth:`ModelBuilder.add_joint` (e.g., joint type, axes, limits, stiffness).

            Cannot be specified together with ``floating``.
        parent_body: Parent body index for hierarchical composition. If specified, attaches the
            imported root body to this existing body, making them part of the same kinematic articulation.
            The connection type is determined by ``floating`` or ``base_joint``. If ``-1`` (default),
            the root connects to the world frame. **Restriction**: Only the most recently added
            articulation can be used as parent; attempting to attach to an older articulation will raise
            a ``ValueError``.

            .. note::
               Valid combinations of ``floating``, ``base_joint``, and ``parent_body``:

               .. list-table::
                  :header-rows: 1
                  :widths: 15 15 15 55

                  * - floating
                    - base_joint
                    - parent_body
                    - Result
                  * - ``None``
                    - ``None``
                    - ``-1``
                    - Format default (URDF: FIXED joint)
                  * - ``True``
                    - ``None``
                    - ``-1``
                    - FREE joint to world (6 DOF)
                  * - ``False``
                    - ``None``
                    - ``-1``
                    - FIXED joint to world (0 DOF)
                  * - ``None``
                    - ``{dict}``
                    - ``-1``
                    - Custom joint to world (e.g., D6)
                  * - ``False``
                    - ``None``
                    - ``body_idx``
                    - FIXED joint to parent body
                  * - ``None``
                    - ``{dict}``
                    - ``body_idx``
                    - Custom joint to parent body (e.g., D6)
                  * - *explicitly set*
                    - *explicitly set*
                    - *any*
                    - ❌ Error: mutually exclusive (cannot specify both)
                  * - ``True``
                    - ``None``
                    - ``body_idx``
                    - ❌ Error: FREE joints require world frame

        scale: The scaling factor to apply to the imported mechanism.
        hide_visuals: If True, hide visual shapes.
        parse_visuals_as_colliders: If True, the geometry defined under the `<visual>` tags is used for collision handling instead of the `<collision>` geometries.
        up_axis: The up axis of the URDF. This is used to transform the URDF to the builder's up axis. It also determines the up axis of capsules and cylinders in the URDF. The default is Z.
        force_show_colliders: If True, the collision shapes are always shown, even if there are visual shapes.
        enable_self_collisions: If True, self-collisions are enabled.
        ignore_inertial_definitions: If True, the inertial parameters defined in the URDF are ignored and the inertia is calculated from the shape geometry.
        joint_ordering: The ordering of the joints in the simulation. Can be either "bfs" or "dfs" for breadth-first or depth-first search, or ``None`` to keep joints in the order in which they appear in the URDF. Default is "dfs".
        bodies_follow_joint_ordering: If True, the bodies are added to the builder in the same order as the joints (parent then child body). Otherwise, bodies are added in the order they appear in the URDF. Default is True.
        collapse_fixed_joints: If True, fixed joints are removed and the respective bodies are merged.
        collapse_massless_fixed_root: If True, collapse only the massless fixed-joint chain below an imported free root body. Ignored when ``collapse_fixed_joints`` is True.
        mesh_maxhullvert: Maximum vertices for convex hull approximation of meshes.
        force_position_velocity_actuation: If True and both position (stiffness) and velocity
            (damping) gains are non-zero, joints use :attr:`~newton.JointTargetMode.POSITION_VELOCITY` actuation mode.
            If False (default), actuator modes are inferred per joint via :func:`newton.JointTargetMode.from_gains`:
            :attr:`~newton.JointTargetMode.POSITION` if stiffness > 0, :attr:`~newton.JointTargetMode.VELOCITY` if only
            damping > 0, :attr:`~newton.JointTargetMode.EFFORT` if a drive is present but both gains are zero
            (direct torque control), or :attr:`~newton.JointTargetMode.NONE` if no drive/actuation is applied.
    """
    # Early validation of base joint parameters
    builder._validate_base_joint_params(floating, base_joint, parent_body)

    if override_root_xform and xform is None:
        raise ValueError("override_root_xform=True requires xform to be set")

    if mesh_maxhullvert is None:
        mesh_maxhullvert = Mesh.MAX_HULL_VERTICES

    axis_xform = wp.transform(wp.vec3(0.0), quat_between_axes(up_axis, builder.up_axis))
    if xform is None:
        xform = axis_xform
    else:
        xform = wp.transform(*xform) * axis_xform

    source = os.fspath(source) if hasattr(source, "__fspath__") else source

    if source.startswith(("package://", "model://")):
        if resolve_robotics_uri is not None:
            try:
                source = resolve_robotics_uri(source)
            except FileNotFoundError:
                raise FileNotFoundError(
                    f'Could not resolve URDF source URI "{source}". '
                    f"Check that the package is installed and that relevant environment variables "
                    f"(ROS_PACKAGE_PATH, AMENT_PREFIX_PATH, GZ_SIM_RESOURCE_PATH, etc.) are set correctly. "
                    f"See https://github.com/ami-iit/resolve-robotics-uri-py for details."
                ) from None
        else:
            raise ImportError(
                f'Cannot resolve URDF source URI "{source}" without resolve-robotics-uri-py. '
                f"Install it with: pip install resolve-robotics-uri-py"
            )

    if os.path.isfile(source):
        file = ET.parse(source)
        urdf_root = file.getroot()
    else:
        xml_content = sanitize_xml_content(source)
        urdf_root = ET.fromstring(xml_content)

    # load joint defaults
    default_joint_limit_lower = builder.default_joint_cfg.limit_lower
    default_joint_limit_upper = builder.default_joint_cfg.limit_upper
    default_joint_limit_effort = builder.default_joint_cfg.effort_limit
    default_joint_damping = builder.default_joint_cfg.target_kd
    default_joint_friction = builder.default_joint_cfg.friction

    # load shape defaults
    default_shape_density = builder.default_shape_cfg.density

    def resolve_urdf_asset(filename: str | None) -> tuple[str | None, tempfile.NamedTemporaryFile | None]:
        """Resolve a URDF asset URI/path to a local filename.

        Args:
            filename: Asset filename or URI from the URDF (may be None).

        Returns:
            A tuple of (resolved_filename, tmpfile). The tmpfile is only
            populated for temporary downloads (e.g., http/https) and must be
            cleaned up by the caller (e.g., remove tmpfile.name).
        """
        if filename is None:
            return None, None

        file_tmp = None
        if filename.startswith(("package://", "model://")):
            if resolve_robotics_uri is not None:
                try:
                    if filename.startswith("package://"):
                        fn = filename.replace("package://", "")
                        parent_urdf_folder = os.path.abspath(
                            os.path.join(os.path.abspath(source), os.pardir, os.pardir, os.pardir)
                        )
                        package_dirs = [parent_urdf_folder]
                    else:
                        package_dirs = []
                    filename = resolve_robotics_uri(filename, package_dirs=package_dirs)
                except FileNotFoundError:
                    warnings.warn(
                        f'Warning: could not resolve URI "{filename}". '
                        f"Check that the package is installed and that relevant environment variables "
                        f"(ROS_PACKAGE_PATH, AMENT_PREFIX_PATH, GZ_SIM_RESOURCE_PATH, etc.) are set correctly. "
                        f"See https://github.com/ami-iit/resolve-robotics-uri-py for details.",
                        stacklevel=2,
                    )
                    return None, None
            else:
                if not os.path.isfile(source):
                    warnings.warn(
                        f'Warning: cannot resolve URI "{filename}" when URDF is loaded from XML string. '
                        f"Load URDF from a file path, or install resolve-robotics-uri-py: "
                        f"pip install resolve-robotics-uri-py",
                        stacklevel=2,
                    )
                    return None, None
                if filename.startswith("package://"):
                    fn = filename.replace("package://", "")
                    package_name = fn.split("/")[0]
                    urdf_folder = os.path.dirname(source)
                    package_root = None
                    urdf_parts = Path(os.path.abspath(urdf_folder)).parts
                    for index in range(len(urdf_parts) - 1, -1, -1):
                        if urdf_parts[index] == package_name:
                            package_root = Path(*urdf_parts[:index])
                            break
                    if package_root is not None:
                        filename = os.path.join(os.fspath(package_root), fn)
                    else:
                        warnings.warn(
                            f'Warning: could not resolve package "{package_name}" in URI "{filename}". '
                            f"For robust URI resolution, install resolve-robotics-uri-py: "
                            f"pip install resolve-robotics-uri-py",
                            stacklevel=2,
                        )
                        return None, None
                else:
                    warnings.warn(
                        f'Warning: cannot resolve model:// URI "{filename}" without resolve-robotics-uri-py. '
                        f"Install it with: pip install resolve-robotics-uri-py",
                        stacklevel=2,
                    )
                    return None, None
        elif filename.startswith(("http://", "https://")):
            file_tmp = download_asset_tmpfile(filename)
            filename = file_tmp.name
        else:
            if not os.path.isabs(filename):
                if not os.path.isfile(source):
                    warnings.warn(
                        f'Warning: cannot resolve relative URI "{filename}" when URDF is loaded from XML string. '
                        f"Load URDF from a file path.",
                        stacklevel=2,
                    )
                    return None, None
                filename = os.path.join(os.path.dirname(source), filename)

        if not os.path.exists(filename):
            warnings.warn(f"Warning: asset file {filename} does not exist", stacklevel=2)
            return None, None

        return filename, file_tmp

    def _parse_material_properties(material_element):
        if material_element is None:
            return None, None, None

        color = None
        opacity = None
        texture = None

        color_el = material_element.find("color")
        if color_el is not None:
            rgba = color_el.get("rgba")
            if rgba:
                values = np.fromstring(rgba, sep=" ", dtype=np.float32)
                if len(values) >= 3:
                    color = (float(values[0]), float(values[1]), float(values[2]))
                if len(values) >= 4:
                    opacity = clamp_imported_opacity(values[3], "URDF material rgba")

        texture_el = material_element.find("texture")
        if texture_el is not None:
            texture_name = texture_el.get("filename")
            if texture_name:
                resolved, tmpfile = resolve_urdf_asset(texture_name)
                try:
                    if resolved is not None:
                        if tmpfile is not None:
                            # Temp file will be deleted, so load texture eagerly
                            texture = load_texture(resolved)
                        else:
                            # Local file, pass path for lazy loading by viewer
                            texture = resolved
                finally:
                    if tmpfile is not None:
                        os.remove(tmpfile.name)

        return color, opacity, texture

    materials: dict[str, dict[str, object | None]] = {}
    for material in urdf_root.findall("material"):
        mat_name = material.get("name")
        if not mat_name:
            continue
        color, opacity, texture = _parse_material_properties(material)
        materials[mat_name] = {
            "color": color,
            "opacity": opacity,
            "texture": texture,
        }

    def resolve_material(material_element):
        if material_element is None:
            return {"color": None, "opacity": None, "texture": None}
        mat_name = material_element.get("name")

        # Fast path: pure name reference to an already-parsed material. URDFs
        # typically define materials once at the top level and then reference
        # them by name on individual geoms (`<material name="foo"/>` with no
        # children). Skip the XML re-parse in that common case.
        if mat_name and mat_name in materials and len(material_element) == 0:
            return dict(materials[mat_name])

        color, opacity, texture = _parse_material_properties(material_element)

        if mat_name and mat_name in materials:
            resolved = dict(materials[mat_name])
        else:
            resolved = {"color": None, "opacity": None, "texture": None}

        if color is not None:
            resolved["color"] = color
        if opacity is not None:
            resolved["opacity"] = opacity
        if texture is not None:
            resolved["texture"] = texture

        if mat_name and mat_name not in materials and any(value is not None for value in (color, opacity, texture)):
            materials[mat_name] = dict(resolved)

        return resolved

    # Process custom attributes defined for different kinds of shapes, bodies, joints, etc.
    builder_custom_attr_shape: list[ModelBuilder.CustomAttribute] = builder.get_custom_attributes_by_frequency(
        [AttributeFrequency.SHAPE]
    )
    builder_custom_attr_body: list[ModelBuilder.CustomAttribute] = builder.get_custom_attributes_by_frequency(
        [AttributeFrequency.BODY]
    )
    builder_custom_attr_joint: list[ModelBuilder.CustomAttribute] = builder.get_custom_attributes_by_frequency(
        [AttributeFrequency.JOINT]
    )
    builder_custom_attr_articulation: list[ModelBuilder.CustomAttribute] = builder.get_custom_attributes_by_frequency(
        [AttributeFrequency.ARTICULATION]
    )

    def parse_transform(element):
        if element is None or element.find("origin") is None:
            return wp.transform()
        origin = element.find("origin")
        xyz = origin.get("xyz") or "0 0 0"
        rpy = origin.get("rpy") or "0 0 0"
        xyz = [float(x) * scale for x in xyz.split()]
        rpy = [float(x) for x in rpy.split()]
        return wp.transform(xyz, wp.quat_rpy(*rpy))

    def parse_shapes(link: int, geoms, density, incoming_xform=None, visible=True, just_visual=False):
        shape_cfg = builder.default_shape_cfg.copy()
        shape_cfg.density = density
        shape_cfg.is_visible = visible
        shape_cfg.has_shape_collision = not just_visual
        shape_cfg.has_particle_collision = not just_visual
        shape_kwargs = {
            "body": link,
            "cfg": shape_cfg,
            "custom_attributes": {},
        }
        shapes = []
        # add geometry
        for geom_group in geoms:
            geo = geom_group.find("geometry")
            if geo is None:
                continue
            custom_attributes = parse_custom_attributes(geo.attrib, builder_custom_attr_shape, parsing_mode="urdf")
            shape_kwargs["custom_attributes"] = custom_attributes

            tf = parse_transform(geom_group)
            if incoming_xform is not None:
                tf = incoming_xform * tf

            material_info = resolve_material(geom_group.find("material"))
            if just_visual:
                if material_info["opacity"] is not None:
                    shape_kwargs["opacity"] = material_info["opacity"]
                else:
                    shape_kwargs.pop("opacity", None)
            else:
                shape_kwargs.pop("opacity", None)

            for box in geo.findall("box"):
                size = box.get("size") or "1 1 1"
                size = [float(x) for x in size.split()]
                s = builder.add_shape_box(
                    xform=tf,
                    hx=size[0] * 0.5 * scale,
                    hy=size[1] * 0.5 * scale,
                    hz=size[2] * 0.5 * scale,
                    color=material_info["color"],
                    **shape_kwargs,
                )
                shapes.append(s)

            for sphere in geo.findall("sphere"):
                s = builder.add_shape_sphere(
                    xform=tf,
                    radius=float(sphere.get("radius") or "1") * scale,
                    color=material_info["color"],
                    **shape_kwargs,
                )
                shapes.append(s)

            for cylinder in geo.findall("cylinder"):
                # Apply axis rotation to transform
                xform = wp.transform(tf.p, tf.q * quat_between_axes(Axis.Z, up_axis))
                s = builder.add_shape_cylinder(
                    xform=xform,
                    radius=float(cylinder.get("radius") or "1") * scale,
                    half_height=float(cylinder.get("length") or "1") * 0.5 * scale,
                    color=material_info["color"],
                    **shape_kwargs,
                )
                shapes.append(s)

            for capsule in geo.findall("capsule"):
                # Apply axis rotation to transform
                xform = wp.transform(tf.p, tf.q * quat_between_axes(Axis.Z, up_axis))
                s = builder.add_shape_capsule(
                    xform=xform,
                    radius=float(capsule.get("radius") or "1") * scale,
                    half_height=float(capsule.get("height") or "1") * 0.5 * scale,
                    color=material_info["color"],
                    **shape_kwargs,
                )
                shapes.append(s)

            for mesh in geo.findall("mesh"):
                filename = mesh.get("filename")
                if filename is None:
                    continue
                scaling = mesh.get("scale") or "1 1 1"
                scaling = np.array([float(x) * scale for x in scaling.split()])
                resolved, file_tmp = resolve_urdf_asset(filename)
                if resolved is None:
                    continue

                m_meshes = load_meshes_from_file(
                    resolved,
                    scale=scaling,
                    maxhullvert=mesh_maxhullvert,
                    override_color=material_info["color"],
                    override_texture=material_info["texture"],
                )
                for m_mesh in m_meshes:
                    if m_mesh.texture is not None and m_mesh.uvs is None:
                        warnings.warn(
                            f"Warning: mesh {resolved} has a texture but no UVs; texture will be ignored.",
                            stacklevel=2,
                        )
                        m_mesh.texture = None
                    # Mesh shapes must not use cfg.sdf_*; SDFs are built on the mesh itself.
                    mesh_shape_kwargs = dict(shape_kwargs)
                    mesh_cfg = shape_cfg.copy()
                    mesh_cfg.sdf_max_resolution = None
                    mesh_cfg.sdf_target_voxel_size = None
                    mesh_cfg.sdf_narrow_band_range = (-0.1, 0.1)
                    mesh_shape_kwargs["cfg"] = mesh_cfg
                    s = builder.add_shape_mesh(
                        xform=tf,
                        mesh=m_mesh,
                        **mesh_shape_kwargs,
                    )
                    shapes.append(s)

                if file_tmp is not None:
                    os.remove(file_tmp.name)
                    file_tmp = None

        return shapes

    joint_indices = []  # Collect joint indices as we create them

    # add joints

    # mapping from parent, child link names to joint
    parent_child_joint = {}

    joints = []
    for joint in urdf_root.findall("joint"):
        parent = joint.find("parent").get("link")
        child = joint.find("child").get("link")
        joint_custom_attributes = parse_custom_attributes(joint.attrib, builder_custom_attr_joint, parsing_mode="urdf")
        joint_data = {
            "name": joint.get("name"),
            "parent": parent,
            "child": child,
            "type": joint.get("type"),
            "origin": parse_transform(joint),
            "damping": default_joint_damping,
            "friction": default_joint_friction,
            "axis": wp.vec3(1.0, 0.0, 0.0),
            "limit_lower": default_joint_limit_lower,
            "limit_upper": default_joint_limit_upper,
            "limit_effort": default_joint_limit_effort,
            "custom_attributes": joint_custom_attributes,
        }
        el_axis = joint.find("axis")
        if el_axis is not None:
            ax = el_axis.get("xyz", "1 0 0").strip().split()
            joint_data["axis"] = wp.vec3(float(ax[0]), float(ax[1]), float(ax[2]))
        el_dynamics = joint.find("dynamics")
        if el_dynamics is not None:
            joint_data["damping"] = float(el_dynamics.get("damping", default_joint_damping))
            joint_data["friction"] = float(el_dynamics.get("friction", default_joint_friction))
        el_limit = joint.find("limit")
        if el_limit is not None:
            joint_data["limit_lower"] = float(el_limit.get("lower", default_joint_limit_lower))
            joint_data["limit_upper"] = float(el_limit.get("upper", default_joint_limit_upper))
            joint_data["limit_effort"] = float(el_limit.get("effort", default_joint_limit_effort))
        el_mimic = joint.find("mimic")
        if el_mimic is not None:
            joint_data["mimic_joint"] = el_mimic.get("joint")
            joint_data["mimic_coef0"] = float(el_mimic.get("offset", 0))
            joint_data["mimic_coef1"] = float(el_mimic.get("multiplier", 1))

        parent_child_joint[(parent, child)] = joint_data
        joints.append(joint_data)

    # Extract the articulation label early so we can build hierarchical labels
    articulation_label = urdf_root.attrib.get("name")

    def make_label(name: str) -> str:
        """Build a hierarchical label for an entity name.

        Args:
            name: The entity name to label.

        Returns:
            Hierarchical label ``{articulation_label}/{name}`` when an
            articulation label is present, otherwise ``name``.
        """
        return f"{articulation_label}/{name}" if articulation_label else name

    # topological sorting of joints because the FK function will resolve body transforms
    # in joint order and needs the parent link transform to be resolved before the child
    urdf_links = []
    sorted_joints = []
    if len(joints) > 0:
        if joint_ordering is not None:
            joint_edges = [(joint["parent"], joint["child"]) for joint in joints]
            sorted_joint_ids = topological_sort(joint_edges, use_dfs=joint_ordering == "dfs")
            sorted_joints = [joints[i] for i in sorted_joint_ids]
        else:
            sorted_joints = joints

        if bodies_follow_joint_ordering:
            body_order: list[str] = [sorted_joints[0]["parent"]] + [joint["child"] for joint in sorted_joints]
            for body in body_order:
                urdf_link = urdf_root.find(f"link[@name='{body}']")
                if urdf_link is None:
                    raise ValueError(f"Link {body} not found in URDF")
                urdf_links.append(urdf_link)
    if len(urdf_links) == 0:
        urdf_links = urdf_root.findall("link")

    # add links and shapes

    # maps from link name -> link index
    link_index: dict[str, int] = {}
    start_shape_count = len(builder.shape_type)
    model_has_visual_shapes = any(len(urdf_link.findall("visual")) > 0 for urdf_link in urdf_links)

    for urdf_link in urdf_links:
        name = urdf_link.get("name")
        if name is None:
            raise ValueError("Link has no name")
        link = builder.add_link(
            label=make_label(name),
            custom_attributes=parse_custom_attributes(urdf_link.attrib, builder_custom_attr_body, parsing_mode="urdf"),
        )

        # add ourselves to the index
        link_index[name] = link

        visuals = urdf_link.findall("visual")
        colliders = urdf_link.findall("collision")

        if parse_visuals_as_colliders:
            colliders = visuals
        else:
            parse_shapes(link, visuals, density=0.0, just_visual=True, visible=not hide_visuals)

        show_colliders = should_show_collider(
            force_show_colliders,
            model_has_visual_shapes=model_has_visual_shapes,
            parse_visuals_as_colliders=parse_visuals_as_colliders,
        )

        parse_shapes(link, colliders, density=default_shape_density, visible=show_colliders)
        m = builder.body_mass[link]
        el_inertia = urdf_link.find("inertial")
        if not ignore_inertial_definitions and el_inertia is not None:
            # overwrite inertial parameters if defined
            inertial_frame = parse_transform(el_inertia)
            com = inertial_frame.p
            builder.body_com[link] = com
            I_m = np.zeros((3, 3))
            el_i_m = el_inertia.find("inertia")
            if el_i_m is not None:
                I_m[0, 0] = float(el_i_m.get("ixx", 0)) * scale**2
                I_m[1, 1] = float(el_i_m.get("iyy", 0)) * scale**2
                I_m[2, 2] = float(el_i_m.get("izz", 0)) * scale**2
                I_m[0, 1] = float(el_i_m.get("ixy", 0)) * scale**2
                I_m[0, 2] = float(el_i_m.get("ixz", 0)) * scale**2
                I_m[1, 2] = float(el_i_m.get("iyz", 0)) * scale**2
                I_m[1, 0] = I_m[0, 1]
                I_m[2, 0] = I_m[0, 2]
                I_m[2, 1] = I_m[1, 2]
                rot = wp.quat_to_matrix(inertial_frame.q)
                I_m = rot @ wp.mat33(I_m) @ wp.transpose(rot)
                builder.body_inertia[link] = I_m
                if any(x for x in I_m):
                    builder.body_inv_inertia[link] = wp.inverse(I_m)
                else:
                    builder.body_inv_inertia[link] = I_m
            el_mass = el_inertia.find("mass")
            if el_mass is not None:
                m = float(el_mass.get("value", 0))
                builder.body_mass[link] = m
                builder.body_inv_mass[link] = 1.0 / m if m > 0.0 else 0.0

    end_shape_count = len(builder.shape_type)

    # add base joint
    if len(sorted_joints) > 0:
        base_link_name = sorted_joints[0]["parent"]
    else:
        base_link_name = next(iter(link_index.keys()))
    root = link_index[base_link_name]

    # Determine the parent for the base joint (-1 for world, or an existing body index)
    base_parent = parent_body

    if base_joint is not None:
        if override_root_xform:
            base_parent_xform = xform
            base_child_xform = wp.transform_identity()
        else:
            # Split xform: position goes to parent, rotation to child (inverted)
            # so the custom base joint's axis isn't rotated by xform.
            base_parent_xform = wp.transform(xform.p, wp.quat_identity())
            base_child_xform = wp.transform((0.0, 0.0, 0.0), wp.quat_inverse(xform.q))
        base_joint_id = builder._add_base_joint(
            child=root,
            base_joint=base_joint,
            label=make_label("base_joint"),
            parent_xform=base_parent_xform,
            child_xform=base_child_xform,
            parent=base_parent,
        )
        joint_indices.append(base_joint_id)
    elif floating and base_parent == -1:
        # floating=True only makes sense when connecting to world
        floating_joint_id = builder._add_base_joint(
            child=root,
            floating=True,
            label=make_label("floating_base"),
            parent_xform=xform,
            parent=base_parent,
        )
        joint_indices.append(floating_joint_id)

        # set dofs to transform for the floating base joint
        start = builder.joint_q_start[floating_joint_id]

        builder.joint_q[start + 0] = xform.p[0]
        builder.joint_q[start + 1] = xform.p[1]
        builder.joint_q[start + 2] = xform.p[2]

        builder.joint_q[start + 3] = xform.q[0]
        builder.joint_q[start + 4] = xform.q[1]
        builder.joint_q[start + 5] = xform.q[2]
        builder.joint_q[start + 6] = xform.q[3]
    else:
        # Fixed joint to world or to parent_body
        # When parent_body is set, xform is interpreted as relative to the parent body
        joint_indices.append(
            builder._add_base_joint(
                child=root,
                floating=False,
                label=make_label("fixed_base"),
                parent_xform=xform,
                parent=base_parent,
            )
        )

    # add joints, in the desired order starting from root body
    # Track only joints that are actually created (some may be skipped if their child body wasn't inserted).
    joint_name_to_idx: dict[str, int] = {}
    for joint in sorted_joints:
        parent = link_index[joint["parent"]]
        child = link_index[joint["child"]]
        if child == -1:
            # we skipped the insertion of the child body
            continue

        lower = joint.get("limit_lower", None)
        upper = joint.get("limit_upper", None)
        effort_limit = joint.get("limit_effort", None)
        joint_damping = joint["damping"]
        joint_friction = joint["friction"]

        parent_xform = joint["origin"]

        joint_params = {
            "parent": parent,
            "child": child,
            "parent_xform": parent_xform,
            "label": make_label(joint["name"]),
            "custom_attributes": joint["custom_attributes"],
        }

        # URDF doesn't contain gain information (only damping, no stiffness), so we can't infer
        # actuator mode. Default to POSITION.
        actuator_mode = (
            JointTargetMode.POSITION_VELOCITY if force_position_velocity_actuation else JointTargetMode.POSITION
        )

        created_joint_idx: int
        if joint["type"] == "revolute" or joint["type"] == "continuous":
            created_joint_idx = builder.add_joint_revolute(
                axis=joint["axis"],
                target_kd=joint_damping,
                friction=joint_friction,
                actuator_mode=actuator_mode,
                limit_lower=lower,
                limit_upper=upper,
                effort_limit=effort_limit,
                **joint_params,
            )
        elif joint["type"] == "prismatic":
            created_joint_idx = builder.add_joint_prismatic(
                axis=joint["axis"],
                target_kd=joint_damping,
                friction=joint_friction,
                actuator_mode=actuator_mode,
                limit_lower=lower * scale,
                limit_upper=upper * scale,
                effort_limit=effort_limit,
                **joint_params,
            )
        elif joint["type"] == "fixed":
            created_joint_idx = builder.add_joint_fixed(**joint_params)
        elif joint["type"] == "floating":
            created_joint_idx = builder.add_joint_free(**joint_params)
        elif joint["type"] == "planar":
            # find plane vectors perpendicular to axis
            axis = np.array(joint["axis"])
            axis /= np.linalg.norm(axis)

            # create helper vector that is not parallel to the axis
            helper = np.array([1, 0, 0]) if np.allclose(axis, [0, 1, 0]) else np.array([0, 1, 0])

            u = np.cross(helper, axis)
            u /= np.linalg.norm(u)

            v = np.cross(axis, u)
            v /= np.linalg.norm(v)

            created_joint_idx = builder.add_joint_d6(
                linear_axes=[
                    ModelBuilder.JointDofConfig(
                        axis=u,
                        limit_lower=lower * scale,
                        limit_upper=upper * scale,
                        target_kd=joint_damping,
                        friction=joint_friction,
                        actuator_mode=actuator_mode,
                    ),
                    ModelBuilder.JointDofConfig(
                        axis=v,
                        limit_lower=lower * scale,
                        limit_upper=upper * scale,
                        target_kd=joint_damping,
                        friction=joint_friction,
                        actuator_mode=actuator_mode,
                    ),
                ],
                **joint_params,
            )
        else:
            raise Exception("Unsupported joint type: " + joint["type"])

        joint_indices.append(created_joint_idx)
        joint_name_to_idx[joint["name"]] = created_joint_idx

    # Create mimic constraints
    for joint in sorted_joints:
        if "mimic_joint" in joint:
            mimic_target_name = joint["mimic_joint"]
            if mimic_target_name not in joint_name_to_idx:
                warnings.warn(
                    f"Mimic joint '{joint['name']}' references unknown joint '{mimic_target_name}', skipping mimic constraint",
                    stacklevel=2,
                )
                continue

            follower_idx = joint_name_to_idx.get(joint["name"])
            leader_idx = joint_name_to_idx.get(mimic_target_name)

            if follower_idx is None:
                warnings.warn(
                    f"Mimic joint '{joint['name']}' was not created, skipping mimic constraint",
                    stacklevel=2,
                )
                continue

            builder.add_constraint_mimic(
                joint0=follower_idx,
                joint1=leader_idx,
                coef0=joint.get("mimic_coef0", 0.0),
                coef1=joint.get("mimic_coef1", 1.0),
                label=make_label(f"mimic_{joint['name']}"),
            )

    # Create articulation from all collected joints
    articulation_custom_attrs = parse_custom_attributes(
        urdf_root.attrib, builder_custom_attr_articulation, parsing_mode="urdf"
    )
    builder._finalize_imported_articulation(
        joint_indices=joint_indices,
        parent_body=parent_body,
        articulation_label=articulation_label,
        custom_attributes=articulation_custom_attrs,
    )

    if not enable_self_collisions:
        # The broad phase only ever tests colliding shapes, so visual-only shapes need no filter pairs.
        colliding_shapes = [
            i for i in range(start_shape_count, end_shape_count) if builder.shape_flags[i] & ShapeFlags.COLLIDE_SHAPES
        ]
        for a, i in enumerate(colliding_shapes):
            for j in colliding_shapes[a + 1 :]:
                builder.add_shape_collision_filter_pair(i, j)

    if collapse_fixed_joints:
        builder.collapse_fixed_joints()
    elif collapse_massless_fixed_root:
        collapse_massless_fixed_root_joints(builder, joint_indices)

# SPDX-FileCopyrightText: Copyright (c) 2025 The Newton Developers
# SPDX-License-Identifier: Apache-2.0

"""
Warp kernels for simplified Newton viewers.
These kernels handle mesh operations and transformations.
"""

from typing import Any

import warp as wp

import newton
from newton._src.math import orthonormal_basis, velocity_at_point


@wp.struct
class PickingState:
    picked_point_local: wp.vec3
    picked_point_world: wp.vec3
    picking_target_world: wp.vec3
    pick_stiffness: float
    pick_damping: float
    pick_max_acceleration: float


@wp.kernel
def compute_pick_state_kernel(
    body_q: wp.array[wp.transform],
    body_flags: wp.array[int],
    body_index: int,
    hit_point_world: wp.vec3,
    # output
    pick_body: wp.array[int],
    pick_state: wp.array[PickingState],
):
    """
    Initialize the pick state when a body is first picked.
    """
    if body_index < 0:
        return
    if body_flags[body_index] & newton.BodyFlags.KINEMATIC:
        pick_body[0] = -1
        return

    # store body index
    pick_body[0] = body_index

    # Get body transform
    X_wb = body_q[body_index]
    X_bw = wp.transform_inverse(X_wb)

    pick_state[0].picked_point_local = wp.transform_point(X_bw, hit_point_world)

    # store target world (current attachment point position)
    pick_state[0].picking_target_world = hit_point_world

    # store current world space picked point on geometry (for visualization)
    pick_state[0].picked_point_world = hit_point_world


@wp.kernel
def apply_picking_force_kernel(
    body_q: wp.array[wp.transform],
    body_qd: wp.array[wp.spatial_vector],
    body_f: wp.array[wp.spatial_vector],
    pick_body_arr: wp.array[int],
    pick_state: wp.array[PickingState],
    body_flags: wp.array[int],
    body_com: wp.array[wp.vec3],
    body_mass: wp.array[float],
    body_inv_inertia: wp.array[wp.mat33],
    pick_effective_mass: wp.array[float],
):
    pick_body = pick_body_arr[0]
    if pick_body < 0:
        return
    if body_flags[pick_body] & newton.BodyFlags.KINEMATIC:
        return

    pick_pos_local = pick_state[0].picked_point_local
    pick_target_world = pick_state[0].picking_target_world

    # world space attachment point
    X_wb = body_q[pick_body]
    pick_pos_world = wp.transform_point(X_wb, pick_pos_local)
    com_world = wp.transform_point(X_wb, body_com[pick_body])

    # update current world space picked point on geometry (for visualization)
    pick_state[0].picked_point_world = pick_pos_world

    offset = pick_pos_world - com_world
    pick_vel = velocity_at_point(body_qd[pick_body], offset)

    # Adjust force to mass for more adaptive manipulation of picked bodies.
    force_multiplier = 10.0 + body_mass[pick_body]

    pick_force = force_multiplier * (
        pick_state[0].pick_stiffness * (pick_target_world - pick_pos_world) - (pick_state[0].pick_damping * pick_vel)
    )

    # Clamp force magnitude to prevent runaway divergence on light objects (#2361).
    # Uses the effective mass (total articulation mass for linked bodies,
    # own mass for free bodies) so picking a light robot link still allows
    # enough force to move the whole chain.
    max_acceleration = pick_state[0].pick_max_acceleration * 9.81
    max_force = max_acceleration * pick_effective_mass[pick_body]
    force_mag = wp.length(pick_force)
    if force_mag > max_force:
        pick_force = pick_force * (max_force / force_mag)

    pick_torque = wp.cross(offset, pick_force)

    # The articulation-mass force limit can produce unstable torque on low-inertia
    # links, so bound it using the picked body's own mass and inertia.
    mass = body_mass[pick_body]
    if mass > 0.0:
        body_rotation = wp.transform_get_rotation(X_wb)
        torque_body = wp.quat_rotate_inv(body_rotation, pick_torque)
        angular_acceleration_body = body_inv_inertia[pick_body] * torque_body
        rotational_acceleration_sq = wp.dot(torque_body, angular_acceleration_body) / mass
        if not wp.isfinite(rotational_acceleration_sq):
            pick_torque = wp.vec3(0.0)
        elif rotational_acceleration_sq > max_acceleration * max_acceleration:
            pick_torque = pick_torque * (max_acceleration / wp.sqrt(rotational_acceleration_sq))

    wp.atomic_add(body_f, pick_body, wp.spatial_vector(pick_force, pick_torque))


@wp.kernel
def update_pick_target_kernel(
    p: wp.vec3,
    d: wp.vec3,
    world_offset: wp.vec3,
    # read-write
    pick_state: wp.array[PickingState],
):
    # get original mouse cursor target (in physics space)
    original_target = pick_state[0].picking_target_world

    # Add world offset to convert to offset space for distance calculation
    original_target_offset = original_target + world_offset

    # compute distance from ray origin to original target (to maintain depth)
    dist = wp.length(original_target_offset - p)

    # Project new mouse cursor target at the same depth (in offset space)
    new_mouse_target_offset = p + d * dist

    # Convert back to physics space by subtracting world offset
    new_mouse_target = new_mouse_target_offset - world_offset

    # Update the original mouse cursor target (no smoothing here)
    pick_state[0].picking_target_world = new_mouse_target


@wp.kernel
def update_shape_xforms(
    shape_xforms: wp.array[wp.transform],
    shape_parents: wp.array[int],
    body_q: wp.array[wp.transform],
    shape_worlds: wp.array[int],
    world_offsets: wp.array[wp.vec3],
    layer_xform: wp.transform,
    world_xforms: wp.array[wp.transform],
):
    tid = wp.tid()

    shape_xform = shape_xforms[tid]
    shape_parent = shape_parents[tid]

    if shape_parent >= 0:
        world_xform = wp.transform_multiply(body_q[shape_parent], shape_xform)
    else:
        world_xform = shape_xform

    if world_offsets:
        shape_world = shape_worlds[tid]
        if shape_world >= 0 and shape_world < world_offsets.shape[0]:
            offset = world_offsets[shape_world]
            world_xform = wp.transform(world_xform.p + offset, world_xform.q)

    world_xforms[tid] = wp.transform_multiply(layer_xform, world_xform)


@wp.kernel
def repack_shape_colors(
    shape_colors: wp.array[wp.vec3],
    slot_to_shape: wp.array[wp.int32],
    packed_shape_colors: wp.array[wp.vec3],
):
    """Repack model-order shape colors into viewer batch order."""
    tid = wp.tid()
    packed_shape_colors[tid] = shape_colors[slot_to_shape[tid]]


@wp.kernel
def repack_shape_opacities(
    shape_opacities: wp.array[wp.float32],
    slot_to_shape: wp.array[wp.int32],
    packed_shape_opacities: wp.array[wp.float32],
):
    """Repack model-order shape opacities into viewer batch order."""
    tid = wp.tid()
    packed_shape_opacities[tid] = wp.clamp(shape_opacities[slot_to_shape[tid]], 0.0, 1.0)


@wp.kernel
def flag_changed_floats(
    current: wp.array[wp.float32],
    cached: wp.array[wp.float32],
    changed: wp.array[wp.int32],
):
    """Set changed[0] when any element differs between the two arrays."""
    tid = wp.tid()
    if current[tid] != cached[tid]:
        changed[0] = 1


@wp.kernel
def flag_changed_vec3s(
    current: wp.array[wp.vec3],
    cached: wp.array[wp.vec3],
    changed: wp.array[wp.int32],
):
    """Set changed[0] when any vector differs between the two arrays."""
    tid = wp.tid()
    delta = current[tid] - cached[tid]
    if wp.dot(delta, delta) != 0.0:
        changed[0] = 1


@wp.kernel
def estimate_world_extents(
    shape_transform: wp.array[wp.transform],
    shape_body: wp.array[int],
    shape_collision_radius: wp.array[float],
    shape_world: wp.array[int],
    body_q: wp.array[wp.transform],
    world_count: int,
    # outputs (world_count x 3 arrays for min/max xyz per world)
    world_bounds_min: wp.array2d[float],
    world_bounds_max: wp.array2d[float],
):
    tid = wp.tid()

    # Get shape's world assignment
    world_idx = shape_world[tid]

    # Skip global shapes (world -1) or invalid world indices
    if world_idx < 0 or world_idx >= world_count:
        return

    # Get collision radius and skip shapes with unreasonably large radii
    radius = shape_collision_radius[tid]
    if radius > 1.0e5:  # Skip outliers like infinite planes
        return

    # Get shape's world position
    shape_xform = shape_transform[tid]
    shape_parent = shape_body[tid]

    # Compute world transform
    if shape_parent >= 0:
        # Shape attached to body: world_xform = body_xform * shape_xform
        body_xform = body_q[shape_parent]
        world_xform = wp.transform_multiply(body_xform, shape_xform)
    else:
        # Static shape: already in world space
        world_xform = shape_xform

    # Get position and radius
    pos = wp.transform_get_translation(world_xform)
    radius = shape_collision_radius[tid]

    # Update bounds for this world using atomic operations
    min_pos = pos - wp.vec3(radius, radius, radius)
    max_pos = pos + wp.vec3(radius, radius, radius)

    # Atomic min for each component
    wp.atomic_min(world_bounds_min, world_idx, 0, min_pos[0])
    wp.atomic_min(world_bounds_min, world_idx, 1, min_pos[1])
    wp.atomic_min(world_bounds_min, world_idx, 2, min_pos[2])

    # Atomic max for each component
    wp.atomic_max(world_bounds_max, world_idx, 0, max_pos[0])
    wp.atomic_max(world_bounds_max, world_idx, 1, max_pos[1])
    wp.atomic_max(world_bounds_max, world_idx, 2, max_pos[2])


@wp.kernel
def compute_contact_lines(
    body_q: wp.array[wp.transform],
    shape_body: wp.array[int],
    shape_world: wp.array[int],
    shape_collision_radius: wp.array[float],
    world_offsets: wp.array[wp.vec3],
    layer_xform: wp.transform,
    visible_worlds_mask: wp.array[int],
    contact_count: wp.array[int],
    contact_shape0: wp.array[int],
    contact_shape1: wp.array[int],
    contact_point0: wp.array[wp.vec3],
    contact_offset0: wp.array[wp.vec3],
    contact_normal: wp.array[wp.vec3],
    line_scale: float,
    # outputs
    line_start: wp.array[wp.vec3],
    line_end: wp.array[wp.vec3],
):
    """Create line segments along contact normals for visualization."""
    tid = wp.tid()
    nan_line = wp.vec3(wp.nan, wp.nan, wp.nan)
    count = contact_count[0]
    if tid >= count:
        line_start[tid] = nan_line
        line_end[tid] = nan_line
        return
    shape_a = contact_shape0[tid]
    shape_b = contact_shape1[tid]
    if shape_a == shape_b:
        line_start[tid] = nan_line
        line_end[tid] = nan_line
        return

    # Filter by visible worlds
    world_a = shape_world[shape_a]
    world_b = shape_world[shape_b]
    if visible_worlds_mask:
        w = world_a if world_a >= 0 else world_b
        if w >= 0:
            if visible_worlds_mask[w] == 0:
                line_start[tid] = nan_line
                line_end[tid] = nan_line
                return

    # Get world transforms for both shapes
    body_a = shape_body[shape_a]
    X_wb_a = wp.transform_identity()
    if body_a >= 0:
        X_wb_a = body_q[body_a]

    # Compute world space contact positions
    world_pos0 = wp.transform_point(X_wb_a, contact_point0[tid] + contact_offset0[tid])
    # Anchor the debug normal at shape 0's contact point.
    contact_center = world_pos0

    # Apply world offset
    if world_a >= 0 or world_b >= 0:
        contact_center += world_offsets[world_a if world_a >= 0 else world_b]

    # Apply layer transform (rotates + translates contact point and rotates the normal)
    contact_center = wp.transform_point(layer_xform, contact_center)
    normal = wp.quat_rotate(wp.transform_get_rotation(layer_xform), contact_normal[tid])

    # Create line along the normal, relative to the smaller shape in the pair.
    # Normal points from shape0 to shape1, draw from center in normal direction
    pair_radius = wp.min(shape_collision_radius[shape_a], shape_collision_radius[shape_b])
    line_vector = normal * (line_scale * pair_radius)

    line_start[tid] = contact_center
    line_end[tid] = contact_center + line_vector


@wp.func
def _quat_from_normal_z(normal: wp.vec3) -> wp.quat:
    """Build a rotation quaternion whose local +Z axis aligns with ``normal``.

    The tangent axes are arbitrary. Implemented with :func:`orthonormal_basis`
    for numerical stability near the poles.
    """
    n = wp.normalize(normal)
    t1, t2 = orthonormal_basis(n)
    R = wp.matrix_from_cols(t1, t2, n)
    return wp.quat_from_matrix(R)


@wp.kernel
def compute_contact_disk_transforms(
    body_q: wp.array[wp.transform],
    body_qd: wp.array[wp.spatial_vector],
    body_com: wp.array[wp.vec3],
    shape_body: wp.array[int],
    shape_world: wp.array[int],
    shape_collision_radius: wp.array[float],
    world_offsets: wp.array[wp.vec3],
    visible_worlds_mask: wp.array[int],
    contact_count: wp.array[int],
    contact_shape0: wp.array[int],
    contact_shape1: wp.array[int],
    contact_point0: wp.array[wp.vec3],
    contact_point1: wp.array[wp.vec3],
    contact_offset0: wp.array[wp.vec3],
    contact_normal: wp.array[wp.vec3],
    contact_force: wp.array[wp.spatial_vector],
    disk_radius_scale: float,
    disk_thickness_scale: float,
    eps_force: float,
    eps_velocity: float,
    color_open: wp.vec3,
    color_stick: wp.vec3,
    color_slip: wp.vec3,
    # outputs
    transforms: wp.array[wp.transform],
    scales: wp.array[wp.vec3],
    colors: wp.array[wp.vec3],
):
    """Compute per-contact disk transforms, scales, and mode-coloured colors.

    A thin oriented disk (rendered via a unit cylinder mesh whose local +Z
    axis is the cylinder axis) is placed at each active contact, oriented so
    that its axis matches ``contact_normal``. Its dimensions are scaled from
    the smaller shape's collision radius.

    When ``contact_force`` is provided (non-null), the disk is colored by an
    inferred contact mode computed from the linear contact force magnitude and
    the tangential relative velocity at the contact point:

    * ``|F| < eps_force``                                  -> ``color_open``
    * ``|F| >= eps_force and |v_tan| < eps_velocity``      -> ``color_stick``
    * ``|F| >= eps_force and |v_tan| >= eps_velocity``     -> ``color_slip``

    When ``contact_force`` is null, every active contact uses ``color_open``.

    Inactive slots (beyond ``contact_count[0]`` or hidden by the visible-worlds
    mask) receive a degenerate zero-scale transform and a black color.
    """
    tid = wp.tid()

    zero_xform = wp.transform(wp.vec3(0.0, 0.0, 0.0), wp.quat_identity())
    zero_vec = wp.vec3(0.0, 0.0, 0.0)

    count = contact_count[0]
    if tid >= count:
        transforms[tid] = zero_xform
        scales[tid] = zero_vec
        colors[tid] = zero_vec
        return

    shape_a = contact_shape0[tid]
    shape_b = contact_shape1[tid]
    if shape_a == shape_b:
        transforms[tid] = zero_xform
        scales[tid] = zero_vec
        colors[tid] = zero_vec
        return

    world_a = shape_world[shape_a]
    world_b = shape_world[shape_b]
    if visible_worlds_mask:
        w = world_a if world_a >= 0 else world_b
        if w >= 0:
            if visible_worlds_mask[w] == 0:
                transforms[tid] = zero_xform
                scales[tid] = zero_vec
                colors[tid] = zero_vec
                return

    body_a = shape_body[shape_a]
    body_b = shape_body[shape_b]

    X_wb_a = wp.transform_identity()
    if body_a >= 0:
        X_wb_a = body_q[body_a]

    world_pos0 = wp.transform_point(X_wb_a, contact_point0[tid] + contact_offset0[tid])

    contact_center = world_pos0
    if world_a >= 0 or world_b >= 0:
        contact_center += world_offsets[world_a if world_a >= 0 else world_b]

    n = contact_normal[tid]
    q = _quat_from_normal_z(n)

    # Mode coloring (default to "color_open" when force is unavailable).
    color = color_open
    thickness_scaling = 1.0  # Apply slightly different thickness based on color to avoid visible z-fighting
    if contact_force:
        f_lin = wp.spatial_top(contact_force[tid])
        f_mag = wp.length(f_lin)
        if f_mag < eps_force:
            color = color_open
        else:
            # Relative tangential velocity at the contact point.
            v_a = wp.vec3(0.0, 0.0, 0.0)
            if body_a >= 0:
                world_com_a = wp.transform_point(body_q[body_a], body_com[body_a])
                r_a = world_pos0 - world_com_a
                v_a = velocity_at_point(body_qd[body_a], r_a)
            v_b = wp.vec3(0.0, 0.0, 0.0)
            if body_b >= 0:
                X_wb_b = body_q[body_b]
                world_pos1 = wp.transform_point(X_wb_b, contact_point1[tid])
                world_com_b = wp.transform_point(X_wb_b, body_com[body_b])
                r_b = world_pos1 - world_com_b
                v_b = velocity_at_point(body_qd[body_b], r_b)
            v_rel = v_a - v_b
            v_t = v_rel - wp.dot(v_rel, n) * n
            if wp.length(v_t) < eps_velocity:
                color = color_stick
                thickness_scaling = 1.02
            else:
                color = color_slip
                thickness_scaling = 1.01

    pair_radius = wp.min(shape_collision_radius[shape_a], shape_collision_radius[shape_b])
    disk_radius = disk_radius_scale * pair_radius
    disk_thickness = disk_thickness_scale * pair_radius

    transforms[tid] = wp.transform(contact_center, q)
    scales[tid] = wp.vec3(disk_radius, disk_radius, disk_thickness * thickness_scaling)
    colors[tid] = color


@wp.kernel
def compute_contact_force_arrows(
    body_q: wp.array[wp.transform],
    shape_body: wp.array[int],
    shape_world: wp.array[int],
    shape_collision_radius: wp.array[float],
    world_offsets: wp.array[wp.vec3],
    visible_worlds_mask: wp.array[int],
    contact_count: wp.array[int],
    contact_shape0: wp.array[int],
    contact_shape1: wp.array[int],
    contact_point0: wp.array[wp.vec3],
    contact_offset0: wp.array[wp.vec3],
    contact_force: wp.array[wp.spatial_vector],
    force_scale: float,
    # outputs
    line_start: wp.array[wp.vec3],
    line_end: wp.array[wp.vec3],
):
    """Create world-space line segments visualizing the linear part of contact wrenches.

    The arrow starts at the world contact point on shape 0 and points along
    ``F = wp.spatial_top(contact_force[i])`` (the world-frame linear force on
    body 0). Its length is relative to the smaller shape's collision radius.
    Inactive slots produce degenerate (NaN) line segments that the renderer
    culls.
    """
    tid = wp.tid()
    nan_line = wp.vec3(wp.nan, wp.nan, wp.nan)

    count = contact_count[0]
    if tid >= count:
        line_start[tid] = nan_line
        line_end[tid] = nan_line
        return

    shape_a = contact_shape0[tid]
    shape_b = contact_shape1[tid]
    if shape_a == shape_b:
        line_start[tid] = nan_line
        line_end[tid] = nan_line
        return

    world_a = shape_world[shape_a]
    world_b = shape_world[shape_b]
    if visible_worlds_mask:
        w = world_a if world_a >= 0 else world_b
        if w >= 0:
            if visible_worlds_mask[w] == 0:
                line_start[tid] = nan_line
                line_end[tid] = nan_line
                return

    body_a = shape_body[shape_a]
    X_wb_a = wp.transform_identity()
    if body_a >= 0:
        X_wb_a = body_q[body_a]

    world_pos0 = wp.transform_point(X_wb_a, contact_point0[tid] + contact_offset0[tid])
    contact_center = world_pos0
    if world_a >= 0 or world_b >= 0:
        contact_center += world_offsets[world_a if world_a >= 0 else world_b]

    f_lin = -wp.spatial_top(contact_force[tid])  # Flip sign so positive force is along normal
    line_start[tid] = contact_center
    pair_radius = wp.min(shape_collision_radius[shape_a], shape_collision_radius[shape_b])
    line_end[tid] = contact_center + (force_scale * pair_radius) * f_lin


@wp.kernel
def compute_joint_basis_lines(
    joint_type: wp.array[int],
    joint_parent: wp.array[int],
    joint_child: wp.array[int],
    joint_transform: wp.array[wp.transform],
    body_q: wp.array[wp.transform],
    body_world: wp.array[int],
    world_offsets: wp.array[wp.vec3],
    layer_xform: wp.transform,
    visible_worlds_mask: wp.array[int],
    shape_collision_radius: wp.array[float],
    shape_body: wp.array[int],
    line_scale: float,
    # outputs - unified buffers for all joint lines
    line_starts: wp.array[wp.vec3],
    line_ends: wp.array[wp.vec3],
    line_colors: wp.array[wp.vec3],
):
    """Create line segments for joint basis vectors for visualization.
    Each joint produces 3 lines (x, y, z axes).
    Thread ID maps to line index: joint_id * 3 + axis_id
    """
    tid = wp.tid()
    nan_line = wp.vec3(wp.nan, wp.nan, wp.nan)
    zero_color = wp.vec3(0.0, 0.0, 0.0)

    # Determine which joint and which axis this thread handles
    joint_id = tid // 3
    axis_id = tid % 3

    # Check if this is a supported joint type
    if joint_id >= len(joint_type):
        line_starts[tid] = nan_line
        line_ends[tid] = nan_line
        line_colors[tid] = zero_color
        return

    joint_t = joint_type[joint_id]
    if (
        joint_t != int(newton.JointType.PRISMATIC)
        and joint_t != int(newton.JointType.REVOLUTE)
        and joint_t != int(newton.JointType.D6)
        and joint_t != int(newton.JointType.ROD)
        and joint_t != int(newton.JointType.BALL)
    ):
        # Set NaN for unsupported joints to hide them
        line_starts[tid] = nan_line
        line_ends[tid] = nan_line
        line_colors[tid] = zero_color
        return

    # Filter by visible worlds (fall back to child body for ground-attached joints)
    parent_body = joint_parent[joint_id]
    child_body = joint_child[joint_id]
    filter_body = parent_body if parent_body >= 0 else child_body
    if visible_worlds_mask:
        if filter_body >= 0:
            world_idx = body_world[filter_body]
            if world_idx >= 0:
                if visible_worlds_mask[world_idx] == 0:
                    line_starts[tid] = nan_line
                    line_ends[tid] = nan_line
                    line_colors[tid] = zero_color
                    return

    # Get joint transform
    joint_tf = joint_transform[joint_id]
    joint_pos = wp.transform_get_translation(joint_tf)
    joint_rot = wp.transform_get_rotation(joint_tf)

    # Get parent body transform
    if parent_body >= 0:
        parent_tf = body_q[parent_body]
        # Transform joint to world space
        world_pos = wp.transform_point(parent_tf, joint_pos)
        world_rot = wp.mul(wp.transform_get_rotation(parent_tf), joint_rot)
        # Apply world offset
        parent_body_world = body_world[parent_body]
        if world_offsets and parent_body_world >= 0:
            world_pos += world_offsets[parent_body_world]
    else:
        world_pos = joint_pos
        world_rot = joint_rot

    # Apply layer transform
    world_pos = wp.transform_point(layer_xform, world_pos)
    world_rot = wp.mul(wp.transform_get_rotation(layer_xform), world_rot)

    # Determine scale based on child body shapes
    scale_factor = line_scale

    # Create the appropriate basis vector based on axis_id
    if axis_id == 0:  # X-axis (red)
        axis_vec = wp.quat_rotate(world_rot, wp.vec3(1.0, 0.0, 0.0))
        color = wp.vec3(1.0, 0.0, 0.0)
    elif axis_id == 1:  # Y-axis (green)
        axis_vec = wp.quat_rotate(world_rot, wp.vec3(0.0, 1.0, 0.0))
        color = wp.vec3(0.0, 1.0, 0.0)
    else:  # Z-axis (blue)
        axis_vec = wp.quat_rotate(world_rot, wp.vec3(0.0, 0.0, 1.0))
        color = wp.vec3(0.0, 0.0, 1.0)

    # Set line endpoints
    line_starts[tid] = world_pos
    line_ends[tid] = world_pos + axis_vec * scale_factor
    line_colors[tid] = color


@wp.kernel
def compute_com_positions(
    body_q: wp.array[wp.transform],
    body_com: wp.array[wp.vec3],
    body_world: wp.array[int],
    world_offsets: wp.array[wp.vec3],
    layer_xform: wp.transform,
    visible_worlds_mask: wp.array[int],
    com_positions: wp.array[wp.vec3],
):
    tid = wp.tid()

    # Filter by visible worlds
    world_idx = body_world[tid]
    if visible_worlds_mask:
        if world_idx >= 0:
            if visible_worlds_mask[world_idx] == 0:
                com_positions[tid] = wp.vec3(wp.nan, wp.nan, wp.nan)
                return

    body_tf = body_q[tid]
    world_com = wp.transform_point(body_tf, body_com[tid])
    if world_offsets and world_idx >= 0 and world_idx < world_offsets.shape[0]:
        world_com = world_com + world_offsets[world_idx]
    com_positions[tid] = wp.transform_point(layer_xform, world_com)


@wp.kernel
def compute_inertia_box_lines(
    body_q: wp.array[wp.transform],
    body_com: wp.array[wp.vec3],
    body_inertia: wp.array[wp.mat33],
    body_inv_mass: wp.array[float],
    body_world: wp.array[int],
    world_offsets: wp.array[wp.vec3],
    layer_xform: wp.transform,
    visible_worlds_mask: wp.array[int],
    color: wp.vec3,
    # outputs: 12 lines per body
    line_starts: wp.array[wp.vec3],
    line_ends: wp.array[wp.vec3],
    line_colors: wp.array[wp.vec3],
):
    """Compute wireframe edges for inertia boxes. 12 edges per body."""
    tid = wp.tid()
    body_id = tid // 12
    edge_id = tid % 12

    nan_line = wp.vec3(wp.nan, wp.nan, wp.nan)
    zero_color = wp.vec3(0.0, 0.0, 0.0)

    # Skip bodies from non-visible worlds
    world_idx = body_world[body_id]
    if visible_worlds_mask:
        if world_idx >= 0:
            if visible_worlds_mask[world_idx] == 0:
                line_starts[tid] = nan_line
                line_ends[tid] = nan_line
                line_colors[tid] = zero_color
                return

    inv_m = body_inv_mass[body_id]
    if inv_m == 0.0:
        line_starts[tid] = nan_line
        line_ends[tid] = nan_line
        line_colors[tid] = zero_color
        return

    # Compute principal inertia axes and extents
    rot, principal_inertia = wp.eig3(body_inertia[body_id])

    # Skip eigenvector rotation for near-isotropic inertia (e.g., cubes, spheres).
    # When eigenvalues are nearly equal, eig3 returns arbitrary eigenvectors
    # causing the wireframe box to appear randomly rotated.
    max_eig = wp.max(principal_inertia)
    min_eig = wp.min(principal_inertia)
    if min_eig > 0.0 and max_eig < 1.01 * min_eig:  # within 1% -> isotropic
        rot = wp.identity(3, float)
    elif min_eig > 0.0:
        # Stabilize for axisymmetric inertia (2 of 3 eigenvalues nearly equal, e.g. cylinders).
        # The two degenerate eigenvectors are arbitrary; rebuild a deterministic frame
        # from the unique eigenvector.
        d01 = wp.abs(principal_inertia[0] - principal_inertia[1])
        d02 = wp.abs(principal_inertia[0] - principal_inertia[2])
        d12 = wp.abs(principal_inertia[1] - principal_inertia[2])
        min_diff = wp.min(d01, wp.min(d02, d12))
        if min_diff < 0.01 * max_eig:  # within 1% -> axisymmetric
            # Identify unique eigenvector (column not in degenerate pair)
            if d12 <= d01 and d12 <= d02:  # e1 approx eq e2, unique = col 0
                u = wp.vec3(rot[0, 0], rot[1, 0], rot[2, 0])
            elif d02 <= d01:  # e0 approx eq e2, unique = col 1
                u = wp.vec3(rot[0, 1], rot[1, 1], rot[2, 1])
            else:  # e0 approx eq e1, unique = col 2
                u = wp.vec3(rot[0, 2], rot[1, 2], rot[2, 2])
            u = wp.normalize(u)

            # Deterministic orthonormal basis from unique axis
            v1, v2 = orthonormal_basis(u)

            # Assign columns as cyclic permutation of (u, v1, v2) to keep det=+1
            c0 = v1
            c1 = v2
            c2 = u
            if d12 <= d01 and d12 <= d02:  # unique col 0
                c0 = u
                c1 = v1
                c2 = v2
            elif d02 <= d01:  # unique col 1
                c0 = v2
                c1 = u
                c2 = v1
            # mat33(*v) unpacks vectors as rows; transpose to place them as columns
            rot = wp.transpose(wp.mat33(*c0, *c1, *c2))

    box_inertia = principal_inertia * inv_m * (12.0 / 8.0)
    sx = wp.sqrt(wp.abs(box_inertia[2] + box_inertia[1] - box_inertia[0]))
    sy = wp.sqrt(wp.abs(box_inertia[0] + box_inertia[2] - box_inertia[1]))
    sz = wp.sqrt(wp.abs(box_inertia[1] + box_inertia[0] - box_inertia[2]))

    # Box edges: pairs of corner indices
    # Corners: 0=(-,-,-) 1=(+,-,-) 2=(+,+,-) 3=(-,+,-)
    #          4=(-,-,+) 5=(+,-,+) 6=(+,+,+) 7=(-,+,+)
    # Bottom face edges (0-3), top face edges (4-7), vertical edges (8-11)
    c0x = float(0.0)
    c0y = float(0.0)
    c0z = float(0.0)
    c1x = float(0.0)
    c1y = float(0.0)
    c1z = float(0.0)

    if edge_id == 0:  # 0-1
        c0x = -sx
        c0y = -sy
        c0z = -sz
        c1x = sx
        c1y = -sy
        c1z = -sz
    elif edge_id == 1:  # 1-2
        c0x = sx
        c0y = -sy
        c0z = -sz
        c1x = sx
        c1y = sy
        c1z = -sz
    elif edge_id == 2:  # 2-3
        c0x = sx
        c0y = sy
        c0z = -sz
        c1x = -sx
        c1y = sy
        c1z = -sz
    elif edge_id == 3:  # 3-0
        c0x = -sx
        c0y = sy
        c0z = -sz
        c1x = -sx
        c1y = -sy
        c1z = -sz
    elif edge_id == 4:  # 4-5
        c0x = -sx
        c0y = -sy
        c0z = sz
        c1x = sx
        c1y = -sy
        c1z = sz
    elif edge_id == 5:  # 5-6
        c0x = sx
        c0y = -sy
        c0z = sz
        c1x = sx
        c1y = sy
        c1z = sz
    elif edge_id == 6:  # 6-7
        c0x = sx
        c0y = sy
        c0z = sz
        c1x = -sx
        c1y = sy
        c1z = sz
    elif edge_id == 7:  # 7-4
        c0x = -sx
        c0y = sy
        c0z = sz
        c1x = -sx
        c1y = -sy
        c1z = sz
    elif edge_id == 8:  # 0-4
        c0x = -sx
        c0y = -sy
        c0z = -sz
        c1x = -sx
        c1y = -sy
        c1z = sz
    elif edge_id == 9:  # 1-5
        c0x = sx
        c0y = -sy
        c0z = -sz
        c1x = sx
        c1y = -sy
        c1z = sz
    elif edge_id == 10:  # 2-6
        c0x = sx
        c0y = sy
        c0z = -sz
        c1x = sx
        c1y = sy
        c1z = sz
    elif edge_id == 11:  # 3-7
        c0x = -sx
        c0y = sy
        c0z = -sz
        c1x = -sx
        c1y = sy
        c1z = sz

    local0 = wp.vec3(c0x, c0y, c0z)
    local1 = wp.vec3(c1x, c1y, c1z)

    # Transform from inertia-principal frame to body COM frame
    inertia_rot = wp.quat_from_matrix(rot)
    local0 = wp.quat_rotate(inertia_rot, local0)
    local1 = wp.quat_rotate(inertia_rot, local1)

    # Transform from COM frame to world frame
    body_tf = body_q[body_id]
    body_rot = wp.transform_get_rotation(body_tf)
    body_pos = wp.transform_get_translation(body_tf)
    com = body_com[body_id]

    # COM offset in world frame
    world_com = body_pos + wp.quat_rotate(body_rot, com)

    world0 = world_com + wp.quat_rotate(body_rot, local0)
    world1 = world_com + wp.quat_rotate(body_rot, local1)

    # Apply world offset
    if world_offsets and world_idx >= 0 and world_idx < world_offsets.shape[0]:
        offset = world_offsets[world_idx]
        world0 = world0 + offset
        world1 = world1 + offset

    # Apply layer transform
    world0 = wp.transform_point(layer_xform, world0)
    world1 = wp.transform_point(layer_xform, world1)

    line_starts[tid] = world0
    line_ends[tid] = world1
    line_colors[tid] = color


@wp.func
def depth_to_color(depth: float, min_depth: float, max_depth: float) -> wp.vec3:
    """Convert depth value to a color using a blue-to-red colormap."""
    # Normalize depth to [0, 1]
    t = wp.clamp((depth - min_depth) / (max_depth - min_depth + 1e-8), 0.0, 1.0)
    # Blue (0,0,1) -> Cyan (0,1,1) -> Green (0,1,0) -> Yellow (1,1,0) -> Red (1,0,0)
    if t < 0.25:
        s = t / 0.25
        return wp.vec3(0.0, s, 1.0)
    elif t < 0.5:
        s = (t - 0.25) / 0.25
        return wp.vec3(0.0, 1.0, 1.0 - s)
    elif t < 0.75:
        s = (t - 0.5) / 0.25
        return wp.vec3(s, 1.0, 0.0)
    else:
        s = (t - 0.75) / 0.25
        return wp.vec3(1.0, 1.0 - s, 0.0)


@wp.kernel(enable_backward=False)
def compute_hydro_contact_surface_lines(
    triangle_vertices: wp.array[wp.vec3],
    face_depths: wp.array[wp.float32],
    face_shape_pairs: wp.array[wp.vec2i],
    shape_world: wp.array[int],
    world_offsets: wp.array[wp.vec3],
    layer_xform: wp.transform,
    visible_worlds_mask: wp.array[int],
    num_faces: int,
    min_depth: float,
    max_depth: float,
    penetrating_only: bool,
    line_starts: wp.array[wp.vec3],
    line_ends: wp.array[wp.vec3],
    line_colors: wp.array[wp.vec3],
):
    """Convert hydroelastic contact surface triangle vertices to line segments for wireframe rendering."""
    tid = wp.tid()
    if tid >= num_faces:
        return

    zero = wp.vec3(0.0, 0.0, 0.0)

    # Filter by visible worlds
    if visible_worlds_mask and shape_world:
        shape_pair = face_shape_pairs[tid]
        world_a = shape_world[shape_pair[0]]
        world_b = shape_world[shape_pair[1]]
        w = world_a if world_a >= 0 else world_b
        if w >= 0:
            if visible_worlds_mask[w] == 0:
                line_starts[tid * 3 + 0] = zero
                line_ends[tid * 3 + 0] = zero
                line_colors[tid * 3 + 0] = zero
                line_starts[tid * 3 + 1] = zero
                line_ends[tid * 3 + 1] = zero
                line_colors[tid * 3 + 1] = zero
                line_starts[tid * 3 + 2] = zero
                line_ends[tid * 3 + 2] = zero
                line_colors[tid * 3 + 2] = zero
                return

    # Get the 3 vertices of this triangle
    v0 = triangle_vertices[tid * 3 + 0]
    v1 = triangle_vertices[tid * 3 + 1]
    v2 = triangle_vertices[tid * 3 + 2]

    # Compute color from depth (standard convention: negative = penetrating)
    depth = face_depths[tid]

    # Skip non-penetrating contacts if requested (only render depth < 0)
    if penetrating_only and depth >= 0.0:
        line_starts[tid * 3 + 0] = zero
        line_ends[tid * 3 + 0] = zero
        line_colors[tid * 3 + 0] = zero
        line_starts[tid * 3 + 1] = zero
        line_ends[tid * 3 + 1] = zero
        line_colors[tid * 3 + 1] = zero
        line_starts[tid * 3 + 2] = zero
        line_ends[tid * 3 + 2] = zero
        line_colors[tid * 3 + 2] = zero
        return

    # Apply world offset if available
    offset = wp.vec3(0.0, 0.0, 0.0)
    if shape_world and world_offsets:
        shape_pair = face_shape_pairs[tid]
        world_a = shape_world[shape_pair[0]]
        world_b = shape_world[shape_pair[1]]
        if world_a >= 0 or world_b >= 0:
            offset = world_offsets[world_a if world_a >= 0 else world_b]

    v0 = wp.transform_point(layer_xform, v0 + offset)
    v1 = wp.transform_point(layer_xform, v1 + offset)
    v2 = wp.transform_point(layer_xform, v2 + offset)

    # Use penetration magnitude (negated depth) for color - deeper = more red
    if depth < 0.0:
        color = depth_to_color(-depth, min_depth, max_depth)
    else:
        color = wp.vec3(0.0, 0.0, 0.0)

    # Each triangle produces 3 line segments (edges)
    # Edge 0: v0 -> v1
    line_starts[tid * 3 + 0] = v0
    line_ends[tid * 3 + 0] = v1
    line_colors[tid * 3 + 0] = color

    # Edge 1: v1 -> v2
    line_starts[tid * 3 + 1] = v1
    line_ends[tid * 3 + 1] = v2
    line_colors[tid * 3 + 1] = color

    # Edge 2: v2 -> v0
    line_starts[tid * 3 + 2] = v2
    line_ends[tid * 3 + 2] = v0
    line_colors[tid * 3 + 2] = color


@wp.kernel
def build_active_particle_mask(
    flags: wp.array[wp.int32],
    mask: wp.array[wp.int32],
):
    i = wp.tid()
    if (flags[i] & newton.ParticleFlags.ACTIVE) != wp.int32(0):
        mask[i] = wp.int32(1)
    else:
        mask[i] = wp.int32(0)


@wp.kernel
def compact(
    src: wp.array[Any],
    mask: wp.array[wp.int32],
    offsets: wp.array[wp.int32],
    dst: wp.array[Any],
):
    i = wp.tid()
    if mask[i] == wp.int32(1):
        dst[offsets[i]] = src[i]


@wp.kernel
def transform_points(
    points: wp.array[wp.vec3],
    xform: wp.transform,
    transformed_points: wp.array[wp.vec3],
):
    i = wp.tid()
    transformed_points[i] = wp.transform_point(xform, points[i])

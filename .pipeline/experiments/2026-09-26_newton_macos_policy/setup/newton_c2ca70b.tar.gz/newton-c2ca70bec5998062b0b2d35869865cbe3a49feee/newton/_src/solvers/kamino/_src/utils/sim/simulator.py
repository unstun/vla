# SPDX-FileCopyrightText: Copyright (c) 2025 The Newton Developers
# SPDX-License-Identifier: Apache-2.0

"""Provides a high-level interface for physics simulation."""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass, field

import warp as wp

import newton

from ....solver_kamino import SolverKamino
from ...core.control import ControlKamino
from ...core.model import ModelKamino
from ...core.state import StateKamino
from ...core.types import FloatArrayLike
from ...geometry import CollisionDetector
from ...solver_kamino_impl import SolverKaminoImpl

###
# Module interface
###

__all__ = [
    "Simulator",
    "SimulatorData",
]


###
# Module configs
###

wp.set_module_options({"enable_backward": False})


###
# Types
###


class SimulatorData:
    """
    Holds the time-varying data for the simulation.

    Attributes:
        state_p: The previous state data of the simulation.
        state_n: The current state data of the simulation, computed from the previous step as:
            ``state_n = f(state_p, control)``, where ``f()`` is the system dynamics function.
        control: The control data, computed at each step as:
            ``control = g(state_n, state_p, control)``, where ``g()`` is the control function.
    """

    def __init__(self, model: ModelKamino):
        """
        Initializes the simulator data for the given model on the specified device.
        """
        self.state_p: StateKamino = model.state(device=model.device)
        self.state_n: StateKamino = model.state(device=model.device)
        self.control: ControlKamino = model.control(device=model.device)

    def cache_state(self):
        """
        Updates the previous-step caches of the state and control data from the next-step.
        """
        self.state_p.copy_from(self.state_n)


###
# Interfaces
###


class Simulator:
    """
    A high-level interface for executing physics simulations using Kamino.

    The Simulator class encapsulates the entire simulation pipeline, including model definition,
    state management, collision detection, constraint handling, and time integration.

    A Simulator is typically instantiated from a :class:`newton.Model` that defines the model
    to be simulated. The simulator manages the time-stepping loop, invoking callbacks at various
    stages of the simulation step, and provides access to the current state and control inputs.

    Example:
    ```python
        # Create a model builder and define the model
        builder = newton.ModelBuilder()

        # Define the model components (e.g., bodies, joints, collision geometries etc.)
        builder.add_rigid_body(...)
        builder.add_joint(...)
        builder.add_geometry(...)

        # Create model from the builder
        model = builder.finalize()

        # Create the simulator from the model
        simulator = Simulator(model)

        # Run the simulation for a specified number of steps
        for _i in range(num_steps):
            simulator.step()
    ```
    """

    @dataclass
    class Config:
        """
        Holds the configuration for the simulator.
        """

        dt: float | FloatArrayLike = 0.001
        """
        The time-step to be used for the simulation.
        Defaults to `0.001` seconds.
        """

        collision_detector: CollisionDetector.Config = field(default_factory=CollisionDetector.Config)
        """
        The config for the collision detector.
        See :class:`CollisionDetector.Config` for more details.
        """

        solver: SolverKaminoImpl.Config = field(default_factory=SolverKaminoImpl.Config)
        """
        The config for the dynamics solver.
        See :class:`SolverKaminoImpl.Config` for more details.
        """

        def validate(self) -> None:
            """
            Validates the simulator configurations.
            """
            # First check the time-step
            if isinstance(self.dt, float):
                if self.dt != self.dt:
                    raise ValueError("Invalid time-step: cannot be NaN.")
                if self.dt <= 0.0:
                    raise ValueError(f"Invalid time-step: got {self.dt}, but must be a positive value.")
            elif isinstance(self.dt, FloatArrayLike):
                if len(self.dt) == 0:
                    raise ValueError("Invalid time-step array: cannot be empty.")
                elif any(dt <= 0.0 or dt != dt for dt in self.dt):
                    raise ValueError("Invalid time-step array: all values must be positive and non-NaN.")
                elif not all(isinstance(dt, float) for dt in self.dt):
                    raise TypeError("Invalid time-step array: all values must be of type float.")
            else:
                raise TypeError("Invalid time-step: must be a `float` or a `FloatArrayLike`.`")

            # Ensure nested configs are properly created
            if not isinstance(self.collision_detector, CollisionDetector.Config):
                raise TypeError(f"Invalid type for collision_detector config: {type(self.collision_detector)}")
            if not isinstance(self.solver, SolverKaminoImpl.Config):
                raise TypeError(f"Invalid type for solver config: {type(self.solver)}")

            # Then check the nested config values
            self.collision_detector.validate()
            self.solver.validate()

        def __post_init__(self):
            """Post-initialization processing to ensure nested configs are properly created."""
            self.validate()

    SimCallbackType = Callable[["Simulator"], None]
    """Defines a common type signature for all simulator callback functions."""

    def __init__(
        self,
        model: newton.Model,
        config: Simulator.Config = None,
    ):
        """
        Initializes the simulator with the given model builder, time-step, and device.

        Args:
            model: The model to be simulated.
            config: The simulator config to use. If None, the default config are used.
        """
        # Cache simulator config: If no config is provided, use default configs
        if config is None:
            config = Simulator.Config()
        config.validate()
        self._config: Simulator.Config = config

        # Cache the target model for the simulation
        self._model_newton = model
        self._model = ModelKamino.from_newton(self._model_newton)

        # Configure model time-steps across all worlds
        if isinstance(self._config.dt, float):
            self.model.time.set_uniform_timestep(self._config.dt)
        elif isinstance(self._config.dt, FloatArrayLike):
            self.model.time.set_timesteps(self._config.dt)

        # Allocate time-varying simulation data
        self._data = SimulatorData(model=self.model)

        # Allocate collision detection and contacts interface
        self._collision_detector = CollisionDetector(
            model=self.model,
            config=self._config.collision_detector,
        )

        # Capture a reference to the contacts manager
        self._contacts = self._collision_detector.contacts

        # Define a physics solver for time-stepping
        self._solver = SolverKaminoImpl(
            model=self.model,
            contacts=self.contacts,
            config=self._config.solver,
        )

        # Initialize callbacks
        self._pre_reset_cb: Simulator.SimCallbackType = None
        self._post_reset_cb: Simulator.SimCallbackType = None
        self._control_cb: Simulator.SimCallbackType = None

        # Initialize the simulation state
        self.reset()

    ###
    # Properties
    ###

    @property
    def config(self) -> Simulator.Config:
        """
        Returns the simulator config.
        """
        return self._config

    @property
    def model(self) -> ModelKamino:
        """
        Returns the Kamino simulation model.
        """
        return self._model

    @property
    def model_newton(self) -> newton.Model:
        """
        Returns the Newton simulation model.
        """
        return self._model_newton

    @property
    def data(self) -> SimulatorData:
        """
        Returns the simulation data container.
        """
        return self._data

    @property
    def state(self) -> StateKamino:
        """
        Returns the current state of the simulation.
        """
        return self._data.state_n

    @property
    def state_previous(self) -> StateKamino:
        """
        Returns the previous state of the simulation.
        """
        return self._data.state_p

    @property
    def control(self) -> ControlKamino:
        """
        Returns the current control inputs of the simulation.
        """
        return self._data.control

    @property
    def limits(self):
        """
        Returns the limits container of the simulation.
        """
        return self._solver._limits

    @property
    def contacts(self):
        """
        Returns the contacts container of the simulation.
        """
        return self._contacts

    @property
    def metrics(self):
        """
        Returns the current simulation metrics.
        """
        return self._solver.metrics

    @property
    def collision_detector(self) -> CollisionDetector:
        """
        Returns the collision detector.
        """
        return self._collision_detector

    @property
    def solver(self) -> SolverKaminoImpl:
        """
        Returns the physics step solver.
        """
        return self._solver

    @property
    def device(self) -> wp.DeviceLike:
        """
        Returns the device on which the simulation data is allocated.
        """
        return self._model.device

    ###
    # Configurations - Callbacks
    ###

    def set_pre_reset_callback(self, callback: SimCallbackType):
        """
        Sets a reset callback to be called at the beginning of each call to `reset_*()` methods.
        """
        self._pre_reset_cb = callback

    def set_post_reset_callback(self, callback: SimCallbackType):
        """
        Sets a reset callback to be called at the end of each call to to `reset_*()` methods.
        """
        self._post_reset_cb = callback

    def set_control_callback(self, callback: SimCallbackType):
        """
        Sets a control callback to be called at the beginning of the step, that
        should populate `data.control`, i.e. the control inputs for the current
        step, based on the current and previous states and controls.
        """
        self._control_cb = callback

    ###
    # Operations
    ###

    def reset(
        self,
        world_mask: wp.array[wp.bool] | None = None,
        config: SolverKamino.ResetConfig | None = None,
    ):
        """
        Performs a configurable in-place reset of the simulation state, in all or a subset
        of worlds, setting body poses and velocities selectively to default or current values,
        or as per joint coordinates/velocities, using a forward kinematics solve.
        This is optionally combined with a reset of the pose and velocity of the floating base.

        All state components are reset consistently with the new body poses and velocities
        (unless prescribed otherwise by state flags), and solver-internal buffers are cleared.

        Args:
            world_mask: Optional array of per-world masks indicating which
                worlds should be reset.
                Shape of ``(num_worlds,)``.
            config: Optional reset configuration, controlling the reset behavior
                for body poses/velocities as well as floating base pose/velocity.
                If not provided, all components are reset to default (initial) values.
        """
        # Run the pre-reset callback if it has been set
        if self._pre_reset_cb is not None:
            self._pre_reset_cb(self)

        # Reset the physics solver
        self._solver.reset(
            state=self._data.state_n,
            world_mask=world_mask,
            config=config,
        )

        # Cache the current state as the previous state for the next step
        self._data.cache_state()

        # Run the post-reset callback if it has been set
        if self._post_reset_cb is not None:
            self._post_reset_cb(self)

    def step(self):
        """
        Advances the simulation by a single time-step.
        """
        # Run the control callback if it has been set
        if self._control_cb is not None:
            self._control_cb(self)

        # Cache the current state as the previous state for the next step
        self._data.cache_state()

        # Step the physics solver
        self._solver.step(
            state_in=self._data.state_p,
            state_out=self._data.state_n,
            control=self._data.control,
            contacts=self._contacts,
            detector=self._collision_detector,
        )

# SPDX-FileCopyrightText: Copyright (c) 2025 The Newton Developers
# SPDX-License-Identifier: Apache-2.0

from __future__ import annotations

import collections
import inspect
import os
import warnings
from pathlib import Path
from typing import Any, ClassVar
from urllib.parse import urlparse

import numpy as np
import warp as wp

import newton

from ..core.types import override
from .utils import prepare_viewer_texture, promote_to_clamped_float_array, to_numpy
from .viewer import ViewerBase, is_jupyter_notebook


class ViewerViser(ViewerBase):
    """
    ViewerViser provides a backend for visualizing Newton simulations using the viser library.

    Viser is a Python library for interactive 3D visualization in the browser. This viewer
    launches a web server and renders simulation geometry via WebGL. It supports both
    standalone browser viewing and Jupyter notebook integration.

    Features:
        - Real-time 3D visualization in any web browser
        - Jupyter notebook integration with inline display
        - Static HTML export for sharing visualizations
        - Interactive camera controls
    """

    _viser_module = None
    _SH_C0 = 0.28209479177387814

    @classmethod
    def _get_viser(cls):
        """Lazily import and return the viser module."""
        if cls._viser_module is None:
            try:
                import viser

                cls._viser_module = viser
            except ImportError as e:
                raise ImportError("viser package is required for ViewerViser. Install with: pip install viser") from e
        return cls._viser_module

    @staticmethod
    def _build_trimesh_mesh(points: np.ndarray, indices: np.ndarray, uvs: np.ndarray, texture: np.ndarray):
        """Create a trimesh object with texture visuals (if trimesh is available)."""
        try:
            import trimesh
        except Exception:
            return None

        if len(uvs) != len(points):
            return None

        faces = indices.astype(np.int64)
        mesh = trimesh.Trimesh(vertices=points, faces=faces, process=False)

        try:
            from PIL import Image
            from trimesh.visual.texture import TextureVisuals

            image = Image.fromarray(texture)
            mesh.visual = TextureVisuals(uv=uvs, image=image)
        except Exception:
            visual_mod = getattr(trimesh, "visual", None)
            TextureVisuals = getattr(visual_mod, "TextureVisuals", None) if visual_mod is not None else None
            if TextureVisuals is not None:
                mesh.visual = TextureVisuals(uv=uvs, image=texture)

        return mesh

    def __init__(
        self,
        *,
        port: int = 8080,
        label: str | None = None,
        verbose: bool = True,
        share: bool = False,
        record_to_viser: str | None = None,
        plot_history_size: int = 250,
    ):
        """
        Initialize the ViewerViser backend for Newton using the viser visualization library.

        This viewer supports both standalone browser viewing and Jupyter notebook environments.
        It launches a web server that serves an interactive 3D visualization.

        Args:
            port: Port number for the web server. Defaults to 8080.
            label: Optional label for the viser server window title.
            verbose: If True, print the server URL when starting. Defaults to True.
            share: If True, create a publicly accessible URL via viser's share feature.
            record_to_viser: Path to record the viewer to a ``*.viser`` recording file
                (e.g. "my_recording.viser"). If None, the viewer will not record to a file.
            plot_history_size: Maximum number of samples kept per
                :meth:`log_scalar` signal for the live time-series plots.
        """
        if not isinstance(plot_history_size, int) or isinstance(plot_history_size, bool):
            raise TypeError("plot_history_size must be an integer")
        if plot_history_size <= 0:
            raise ValueError("plot_history_size must be > 0")

        viser = self._get_viser()

        # Rolling buffers for log_scalar() time-series plots.
        self._scalar_buffers: dict[str, collections.deque] = {}
        self._scalar_accumulators: dict[str, list[float]] = {}
        self._scalar_smoothing: dict[str, int] = {}
        self._scalar_dirty: set[str] = set()
        self._plot_handles: dict[str, Any] = {}
        self._plot_folder: Any = None
        self._plot_history_size = plot_history_size
        self._plane_meshes = {}
        self._plane_handles = {}
        self._plane_geometry_keys = {}  # Cache of (count, widths, lengths, cell_sizes) per plane batch name

        super().__init__()

        self._running = True
        self.verbose = verbose

        # Store mesh data for instances
        self._meshes = {}
        self._instances = {}
        self._scene_handles = {}  # Track viser scene node handles
        self._gaussian_splats = {}  # Track cached Gaussian splat upload keys, by name
        self._line_segment_counts = {}
        self._line_versions = {}

        # Initialize viser server
        self._server = viser.ViserServer(port=port, label=label or "Newton Viewer")
        self._camera_request: tuple[np.ndarray, np.ndarray, np.ndarray] | None = None
        self._pending_camera_clients: set[int] = set()
        self._server.on_client_connect(self._handle_client_connect)
        self._server.on_client_disconnect(self._handle_client_disconnect)

        # Store configuration before any URL generation.
        self._port = port
        self.is_jupyter_notebook = is_jupyter_notebook()

        if share:
            self._share_url = self._server.request_share_url()
            if verbose:
                print(f"Viser share URL: {self._share_url}")
        else:
            self._share_url = None

        if verbose:
            print(f"Viser server running at: {self.url}")

        # Recording state
        self._frame_dt = 0.0
        self._record_to_viser = record_to_viser
        self._serializer = self._server.get_scene_serializer() if record_to_viser else None

        # Set up default scene
        self._setup_scene()

        if self._serializer is not None and verbose:
            print(f"Recording to: {record_to_viser}")

    @override
    def clear_model(self):
        """Reset model-dependent state, including scalar plot buffers."""
        owns = self._is_layer_owned_path
        for plane_name in list(self._plane_handles.keys()):
            if owns(plane_name):
                self._remove_plane_handles(plane_name)
        self._plane_meshes = {name: value for name, value in self._plane_meshes.items() if not owns(name)}

        for gaussian_name in list(getattr(self, "_gaussian_splats", {}).keys()):
            if owns(gaussian_name):
                handle = self._scene_handles.pop(gaussian_name, None)
                if handle is not None:
                    try:
                        handle.remove()
                    except Exception:
                        pass
                self._gaussian_splats.pop(gaussian_name, None)

        for name, handle in list(getattr(self, "_scene_handles", {}).items()):
            if not owns(name):
                continue
            try:
                handle.remove()
            except Exception:
                pass
            self._scene_handles.pop(name, None)
            self._instances.pop(name, None)
            self._meshes.pop(name, None)
            self._gaussian_splats.pop(name, None)
            self._line_segment_counts.pop(name, None)
            self._line_versions.pop(name, None)

        # Remove only scalar plot state owned by the active layer.
        for name, handle in list(self._plot_handles.items()):
            if not owns(name):
                continue
            try:
                handle.remove()
            except Exception:
                pass
            self._plot_handles.pop(name, None)
        if not self._plot_handles and self._plot_folder is not None:
            try:
                self._plot_folder.remove()
            except Exception:
                pass
            self._plot_folder = None
        for name in list(self._scalar_buffers.keys()):
            if owns(name):
                self._scalar_buffers.pop(name, None)
                self._scalar_accumulators.pop(name, None)
                self._scalar_smoothing.pop(name, None)
        for name in list(self._scalar_dirty):
            if owns(name):
                self._scalar_dirty.discard(name)

        super().clear_model()

    def _setup_scene(self):
        """Set up the default scene configuration."""

        self._server.scene.add_light_ambient("ambient_light")

        # remove HDR map
        self._server.scene.configure_environment_map(hdri=None)

    @staticmethod
    def _call_scene_method(method, **kwargs):
        """Call a viser scene method with only supported keyword args."""
        try:
            signature = inspect.signature(method)
        except (TypeError, ValueError):
            return method(**kwargs)

        accepts_kwargs = any(param.kind == inspect.Parameter.VAR_KEYWORD for param in signature.parameters.values())
        allowed = kwargs if accepts_kwargs else {k: v for k, v in kwargs.items() if k in signature.parameters}
        dropped_appearance = [
            key
            for key in ("opacity", "batched_opacities", "color", "batched_colors", "material")
            if kwargs.get(key) is not None and key not in signature.parameters and not accepts_kwargs
        ]
        if dropped_appearance:
            warnings.warn(
                f"Viser {method.__name__} does not support requested appearance argument(s): "
                f"{', '.join(dropped_appearance)}.",
                stacklevel=2,
            )
        return method(**allowed)

    @property
    def url(self) -> str:
        """Get the browser URL of the viser server.

        Returns:
            str: Browser URL for the running viser server.
        """
        if self.is_jupyter_notebook:
            return self._build_browser_url(self._port)
        return f"http://localhost:{self._port}"

    @staticmethod
    def _normalize_jupyter_base_url(base_url: str) -> str:
        """Normalize a Jupyter base URL for proxy path construction."""
        if not base_url:
            return ""
        if not base_url.startswith("/"):
            base_url = "/" + base_url
        if base_url != "/":
            return base_url.rstrip("/")
        return ""

    @classmethod
    def _get_jupyter_proxy_base_url(cls) -> str | None:
        """Return the Jupyter base URL when notebook proxying is available."""
        try:
            from importlib.util import find_spec  # noqa: PLC0415

            if find_spec("jupyter_server_proxy") is None:
                return None
        except Exception:
            return None

        # JUPYTER_BASE_URL is not always exported (e.g. CLI --NotebookApp.base_url).
        for env_name in ("JUPYTER_BASE_URL", "JUPYTERHUB_SERVICE_PREFIX", "NB_PREFIX"):
            candidate = os.environ.get(env_name)
            if candidate:
                return cls._normalize_jupyter_base_url(candidate)

        try:
            from jupyter_server.serverapp import list_running_servers  # noqa: PLC0415

            for server in list_running_servers():
                candidate = server.get("base_url")
                if candidate:
                    return cls._normalize_jupyter_base_url(candidate)
        except Exception:
            pass

        return None

    @classmethod
    def _build_browser_url(
        cls,
        port: int,
        *,
        path: str = "/",
        query: str = "",
        local_host: str = "localhost",
    ) -> str:
        """Build a browser URL, preferring Jupyter proxy routes when available."""
        normalized_path = "/" if path in ("", "/") else "/" + path.lstrip("/")

        jupyter_base_url = cls._get_jupyter_proxy_base_url()
        if jupyter_base_url is not None:
            return f"{jupyter_base_url}/proxy/{port}{normalized_path}{query}"

        return f"http://{local_host}:{port}{normalized_path}{query}"

    @staticmethod
    def _get_colab_output() -> Any | None:
        """Return google.colab.output when Colab iframe display is available."""
        try:
            from google.colab import output  # noqa: PLC0415
        except Exception:
            return None

        if not hasattr(output, "serve_kernel_port_as_iframe"):
            return None

        return output

    @classmethod
    def _display_colab_iframe(
        cls,
        port: int,
        *,
        path: str = "/",
        query: str = "",
        width: int | str = "100%",
        height: int | str = 400,
    ) -> bool:
        """Display a local server port in Colab when the Colab helper is available."""
        output = cls._get_colab_output()
        if output is None:
            return False

        normalized_path = "/" if path in ("", "/") else "/" + path.lstrip("/")
        normalized_query = ""
        if query:
            normalized_query = query if query.startswith("?") else "?" + query
        iframe_path = f"{normalized_path}{normalized_query}"

        try:
            output.serve_kernel_port_as_iframe(port, path=iframe_path, width=width, height=height)
        except TypeError:
            output.serve_kernel_port_as_iframe(port, path=iframe_path, height=height)

        return True

    @classmethod
    def _colab_iframe_target_from_url(cls, player_url: str) -> tuple[int, str, str] | None:
        """Extract a Colab iframe target from an absolute or Jupyter proxy URL."""
        parsed_url = urlparse(player_url)

        proxy_target = None
        path_segments = parsed_url.path.split("/")
        for index, segment in enumerate(path_segments[:-1]):
            if segment != "proxy":
                continue

            port_text = path_segments[index + 1]
            if not port_text.isdecimal():
                continue

            proxy_port = int(port_text)
            if proxy_port > 65535:
                continue

            downstream_segments = path_segments[index + 2 :]
            if not downstream_segments or downstream_segments == [""]:
                downstream_path = "/"
            else:
                downstream_path = "/" + "/".join(downstream_segments)
            proxy_target = (proxy_port, downstream_path, parsed_url.query)

        if proxy_target is not None:
            return proxy_target

        try:
            parsed_port = parsed_url.port
        except ValueError:
            parsed_port = None

        if parsed_port is not None:
            return parsed_port, parsed_url.path or "/", parsed_url.query

        return None

    @classmethod
    def get_viser_client_dir(cls) -> Path:
        """Return the installed Viser client build for notebook playback."""
        viser = cls._get_viser()

        try:
            viser_package_dir = Path(inspect.getfile(viser)).resolve().parent
        except Exception:
            viser_package_dir = None

        if viser_package_dir is not None:
            # Prefer the client build shipped with the installed viser package so
            # the playback UI matches the serializer that generated the .viser file.
            for candidate in (
                viser_package_dir / "client" / "build",
                viser_package_dir / "static",
            ):
                if (candidate / "index.html").exists():
                    return candidate.resolve()

        raise FileNotFoundError(
            "Viser client files not found in the installed viser package. "
            "The notebook playback feature requires a Viser client build."
        )

    @staticmethod
    def _is_client_camera_ready(client: Any) -> bool:
        """Return True if the client has reported an initial camera state."""
        try:
            update_timestamp = float(client.camera.update_timestamp)
        except Exception:
            # Older viser versions may not expose update_timestamp.
            try:
                _ = client.camera.position
            except Exception:
                return False
            return True
        return update_timestamp > 0.0

    def _handle_client_connect(self, client: Any):
        """Apply cached camera settings to newly connected clients."""
        self._pending_camera_clients.discard(int(client.client_id))
        self._apply_camera_to_client(client)

    def _handle_client_disconnect(self, client: Any):
        """Clear pending camera state for disconnected clients."""
        self._pending_camera_clients.discard(int(client.client_id))

    def _get_camera_up_axis(self) -> int:
        """Resolve the model up-axis as an integer index (0, 1, 2)."""
        if self.model is None:
            return 2
        up_axis = self.model.up_axis
        if isinstance(up_axis, str):
            return "XYZ".index(up_axis.upper())
        return int(up_axis)

    def _compute_camera_front_up(self, pitch: float, yaw: float) -> tuple[np.ndarray, np.ndarray]:
        """Compute camera front and up vectors from pitch/yaw angles."""
        pitch = float(np.clip(pitch, -89.0, 89.0))
        yaw = float(yaw)
        pitch_rad = np.deg2rad(pitch)
        yaw_rad = np.deg2rad(yaw)
        up_axis = self._get_camera_up_axis()

        if up_axis == 0:  # X up
            front = np.array(
                [
                    np.sin(pitch_rad),
                    np.cos(yaw_rad) * np.cos(pitch_rad),
                    np.sin(yaw_rad) * np.cos(pitch_rad),
                ],
                dtype=np.float64,
            )
            world_up = np.array([1.0, 0.0, 0.0], dtype=np.float64)
        elif up_axis == 2:  # Z up
            front = np.array(
                [
                    np.cos(yaw_rad) * np.cos(pitch_rad),
                    np.sin(yaw_rad) * np.cos(pitch_rad),
                    np.sin(pitch_rad),
                ],
                dtype=np.float64,
            )
            world_up = np.array([0.0, 0.0, 1.0], dtype=np.float64)
        else:  # Y up
            front = np.array(
                [
                    np.cos(yaw_rad) * np.cos(pitch_rad),
                    np.sin(pitch_rad),
                    np.sin(yaw_rad) * np.cos(pitch_rad),
                ],
                dtype=np.float64,
            )
            world_up = np.array([0.0, 1.0, 0.0], dtype=np.float64)

        front /= np.linalg.norm(front)
        right = np.cross(front, world_up)
        right_norm = np.linalg.norm(right)
        if right_norm < 1.0e-8:
            fallback_up = np.array([0.0, 1.0, 0.0], dtype=np.float64)
            if np.linalg.norm(np.cross(front, fallback_up)) < 1.0e-8:
                fallback_up = np.array([0.0, 0.0, 1.0], dtype=np.float64)
            right = np.cross(front, fallback_up)
            right_norm = np.linalg.norm(right)
        right /= right_norm

        up = np.cross(right, front)
        up /= np.linalg.norm(up)
        return front, up

    def _apply_camera_to_client(self, client: Any):
        """Apply the cached camera request to a connected client if ready."""
        if self._camera_request is None:
            return

        client_id = int(client.client_id)
        if not self._is_client_camera_ready(client):
            if client_id in self._pending_camera_clients:
                return

            self._pending_camera_clients.add(client_id)

            def _on_camera_update(_camera: Any):
                if client_id not in self._pending_camera_clients:
                    return
                self._pending_camera_clients.discard(client_id)
                self._apply_camera_to_client(client)

            client.camera.on_update(_on_camera_update)
            return

        self._pending_camera_clients.discard(client_id)
        position, look_at, up_direction = self._camera_request

        # Keep camera updates synchronized to avoid transient jitter.
        if hasattr(client, "atomic"):
            with client.atomic():
                client.camera.position = tuple(position.tolist())
                client.camera.look_at = tuple(look_at.tolist())
                client.camera.up_direction = tuple(up_direction.tolist())
        else:
            client.camera.position = tuple(position.tolist())
            client.camera.look_at = tuple(look_at.tolist())
            client.camera.up_direction = tuple(up_direction.tolist())

    @override
    def set_camera(self, pos: wp.vec3, pitch: float, yaw: float):
        """Set camera position and orientation for connected Viser clients.

        The requested view is also cached so that newly connected clients receive
        the same camera setup as soon as they report camera state.

        Args:
            pos: Requested camera position.
            pitch: Requested camera pitch angle.
            yaw: Requested camera yaw angle.
        """
        position = np.asarray((float(pos[0]), float(pos[1]), float(pos[2])), dtype=np.float64)
        front, up_direction = self._compute_camera_front_up(pitch, yaw)
        look_at = position + front
        self._camera_request = (position, look_at, up_direction)

        if hasattr(self._server, "initial_camera"):
            self._server.initial_camera.position = tuple(position.tolist())
            self._server.initial_camera.look_at = tuple(look_at.tolist())
            if hasattr(self._server.initial_camera, "up"):
                self._server.initial_camera.up = tuple(up_direction.tolist())
            elif hasattr(self._server.initial_camera, "up_direction"):
                self._server.initial_camera.up_direction = tuple(up_direction.tolist())

        for client in self._server.get_clients().values():
            self._apply_camera_to_client(client)

    @staticmethod
    def _camera_query_from_request(camera_request: tuple[np.ndarray, np.ndarray, np.ndarray] | None) -> str:
        """Build URL query parameters for playback initial camera overrides."""
        if camera_request is None:
            return ""

        position, look_at, up_direction = camera_request

        def _format_vec3(values: np.ndarray) -> str:
            values = np.asarray(values, dtype=np.float64).reshape(3)
            return ",".join(f"{float(v):.9g}" for v in values)

        return (
            f"&initialCameraPosition={_format_vec3(position)}"
            f"&initialCameraLookAt={_format_vec3(look_at)}"
            f"&initialCameraUp={_format_vec3(up_direction)}"
        )

    @override
    def log_mesh(
        self,
        name: str,
        points: wp.array[wp.vec3],
        indices: wp.array[wp.int32] | wp.array[wp.uint32],
        normals: wp.array[wp.vec3] | None = None,
        uvs: wp.array[wp.vec2] | None = None,
        texture: np.ndarray | str | None = None,
        hidden: bool = False,
        backface_culling: bool = True,
        color: tuple[float, float, float] | None = None,
        roughness: float | None = None,
        metallic: float | None = None,
        dynamic: bool = False,
        opacity: float | None = None,
    ):
        """
        Log a mesh to viser for visualization.

        Args:
            name: Entity path for the mesh.
            points: Vertex positions.
            indices: Triangle indices.
            normals: Vertex normals, unused in viser.
            uvs: UV coordinates, used for textures if supported.
            texture: Texture path/URL or image array (H, W, C).
            hidden: Whether the mesh is hidden.
            backface_culling: Whether to enable backface culling.
            color: Optional base color as an RGB tuple with values in
                [0, 1]. Used when no texture is provided.
            roughness: Surface roughness in ``[0, 1]``. ``0`` is perfectly
                smooth, ``1`` is fully rough.
            metallic: Metallicity in ``[0, 1]``. ``0`` is dielectric, ``1``
                is metal.
            dynamic: Whether mesh topology may change between frames.
            opacity: Optional display opacity in [0, 1].
        """
        name = self._qualify(name)

        assert isinstance(points, wp.array)
        assert isinstance(indices, wp.array)

        # Convert to numpy arrays
        points_np = to_numpy(points).astype(np.float32)
        indices_np = to_numpy(indices).astype(np.uint32)
        uvs_np = to_numpy(uvs).astype(np.float32) if uvs is not None else None
        texture_image = prepare_viewer_texture(texture)

        if texture_image is not None and uvs_np is None:
            warnings.warn(f"Mesh {name} has a texture but no UVs; texture will be ignored.", stacklevel=2)
            texture_image = None
        if texture_image is not None and uvs_np is not None and len(uvs_np) != len(points_np):
            warnings.warn(
                f"Mesh {name} has {len(uvs_np)} UVs for {len(points_np)} vertices; texture will be ignored.",
                stacklevel=2,
            )
            texture_image = None

        # Viser expects indices as (N, 3) for triangles
        if indices_np.ndim == 1:
            indices_np = indices_np.reshape(-1, 3)

        trimesh_mesh = None
        if texture_image is not None and uvs_np is not None:
            trimesh_mesh = self._build_trimesh_mesh(points_np, indices_np, uvs_np, texture_image)
            if trimesh_mesh is None:
                warnings.warn(
                    "Viser textured meshes require trimesh; falling back to untextured rendering.",
                    stacklevel=2,
                )

        # Store mesh data for instancing
        self._meshes[name] = {
            "points": points_np,
            "indices": indices_np,
            "uvs": uvs_np,
            "texture": texture_image,
            "trimesh": trimesh_mesh,
            "opacity": opacity,
        }

        # Remove existing mesh if present
        if name in self._scene_handles:
            try:
                self._scene_handles[name].remove()
            except Exception:
                pass
            del self._scene_handles[name]

        if hidden:
            return

        # Add mesh to viser scene
        if trimesh_mesh is not None:
            mesh_kwargs = {
                "name": name,
                "mesh": trimesh_mesh,
            }
            if opacity is not None:
                mesh_kwargs["opacity"] = float(np.clip(opacity, 0.0, 1.0))
            handle = self._call_scene_method(self._server.scene.add_mesh_trimesh, **mesh_kwargs)
        else:
            mesh_kwargs = {
                "name": name,
                "vertices": points_np,
                "faces": indices_np,
                "color": (180, 180, 180) if color is None else color,
                "wireframe": False,
                "side": "double" if not backface_culling else "front",
            }
            if opacity is not None:
                mesh_kwargs["opacity"] = float(np.clip(opacity, 0.0, 1.0))
            handle = self._call_scene_method(self._server.scene.add_mesh_simple, **mesh_kwargs)
        self._scene_handles[name] = handle

    @staticmethod
    def _quats_xyzw_to_wxyz(quats_xyzw: np.ndarray) -> np.ndarray:
        """Convert quaternions from Warp's XYZW layout to viser's WXYZ layout."""
        quats_xyzw = np.asarray(quats_xyzw, dtype=np.float32)
        was_1d = quats_xyzw.ndim == 1
        if was_1d:
            quats_xyzw = quats_xyzw.reshape(1, 4)
        if quats_xyzw.ndim != 2 or quats_xyzw.shape[1] != 4:
            raise ValueError(f"Expected quaternion array with shape (4,) or (N, 4), got {quats_xyzw.shape}")

        quats_wxyz = np.empty_like(quats_xyzw)
        quats_wxyz[:, 0] = quats_xyzw[:, 3]
        quats_wxyz[:, 1] = quats_xyzw[:, 0]
        quats_wxyz[:, 2] = quats_xyzw[:, 1]
        quats_wxyz[:, 3] = quats_xyzw[:, 2]
        return quats_wxyz[0] if was_1d else quats_wxyz

    @staticmethod
    def _quats_xyzw_to_rotmats(quats_xyzw: np.ndarray) -> np.ndarray:
        """Convert a batch of XYZW quaternions to (N, 3, 3) rotation matrices."""
        quats_xyzw = np.asarray(quats_xyzw, dtype=np.float32)
        quats_xyzw = quats_xyzw / np.maximum(np.linalg.norm(quats_xyzw, axis=1, keepdims=True), 1e-12)
        x, y, z, w = quats_xyzw[:, 0], quats_xyzw[:, 1], quats_xyzw[:, 2], quats_xyzw[:, 3]
        n = quats_xyzw.shape[0]
        rot = np.empty((n, 3, 3), dtype=np.float32)
        rot[:, 0, 0] = 1.0 - 2.0 * (y * y + z * z)
        rot[:, 0, 1] = 2.0 * (x * y - w * z)
        rot[:, 0, 2] = 2.0 * (x * z + w * y)
        rot[:, 1, 0] = 2.0 * (x * y + w * z)
        rot[:, 1, 1] = 1.0 - 2.0 * (x * x + z * z)
        rot[:, 1, 2] = 2.0 * (y * z - w * x)
        rot[:, 2, 0] = 2.0 * (x * z - w * y)
        rot[:, 2, 1] = 2.0 * (y * z + w * x)
        rot[:, 2, 2] = 1.0 - 2.0 * (x * x + y * y)
        return rot

    def _remove_plane_handles(self, name: str):
        """Remove any plane-grid handles associated with an instance batch."""
        self._plane_geometry_keys.pop(name, None)
        handle = self._plane_handles.pop(name, None)
        if handle is None:
            return
        handles = handle if isinstance(handle, (list, tuple)) else (handle,)
        for handle in handles:
            try:
                handle.remove()
            except Exception:
                pass

    @staticmethod
    def _plane_cell_size(width: float, length: float) -> float:
        """Pick a grid cell size for a plane of the given extents."""
        spacing = max(min(float(width), float(length)) / 10.0, 0.25)
        return min(spacing, 2.0)

    def _log_plane_instances(
        self,
        name: str,
        plane_info: dict[str, float | bool],
        xforms: wp.array[wp.transform] | None,
        scales: wp.array[wp.vec3] | None,
        hidden: bool = False,
    ):
        """Render plane instances as viser grids.

        Grid handles are cached by name and only recreated when the instance
        count, extents, or cell sizes change; a pose-only update (the common case for a
        static ground plane logged every frame) just moves the existing
        handles instead of tearing them down and rebuilding, which avoids a
        visible flicker as handles disappear and reappear over the websocket.
        """
        if hidden or xforms is None:
            for handle in self._plane_handles.get(name, ()):
                handle.visible = False
            return

        xforms_np = to_numpy(xforms)
        if xforms_np is None or len(xforms_np) == 0:
            self._remove_plane_handles(name)
            return

        xforms_np = np.asarray(xforms_np, dtype=np.float32)
        positions = xforms_np[:, :3]
        quats_wxyz = self._quats_xyzw_to_wxyz(xforms_np[:, 3:7])
        scales_np = to_numpy(scales) if scales is not None else None
        if scales_np is not None:
            scales_np = np.asarray(scales_np, dtype=np.float32)

        base_width = float(plane_info["width"])
        base_length = float(plane_info["length"])

        widths = []
        lengths = []
        cell_sizes = []
        for idx in range(len(positions)):
            width = base_width
            length = base_length

            # TODO: Compute cell size for the scaled width/length directly
            cell_size = self._plane_cell_size(width, length)

            if scales_np is not None:
                sx = float(scales_np[idx][0])
                sy = float(scales_np[idx][1])
                width *= sx
                length *= sy
                cell_size *= max(sx, sy)

            widths.append(width)
            lengths.append(length)
            cell_sizes.append(cell_size)

        geometry_key = (len(positions), tuple(widths), tuple(lengths), tuple(cell_sizes))
        existing = self._plane_handles.get(name)

        if (
            existing is not None
            and len(existing) == len(positions)
            and self._plane_geometry_keys.get(name) == geometry_key
        ):
            # Only the pose changed (e.g. a body-attached plane, or the same
            # static plane logged again this frame) -- move handles in place.
            for handle, position, quat_wxyz in zip(existing, positions, quats_wxyz, strict=False):
                handle.position = tuple(float(v) for v in position)
                handle.wxyz = tuple(float(v) for v in quat_wxyz)
                handle.visible = True
            return

        self._remove_plane_handles(name)

        handles = []
        for idx, (position, quat_wxyz) in enumerate(zip(positions, quats_wxyz, strict=False)):
            # The plane's local frame has its normal along +Z, so the grid lies in the local XY plane.
            handle = self._call_scene_method(
                self._server.scene.add_grid,
                name=f"{name}/grid_{idx}",
                width=widths[idx],
                height=lengths[idx],
                plane="xy",
                cell_color=(150, 150, 150),
                section_color=(110, 110, 110),
                cell_size=cell_sizes[idx],
                section_size=cell_sizes[idx],
                position=tuple(float(v) for v in position),
                wxyz=tuple(float(v) for v in quat_wxyz),
            )
            handles.append(handle)

        if handles:
            self._plane_handles[name] = handles
            self._plane_geometry_keys[name] = geometry_key

    @override
    def log_instances(
        self,
        name: str,
        mesh: str,
        xforms: wp.array[wp.transform] | None,
        scales: wp.array[wp.vec3] | None,
        colors: wp.array[wp.vec3] | None,
        materials: wp.array[wp.vec4] | None,
        hidden: bool = False,
        opacities: wp.array[wp.float32] | None = None,
    ):
        """
        Log instanced mesh data to viser using efficient batched rendering.

        Uses viser's add_batched_meshes_simple for GPU-accelerated instanced rendering.
        Supports in-place updates of transforms for real-time animation.

        Args:
            name: Entity path for the instances.
            mesh: Name of the mesh asset to instance.
            xforms: Instance transforms.
            scales: Instance scales.
            colors: Instance colors.
            materials: Instance materials.
            hidden: Whether the instances are hidden.
            opacities: Instance opacities.
        """
        name = self._qualify(name)
        mesh = self._qualify(mesh)

        if mesh in self._plane_meshes:
            self._log_plane_instances(name, self._plane_meshes[mesh], xforms, scales, hidden=hidden)
            return

        self._remove_plane_handles(name)

        # Check that mesh exists
        if mesh not in self._meshes:
            raise RuntimeError(f"Mesh {mesh} not found. Call log_mesh first.")

        mesh_data = self._meshes[mesh]
        base_points = mesh_data["points"]
        base_indices = mesh_data["indices"]
        base_uvs = mesh_data.get("uvs")
        texture_image = prepare_viewer_texture(mesh_data.get("texture"))
        trimesh_mesh = mesh_data.get("trimesh")
        mesh_opacity = mesh_data.get("opacity")

        if hidden:
            # Remove existing instances if present
            if name in self._scene_handles:
                try:
                    self._scene_handles[name].remove()
                except Exception:
                    pass
                del self._scene_handles[name]
                if name in self._instances:
                    del self._instances[name]
            return

        # Convert transforms and properties to numpy
        if xforms is None:
            return

        xforms_np = to_numpy(xforms)
        scales_np = to_numpy(scales) if scales is not None else None
        colors_np = to_numpy(colors) if colors is not None else None

        num_instances = len(xforms_np)
        opacities_np = promote_to_clamped_float_array(
            opacities if opacities is not None else mesh_opacity,
            num_instances,
            value_name="Opacity",
        )

        # Extract positions from transforms
        # Warp transform format: [x, y, z, qx, qy, qz, qw]
        positions = xforms_np[:, :3].astype(np.float32)

        quats_wxyz = self._quats_xyzw_to_wxyz(xforms_np[:, 3:7])

        # Prepare scales
        if scales_np is not None:
            batched_scales = scales_np.astype(np.float32)
        else:
            batched_scales = np.ones((num_instances, 3), dtype=np.float32)

        # Prepare colors (convert from 0-1 float to 0-255 uint8)
        if colors_np is not None:
            batched_colors = (colors_np * 255).astype(np.uint8)
        else:
            batched_colors = None  # Will use cached colors or default gray

        # Check if we already have a batched mesh handle for this name
        use_trimesh = trimesh_mesh is not None and texture_image is not None and base_uvs is not None
        if name in self._instances and name in self._scene_handles:
            # Update existing batched mesh in-place (much faster)
            handle = self._scene_handles[name]
            prev_count = self._instances[name]["count"]
            prev_use_trimesh = self._instances[name].get("use_trimesh", False)

            # If instance count changed, we need to recreate the mesh
            if prev_count != num_instances or prev_use_trimesh != use_trimesh:
                try:
                    handle.remove()
                except Exception:
                    pass
                del self._scene_handles[name]
                del self._instances[name]
            else:
                # Update transforms in-place
                try:
                    handle.batched_positions = positions
                    handle.batched_wxyzs = quats_wxyz
                    if hasattr(handle, "batched_scales"):
                        handle.batched_scales = batched_scales
                    # Only update colors if they were explicitly provided
                    if batched_colors is not None and hasattr(handle, "batched_colors"):
                        handle.batched_colors = batched_colors
                        # Cache the colors for future reference
                        self._instances[name]["colors"] = batched_colors
                    if opacities_np is not None:
                        if hasattr(handle, "batched_opacities"):
                            handle.batched_opacities = opacities_np
                            self._instances[name]["opacities"] = opacities_np
                        else:
                            warnings.warn(
                                f"Viser handle for {name!r} does not support batched opacity updates.",
                                stacklevel=2,
                            )
                    return
                except Exception:
                    # If update fails, recreate the mesh
                    try:
                        handle.remove()
                    except Exception:
                        pass
                    del self._scene_handles[name]
                    del self._instances[name]

        # For new instances, use provided colors or default gray
        if batched_colors is None:
            batched_colors = np.full((num_instances, 3), 180, dtype=np.uint8)

        # Create new batched mesh.
        # LOD is disabled because viser's automatic mesh simplification creates
        # holes in complex geometry (e.g. terrain), causing popping artifacts.
        if use_trimesh:
            handle = self._call_scene_method(
                self._server.scene.add_batched_meshes_trimesh,
                name=name,
                mesh=trimesh_mesh,
                batched_positions=positions,
                batched_wxyzs=quats_wxyz,
                batched_scales=batched_scales,
                batched_opacities=opacities_np,
                lod="off",
            )
        else:
            handle = self._call_scene_method(
                self._server.scene.add_batched_meshes_simple,
                name=name,
                vertices=base_points,
                faces=base_indices,
                batched_positions=positions,
                batched_wxyzs=quats_wxyz,
                batched_scales=batched_scales,
                batched_colors=batched_colors,
                batched_opacities=opacities_np,
                lod="off",
            )

        self._scene_handles[name] = handle
        self._instances[name] = {
            "mesh": mesh,
            "count": num_instances,
            "colors": batched_colors,  # Cache the colors
            "opacities": opacities_np,
            "use_trimesh": use_trimesh,
        }

    @override
    def begin_frame(self, time: float):
        """
        Begin a new frame.

        Args:
            time: The current simulation time.
        """
        self._frame_dt = time - self.time
        self.time = time

    @override
    def end_frame(self):
        """
        End the current frame.

        If recording is active, inserts a sleep command for playback timing.
        Updates scalar plots if any data changed since last frame.
        """
        self._update_scalar_plots()

        if self._serializer is not None:
            # Insert sleep for frame timing during recording
            self._serializer.insert_sleep(self._frame_dt)

    def _update_scalar_plots(self):
        """Create or update uPlot chart handles for dirty scalar signals."""
        if not self._scalar_dirty:
            return

        try:
            from viser import uplot

            # Create the plots folder on first use.
            if self._plot_folder is None:
                self._plot_folder = self._server.gui.add_folder("Plots")

            n = self._plot_history_size
            x = np.arange(n, dtype=np.float64)

            for name in self._scalar_dirty:
                buf = self._scalar_buffers[name]
                y = np.full(n, np.nan, dtype=np.float64)
                y[n - len(buf) :] = np.array(buf, dtype=np.float64)

                handle = self._plot_handles.get(name)
                if handle is None:
                    with self._plot_folder:
                        handle = self._server.gui.add_uplot(
                            data=(x, y),
                            series=(
                                uplot.Series(label="step"),
                                uplot.Series(label=name, stroke="#3b82f6", width=2),
                            ),
                            scales={"x": uplot.Scale(time=False)},
                            aspect=2.0,
                        )
                    self._plot_handles[name] = handle
                else:
                    handle.data = (x, y)
        except Exception:
            pass

        self._scalar_dirty.clear()

    @override
    def is_running(self) -> bool:
        """
        Check if the viewer is still running.

        Returns:
            bool: True if the viewer is running, False otherwise.
        """
        return self._running

    @override
    def close(self):
        """
        Close the viewer and clean up resources.
        """
        self._running = False
        try:
            self._server.stop()
            if self._serializer is not None:
                self.save_recording()
        except Exception:
            pass

    @override
    def apply_forces(self, state: newton.State):
        """Viser backend does not apply interactive forces.

        Args:
            state: Current simulation state.
        """
        pass

    def save_recording(self):
        """
        Save the current recording to a .viser file.

        The recording can be played back in a static HTML viewer.
        See build_static_viewer() for creating the HTML player.

        Note:
            Recording must be enabled by passing ``record_to_viser`` to the constructor.

        Example:

            .. code-block:: python

                viewer = ViewerViser(record_to_viser="my_simulation.viser")
                # ... run simulation ...
                viewer.save_recording()
        """
        if self._serializer is None or self._record_to_viser is None:
            raise RuntimeError("No recording in progress. Pass record_to_viser to the constructor.")

        from pathlib import Path  # noqa: PLC0415

        data = self._serializer.serialize()
        Path(self._record_to_viser).write_bytes(data)

        self._serializer = None

        if self.verbose:
            print(f"Recording saved to: {self._record_to_viser}")

    @override
    def log_lines(
        self,
        name: str,
        starts: wp.array[wp.vec3] | None,
        ends: wp.array[wp.vec3] | None,
        colors: (wp.array[wp.vec3] | wp.array[wp.float32] | tuple[float, float, float] | list[float] | None),
        width: float = 0.01,
        hidden: bool = False,
    ):
        """
        Log lines for visualization.

        Args:
            name: Name of the line batch.
            starts: Line start points.
            ends: Line end points.
            colors: Line colors.
            width: Line width.
            hidden: Whether the lines are hidden.
        """
        name = self._qualify(name)

        def remove_existing_line(reset_version: bool = True):
            handle = self._scene_handles.pop(name, None)
            if handle is not None:
                try:
                    handle.remove()
                except Exception:
                    pass
            self._line_segment_counts.pop(name, None)
            if reset_version:
                self._line_versions.pop(name, None)

        if hidden:
            remove_existing_line()
            return

        if starts is None or ends is None:
            remove_existing_line()
            return

        starts_np = to_numpy(starts)
        ends_np = to_numpy(ends)

        if starts_np is None or ends_np is None or len(starts_np) == 0:
            remove_existing_line()
            return

        starts_np = np.asarray(starts_np, dtype=np.float32)
        ends_np = np.asarray(ends_np, dtype=np.float32)
        num_lines = len(starts_np)

        # Viser requires points with shape (N, 2, 3): [start, end] per segment.
        line_points = np.stack((starts_np, ends_np), axis=1)

        def _rgb_to_uint8_array(rgb: np.ndarray) -> np.ndarray:
            rgb = np.asarray(rgb, dtype=np.float32)
            max_val = float(np.max(rgb)) if rgb.size > 0 else 0.0
            if max_val <= 1.0:
                rgb = rgb * 255.0
            return np.clip(rgb, 0, 255).astype(np.uint8)

        # Process colors. Keep this as a NumPy array because Viser handle
        # property updates require the normalized array form, even though
        # add_line_segments() also accepts RGB tuples on initial creation.
        color_rgb: np.ndarray = np.array((0, 255, 0), dtype=np.uint8)
        if colors is not None:
            colors_np = to_numpy(colors)
            if colors_np is not None:
                colors_np = np.asarray(colors_np)
                if colors_np.ndim == 1 and colors_np.shape[0] == 3:
                    # Single color for all lines.
                    color_rgb = _rgb_to_uint8_array(colors_np)
                elif colors_np.ndim == 2 and colors_np.shape == (num_lines, 3):
                    # Per-line colors: repeat each line color for [start, end].
                    line_colors = _rgb_to_uint8_array(colors_np)
                    color_rgb = np.repeat(line_colors[:, None, :], 2, axis=1)
                elif colors_np.ndim == 3 and colors_np.shape == (num_lines, 2, 3):
                    # Already per-point-per-segment colors.
                    color_rgb = _rgb_to_uint8_array(colors_np)

        line_width = width * 100  # Scale for visibility
        if name in self._scene_handles:
            handle = self._scene_handles[name]
            if self._line_segment_counts.get(name) == num_lines:
                try:
                    handle.points = line_points
                    handle.colors = color_rgb
                    handle.line_width = line_width
                    return
                except Exception:
                    remove_existing_line()
            else:
                self._line_versions[name] = self._line_versions.get(name, 0) + 1
                remove_existing_line(reset_version=False)

        version = self._line_versions.get(name, 0)
        scene_name = name if version == 0 else f"{name}__line_{version}"

        handle = self._server.scene.add_line_segments(
            name=scene_name,
            points=line_points,
            colors=color_rgb,
            line_width=line_width,
        )
        self._scene_handles[name] = handle
        self._line_segment_counts[name] = num_lines

    @override
    def log_geo(
        self,
        name: str,
        geo_type: int,
        geo_scale: tuple[float, ...],
        geo_thickness: float,
        geo_is_solid: bool,
        geo_src: newton.Mesh | newton.Heightfield | None = None,
        hidden: bool = False,
    ):
        """Log a geometry primitive, with plane expansion for infinite planes.

        Args:
            name: Unique path/name for the geometry asset.
            geo_type: Geometry type value from `newton.GeoType`.
            geo_scale: Geometry scale tuple interpreted by `geo_type`.
            geo_thickness: Shell thickness for mesh-like geometry.
            geo_is_solid: Whether mesh geometry is treated as solid.
            geo_src: Optional source geometry for mesh-backed types.
            hidden: Whether the resulting geometry is hidden.
        """
        name = self._qualify(name)

        if geo_type == newton.GeoType.PLANE:
            # Handle "infinite" planes encoded with non-positive scales
            if geo_scale[0] == 0.0 or geo_scale[1] == 0.0:
                extents = self._get_world_extents()
                if extents is None:
                    width, length = 10.0, 10.0
                else:
                    max_extent = max(max(extents) * 1.5, 8.0)
                    width = max_extent
                    length = max_extent
            else:
                width = geo_scale[0]
                length = geo_scale[1] if len(geo_scale) > 1 else 10.0
            self._plane_meshes[name] = {
                "width": float(width),
                "length": float(length),
            }
        else:
            super().log_geo(name, geo_type, geo_scale, geo_thickness, geo_is_solid, geo_src, hidden)

    @override
    def log_points(
        self,
        name: str,
        points: wp.array[wp.vec3] | None,
        radii: wp.array[wp.float32] | float | None = None,
        colors: (wp.array[wp.vec3] | wp.array[wp.float32] | tuple[float, float, float] | list[float] | None) = None,
        hidden: bool = False,
    ):
        """
        Log points for visualization.

        Args:
            name: Name of the point batch.
            points: Point positions (can be a wp.array or a numpy array).
            radii: Point radii (can be a wp.array or a numpy array).
            colors: Point colors (can be a wp.array or a numpy array).
            hidden: Whether the points are hidden.
        """
        name = self._qualify(name)

        # Remove existing points if present
        if name in self._scene_handles:
            try:
                self._scene_handles[name].remove()
            except Exception:
                pass
            del self._scene_handles[name]

        if hidden:
            return

        if points is None:
            return

        pts = to_numpy(points)
        n_points = pts.shape[0]

        if n_points == 0:
            return

        # Handle radii (point size)
        if radii is not None:
            size = to_numpy(radii)
            if size.ndim == 0 or size.shape == ():
                point_size = float(size)
            elif len(size) == n_points:
                point_size = float(np.mean(size))  # Use average for uniform size
            else:
                point_size = 0.1
        else:
            point_size = 0.1

        # Handle colors
        if colors is not None:
            cols = to_numpy(colors)
            if cols.shape == (n_points, 3):
                # Convert from 0-1 to 0-255
                colors_val = (cols * 255).astype(np.uint8)
            elif cols.shape == (3,):
                colors_val = np.tile((cols * 255).astype(np.uint8), (n_points, 1))
            else:
                colors_val = np.full((n_points, 3), 255, dtype=np.uint8)
        else:
            colors_val = np.full((n_points, 3), 255, dtype=np.uint8)

        # Add point cloud to viser
        handle = self._server.scene.add_point_cloud(
            name=name,
            points=pts.astype(np.float32),
            colors=colors_val,
            point_size=point_size,
            point_shape="circle",
        )
        self._scene_handles[name] = handle

    @override
    def log_gaussian(
        self,
        name: str,
        gaussian: newton.Gaussian | None,
        xform: wp.transformf | None = None,
        hidden: bool = False,
    ):
        """
        Log a :class:`newton.Gaussian` splat asset using viser's native Gaussian renderer.

        Note: viser's ``add_gaussian_splats`` is marked experimental upstream and its
        API may change or be removed in a future viser release.

        Args:
            name: Unique path/name for the Gaussian splat asset.
            gaussian: The :class:`newton.Gaussian` asset to visualize, with centers and
                per-axis scales in meters [m]. ``None`` removes any existing asset at ``name``.
            xform: Optional world-space transform applied to the splat asset; its
                translation component is in meters [m].
            hidden: Whether the splat asset should be hidden.
        """
        name = self._qualify(name)

        if gaussian is None or gaussian.count == 0:
            if name in self._scene_handles:
                try:
                    self._scene_handles[name].remove()
                except Exception:
                    pass
                self._scene_handles.pop(name, None)
            self._gaussian_splats.pop(name, None)
            return

        if hidden:
            if name in self._scene_handles:
                self._scene_handles[name].visible = False
            return

        cached = self._gaussian_splats.get(name)

        if (
            cached is None
            or cached["gaussian"] is not gaussian
            or cached["count"] != gaussian.count
            or self._scene_handles.get(name) is not cached["handle"]
        ):
            centers = self._to_numpy(gaussian.positions).astype(np.float32)
            rotations_xyzw = self._to_numpy(gaussian.rotations).astype(np.float32)
            scales = self._to_numpy(gaussian.scales).astype(np.float32)
            opacities = self._to_numpy(gaussian.opacities).astype(np.float32).reshape(-1, 1)

            # Local-space covariance per Gaussian: Sigma = R * diag(scale^2) * R^T
            rot_mats = self._quats_xyzw_to_rotmats(rotations_xyzw)
            scale_sq = scales * scales
            covariances = np.einsum("nij,nj,nkj->nik", rot_mats, scale_sq, rot_mats).astype(np.float32)

            sh_coeffs = self._to_numpy(gaussian.sh_coeffs)
            if sh_coeffs is not None and sh_coeffs.shape[1] >= 3:
                rgbs = np.clip(self._SH_C0 * sh_coeffs[:, :3] + 0.5, 0.0, 1.0).astype(np.float32)
            else:
                rgbs = np.ones((gaussian.count, 3), dtype=np.float32)

            if cached is not None and name in self._scene_handles:
                try:
                    self._scene_handles[name].remove()
                except Exception:
                    pass

            handle = self._call_scene_method(
                self._server.scene.add_gaussian_splats,
                name=name,
                centers=centers,
                covariances=covariances,
                rgbs=rgbs,
                opacities=opacities,
            )
            self._scene_handles[name] = handle
            self._gaussian_splats[name] = {"gaussian": gaussian, "count": gaussian.count, "handle": handle}

        handle = self._scene_handles[name]
        handle.visible = True
        if xform is not None:
            xform_np = np.asarray(xform, dtype=np.float32)
            handle.position = xform_np[:3]
            handle.wxyz = self._quats_xyzw_to_wxyz(xform_np[3:7])
        else:
            handle.position = (0.0, 0.0, 0.0)
            handle.wxyz = (1.0, 0.0, 0.0, 0.0)

    @override
    def log_array(self, name: str, array: wp.array[Any] | np.ndarray):
        """Viser viewer does not visualize generic arrays.

        Args:
            name: Unique path/name for the array signal.
            array: Array data to visualize.
        """
        pass

    @override
    def log_scalar(
        self,
        name: str,
        value: int | float | bool | np.number,
        *,
        clear: bool = False,
        smoothing: int = 1,
    ):
        """
        Log a scalar value as a live time-series plot.

        Each unique *name* creates a separate uPlot chart in a "Plots"
        folder in the GUI sidebar.  Values are stored in a rolling
        buffer of the last ``plot_history_size`` samples.

        Args:
            name: Unique path/name for the scalar signal.
            value: Scalar value to record.
            clear: If ``True``, discard previously recorded samples for
                *name* before logging the new value.
            smoothing: Number of raw samples to average before committing
                a point to the plot history.  Defaults to ``1`` (no smoothing).
        """
        if smoothing < 1:
            raise ValueError("smoothing must be >= 1")
        name = self._qualify(name)
        val = float(value.item() if hasattr(value, "item") else value)
        buf = self._scalar_buffers.get(name)
        if buf is None:
            buf = collections.deque(maxlen=self._plot_history_size)
            self._scalar_buffers[name] = buf
        elif clear:
            buf.clear()
            self._scalar_accumulators.pop(name, None)

        if self._scalar_smoothing.get(name, smoothing) != smoothing:
            self._scalar_accumulators.pop(name, None)
        self._scalar_smoothing[name] = smoothing
        if smoothing <= 1:
            buf.append(val)
        else:
            acc = self._scalar_accumulators.get(name)
            if acc is None:
                acc = []
                self._scalar_accumulators[name] = acc
            acc.append(val)
            if len(acc) >= smoothing:
                buf.append(sum(acc) / len(acc))
                acc.clear()

        self._scalar_dirty.add(name)

    def show_notebook(self, width: int | str = "100%", height: int | str = 400):
        """
        Show the viewer in a Jupyter notebook.

        If recording is active, saves the recording and displays using the static HTML
        viewer with timeline controls. Otherwise, displays the live server in an IFrame.

        Args:
            width: Width of the embedded player in pixels.
            height: Height of the embedded player in pixels.

        Returns:
            The display object.

        Example:

            .. code-block:: python

                viewer = newton.viewer.ViewerViser(record_to_viser="my_sim.viser")
                viewer.set_model(model)
                # ... run simulation ...
                viewer.show_notebook()  # Saves recording and displays with timeline
        """

        from IPython.display import HTML, IFrame, display

        from .viewer import is_sphinx_build  # noqa: PLC0415

        if self._record_to_viser is None:
            if self._display_colab_iframe(self._port, width=width, height=height):
                return None

            # No recording - display the live server via IFrame
            return display(IFrame(src=self.url, width=width, height=height))

        if self._serializer is not None:
            # Recording is active - save it first
            recording_path = Path(self._record_to_viser)
            recording_path.parent.mkdir(parents=True, exist_ok=True)
            self.save_recording()

        # Check if recording path contains _static - indicates Sphinx docs build
        recording_str = str(self._record_to_viser).replace("\\", "/")

        if is_sphinx_build():
            # Sphinx build - use static HTML with viser player
            # The recording path needs to be relative to the viser index.html location
            # which is at _static/viser/index.html

            # Find the _static portion of the path
            static_idx = recording_str.find("_static/")
            if static_idx == -1:
                raise ValueError(
                    f"Recordings that are supposed to appear in the Sphinx documentation must be stored in docs/_static/, but the path {recording_str} does not contain _static/"
                )
            else:
                # Extract path from _static onwards (e.g., "_static/recordings/foo.viser")
                static_relative = recording_str[static_idx:]
                # The viser index.html is at _static/viser/index.html
                # So from there, we need "../recordings/foo.viser"
                # Remove the "_static/" prefix and prepend "../"
                playback_path = "../" + static_relative[len("_static/") :]

            camera_query = self._camera_query_from_request(self._camera_request)

            embed_html = f"""
<div class="viser-player-container" style="margin: 20px 0;">
<iframe
    src="../_static/viser/index.html?playbackPath={playback_path}{camera_query}"
    width="{width}"
    height="{height}"
    frameborder="0"
    style="border: 1px solid #ccc; border-radius: 8px;">
</iframe>
</div>
"""
            return display(HTML(embed_html))
        else:
            # Regular Jupyter - use local HTTP server with viser client
            player_url = self._serve_viser_recording(
                self._record_to_viser,
                camera_request=self._camera_request,
            )
            colab_target = self._colab_iframe_target_from_url(player_url)
            if colab_target is not None:
                colab_port, colab_path, colab_query = colab_target
                if self._display_colab_iframe(
                    colab_port,
                    path=colab_path,
                    query=colab_query,
                    width=width,
                    height=height,
                ):
                    return None

            return display(IFrame(src=player_url, width=width, height=height))

    def _ipython_display_(self):
        """
        Display the viewer in an IPython notebook when the viewer is at the end of a cell.
        """
        self.show_notebook()

    @staticmethod
    def _serve_viser_recording(
        recording_path: str, camera_request: tuple[np.ndarray, np.ndarray, np.ndarray] | None = None
    ) -> str:
        """
        Hosts a simple HTTP server to serve the viser recording file with the viser client
        and returns the URL of the player.

        Args:
            recording_path: Path to the .viser recording file.
            camera_request: Optional `(position, look_at, up_direction)` triple used
                to append initial camera URL overrides for playback.

        Returns:
            URL of the player.
        """
        import threading  # noqa: PLC0415
        from http.server import HTTPServer, SimpleHTTPRequestHandler  # noqa: PLC0415

        recording_path = Path(recording_path).resolve()
        if not recording_path.exists():
            raise FileNotFoundError(f"Recording file not found: {recording_path}")

        viser_client_dir = ViewerViser.get_viser_client_dir()

        # Read the recording file content
        recording_bytes = recording_path.read_bytes()

        # Create a custom HTTP handler factory that serves both viser client and the recording
        def make_handler(recording_data: bytes, client_dir: str):
            class RecordingHandler(SimpleHTTPRequestHandler):
                # Fix MIME types for JavaScript and other files (Windows often has wrong mappings)
                extensions_map: ClassVar = {  # pyright: ignore[reportIncompatibleVariableOverride]
                    **SimpleHTTPRequestHandler.extensions_map,
                    ".html": "text/html",
                    ".htm": "text/html",
                    ".css": "text/css",
                    ".js": "application/javascript",
                    ".json": "application/json",
                    ".wasm": "application/wasm",
                    ".svg": "image/svg+xml",
                    ".png": "image/png",
                    ".jpg": "image/jpeg",
                    ".jpeg": "image/jpeg",
                    ".ico": "image/x-icon",
                    ".ttf": "font/ttf",
                    ".hdr": "application/octet-stream",
                    ".viser": "application/octet-stream",
                    "": "application/octet-stream",
                }

                def __init__(self, *args, **kwargs):
                    self.recording_data = recording_data
                    super().__init__(*args, directory=client_dir, **kwargs)

                def do_GET(self):
                    # Parse path without query string
                    path = self.path.split("?")[0]

                    # Serve the recording file at /recording.viser
                    if path == "/recording.viser":
                        self.send_response(200)
                        self.send_header("Content-Type", "application/octet-stream")
                        self.send_header("Content-Length", str(len(self.recording_data)))
                        self.send_header("Access-Control-Allow-Origin", "*")
                        self.end_headers()
                        self.wfile.write(self.recording_data)
                    else:
                        # Serve viser client files
                        super().do_GET()

                def log_message(self, format, *args):
                    pass  # Suppress log messages

            return RecordingHandler

        handler_class = make_handler(recording_bytes, str(viser_client_dir))
        server = HTTPServer(("127.0.0.1", 0), handler_class)
        port = server.server_address[1]

        # Start server in background thread
        server_thread = threading.Thread(target=server.serve_forever, daemon=True)
        server_thread.start()

        # Keep playbackPath relative so notebook proxy prefixes (e.g. /lab/proxy/<port>/)
        # are preserved. Each viewer instance uses a different port, so paths stay distinct.
        playback_path = "recording.viser"
        player_url = ViewerViser._build_browser_url(
            port,
            query=f"?playbackPath={playback_path}",
            local_host="127.0.0.1",
        )

        return player_url + ViewerViser._camera_query_from_request(camera_request)

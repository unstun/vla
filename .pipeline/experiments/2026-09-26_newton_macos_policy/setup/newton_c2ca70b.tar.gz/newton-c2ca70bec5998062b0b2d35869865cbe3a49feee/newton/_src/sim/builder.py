# SPDX-FileCopyrightText: Copyright (c) 2025 The Newton Developers
# SPDX-License-Identifier: Apache-2.0

"""A module for building Newton models."""

from __future__ import annotations

import copy
import ctypes
import functools
import inspect
import math
import os
import warnings
import weakref
from collections import Counter, deque
from collections.abc import Callable, Iterable, Sequence
from dataclasses import dataclass, replace
from typing import TYPE_CHECKING, Any, ClassVar, Literal

import numpy as np
import warp as wp

from ..core.types import (
    MAXVAL,
    Axis,
    AxisType,
    Devicelike,
    Mat22,
    Mat33,
    Quat,
    Transform,
    Vec3,
    Vec4,
    Vec6,
    axis_to_vec3,
    flag_to_int,
)
from ..geometry import (
    Gaussian,
    GeoType,
    Mesh,
    ParticleFlags,
    ShapeFlags,
    compute_inertia_shape,
    compute_shape_radius,
    transform_inertia,
)
from ..geometry.flags import MeshProperties
from ..geometry.inertia import validate_and_correct_inertia_kernel, verify_and_correct_inertia
from ..geometry.sdf_utils import _resolve_paired_samples_flag
from ..geometry.types import Heightfield
from ..geometry.utils import RemeshingMethod, compute_inertia_obb, remesh_mesh
from ..math import quat_between_vectors_robust
from ..usd.schema_resolver import SchemaResolver
from ..utils import compute_world_offsets
from ..utils.deprecation import RemovedAttribute, deprecate_nonkeyword_arguments
from ..utils.mesh import MeshAdjacency, split_mesh_components
from .enums import (
    BodyFlags,
    JointTargetMode,
    JointType,
)
from .graph_coloring import (
    ColoringAlgorithm,
    color_graph,
    color_rigid_bodies,
    combine_independent_coloring_plan,
    construct_particle_graph,
)
from .model import Model, _pack_shape_pair_codes
from .rod import Rod

if TYPE_CHECKING:
    from pxr import Usd

    from ..actuators.clamping.base import ClampingBase
    from ..actuators.drives.base import DriveBase
    from ..geometry.types import TetMesh

    UsdStage = Usd.Stage
else:
    UsdStage = Any


def _validate_opacity(value: Any, value_name: str) -> float:
    """Return a finite display opacity in [0, 1]."""
    opacity = float(value)
    if not np.isfinite(opacity) or not 0.0 <= opacity <= 1.0:
        raise ValueError(f"{value_name} must be a finite value in [0, 1], got {opacity!r}.")
    return opacity


def _validate_color(value: Any, value_name: str) -> tuple[float, float, float]:
    """Return a finite RGB display color with components in [0, 1]."""
    color = np.asarray(value, dtype=np.float32)
    if color.shape != (3,):
        raise ValueError(f"{value_name} must contain exactly 3 values, got shape {color.shape}.")
    if np.any(~np.isfinite(color)) or np.any(color < 0.0) or np.any(color > 1.0):
        raise ValueError(f"{value_name} must contain finite values in [0, 1], got {color.tolist()!r}.")
    return (float(color[0]), float(color[1]), float(color[2]))


def _broadcast_triangle_colors(value: Any, triangle_count: int, default_color: Vec3) -> np.ndarray:
    """Return one validated RGB display color per triangle."""
    colors = np.asarray(default_color if value is None else value, dtype=np.float32)
    if colors.shape == (3,):
        colors = np.broadcast_to(colors, (triangle_count, 3))
    elif colors.shape != (triangle_count, 3):
        raise ValueError(
            f"Triangle color arrays must contain one RGB value or exactly {triangle_count} RGB values, "
            f"got shape {colors.shape}."
        )
    invalid_color = (~np.isfinite(colors)) | (colors < 0.0) | (colors > 1.0)
    if np.any(invalid_color):
        invalid_row = colors[np.flatnonzero(np.any(invalid_color, axis=1))[0]]
        raise ValueError(f"Triangle color must contain finite values in [0, 1], got {invalid_row.tolist()!r}.")
    return colors


def _broadcast_triangle_opacities(value: Any, triangle_count: int) -> np.ndarray:
    """Return one validated display opacity per triangle."""
    opacities = np.asarray(1.0 if value is None else value, dtype=np.float32).reshape(-1)
    if opacities.size == 1:
        opacities = np.full(triangle_count, float(opacities[0]), dtype=np.float32)
    elif opacities.size != triangle_count:
        raise ValueError(
            f"Triangle opacity arrays must contain one value or exactly {triangle_count} values, got {opacities.size}."
        )
    invalid_opacity = (~np.isfinite(opacities)) | (opacities < 0.0) | (opacities > 1.0)
    if np.any(invalid_opacity):
        invalid_value = float(opacities[np.flatnonzero(invalid_opacity)[0]])
        raise ValueError(f"Triangle opacity must contain finite values in [0, 1], got {invalid_value!r}.")
    return opacities


_NEWTON_SRC_DIR = os.path.normpath(os.path.join(os.path.dirname(__file__), os.pardir)) + os.sep

_SCALAR_GRAVITY_DEPRECATION_MSG = (
    "Scalar ModelBuilder.gravity is deprecated in Newton 1.4; pass a gravity vector instead. "
    "Scalar gravity will be removed in a future release."
)
_DEPRECATED_ACTUATOR_DRIVE_UNSET = object()
_ACTUATOR_CONTROLLER_CLASS_DEPRECATION_MSG = (
    "ModelBuilder.add_actuator(controller_class=...) is deprecated in Newton 1.6; use drive_class=... instead."
)
_ADD_ROD_POSITIONS_DEPRECATION_MSG = (
    "ModelBuilder.add_rod(positions=...) is deprecated in Newton 1.6; "
    "construct newton.Rod(...) and pass it with add_rod(rod=...) instead."
)
_ADD_ROD_GRAPH_DEPRECATION_MSG = (
    "ModelBuilder.add_rod_graph() is deprecated in Newton 1.6; "
    "construct newton.Rod(..., edges=...) and pass it with add_rod(rod=...) instead."
)

# Plain constructors, not wp.transform_identity()/wp.quat_identity(): builtins
# dispatch through overload resolution and would initialize the Warp runtime at import.
_IDENTITY_TRANSFORM = np.asarray(wp.transformf((0.0, 0.0, 0.0), (0.0, 0.0, 0.0, 1.0)), dtype=np.float32)
_IDENTITY_ROTATION = np.asarray(wp.quatf(0.0, 0.0, 0.0, 1.0), dtype=np.float32)

_MERGE_VALIDATION_CACHE: weakref.WeakKeyDictionary = weakref.WeakKeyDictionary()
"""Memoizes :meth:`ModelBuilder._validate_builder_merge` as ``dest -> {source: schema epochs}``.

Kept out of the builders themselves: this is a memoization table, not model state, and it must
not show up in builder-state comparisons or survive past either builder's lifetime.
"""


def _deduplicate_convex_collision_mesh(source: Mesh) -> Mesh:
    """Build a collision-only mesh containing each exact vertex position once."""
    vertices = source.vertices
    _, first_indices, inverse = np.unique(vertices, axis=0, return_index=True, return_inverse=True)
    if len(first_indices) == len(vertices):
        return source

    # Retain first-occurrence order so support-map tie breaking stays unchanged.
    first_order = np.argsort(first_indices)
    unique_remap = np.empty(len(first_indices), dtype=np.int32)
    unique_remap[first_order] = np.arange(len(first_indices), dtype=np.int32)
    vertex_remap = unique_remap[inverse]
    collision_mesh = Mesh(
        vertices=vertices[first_indices[first_order]],
        indices=vertex_remap[source.indices],
        compute_inertia=False,
        is_solid=source.is_solid,
        maxhullvert=source.maxhullvert,
        sdf=source.sdf,
    )
    collision_mesh.mass = source.mass
    collision_mesh.com = source.com
    collision_mesh.inertia = source.inertia
    collision_mesh.has_inertia = source.has_inertia

    if source._collision_edges is not None:
        collision_edges = vertex_remap[source._collision_edges]
        collision_edges = collision_edges[collision_edges[:, 0] != collision_edges[:, 1]]
        if len(collision_edges) > 0:
            _, first_edges = np.unique(collision_edges, axis=0, return_index=True)
            collision_edges = collision_edges[np.sort(first_edges)]
        collision_mesh._collision_edges = collision_edges

    return collision_mesh


_CONVEX_SUPPORT_MIN_VERTICES = 256
_CONVEX_SUPPORT_LUT_RESOLUTION = 32


def _build_convex_support_acceleration(source: Mesh) -> tuple[np.ndarray, np.ndarray, np.ndarray] | None:
    """Build a directional seed table and welded vertex adjacency for a convex collision mesh."""
    vertices = np.asarray(source.vertices, dtype=np.float32).reshape(-1, 3)
    vertex_count = len(vertices)
    if vertex_count < _CONVEX_SUPPORT_MIN_VERTICES:
        return None

    triangles = np.asarray(source.indices, dtype=np.int32).reshape(-1, 3)
    geometry_scale = max(float(np.max(np.ptp(vertices, axis=0))), 1.0e-6)
    vertices64 = vertices.astype(np.float64)
    triangle_points = vertices64[triangles]
    face_normals = np.cross(
        triangle_points[:, 1] - triangle_points[:, 0], triangle_points[:, 2] - triangle_points[:, 0]
    )
    normal_lengths = np.linalg.norm(face_normals, axis=1)
    nondegenerate = normal_lengths > geometry_scale * geometry_scale * 1.0e-12
    face_normals = face_normals[nondegenerate]
    if len(face_normals) == 0:
        return None
    face_normals /= normal_lengths[nondegenerate, None]
    face_offsets = np.einsum("ij,ij->i", face_normals, triangle_points[nondegenerate, 0])

    # The input indices are not automatically rebuilt as a convex hull. Only
    # use their edges when every non-degenerate triangle lies on a supporting
    # plane of the point set; otherwise a local edge maximum need not be the
    # global support point and the exhaustive path must remain active.
    plane_tolerance = geometry_scale * 2.0e-6
    for start in range(0, len(face_normals), 64):
        stop = min(start + 64, len(face_normals))
        projections = face_normals[start:stop] @ vertices64.T
        offsets = face_offsets[start:stop]
        supported_positive = np.max(projections, axis=1) <= offsets + plane_tolerance
        supported_negative = np.min(projections, axis=1) >= offsets - plane_tolerance
        if not np.all(supported_positive | supported_negative):
            return None

    # A connected subset of supporting faces is not necessarily a complete
    # hull. Walking its edges can stop at a local maximum because an omitted
    # face also omits the edge needed to reach the global support vertex.
    # Validate a closed two-manifold after welding numerically split seams.
    coordinate_scale = max(float(np.max(np.abs(vertices))), 1.0)
    weld_groups: dict[tuple[float, float, float], list[int]] = {}
    welded_vertex = np.empty(vertex_count, dtype=np.int32)
    for vertex, position in enumerate(vertices):
        key = tuple(np.round(position / coordinate_scale, decimals=6))
        group = weld_groups.setdefault(key, [])
        if group:
            welded_vertex[vertex] = group[0]
        else:
            welded_vertex[vertex] = vertex
        group.append(vertex)

    edge_incidence: Counter[tuple[int, int]] = Counter()
    for triangle in triangles[nondegenerate]:
        welded = tuple(int(welded_vertex[int(vertex)]) for vertex in triangle)
        if len(set(welded)) < 3:
            continue
        for first, second in ((welded[0], welded[1]), (welded[1], welded[2]), (welded[2], welded[0])):
            edge_incidence[min(first, second), max(first, second)] += 1
    if not edge_incidence or any(count != 2 for count in edge_incidence.values()):
        warnings.warn(
            "Convex support acceleration requires complete closed hull topology; "
            "falling back to exhaustive support mapping.",
            RuntimeWarning,
            stacklevel=2,
        )
        return None

    adjacent = [set() for _ in range(vertex_count)]
    for triangle in triangles:
        a, b, c = (int(value) for value in triangle)
        if a != b:
            adjacent[a].add(b)
            adjacent[b].add(a)
        if a != c:
            adjacent[a].add(c)
            adjacent[c].add(a)
        if b != c:
            adjacent[b].add(c)
            adjacent[c].add(b)

    # Procedural and imported meshes can have numerically split seam vertices.
    # Share their neighborhoods without changing the mesh points or support values.
    for group in weld_groups.values():
        if len(group) <= 1:
            continue
        merged = set(group)
        for vertex in group:
            merged.update(adjacent[vertex])
        for vertex in group:
            adjacent[vertex].update(merged)
            adjacent[vertex].discard(vertex)

    if any(not neighbors for neighbors in adjacent):
        return None
    visited = {0}
    stack = [0]
    while stack:
        vertex = stack.pop()
        for neighbor in adjacent[vertex]:
            if neighbor not in visited:
                visited.add(neighbor)
                stack.append(neighbor)
    if len(visited) != vertex_count:
        return None

    resolution = _CONVEX_SUPPORT_LUT_RESOLUTION
    coordinates = np.linspace(-1.0, 1.0, resolution, dtype=np.float32)
    xx, yy = np.meshgrid(coordinates, coordinates, indexing="xy")
    zz = 1.0 - np.abs(xx) - np.abs(yy)
    folded = zz < 0.0
    old_x = xx.copy()
    old_y = yy.copy()
    xx[folded] = (1.0 - np.abs(old_y[folded])) * np.where(old_x[folded] >= 0.0, 1.0, -1.0)
    yy[folded] = (1.0 - np.abs(old_x[folded])) * np.where(old_y[folded] >= 0.0, 1.0, -1.0)
    directions = np.column_stack((xx.ravel(), yy.ravel(), zz.ravel()))
    directions /= np.linalg.norm(directions, axis=1)[:, None]

    lut = np.empty(resolution * resolution, dtype=np.int32)
    for start in range(0, len(directions), 64):
        stop = min(start + 64, len(directions))
        lut[start:stop] = np.argmax(directions[start:stop] @ vertices.T, axis=1)

    offsets = np.zeros(vertex_count + 1, dtype=np.int32)
    neighbors = []
    for vertex, values in enumerate(adjacent):
        neighbors.extend(sorted(values))
        offsets[vertex + 1] = len(neighbors)
    return lut, offsets, np.asarray(neighbors, dtype=np.int32)


def _build_joint_ancestor(joint_parent: Sequence[int], joint_child: Sequence[int]) -> np.ndarray:
    joint_parents = np.asarray(joint_parent, dtype=np.int32)
    joint_children = np.asarray(joint_child, dtype=np.int32)
    joint_indices = np.arange(len(joint_parents), dtype=np.int32)
    max_child = int(np.max(joint_children, initial=-1))

    body_joint = np.full(max_child + 1, -1, dtype=np.int32)
    valid_child = joint_children >= 0
    body_joint[joint_children[valid_child]] = joint_indices[valid_child]

    parent_joint = np.full(len(joint_parents), -1, dtype=np.int32)
    has_parent = (joint_parents >= 0) & (joint_parents <= max_child)
    parent_joint[has_parent] = body_joint[joint_parents[has_parent]]
    return parent_joint


def _build_fk_level_topology(
    articulation_count: int,
    joint_articulation: Sequence[int],
    joint_parent: Sequence[int],
    joint_child: Sequence[int],
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray] | None:
    if articulation_count == 0:
        return None

    joint_articulations = np.asarray(joint_articulation, dtype=np.int32)
    joint_parents = np.asarray(joint_parent, dtype=np.int32)
    joint_children = np.asarray(joint_child, dtype=np.int32)
    articulation_joints = np.flatnonzero(joint_articulations >= 0).astype(np.int32)
    articulation_ids = joint_articulations[articulation_joints]
    if np.any(articulation_ids >= articulation_count):
        raise ValueError("Joint references an invalid articulation")

    articulation_children = joint_children[articulation_joints]
    max_child = int(np.max(articulation_children, initial=-1))
    body_joint = np.full(max_child + 1, -1, dtype=np.int32)
    body_joint[articulation_children] = articulation_joints
    if np.count_nonzero(body_joint >= 0) != len(articulation_children):
        return None

    parent_joint = np.full(len(joint_articulations), -1, dtype=np.int32)
    has_parent_body = (joint_parents[articulation_joints] >= 0) & (joint_parents[articulation_joints] <= max_child)
    parent_joint[articulation_joints[has_parent_body]] = body_joint[joint_parents[articulation_joints[has_parent_body]]]
    has_parent_joint = parent_joint[articulation_joints] >= 0
    parent_articulation = np.full(len(articulation_joints), -1, dtype=np.int32)
    parent_articulation[has_parent_joint] = joint_articulations[parent_joint[articulation_joints[has_parent_joint]]]
    parent_joint[articulation_joints[parent_articulation != articulation_ids]] = -1

    depth = np.full(len(joint_articulations), -1, dtype=np.int32)
    roots = articulation_joints[parent_joint[articulation_joints] < 0]
    depth[roots] = 0
    unresolved = articulation_joints[depth[articulation_joints] < 0]
    while len(unresolved):
        parents = parent_joint[unresolved]
        ready = depth[parents] >= 0
        if not np.any(ready):
            return None
        ready_joints = unresolved[ready]
        depth[ready_joints] = depth[parents[ready]] + 1
        unresolved = unresolved[~ready]

    joint_depths = depth[articulation_joints]
    depth_stride = int(np.max(joint_depths, initial=0)) + 1
    level_key = articulation_ids.astype(np.int64) * depth_stride + joint_depths
    order = np.argsort(level_key, kind="stable")
    level_joints = articulation_joints[order]
    sorted_articulations = articulation_ids[order]
    sorted_depths = joint_depths[order]

    new_level = np.ones(len(level_joints), dtype=bool)
    new_level[1:] = (sorted_articulations[1:] != sorted_articulations[:-1]) | (sorted_depths[1:] != sorted_depths[:-1])
    level_joint_start = np.append(np.flatnonzero(new_level), len(level_joints)).astype(np.int32)
    articulation_level_count = np.bincount(sorted_articulations[new_level], minlength=articulation_count)
    articulation_level_start = np.concatenate(([0], np.cumsum(articulation_level_count))).astype(np.int32)

    # Position of each scheduled joint's parent within the previous level.
    pos_in_level = np.arange(len(level_joints), dtype=np.int32) - np.repeat(
        level_joint_start[:-1], np.diff(level_joint_start)
    )
    joint_pos = np.full(len(joint_articulations), -1, dtype=np.int32)
    joint_pos[level_joints] = pos_in_level
    scheduled_parents = parent_joint[level_joints]
    level_parent_pos = np.where(scheduled_parents >= 0, joint_pos[np.maximum(scheduled_parents, 0)], -1).astype(
        np.int32
    )

    return articulation_level_start, level_joint_start, level_joints, level_parent_pos


@dataclass(frozen=True)
class _ShapeCollisionFilterBlock:
    """Compact replicated collision-filter block."""

    shape_start: int
    local_pairs: tuple[tuple[int, int], ...]
    world: int | None = None
    shape_count: int = 0


class _BuilderShapeCollisionFilterPairs:
    """Private compact storage for builder collision filters."""

    def __init__(self):
        self._entries: list[tuple[int, int] | _ShapeCollisionFilterBlock] = []
        self._pair_count = 0
        self._template_cache: tuple[tuple[int, int], ...] | None = None

    def __len__(self) -> int:
        return self._pair_count

    @property
    def explicit_pairs(self) -> tuple[tuple[int, int], ...]:
        """Pairs stored outside compact replicated blocks."""
        return tuple(entry for entry in self._entries if not isinstance(entry, _ShapeCollisionFilterBlock))

    @property
    def blocks(self) -> tuple[_ShapeCollisionFilterBlock, ...]:
        """All compact replicated blocks, regardless of world assignment."""
        return tuple(entry for entry in self._entries if isinstance(entry, _ShapeCollisionFilterBlock))

    def template_pairs(self) -> tuple[tuple[int, int], ...]:
        """Materialized filter template used when copying a source builder."""
        if self._template_cache is None:
            self._template_cache = tuple(self)
        return self._template_cache

    def __bool__(self) -> bool:
        return self._pair_count != 0

    def __iter__(self):
        for entry in self._entries:
            if isinstance(entry, _ShapeCollisionFilterBlock):
                yield from (
                    (entry.shape_start + shape_a, entry.shape_start + shape_b) for shape_a, shape_b in entry.local_pairs
                )
            else:
                yield entry

    def append(self, pair: tuple[int, int]) -> None:
        self._entries.append(pair)
        self._pair_count += 1
        self._template_cache = None

    def extend_offset(
        self,
        local_pairs: Iterable[tuple[int, int]],
        shape_offset: int,
        *,
        world: int | None = None,
        shape_count: int = 0,
    ) -> None:
        local_pairs = tuple(local_pairs)
        if not local_pairs:
            return

        # Replication repeatedly appends the same source-builder local filter
        # pairs with a different shape offset. Store that as one block instead
        # of expanding every pair immediately.
        self._entries.append(
            _ShapeCollisionFilterBlock(
                shape_start=shape_offset,
                local_pairs=local_pairs,
                world=world,
                shape_count=shape_count,
            )
        )
        self._pair_count += len(local_pairs)
        self._template_cache = None


class ModelBuilder:
    """A helper class for building simulation models at runtime.

    Use the ModelBuilder to construct a simulation scene. The ModelBuilder
    represents the scene using standard Python data structures like lists,
    which are convenient but unsuitable for efficient simulation.
    Call :meth:`finalize <ModelBuilder.finalize>` to construct a simulation-ready Model.

    Example
    -------

    .. testcode::

        import newton
        from newton.solvers import SolverXPBD

        builder = newton.ModelBuilder()

        # anchor point (zero mass)
        builder.add_particle((0, 1.0, 0.0), (0.0, 0.0, 0.0), 0.0)

        # build chain
        for i in range(1, 10):
            builder.add_particle((i, 1.0, 0.0), (0.0, 0.0, 0.0), 1.0)
            builder.add_spring(i - 1, i, 1.0e3, 0.0, 0)

        # create model
        model = builder.finalize()

        state_0, state_1 = model.state(), model.state()
        control = model.control()
        solver = SolverXPBD(model)
        collision_pipeline = newton.CollisionPipeline(model)
        contacts = collision_pipeline.contacts()

        for i in range(10):
            state_0.clear_forces()
            collision_pipeline.collide(state_0, contacts)
            solver.step(state_0, state_1, control, contacts, dt=1.0 / 60.0)
            state_0, state_1 = state_1, state_0

    World Grouping
    --------------------

    ModelBuilder supports world grouping to organize entities for multi-world simulations.
    Each entity (particle, body, shape, joint, articulation) has an associated world index:

    - Index -1: Global entities shared across all worlds (e.g., ground plane)
    - Index 0, 1, 2, ...: World-specific entities

    See :doc:`Worlds </concepts/worlds>` for a full overview of world semantics,
    layout, and supported workflows.

    There are two supported workflows for assigning world indices:

    1. **Using begin_world()/end_world()**: Entities added outside any world
       context, before the first :meth:`begin_world` or after the matching
       :meth:`end_world`, are assigned to the global world (index ``-1``).
       :class:`ModelBuilder` manages :attr:`current_world` while a world context is
       active::

           builder = ModelBuilder()
           builder.add_ground_plane()  # global (world -1)

           builder.begin_world(label="robot_0")
           builder.add_body(...)  # world 0
           builder.end_world()

    2. **Using add_world()/replicate()**: All entities from the sub-builder are
       assigned to a new world::

           robot = ModelBuilder()
           robot.add_body(...)  # World assignments here will be overridden

           main = ModelBuilder()
           main.add_world(robot)  # All robot entities -> world 0
           main.replicate(robot, world_count=2)  # Add more worlds from the same source

    :attr:`current_world` is builder-managed, read-only state. Use
    :meth:`begin_world`, :meth:`end_world`, :meth:`add_world`, or
    :meth:`replicate` to manage world assignment.

    Note:
        It is strongly recommended to use the ModelBuilder to construct a simulation rather
        than creating your own Model object directly, however it is possible to do so if
        desired.

    """

    _DEFAULT_GROUND_PLANE_COLOR = (0.125, 0.125, 0.15)
    _DEFAULT_TRI_COLOR = (0.7, 0.5, 0.3)
    _SHAPE_COLOR_PALETTE = (
        # Paul Tol - Bright 9
        (68, 119, 170),  # blue
        (102, 204, 238),  # cyan
        (34, 136, 51),  # green
        (204, 187, 68),  # yellow
        (238, 102, 119),  # red
        (170, 51, 119),  # magenta
        (238, 153, 51),  # orange
        (0, 153, 136),  # teal
    )
    # Use one quiet default for dense cable/rod examples; callers can pass color=
    # when per-rod or per-scene coloring matters.
    _DEFAULT_ROD_COLOR = (
        _SHAPE_COLOR_PALETTE[0][0] / 255.0,
        _SHAPE_COLOR_PALETTE[0][1] / 255.0,
        _SHAPE_COLOR_PALETTE[0][2] / 255.0,
    )
    _ROD_BODY_FRAME_ORIGIN_DEPRECATION_MESSAGE = (
        "Omitting body_frame_origin when creating rods is deprecated because the implicit default "
        "will change from 'start' to 'com' in a future release. Pass body_frame_origin='start' to "
        "preserve the existing start-node body frame, or body_frame_origin='com' to opt into "
        "COM-centered capsule body frames."
    )

    _BUILDER_ATTRIBUTE_SPECS: ClassVar[dict[str, Model.AttributeSpec]] = {
        "body_lock_inertia": Model.AttributeSpec(Model.AttributeFrequency.BODY),
        "joint_collision_filter_parent": Model.AttributeSpec(Model.AttributeFrequency.JOINT),
        "joint_cts": Model.AttributeSpec(Model.AttributeFrequency.JOINT_CONSTRAINT),
        "joint_cts_start": Model.AttributeSpec(
            Model.AttributeFrequency.JOINT,
            references=Model.AttributeFrequency.JOINT_CONSTRAINT,
            compaction_policy="start",
        ),
        "shape_sdf_narrow_band_range": Model.AttributeSpec(Model.AttributeFrequency.SHAPE),
        "shape_sdf_max_resolution": Model.AttributeSpec(Model.AttributeFrequency.SHAPE),
        "shape_force_sdf": Model.AttributeSpec(Model.AttributeFrequency.SHAPE),
        "shape_sdf_target_voxel_size": Model.AttributeSpec(Model.AttributeFrequency.SHAPE),
        "shape_sdf_texture_format": Model.AttributeSpec(Model.AttributeFrequency.SHAPE),
        "shape_sdf_padding": Model.AttributeSpec(Model.AttributeFrequency.SHAPE),
        "muscle_start": Model.AttributeSpec("muscle", references="muscle_point", compaction_policy="start"),
        "muscle_params": Model.AttributeSpec("muscle"),
        "muscle_activations": Model.AttributeSpec("muscle"),
        "muscle_bodies": Model.AttributeSpec("muscle_point", references=Model.AttributeFrequency.BODY),
        "muscle_points": Model.AttributeSpec("muscle_point"),
        "world_gravity": Model.AttributeSpec(Model.AttributeFrequency.WORLD, compaction_policy="passthrough"),
        "_equality_constraint_world_start": Model.AttributeSpec(
            Model.AttributeFrequency.WORLD,
            compaction_policy="passthrough",
        ),
        "_shape_collision_filter_pairs": Model.AttributeSpec(
            Model.AttributeFrequency.ONCE,
            compaction_policy="passthrough",
        ),
    }

    _BUILDER_GROUP_REFERENCES: ClassVar[dict[str, dict[str, Model.AttributeFrequency]]] = {
        "cable": {
            "body_start": Model.AttributeFrequency.BODY,
            "body_end": Model.AttributeFrequency.BODY,
            "joint_start": Model.AttributeFrequency.JOINT,
            "joint_end": Model.AttributeFrequency.JOINT,
        },
        "cloth": {
            "particle_start": Model.AttributeFrequency.PARTICLE,
            "particle_end": Model.AttributeFrequency.PARTICLE,
            "tri_start": Model.AttributeFrequency.TRIANGLE,
            "tri_end": Model.AttributeFrequency.TRIANGLE,
            "edge_start": Model.AttributeFrequency.EDGE,
            "edge_end": Model.AttributeFrequency.EDGE,
        },
        "soft": {
            "particle_start": Model.AttributeFrequency.PARTICLE,
            "particle_end": Model.AttributeFrequency.PARTICLE,
            "tet_start": Model.AttributeFrequency.TETRAHEDRON,
            "tet_end": Model.AttributeFrequency.TETRAHEDRON,
        },
    }

    # Lazy snapshots of a plain ModelBuilder's attribute names; see _base_builder_attributes().
    _BASE_ATTRIBUTES: ClassVar[frozenset[str] | None] = None
    _BASE_LIST_ATTRIBUTES: ClassVar[frozenset[str] | None] = None
    # Per-class merge schema cache; see _builder_merge_attribute_specs().
    _MERGE_ATTRIBUTE_SPEC_CACHE: ClassVar[dict[bool, dict[str, Model.AttributeSpec]]]

    @staticmethod
    def _shape_palette_color(index: int) -> tuple[float, float, float]:
        color = ModelBuilder._SHAPE_COLOR_PALETTE[index % len(ModelBuilder._SHAPE_COLOR_PALETTE)]
        return (color[0] / 255.0, color[1] / 255.0, color[2] / 255.0)

    @staticmethod
    def _coerce_shape_color(color: Vec3 | None) -> tuple[float, float, float] | None:
        if color is None:
            return None
        return (float(color[0]), float(color[1]), float(color[2]))

    @staticmethod
    def _external_warning_stacklevel() -> int:
        frame = inspect.currentframe()
        if frame is None:
            return 2

        frame = frame.f_back
        stacklevel = 1
        try:
            while frame is not None and os.path.normpath(frame.f_code.co_filename).startswith(_NEWTON_SRC_DIR):
                frame = frame.f_back
                stacklevel += 1
            return stacklevel
        finally:
            del frame

    @classmethod
    def _resolve_rod_body_frame_origin(
        cls,
        method_name: str,
        body_frame_origin: Literal["start", "com"] | None,
    ) -> Literal["start", "com"]:
        if body_frame_origin is None:
            warnings.warn(
                cls._ROD_BODY_FRAME_ORIGIN_DEPRECATION_MESSAGE,
                DeprecationWarning,
                stacklevel=cls._external_warning_stacklevel(),
            )
            return "start"
        if body_frame_origin not in ("start", "com"):
            raise ValueError(f"{method_name}: body_frame_origin must be 'start' or 'com', got {body_frame_origin!r}")
        return body_frame_origin

    @dataclass
    class ActuatorEntry:
        """Stores accumulated specs for one group of compatible composed actuators.

        Each element in ``indices`` is a single DOF index.  The entry key is
        ``(drive_class, delay_steps is not None, clamping_key, drive_shared_key)``
        where shared params (e.g. ``model_path``, lookup tables) must
        be identical across all actuators in a group.  Delay step values
        are per-DOF; the buffer is sized to ``max(delay_step_values) + 1``.
        """

        drive_class: type  # DriveBase subclass (e.g. DrivePD)
        clamping_classes: tuple  # Tuple of Clamping subclass types (in order)
        clamping_shared_kwargs: tuple  # Tuple of dicts: shared kwargs per clamping class
        drive_shared_kwargs: dict  # Shared drive kwargs (e.g. model_path)
        indices: list[int]  # Per-actuator DOF indices (joint_qd layout)
        pos_indices: list[int]  # Per-actuator position indices (joint_q layout)
        drive_args: list[dict[str, Any]]  # Per-actuator drive array params
        delay_args: list[dict[str, Any]]  # Per-actuator delay params (empty if no delay)
        clamping_args: list[list[dict[str, Any]]]  # Per-actuator per-clamping array params

    @dataclass
    class BvhConfig:
        """Default BVH construction settings used during model finalization."""

        mesh_constructor: str | None = None
        """Warp mesh BVH constructor backend. If ``None``, Warp's default is used."""

        gaussian_constructor: str | None = None
        """Warp Gaussian BVH constructor backend. If ``None``, Warp's default is used."""

        shape_constructor: str | None = None
        """Warp model shape BVH constructor backend. If ``None``, Warp's default is used."""

        shape_flags: ShapeFlags = ShapeFlags.VISIBLE
        """Mask of :class:`~newton.ShapeFlags`; a shape is included in the model shape BVH if any of its flags are set in the mask."""

    @dataclass
    class MeshApproximationConfig:
        """Default settings for mesh approximation.

        :attr:`ModelBuilder.default_mesh_approximation_cfg` supplies defaults for
        settings not passed to :meth:`ModelBuilder.approximate_meshes` explicitly,
        including approximation triggered by :meth:`ModelBuilder.add_usd` via the
        authored ``physics:approximation`` attribute.
        """

        coacd_threshold: float = 0.05
        """CoACD concavity threshold. Lower values produce finer convex decompositions with more parts."""

    @dataclass(kw_only=True)
    class ShapeConfig:
        """
        Represents per-shape collision, material, mass, and SDF settings.

        These fields are general model data, and not every field is respected
        or needed by every solver. Solvers and contact backends may use,
        combine, or ignore individual fields according to their formulation;
        see solver-specific documentation for behavior.
        """

        density: float = 1000.0
        """The density of the shape material."""
        ke: float = 2.5e3
        """The normal contact stiffness [N/m]."""
        kd: float = 100.0
        """The normal contact damping coefficient [N·s/m]."""
        kf: float = 1000.0
        """The contact friction gain [N·s/m]."""
        ka: float = 0.0
        """The contact adhesion distance [m]."""
        mu: float = 1.0
        """The coefficient of friction."""
        restitution: float = 0.0
        """The coefficient of restitution.

        :class:`~newton.solvers.SolverXPBD` requires ``enable_restitution=True``
        on the solver constructor for this field to take effect.
        """
        mu_torsional: float = 0.005
        """The coefficient of torsional friction [m] (resistance to spinning at contact point)."""
        mu_rolling: float = 0.0001
        """The coefficient of rolling friction [m] (resistance to rolling motion)."""
        margin: float = 0.0
        """Outward offset from the shape's surface [m] for collision detection.
        Extends the effective collision surface outward by this amount. When two shapes collide,
        their margins are summed (margin_a + margin_b) to determine the total separation [m].
        This value is also used when computing inertia for hollow shapes (``is_solid=False``)."""
        gap: float | None = None
        """Additional contact detection gap [m]. If None, uses builder.rigid_gap as default.
        Broad phase uses (margin + gap) [m] for AABB expansion and pair filtering."""
        is_solid: bool = True
        """Indicates whether the shape is solid or hollow. Defaults to True."""
        collision_group: int = 1
        """The collision group ID for the shape. Defaults to 1 (default group). Set to 0 to disable collisions for this shape."""
        collision_filter_parent: bool = True
        """Whether to inherit collision filtering from the parent. Defaults to True."""
        has_shape_collision: bool = True
        """Whether the shape can collide with other shapes. Defaults to True."""
        has_particle_collision: bool = True
        """Whether the shape can collide with particles. Defaults to True."""
        is_visible: bool = True
        """Indicates whether the shape is visible in the simulation. Defaults to True."""
        is_site: bool = False
        """Indicates whether the shape is a site (non-colliding reference point). Directly setting this to True will NOT enforce site invariants. Use `mark_as_site()` or set via the `flags` property to ensure invariants. Defaults to False."""
        sdf_narrow_band_range: tuple[float, float] | list[float] = (-0.1, 0.1)
        """The narrow band distance range (inner, outer) for primitive SDF computation."""
        sdf_target_voxel_size: float | None = None
        """Target voxel size for sparse SDF grid.
        If provided, enables primitive SDF generation and takes precedence over
        sdf_max_resolution. Requires GPU since wp.Volume only supports CUDA."""
        sdf_max_resolution: int | None = None
        """Maximum dimension for sparse SDF grid (must be divisible by 8).
        If provided (and sdf_target_voxel_size is None), enables primitive SDF
        generation. Requires GPU since wp.Volume only supports CUDA."""
        force_sdf: bool = False
        """If True, :meth:`ModelBuilder.finalize` builds a volume SDF for this mesh/convex shape even
        when neither ``sdf_max_resolution`` nor ``sdf_target_voxel_size`` is set (built at the default
        resolution). Use to provision SDFs for full-surface rigid-soft contact; see :meth:`configure_sdf`."""
        sdf_texture_format: str = "uint16"
        """Subgrid texture storage format for the SDF. ``"uint16"``
        (default) stores subgrid voxels as 16-bit normalized textures (half
        the memory of ``"float32"``). ``"float32"`` stores full-precision
        values. ``"uint8"`` uses 8-bit textures for minimum memory."""
        is_hydroelastic: bool = False
        """Whether the shape collides using SDF-based hydroelastics. For hydroelastic collisions, both participating shapes must have is_hydroelastic set to True. Defaults to False.

        .. note::
            Hydroelastic collision handling only works with volumetric shapes and in particular will not work for shapes like flat meshes or cloth.
            This flag will be automatically set to False for planes and heightfields in :meth:`ModelBuilder.add_shape`.
        """
        kh: float = 1.0e10
        """Hydroelastic contact stiffness coefficient [N/m^3].

        .. note::
            The default linear pressure law is
            ``pressure = -kh * signed_depth``. Effective contact force scales
            with contact area, so ``kh`` sets a pressure-to-penetration ratio,
            not a direct force-to-penetration ratio. Solvers and contact
            backends may scale or otherwise interpret this coefficient
            according to their formulation.

            For :class:`~newton.solvers.SolverMuJoCo`, stiffness values are
            internally scaled by masses when Newton-generated contacts are
            passed through the MuJoCo contact path. Tune ``kh`` with that
            scaling in mind.
        """
        sdf_padding: float | None = None
        """SDF AABB padding [m] for primitive texture SDFs. Falls back to
        :attr:`gap`, plus :attr:`margin` for hydroelastic shapes, when
        ``None``. Hydroelastic padding must cover ``margin + gap``. Rejected
        on ``MESH`` / ``CONVEX_MESH`` shapes — pass ``margin`` to
        :meth:`~newton.geometry.Mesh.build_sdf` instead."""

        def configure_sdf(
            self,
            *,
            max_resolution: int | None = None,
            target_voxel_size: float | None = None,
            is_hydroelastic: bool = False,
            kh: float = 1.0e10,
            texture_format: str | None = None,
            force_sdf: bool = False,
        ) -> None:
            """Enable SDF-based collision for this shape.

            Sets SDF and hydroelastic options in one place. Call this when the shape
            should use SDF mesh-mesh collision and optionally hydroelastic contacts.

            Args:
                max_resolution: Maximum dimension for sparse SDF grid (must be divisible by 8).
                    If provided, enables SDF-based mesh-mesh collision and clears any
                    previous target_voxel_size setting.
                target_voxel_size: Target voxel size for sparse SDF grid. If provided, enables
                    SDF generation and clears any previous max_resolution setting.
                is_hydroelastic: Whether to use SDF-based hydroelastic contacts. Both shapes
                    in a pair must have this enabled.
                kh: Hydroelastic contact stiffness coefficient.
                texture_format: Subgrid texture storage format. ``"uint16"``
                    (default) uses 16-bit normalized textures. ``"float32"``
                    uses full-precision. ``"uint8"`` uses 8-bit textures.
                force_sdf: Build the SDF even when neither ``max_resolution`` nor
                    ``target_voxel_size`` is given (uses the default resolution). Provisions the SDF
                    needed for full-surface rigid-soft contact without picking a resolution.

            Raises:
                ValueError: If both max_resolution and target_voxel_size are provided.
            """
            if max_resolution is not None and target_voxel_size is not None:
                raise ValueError("configure_sdf accepts either max_resolution or target_voxel_size, not both.")
            self.force_sdf = force_sdf
            if max_resolution is not None:
                self.sdf_max_resolution = max_resolution
                self.sdf_target_voxel_size = None
            if target_voxel_size is not None:
                self.sdf_target_voxel_size = target_voxel_size
                self.sdf_max_resolution = None
            self.is_hydroelastic = is_hydroelastic
            self.kh = kh
            if texture_format is not None:
                self.sdf_texture_format = texture_format

        def validate(self, shape_type: int | None = None) -> None:
            """Validate ShapeConfig parameters.

            Args:
                shape_type: Optional shape geometry type used for context-specific
                    validation.
            """
            _valid_tex_fmts = ("float32", "uint16", "uint8")
            if self.sdf_texture_format not in _valid_tex_fmts:
                raise ValueError(
                    f"Unknown sdf_texture_format {self.sdf_texture_format!r}. Expected one of {list(_valid_tex_fmts)}."
                )
            if not math.isfinite(self.density) or self.density < 0.0:
                raise ValueError(f"density must be finite and >= 0 (got {self.density}).")

            if self.sdf_target_voxel_size is not None and (
                not math.isfinite(self.sdf_target_voxel_size) or self.sdf_target_voxel_size <= 0.0
            ):
                raise ValueError(f"sdf_target_voxel_size must be finite and > 0 (got {self.sdf_target_voxel_size}).")

            if self.sdf_padding is not None and (not math.isfinite(self.sdf_padding) or self.sdf_padding < 0.0):
                raise ValueError(f"sdf_padding must be finite and >= 0 (got {self.sdf_padding}).")

            if not isinstance(self.sdf_narrow_band_range, (tuple, list)) or len(self.sdf_narrow_band_range) != 2:
                raise ValueError(
                    "sdf_narrow_band_range must contain two distances (inner, outer) with inner < 0 < outer."
                )
            inner, outer = self.sdf_narrow_band_range
            if not math.isfinite(inner) or not math.isfinite(outer) or not inner < 0.0 < outer:
                raise ValueError(
                    f"sdf_narrow_band_range must contain finite values satisfying inner < 0 < outer "
                    f"(got {self.sdf_narrow_band_range})."
                )

            if self.sdf_max_resolution is not None and self.sdf_target_voxel_size is not None:
                raise ValueError("Set only one of sdf_max_resolution or sdf_target_voxel_size, not both.")
            if self.sdf_max_resolution is not None:
                if self.sdf_max_resolution <= 0:
                    raise ValueError(f"sdf_max_resolution must be > 0 (got {self.sdf_max_resolution}).")
                if self.sdf_max_resolution >= (1 << 16):
                    raise ValueError(f"sdf_max_resolution must be less than {1 << 16}.")
                if self.sdf_max_resolution % 8 != 0:
                    raise ValueError(
                        f"sdf_max_resolution must be divisible by 8 (got {self.sdf_max_resolution}). "
                        "This is required because SDF volumes are allocated in 8x8x8 tiles."
                    )
            hydroelastic_supported = shape_type not in (GeoType.PLANE, GeoType.HFIELD)
            hydroelastic_requires_configured_sdf = shape_type in (
                GeoType.SPHERE,
                GeoType.BOX,
                GeoType.CAPSULE,
                GeoType.CYLINDER,
                GeoType.ELLIPSOID,
                GeoType.CONE,
            )
            if (
                self.is_hydroelastic
                and hydroelastic_supported
                and hydroelastic_requires_configured_sdf
                and self.has_shape_collision
                and self.sdf_max_resolution is None
                and self.sdf_target_voxel_size is None
            ):
                raise ValueError(
                    "Hydroelastic shapes require an SDF. Set either sdf_max_resolution or sdf_target_voxel_size."
                )

        def mark_as_site(self) -> None:
            """Marks this shape as a site and enforces all site invariants.

            Sets:
            - is_site = True
            - has_shape_collision = False
            - has_particle_collision = False
            - density = 0.0
            - collision_group = 0
            """
            self.is_site = True
            self.has_shape_collision = False
            self.has_particle_collision = False
            self.density = 0.0
            self.collision_group = 0

        @property
        def flags(self) -> int:
            """Returns the flags for the shape."""

            shape_flags = ShapeFlags.VISIBLE if self.is_visible else 0
            shape_flags |= ShapeFlags.COLLIDE_SHAPES if self.has_shape_collision else 0
            shape_flags |= ShapeFlags.COLLIDE_PARTICLES if self.has_particle_collision else 0
            shape_flags |= ShapeFlags.SITE if self.is_site else 0
            shape_flags |= ShapeFlags.HYDROELASTIC if self.is_hydroelastic else 0
            return shape_flags

        @flags.setter
        def flags(self, value: int):
            """Sets the flags for the shape."""

            self.is_visible = bool(value & ShapeFlags.VISIBLE)
            self.is_hydroelastic = bool(value & ShapeFlags.HYDROELASTIC)

            # Check if SITE flag is being set
            is_site_flag = bool(value & ShapeFlags.SITE)

            if is_site_flag:
                # Use mark_as_site() to enforce invariants
                self.mark_as_site()
                # Collision flags will be cleared by mark_as_site()
            else:
                # SITE flag is being cleared - restore non-site defaults
                defaults = self.__class__()
                self.is_site = False
                self.density = defaults.density
                self.collision_group = defaults.collision_group
                self.has_shape_collision = bool(value & ShapeFlags.COLLIDE_SHAPES)
                self.has_particle_collision = bool(value & ShapeFlags.COLLIDE_PARTICLES)

        def copy(self) -> ModelBuilder.ShapeConfig:
            return copy.copy(self)

    class JointDofConfig:
        """
        Describes a joint axis (a single degree of freedom) that can have limits and be driven towards a target.
        """

        def __init__(
            self,
            *,
            axis: AxisType | Vec3 = Axis.X,
            limit_lower: float = -MAXVAL,
            limit_upper: float = MAXVAL,
            limit_ke: float = 1e4,
            limit_kd: float = 1e1,
            target_pos: float = 0.0,
            target_vel: float = 0.0,
            target_ke: float = 0.0,
            target_kd: float = 0.0,
            damping: float = 0.0,
            armature: float = 0.0,
            effort_limit: float = 1e6,
            velocity_limit: float = 1e6,
            friction: float = 0.0,
            actuator_mode: JointTargetMode | None = None,
        ):
            self.axis = wp.normalize(axis_to_vec3(axis))
            """The 3D joint axis in the joint parent anchor frame."""
            self.limit_lower = limit_lower
            """The lower position limit of the joint axis. Defaults to -MAXVAL (unlimited)."""
            self.limit_upper = limit_upper
            """The upper position limit of the joint axis. Defaults to MAXVAL (unlimited)."""
            self.limit_ke = limit_ke
            """The elastic stiffness of the joint axis limits. Defaults to 1e4."""
            self.limit_kd = limit_kd
            """The damping coefficient of the joint axis limits
            [N·s/m or N·m·s/rad, depending on joint type]. Defaults to 1e1."""
            self.target_pos = target_pos
            """The target position of the joint axis.
            If the initial `target_pos` is outside the limits,
            it defaults to the midpoint of `limit_lower` and `limit_upper`. Otherwise, defaults to 0.0."""
            self.target_vel = target_vel
            """The target velocity of the joint axis."""
            self.target_ke = target_ke
            """The proportional gain of the target drive PD controller. Defaults to 0.0."""
            self.target_kd = target_kd
            """The derivative gain of the target drive PD controller. Defaults to 0.0."""
            self.damping = damping
            """Passive velocity damping [N·s/m or N·m·s/rad, depending on joint type] that is always active. Defaults to 0.0."""
            self.armature = armature
            """Artificial inertia added around the joint axis [kg·m² or kg]. Defaults to 0."""
            self.effort_limit = effort_limit
            """Maximum effort (force or torque) the joint axis can exert. Defaults to 1e6."""
            self.velocity_limit = velocity_limit
            """Maximum velocity the joint axis can achieve. Defaults to 1e6."""
            self.friction = friction
            """Friction coefficient for the joint axis. Defaults to 0.0."""
            self.actuator_mode = actuator_mode
            """Actuator mode for this DOF. Determines which actuators are installed (see :class:`JointTargetMode`).
            If None, the mode is inferred from gains and targets."""

            if self.target_pos > self.limit_upper or self.target_pos < self.limit_lower:
                self.target_pos = 0.5 * (self.limit_lower + self.limit_upper)

        @classmethod
        def create_unlimited(cls, axis: AxisType | Vec3) -> ModelBuilder.JointDofConfig:
            """Creates a JointDofConfig with no limits."""
            return ModelBuilder.JointDofConfig(
                axis=axis,
                limit_lower=-MAXVAL,
                limit_upper=MAXVAL,
                target_pos=0.0,
                target_vel=0.0,
                target_ke=0.0,
                target_kd=0.0,
                damping=0.0,
                armature=0.0,
                limit_ke=0.0,
                limit_kd=0.0,
            )

    @dataclass
    class CustomAttribute:
        """
        Represents a custom attribute definition for the ModelBuilder.
        This is used to define custom attributes that are not part of the standard ModelBuilder API.
        Custom attributes can be defined for the :class:`~newton.Model`, :class:`~newton.State`, :class:`~newton.Control`, or :class:`~newton.Contacts` objects, depending on the :class:`Model.AttributeAssignment` category.
        Custom attributes must be declared before use via the :meth:`newton.ModelBuilder.add_custom_attribute` method.

        See :ref:`custom_attributes` for more information.
        """

        name: str
        """Variable name to expose on the Model. Must be a valid Python identifier."""

        dtype: type
        """Warp dtype (e.g., wp.float32, wp.int32, wp.bool, wp.vec3) that is compatible with Warp arrays,
        or ``str`` for string attributes that remain as Python lists."""

        frequency: Model.AttributeFrequency | str
        """Frequency category that determines how the attribute is indexed in the Model.

        Can be either:
            - A :class:`Model.AttributeFrequency` enum value for built-in frequencies (BODY, SHAPE, JOINT, etc.)
              Uses dict-based storage where keys are entity indices, allowing sparse assignment.
            - A string for custom frequencies using the full frequency key (e.g., ``"mujoco:pair"``).
              Uses list-based storage for sequential data appended via :meth:`~newton.ModelBuilder.add_custom_values`. All attributes
              sharing the same custom frequency must have the same count, validated by
              :meth:`finalize <ModelBuilder.finalize>`."""

        assignment: Model.AttributeAssignment = Model.AttributeAssignment.MODEL
        """Assignment category (see :class:`Model.AttributeAssignment`), defaults to :attr:`Model.AttributeAssignment.MODEL`"""

        namespace: str | None = None
        """Namespace for the attribute. If None, the attribute is added directly to the assigned object without a namespace."""

        references: str | None = None
        """For attributes containing entity indices, specifies how values are transformed during add_builder/add_world/replicate merging.

        Built-in entity types (values are offset by entity count):
            - ``"body"``, ``"shape"``, ``"joint"``, ``"joint_dof"``, ``"joint_coord"``, ``"articulation"``,
              ``"constraint_mimic"``, ``"particle"``, ``"edge"``, ``"triangle"``, ``"tetrahedron"``, ``"spring"``

        Special handling:
            - ``"world"``: Values are replaced with the builder-managed
              :attr:`ModelBuilder.current_world` context (not offset)

        Custom frequencies (values are offset by that frequency's count):
            - Any custom frequency string, e.g., ``"mujoco:pair"``
        """

        default: Any = None
        """Default value for the attribute. If None, the default value is determined based on the dtype."""

        values: dict[int, Any] | list[Any] | None = None
        """Storage for specific values (overrides).

        For enum frequencies (BODY, SHAPE, etc.): dict[int, Any] mapping entity indices to values.
        For string frequencies ("mujoco:pair", etc.): list[Any] for sequential custom data.

        If None, the attribute is not initialized with any values. Values can be assigned in subsequent
        ``ModelBuilder.add_*(..., custom_attributes={...})`` method calls for specific entities after
        the CustomAttribute has been added through the :meth:`ModelBuilder.add_custom_attribute` method."""

        usd_attribute_name: str | None = None
        """Name of the USD attribute to read values from during USD parsing.

        - If ``None`` (default), the name is derived automatically as ``"newton:<key>"``
          where ``<key>`` is ``"<namespace>:<name>"`` or just ``"<name>"`` if no namespace is set.
        - If set to ``"*"``, the :attr:`usd_value_transformer` is called for every prim matching
          the attribute's frequency, regardless of which USD attributes exist on the prim. The transformer
          receives ``None`` as the value argument. This is useful for computing attribute values from
          arbitrary prim data rather than reading a specific USD attribute.
          A :attr:`usd_value_transformer` **must** be provided when using ``"*"``; otherwise,
          :meth:`~newton.ModelBuilder.add_custom_attribute` raises a :class:`ValueError`.
        """

        mjcf_attribute_name: str | None = None
        """Name of the attribute in the MJCF definition. If None, the attribute name is used."""

        urdf_attribute_name: str | None = None
        """Name of the attribute in the URDF definition. If None, the attribute name is used."""

        usd_value_transformer: Callable[[Any, dict[str, Any]], Any] | None = None
        """Transformer function that converts a USD attribute value to a valid Warp dtype. If undefined, the generic converter from :func:`newton.usd.convert_warp_value` is used. Receives a context dict with the following keys:
        - ``"prim"``: The USD prim to query.
        - ``"attr"``: The :class:`~newton.ModelBuilder.CustomAttribute` object to get the value for."""

        mjcf_value_transformer: Callable[[str, dict[str, Any] | None], Any] | None = None
        """Transformer function that converts a MJCF attribute value string to a valid Warp dtype. If undefined, the generic converter from :func:`newton.utils.parse_warp_value_from_string` is used. Receives an optional context dict with parsing-time information (e.g., use_degrees, joint_type)."""

        urdf_value_transformer: Callable[[str, dict[str, Any] | None], Any] | None = None
        """Transformer function that converts a URDF attribute value string to a valid Warp dtype. If undefined, the generic converter from :func:`newton.utils.parse_warp_value_from_string` is used. Receives an optional context dict with parsing-time information."""

        def __post_init__(self):
            """Initialize default values and validate dtype compatibility."""
            # Allow str dtype for string attributes (stored as Python lists, not warp arrays)
            if self.dtype is not str:
                # ensure dtype is a valid Warp dtype
                try:
                    _size = wp.types.type_size_in_bytes(self.dtype)
                except TypeError as e:
                    raise ValueError(f"Invalid dtype: {self.dtype}. Must be a valid Warp dtype or str.") from e

            # Set dtype-specific default value if none was provided
            if self.default is None:
                self.default = self._default_for_dtype(self.dtype)

            # Initialize values with correct container type based on frequency
            if self.values is None:
                self.values = self._create_empty_values_container()
            if self.usd_attribute_name is None:
                self.usd_attribute_name = f"newton:{self.key}"
            if self.mjcf_attribute_name is None:
                self.mjcf_attribute_name = self.name
            if self.urdf_attribute_name is None:
                self.urdf_attribute_name = self.name

        @staticmethod
        def _default_for_dtype(dtype: object) -> Any:
            """Get default value for dtype when not specified."""
            # string type gets empty string
            if dtype is str:
                return ""
            # quaternions get identity quaternion
            if wp.types.type_is_quaternion(dtype):
                return wp.quat_identity(dtype._wp_scalar_type_)
            if dtype is wp.bool or dtype is bool:
                return False
            # vectors, matrices, scalars
            return dtype(0)

        @property
        def key(self) -> str:
            """Return the full name of the attribute, formatted as "namespace:name" or "name" if no namespace is specified."""
            return f"{self.namespace}:{self.name}" if self.namespace else self.name

        @property
        def is_custom_frequency(self) -> bool:
            """Check if this attribute uses a custom (string) frequency.

            Returns:
                True if the frequency is a string (custom frequency), False if it's a
                Model.AttributeFrequency enum (built-in frequency like BODY, SHAPE, etc.).
            """
            return isinstance(self.frequency, str)

        def _create_empty_values_container(self) -> list | dict:
            """Create appropriate empty container based on frequency type."""
            return [] if self.is_custom_frequency else {}

        def _get_values_count(self) -> int:
            """Get current count of values in this attribute."""
            if self.values is None:
                return 0
            return len(self.values)

        def _build_default_array(
            self, count: int, device: Devicelike | None = None, requires_grad: bool = False
        ) -> wp.array[Any] | list:
            """Build an attribute array when every entry is the default value."""
            if self.dtype is str:
                return [self.default] * count

            if isinstance(self.default, (list, tuple, np.ndarray)):
                arr = [self.default] * count
                return wp.array(arr, dtype=self.dtype, requires_grad=requires_grad, device=device)

            # Empty numeric custom attributes are common for registered solver
            # defaults. Let Warp fill the array directly instead of first
            # allocating a large Python list of repeated default values.
            return wp.full(
                count,
                self.default,
                dtype=self.dtype,
                requires_grad=requires_grad,
                device=device,
            )

        def build_array(
            self, count: int, device: Devicelike | None = None, requires_grad: bool = False
        ) -> wp.array[Any] | list:
            """Build wp.array (or list for string dtype) from count, dtype, default and overrides.

            For string dtype, returns a Python list[str] instead of a Warp array.
            """
            if self.values is None or len(self.values) == 0:
                return self._build_default_array(count, device=device, requires_grad=requires_grad)
            elif self.is_custom_frequency:
                # Custom frequency: vals is a list, replace None with defaults and pad/truncate as needed
                arr = [val if val is not None else self.default for val in self.values]
                arr = arr + [self.default] * max(0, count - len(arr))
                arr = arr[:count]  # Truncate if needed
            else:
                # Enum frequency: vals is a dict, use get() to fill gaps with defaults
                arr = [self.values.get(i, self.default) for i in range(count)]

            # String dtype: return as Python list instead of warp array
            if self.dtype is str:
                return arr

            return wp.array(arr, dtype=self.dtype, requires_grad=requires_grad, device=device)

    @dataclass
    class CustomFrequency:
        """
        Represents a custom frequency definition for the ModelBuilder.

        Custom frequencies allow defining entity types beyond the built-in ones (BODY, SHAPE, JOINT, etc.).
        They must be registered via :meth:`ModelBuilder.add_custom_frequency` before any custom attributes
        using them can be added.

        The optional ``usd_prim_filter`` callback enables automatic USD parsing for this frequency.
        When provided, :meth:`ModelBuilder.add_usd` will call this function for each prim in the USD
        stage to determine whether custom attribute values with this frequency should be extracted from it.

        See :ref:`custom_attributes` for more information on custom frequencies.

        Example:

            .. code-block:: python

                # Define a custom frequency for MuJoCo actuators with USD parsing support
                def is_actuator_prim(prim: Usd.Prim, context: dict[str, Any]) -> bool:
                    return prim.GetTypeName() == "MjcActuator"


                builder.add_custom_frequency(
                    ModelBuilder.CustomFrequency(
                        name="actuator",
                        namespace="mujoco",
                        usd_prim_filter=is_actuator_prim,
                    )
                )
        """

        name: str
        """The name of the custom frequency (e.g., ``"actuator"``, ``"pair"``)."""

        namespace: str | None = None
        """Namespace for the custom frequency. If provided, the frequency key becomes ``"namespace:name"``.
        If None, the custom frequency is registered without a namespace."""

        usd_prim_filter: Callable[[Usd.Prim, dict[str, Any]], bool] | None = None
        """Select which USD prims are used for this frequency.

        Called by :meth:`newton.ModelBuilder.add_usd` for each visited prim with:

        - ``prim``: current ``Usd.Prim``
        - ``context``: callback context dictionary with ``prim``, ``result``,
          and ``builder``

        Return ``True`` to parse this prim for the frequency, or ``False`` to skip it.
        If this is ``None``, the frequency is not parsed automatically from USD.

        Example:

            .. code-block:: python

                def is_actuator_prim(prim: Usd.Prim, context: dict[str, Any]) -> bool:
                    return prim.GetTypeName() == "MjcActuator"
        """

        usd_entry_expander: Callable[[Usd.Prim, dict[str, Any]], Iterable[dict[str, Any]]] | None = None
        """Build row entries for a matching USD prim.

        Called by :meth:`newton.ModelBuilder.add_usd` after :attr:`usd_prim_filter`
        returns ``True``. Return an iterable of dictionaries; each dictionary is one
        row passed to :meth:`newton.ModelBuilder.add_custom_values`.

        Use this when one prim should produce multiple rows. Missing keys in a row are
        filled with ``None`` so defaults still apply. Returning an empty iterable adds
        no rows.

        See also:
            When this callback is set, :meth:`newton.ModelBuilder.add_usd` does not run
            default per-attribute extraction for this frequency on matched prims
            (``usd_attribute_name`` / ``usd_value_transformer``).

        Example:

            .. code-block:: python

                def expand_tendon_rows(prim: Usd.Prim, context: dict[str, Any]) -> Iterable[dict[str, Any]]:
                    for joint_path in prim.GetCustomDataByKey("joint_paths") or []:
                        yield {"joint": joint_path, "stiffness": prim.GetCustomDataByKey("stiffness")}
        """

        articulation_owner_attribute: str | None = None
        """Full key of the attribute that assigns each row to an articulation.

        The key must be named ``<frequency>_articulation``.
        The attribute must use this custom frequency, be assigned to the model,
        and declare ``references="articulation"``. When provided,
        :class:`~newton.selection.ArticulationView` automatically exposes every
        array that uses this frequency.
        """

        articulation_owner_resolver: Callable[[ModelBuilder], Sequence[int]] | None = None
        """Optional callback that computes the articulation owner for every row.

        The callback runs before this builder is merged or finalized and its
        results populate :attr:`articulation_owner_attribute`. This keeps
        solver-specific ownership logic local to the custom-frequency
        registration while preserving ordinary reference remapping. Rows whose
        ownership was already remapped by a merge are preserved when later rows
        are appended and resolved.
        """

        label_attribute: str | None = None
        """Optional full key of a string attribute containing row labels.

        The key must be named ``<frequency>_label``.
        The attribute must use this custom frequency and be assigned to the model.
        :class:`~newton.selection.ArticulationView` uses it to expose labels for
        the template articulation. Builder merging applies ``label_prefix`` to
        these values like other entity labels.
        """

        def __post_init__(self):
            """Validate frequency naming and callback relationships."""
            if not self.name or ":" in self.name:
                raise ValueError(f"name must be non-empty and colon-free, got '{self.name}'")
            if self.namespace is not None and (not self.namespace or ":" in self.namespace):
                raise ValueError(f"namespace must be non-empty and colon-free, got '{self.namespace}'")
            if self.usd_entry_expander is not None and self.usd_prim_filter is None:
                raise ValueError("usd_entry_expander requires usd_prim_filter")
            if self.articulation_owner_resolver is not None and self.articulation_owner_attribute is None:
                raise ValueError("articulation_owner_resolver requires articulation_owner_attribute")
            for field_name, attribute_key, expected_key in (
                (
                    "articulation_owner_attribute",
                    self.articulation_owner_attribute,
                    f"{self.key}_articulation",
                ),
                ("label_attribute", self.label_attribute, f"{self.key}_label"),
            ):
                if attribute_key is not None and attribute_key != expected_key:
                    raise ValueError(
                        f"{field_name} for custom frequency '{self.key}' must be '{expected_key}', "
                        f"got '{attribute_key}'"
                    )

        @property
        def key(self) -> str:
            """The key of the custom frequency (e.g., ``"mujoco:actuator"`` or ``"pair"``)."""
            return f"{self.namespace}:{self.name}" if self.namespace else self.name

    def __init__(
        self,
        up_axis: AxisType = Axis.Z,
        gravity: float | Vec3 | None = None,
        sdf_texture_paired_samples: bool = True,
    ):
        """
        Initializes a new ModelBuilder instance for constructing simulation models.

        Args:
            up_axis: The axis to use as the "up" direction in the simulation.
                Defaults to Axis.Z.
            gravity: Default gravity vector [m/s^2]. The deprecated scalar form
                applies acceleration along ``up_axis``. If omitted, gravity
                defaults to -9.81 along ``up_axis``.
            sdf_texture_paired_samples: Store adjacent X samples together in
                SDF textures for faster software interpolation. Disable to
                halve SDF texture memory at the cost of slower hydroelastic
                sampling. This optimization is automatically disabled on CUDA
                devices with architectures older than SM90 when Warp was built
                with CUDA Toolkit 13.0 or earlier. Every prebuilt mesh SDF
                added to this builder must use the same effective layout,
                selected by the ``paired_samples`` argument to
                :meth:`Mesh.build_sdf` and the target device.
        """
        self.world_count: int = 0
        """Number of worlds accumulated for :attr:`Model.world_count`."""

        self.sdf_texture_paired_samples = bool(sdf_texture_paired_samples)
        """Whether generated SDF textures should store adjacent X samples together."""

        # region defaults
        self.default_bvh_cfg = ModelBuilder.BvhConfig()
        """Default BVH construction configuration used during model finalization."""

        self.default_mesh_approximation_cfg = ModelBuilder.MeshApproximationConfig()
        """Default mesh approximation settings used by :meth:`approximate_meshes` when not
        passed explicitly, including USD-triggered approximation in :meth:`add_usd`."""

        self.default_shape_cfg = ModelBuilder.ShapeConfig()
        """Default shape configuration used when shape-creation methods are called with ``cfg=None``.
        Update this object before adding shapes to set default contact/material properties."""

        self.default_joint_cfg = ModelBuilder.JointDofConfig()
        """Default joint DoF configuration used when joint DoF configuration is omitted."""

        self.default_particle_radius = 0.1
        """Default particle radius used when particle radius is not provided explicitly."""

        self.default_tri_ke = 100.0
        """Default triangle elastic stiffness for cloth/soft-triangle constraints."""

        self.default_tri_ka = 100.0
        """Default triangle area stiffness for cloth/soft-triangle constraints."""

        self.default_tri_kd = 10.0
        """Default triangle damping for cloth/soft-triangle constraints."""

        self.default_tri_drag = 0.0
        """Default aerodynamic drag coefficient for triangle elements."""

        self.default_tri_lift = 0.0
        """Default aerodynamic lift coefficient for triangle elements."""

        self.default_spring_ke = 100.0
        """Default spring elastic stiffness for distance constraints."""

        self.default_spring_kd = 0.0
        """Default spring damping for distance constraints."""

        self.default_edge_ke = 100.0
        """Default edge-bending elastic stiffness."""

        self.default_edge_kd = 0.0
        """Default edge-bending damping."""

        self.default_tet_k_mu = 1.0e3
        """Default first Lame parameter [Pa] for tetrahedral elements."""

        self.default_tet_k_lambda = 1.0e3
        """Default second Lame parameter [Pa] for tetrahedral elements."""

        self.default_tet_k_damp = 0.0
        """Default viscous damping coefficient [Pa·s] for tetrahedral elements."""

        self.default_tet_density = 1.0
        """Default density [kg/m^3] for tetrahedral soft bodies."""

        # endregion

        # region compiler settings (similar to MuJoCo)
        self.balance_inertia: bool = True
        """Whether to automatically correct rigid body inertia tensors that violate the triangle inequality.
        When True, adds a scalar multiple of the identity matrix to preserve rotation structure while
        ensuring physical validity (I1 + I2 >= I3 for principal moments). Default: True."""

        self.bound_mass: float | None = None
        """Minimum allowed mass value for rigid bodies [kg]. If set, any body mass below this
        value will be clamped to this minimum. Set to None to disable mass clamping.
        Default: None."""

        self.bound_inertia: float | None = None
        """Minimum allowed eigenvalue for rigid body inertia tensors [kg*m^2]. If set, ensures
        all principal moments of inertia are at least this value. Set to None to disable inertia
        eigenvalue clamping. Default: None."""

        self.validate_inertia_detailed: bool = False
        """Whether to use detailed (slower) inertia validation that provides per-body warnings.
        When False, uses a fast GPU kernel that reports only the total number of corrected bodies.
        When True, uses a CPU implementation that reports specific issues for each body.
        Both modes produce semantically identical corrected values on the returned
        :class:`Model`. Neither mode modifies the builder's internal state — corrected
        values live only on the Model.
        Default: False."""

        # endregion

        # particles
        self.particle_q: list[Vec3] = []
        """Particle positions [m] accumulated for :attr:`Model.particle_q`."""
        self.particle_qd: list[Vec3] = []
        """Particle velocities [m/s] accumulated for :attr:`Model.particle_qd`."""
        self.particle_mass: list[float] = []
        """Particle masses [kg] accumulated for :attr:`Model.particle_mass`."""
        self.particle_radius: list[float] = []
        """Particle radii [m] accumulated for :attr:`Model.particle_radius`."""
        self.particle_flags: list[int | ParticleFlags] = []
        """Particle flags accumulated for :attr:`Model.particle_flags`."""
        self.particle_max_velocity: float = 1e5
        """Maximum particle velocity [m/s] propagated to :attr:`Model.particle_max_velocity`."""
        self.particle_color_groups: list[Any] = []
        """Particle color groups accumulated for :attr:`Model.particle_color_groups`."""
        self.particle_world: list[int] = []
        """World indices accumulated for :attr:`Model.particle_world`."""

        # shapes (each shape has an entry in these arrays)
        self.shape_label: list[str] = []
        """Shape labels accumulated for :attr:`Model.shape_label`."""
        self.shape_transform: list[Transform] = []
        """Shape-to-body transforms accumulated for :attr:`Model.shape_transform`."""
        self.shape_body: list[int] = []
        """Body indices accumulated for :attr:`Model.shape_body`."""
        self.shape_flags: list[int] = []
        """Shape flags accumulated for :attr:`Model.shape_flags`."""
        self.shape_type: list[int] = []
        """Geometry type ids accumulated for :attr:`Model.shape_type`."""
        self.shape_scale: list[Vec3] = []
        """Shape scales accumulated for :attr:`Model.shape_scale`."""
        self.shape_source: list[Any] = []
        """Source geometry objects accumulated for :attr:`Model.shape_source`."""
        self.shape_color: list[Vec3] = []
        """Resolved display colors accumulated for :attr:`Model.shape_color`."""
        self.shape_opacity: list[float] = []
        """Resolved display opacities accumulated for :attr:`Model.shape_opacity`."""
        self.shape_is_solid: list[bool] = []
        """Solid-vs-hollow flags accumulated for :attr:`Model.shape_is_solid`."""
        self.shape_margin: list[float] = []
        """Shape margins [m] accumulated for :attr:`Model.shape_margin`."""
        self.shape_material_ke: list[float] = []
        """Contact stiffness values [N/m] accumulated for :attr:`Model.shape_material_ke`."""
        self.shape_material_kd: list[float] = []
        """Contact damping values accumulated for :attr:`Model.shape_material_kd`."""
        self.shape_material_kf: list[float] = []
        """Contact friction gains [N·s/m] accumulated for :attr:`Model.shape_material_kf`."""
        self.shape_material_ka: list[float] = []
        """Adhesion distances [m] accumulated for :attr:`Model.shape_material_ka`."""
        self.shape_material_mu: list[float] = []
        """Friction coefficients accumulated for :attr:`Model.shape_material_mu`."""
        self.shape_material_restitution: list[float] = []
        """Restitution coefficients accumulated for :attr:`Model.shape_material_restitution`."""
        self.shape_material_mu_torsional: list[float] = []
        """Torsional friction coefficients accumulated for :attr:`Model.shape_material_mu_torsional`."""
        self.shape_material_mu_rolling: list[float] = []
        """Rolling friction coefficients accumulated for :attr:`Model.shape_material_mu_rolling`."""
        self.shape_material_kh: list[float] = []
        """Hydroelastic stiffness values accumulated for :attr:`Model.shape_material_kh`."""
        self.shape_gap: list[float] = []
        """Contact gaps [m] accumulated for :attr:`Model.shape_gap`."""
        self.shape_collision_group: list[int] = []
        """Collision groups accumulated for :attr:`Model.shape_collision_group`."""
        self.shape_collision_radius: list[float] = []
        """Broadphase collision radii [m] accumulated for :attr:`Model.shape_collision_radius`."""
        self.shape_world: list[int] = []
        """World indices accumulated for :attr:`Model.shape_world`."""
        self.shape_sdf_narrow_band_range: list[tuple[float, float]] = []
        """Per-shape SDF narrow-band ranges retained until :meth:`finalize <ModelBuilder.finalize>` generates
        SDF data."""
        self.shape_sdf_target_voxel_size: list[float | None] = []
        """Per-shape target SDF voxel sizes retained until :meth:`finalize <ModelBuilder.finalize>`."""
        self.shape_sdf_max_resolution: list[int | None] = []
        """Per-shape SDF maximum resolutions retained until :meth:`finalize <ModelBuilder.finalize>`."""
        self.shape_force_sdf: list[bool] = []
        """Per-shape :attr:`ShapeConfig.force_sdf` flags retained until :meth:`finalize <ModelBuilder.finalize>`."""
        self.shape_sdf_texture_format: list[str] = []
        """Per-shape SDF texture format retained until :meth:`finalize <ModelBuilder.finalize>`."""
        self.shape_sdf_padding: list[float | None] = []
        """Per-shape SDF generation margins [m] retained until :meth:`finalize <ModelBuilder.finalize>`.
        When ``None``, :attr:`shape_gap` is used for primitive texture SDF generation."""
        # Mesh SDF storage (texture SDF arrays created at finalize)

        # filtering to ignore certain collision pairs
        self._shape_collision_filter_pairs: _BuilderShapeCollisionFilterPairs | list[tuple[int, int]] = (
            _BuilderShapeCollisionFilterPairs()
        )
        self._merge_filter_template: tuple[list[tuple[int, int]], int, tuple[tuple[int, int], ...]] | None = None
        """Cache backing :meth:`_materialized_filter_template`, as ``(source, length, template)``."""
        self._custom_schema_epoch: int = 0
        """Bumped whenever the custom attribute/frequency registry changes; keys the merge-validation cache."""

        self._requested_contact_attributes: set[str] = set()
        """Optional contact attributes requested via :meth:`request_contact_attributes`."""
        self._requested_state_attributes: set[str] = set()
        """Optional state attributes requested via :meth:`request_state_attributes`."""

        # springs
        self.spring_indices: list[int] = []
        """Spring particle index pairs accumulated for :attr:`Model.spring_indices`."""
        self.spring_rest_length: list[float] = []
        """Spring rest lengths [m] accumulated for :attr:`Model.spring_rest_length`."""
        self.spring_stiffness: list[float] = []
        """Spring stiffness values [N/m] accumulated for :attr:`Model.spring_stiffness`."""
        self.spring_damping: list[float] = []
        """Spring damping values accumulated for :attr:`Model.spring_damping`."""
        self.spring_control: list[float] = []
        """Spring control activations accumulated for :attr:`Model.spring_control`."""

        # triangles
        self.tri_indices: list[tuple[int, int, int]] = []
        """Triangle connectivity accumulated for :attr:`Model.tri_indices`."""
        self.tri_poses: list[Mat22] = []
        """Triangle rest-pose 2x2 matrices accumulated for :attr:`Model.tri_poses`."""
        self.tri_activations: list[float] = []
        """Triangle activations accumulated for :attr:`Model.tri_activations`."""
        self.tri_materials: list[tuple[float, float, float, float, float]] = []
        """Triangle material rows accumulated for :attr:`Model.tri_materials`."""
        self.tri_areas: list[float] = []
        """Triangle rest areas [m^2] accumulated for :attr:`Model.tri_areas`."""
        self.tri_color: list[Vec3] = []
        """Triangle surface display colors accumulated for :attr:`Model.tri_color`."""
        self.tri_opacity: list[float] = []
        """Triangle surface display opacities accumulated for :attr:`Model.tri_opacity`."""

        # edges (bending)
        self.edge_indices: list[tuple[int, int, int, int]] = []
        """Bending-edge connectivity accumulated for :attr:`Model.edge_indices`."""
        self.edge_rest_angle: list[float] = []
        """Edge rest angles [rad] accumulated for :attr:`Model.edge_rest_angle`."""
        self.edge_rest_length: list[float] = []
        """Edge rest lengths [m] accumulated for :attr:`Model.edge_rest_length`."""
        self.edge_bending_properties: list[tuple[float, float]] = []
        """Bending stiffness/damping rows accumulated for :attr:`Model.edge_bending_properties`."""

        # tetrahedra
        self.tet_indices: list[tuple[int, int, int, int]] = []
        """Tetrahedral connectivity accumulated for :attr:`Model.tet_indices`."""
        self.tet_poses: list[Mat33] = []
        """Tetrahedral rest-pose 3x3 matrices accumulated for :attr:`Model.tet_poses`."""
        self.tet_activations: list[float] = []
        """Tetrahedral activations accumulated for :attr:`Model.tet_activations`."""
        self.tet_materials: list[tuple[float, float, float]] = []
        """Tetrahedral material rows accumulated for :attr:`Model.tet_materials`."""

        # muscles
        self.muscle_start: list[int] = []
        """Muscle waypoint start indices accumulated for :attr:`Model.muscle_start`."""
        self.muscle_params: list[tuple[float, float, float, float, float]] = []
        """Muscle parameter rows accumulated for :attr:`Model.muscle_params`."""
        self.muscle_activations: list[float] = []
        """Muscle activations accumulated for :attr:`Model.muscle_activations`."""
        self.muscle_bodies: list[int] = []
        """Muscle waypoint body indices accumulated for :attr:`Model.muscle_bodies`."""
        self.muscle_points: list[Vec3] = []
        """Muscle waypoint local offsets accumulated for :attr:`Model.muscle_points`."""

        # rigid bodies
        self.body_mass: list[float] = []
        """Body masses [kg] accumulated for :attr:`Model.body_mass`."""
        self.body_inertia: list[Mat33] = []
        """Body inertia tensors accumulated for :attr:`Model.body_inertia`."""
        self.body_inv_mass: list[float] = []
        """Inverse body masses accumulated for :attr:`Model.body_inv_mass`."""
        self.body_inv_inertia: list[Mat33] = []
        """Inverse body inertia tensors accumulated for :attr:`Model.body_inv_inertia`."""
        self.body_com: list[Vec3] = []
        """Body centers of mass [m] accumulated for :attr:`Model.body_com`."""
        self.body_q: list[Transform] = []
        """Body poses accumulated for :attr:`Model.body_q`."""
        self.body_qd: list[Vec6] = []
        """Body spatial velocities accumulated for :attr:`Model.body_qd`."""
        self.body_label: list[str] = []
        """Body labels accumulated for :attr:`Model.body_label`."""
        self.body_lock_inertia: list[bool] = []
        """Per-body inertia-lock flags retained while composing bodies in the builder."""
        self.body_flags: list[int] = []
        """Body flags accumulated for :attr:`Model.body_flags`."""
        self.body_shapes: dict[int, list[int]] = {-1: []}
        """Mapping from body index to attached shape indices, finalized into :attr:`Model.body_shapes`."""
        self.body_world: list[int] = []
        """World indices accumulated for :attr:`Model.body_world`."""
        self.body_color_groups: list[Any] = []
        """Rigid-body color groups accumulated for :attr:`Model.body_color_groups`."""

        # rigid joints
        self.joint_parent: list[int] = []
        """Parent body indices accumulated for :attr:`Model.joint_parent`."""
        self.joint_parents: dict[int, list[tuple[int, int]]] = {}
        """Mapping from child body index to ``(parent_body, joint_idx)`` pairs (one per joint, no dedup)."""
        self.joint_children: dict[int, list[tuple[int, int]]] = {}
        """Mapping from parent body index to ``(child_body, joint_idx)`` pairs (one per joint, no dedup)."""
        self.joint_child: list[int] = []
        """Child body indices accumulated for :attr:`Model.joint_child`."""
        self.joint_axis: list[Vec3] = []
        """Joint axes accumulated for :attr:`Model.joint_axis`."""
        self.joint_X_p: list[Transform] = []
        """Parent-frame joint transforms accumulated for :attr:`Model.joint_X_p`."""
        self.joint_X_c: list[Transform] = []
        """Child-frame joint transforms accumulated for :attr:`Model.joint_X_c`."""
        self.joint_q: list[float] = []
        """Joint coordinates accumulated for :attr:`Model.joint_q`."""
        self.joint_qd: list[float] = []
        """Joint velocities accumulated for :attr:`Model.joint_qd`."""
        self.joint_cts: list[float] = []
        """Per-joint constraint placeholders used to derive finalized joint-constraint counts."""
        self.joint_f: list[float] = []
        """Joint forces accumulated for :attr:`Model.joint_f`."""
        self.joint_act: list[float] = []
        """Joint actuation inputs accumulated for :attr:`Model.joint_act`."""

        self.joint_type: list[int] = []
        """Joint type ids accumulated for :attr:`Model.joint_type`."""
        self.joint_label: list[str] = []
        """Joint labels accumulated for :attr:`Model.joint_label`."""
        self.joint_armature: list[float] = []
        """Joint armature values accumulated for :attr:`Model.joint_armature`."""
        self.joint_target_mode: list[int] = []
        """Joint target modes accumulated for :attr:`Model.joint_target_mode`."""
        self.joint_target_ke: list[float] = []
        """Joint target stiffness values accumulated for :attr:`Model.joint_target_ke`."""
        self.joint_target_kd: list[float] = []
        """Joint target damping values accumulated for :attr:`Model.joint_target_kd`."""
        self.joint_damping: list[float] = []
        """Passive velocity damping values accumulated for :attr:`Model.joint_damping`."""
        self.joint_limit_lower: list[float] = []
        """Lower joint limits accumulated for :attr:`Model.joint_limit_lower`."""
        self.joint_limit_upper: list[float] = []
        """Upper joint limits accumulated for :attr:`Model.joint_limit_upper`."""
        self.joint_limit_ke: list[float] = []
        """Joint limit stiffness values accumulated for :attr:`Model.joint_limit_ke`."""
        self.joint_limit_kd: list[float] = []
        """Joint limit damping values accumulated for :attr:`Model.joint_limit_kd`."""
        self.joint_target_q: list[float] = []
        """Joint position targets in :attr:`joint_q` (coord) layout, accumulated for :attr:`Model.joint_target_q`."""
        self.joint_target_qd: list[float] = []
        """Joint velocity targets per DOF, accumulated for :attr:`Model.joint_target_qd`."""
        self.joint_effort_limit: list[float] = []
        """Joint effort limits accumulated for :attr:`Model.joint_effort_limit`."""
        self.joint_velocity_limit: list[float] = []
        """Joint velocity limits accumulated for :attr:`Model.joint_velocity_limit`."""
        self.joint_friction: list[float] = []
        """Joint friction values accumulated for :attr:`Model.joint_friction`."""

        self.joint_twist_lower: list[float] = []
        """Lower twist limits accumulated for :attr:`Model.joint_twist_lower`."""
        self.joint_twist_upper: list[float] = []
        """Upper twist limits accumulated for :attr:`Model.joint_twist_upper`."""

        self.joint_enabled: list[bool] = []
        """Joint enabled flags accumulated for :attr:`Model.joint_enabled`."""

        self.joint_collision_filter_parent: list[bool] = []
        """Per-joint resolved ``collision_filter_parent`` flag. Builder-only."""

        self.joint_q_start: list[int] = []
        """Joint coordinate start indices accumulated for :attr:`Model.joint_q_start`."""
        self.joint_qd_start: list[int] = []
        """Joint DoF start indices accumulated for :attr:`Model.joint_qd_start`."""
        self.joint_cts_start: list[int] = []
        """Joint-constraint start indices retained while building per-joint constraint data."""
        self.joint_dof_dim: list[tuple[int, int]] = []
        """Per-joint linear/angular DoF dimensions accumulated for :attr:`Model.joint_dof_dim`."""
        self.joint_world: list[int] = []
        """World indices accumulated for :attr:`Model.joint_world`."""
        self.joint_articulation: list[int] = []
        """Articulation indices accumulated for :attr:`Model.joint_articulation`."""

        self.articulation_start: list[int] = []
        """Articulation start indices accumulated for :attr:`Model.articulation_start`."""
        self.articulation_end: list[int] = []
        """Exclusive end indices of regular tree joints accumulated for :attr:`Model.articulation_end`."""
        self.articulation_label: list[str] = []
        """Articulation labels accumulated for :attr:`Model.articulation_label`."""
        self.articulation_world: list[int] = []
        """World indices accumulated for :attr:`Model.articulation_world`."""

        # Deformable group registries: prim-path-labelled, world-tagged index ranges for each
        # imported cable/cloth/volume (mirrors articulation_start/end/label/world). Ranges are
        # [start, end) into the corresponding builder arrays, and replicate()/add_builder() carry
        # them per world so each group stays indexable by path.
        self._cable_label: list[str] = []
        """Prim-path labels of imported cable groups."""
        self._cable_world: list[int] = []
        """World index of each cable group."""
        self._cable_body_start: list[int] = []
        """Inclusive body-range start of each cable group."""
        self._cable_body_end: list[int] = []
        """Exclusive body-range end of each cable group."""
        self._cable_joint_start: list[int] = []
        """Inclusive joint-range start of each cable group."""
        self._cable_joint_end: list[int] = []
        """Exclusive joint-range end of each cable group."""

        self._cloth_label: list[str] = []
        """Prim-path labels of imported cloth groups."""
        self._cloth_world: list[int] = []
        """World index of each cloth group."""
        self._cloth_particle_start: list[int] = []
        """Inclusive particle-range start of each cloth group."""
        self._cloth_particle_end: list[int] = []
        """Exclusive particle-range end of each cloth group."""
        self._cloth_tri_start: list[int] = []
        """Inclusive triangle-range start of each cloth group."""
        self._cloth_tri_end: list[int] = []
        """Exclusive triangle-range end of each cloth group."""
        self._cloth_edge_start: list[int] = []
        """Inclusive edge-range start of each cloth group."""
        self._cloth_edge_end: list[int] = []
        """Exclusive edge-range end of each cloth group."""

        self._soft_label: list[str] = []
        """Prim-path labels of imported soft (volume) groups."""
        self._soft_world: list[int] = []
        """World index of each soft group."""
        self._soft_particle_start: list[int] = []
        """Inclusive particle-range start of each soft group."""
        self._soft_particle_end: list[int] = []
        """Exclusive particle-range end of each soft group."""
        self._soft_tet_start: list[int] = []
        """Inclusive tetrahedron-range start of each soft group."""
        self._soft_tet_end: list[int] = []
        """Exclusive tetrahedron-range end of each soft group."""

        self.joint_dof_count: int = 0
        """Total joint DoF count propagated to :attr:`Model.joint_dof_count`."""
        self.joint_coord_count: int = 0
        """Total joint coordinate count propagated to :attr:`Model.joint_coord_count`."""
        self.joint_constraint_count: int = 0
        """Total joint constraint count propagated to :attr:`Model.joint_constraint_count`."""

        self._current_world: int = -1
        """Internal world context backing the read-only :attr:`current_world` property."""

        self.up_axis: Axis = Axis.from_any(up_axis)
        """Up axis used by geometry helpers and for resolving default or scalar gravity."""
        self._gravity: float | wp.vec3 | None = None
        """Explicit global/default gravity; ``None`` means -9.81 along the current :attr:`up_axis`."""
        if gravity is not None:
            self._set_gravity(gravity, stacklevel=3)

        self.world_gravity: list[Vec3] = []
        """Per-world gravity vectors [m/s^2] retained until :meth:`finalize <ModelBuilder.finalize>` populates
        :attr:`Model.gravity`."""

        self.rigid_gap: float = 0.1
        """Default rigid contact gap [m] applied when adding a shape whose
        ``ModelBuilder.ShapeConfig.gap`` is ``None``. The resolved per-shape values are later
        propagated to :attr:`Model.shape_gap`."""

        self.num_rigid_contacts_per_world: int | None = None
        """Optional per-world rigid-contact allocation budget used to set :attr:`Model.rigid_contact_max`."""

        # mimic constraints
        self.constraint_mimic_joint0: list[int] = []
        """Follower joint indices accumulated for :attr:`Model.constraint_mimic_joint0`."""
        self.constraint_mimic_joint1: list[int] = []
        """Leader joint indices accumulated for :attr:`Model.constraint_mimic_joint1`."""
        self.constraint_mimic_coef0: list[float] = []
        """Offset coefficients accumulated for :attr:`Model.constraint_mimic_coef0`."""
        self.constraint_mimic_coef1: list[float] = []
        """Scale coefficients accumulated for :attr:`Model.constraint_mimic_coef1`."""
        self.constraint_mimic_enabled: list[bool] = []
        """Enabled flags accumulated for :attr:`Model.constraint_mimic_enabled`."""
        self.constraint_mimic_label: list[str] = []
        """Mimic constraint labels accumulated for :attr:`Model.constraint_mimic_label`."""
        self.constraint_mimic_world: list[int] = []
        """World indices accumulated for :attr:`Model.constraint_mimic_world`."""

        # per-world entity start indices
        self.particle_world_start: list[int] = []
        """Per-world particle starts accumulated for :attr:`Model.particle_world_start`."""
        self.body_world_start: list[int] = []
        """Per-world body starts accumulated for :attr:`Model.body_world_start`."""
        self.shape_world_start: list[int] = []
        """Per-world shape starts accumulated for :attr:`Model.shape_world_start`."""
        self.joint_world_start: list[int] = []
        """Per-world joint starts accumulated for :attr:`Model.joint_world_start`."""
        self.articulation_world_start: list[int] = []
        """Per-world articulation starts accumulated for :attr:`Model.articulation_world_start`."""
        self._equality_constraint_world_start: list[int] = []
        """Per-world equality-constraint starts accumulated for ``model.mujoco.equality_constraint_world_start``."""
        self.joint_dof_world_start: list[int] = []
        """Per-world joint DoF starts accumulated for :attr:`Model.joint_dof_world_start`."""
        self.joint_coord_world_start: list[int] = []
        """Per-world joint-coordinate starts accumulated for :attr:`Model.joint_coord_world_start`."""
        self.joint_constraint_world_start: list[int] = []
        """Per-world joint-constraint starts accumulated for :attr:`Model.joint_constraint_world_start`."""

        # Custom attributes (user-defined per-frequency arrays)
        self.custom_attributes: dict[str, ModelBuilder.CustomAttribute] = {}
        """Registered custom attributes to materialize during :meth:`finalize <ModelBuilder.finalize>`."""
        self._custom_attribute_model_finalizers: dict[
            str, Callable[[ModelBuilder, Model, ModelBuilder.CustomAttribute], None]
        ] = {}
        # Registered custom frequencies (must be registered before adding attributes with that frequency)
        self.custom_frequencies: dict[str, ModelBuilder.CustomFrequency] = {}
        """Registered custom string frequencies keyed by ``namespace:name`` or bare name."""
        # Incrementally maintained counts for custom string frequencies
        self._custom_frequency_counts: dict[str, int] = {}
        """Running counts for custom string frequencies used to size custom attribute arrays."""
        self._custom_frequency_owner_resolved_counts: dict[str, int] = {}
        """Row counts covered by the latest custom-frequency owner resolution."""

        # Actuator entries (accumulated during add_actuator calls)
        # Key is (drive_class, delay is not None, clamping_key, drive_shared_key) to group compatible actuators
        self.actuator_entries: dict[tuple, ModelBuilder.ActuatorEntry] = {}
        """Actuator entry groups accumulated from :meth:`add_actuator`, keyed by drive class and shared params."""

        # Equality constraints are canonical MuJoCo custom attributes and must be available
        # independently of SolverMuJoCo. Lazy import avoids a module-level solver dependency.
        from ..solvers.mujoco.equality import _register_equality_constraint_attributes  # noqa: PLC0415

        _register_equality_constraint_attributes(self)

    def _eq_attr(self, name: str) -> ModelBuilder.CustomAttribute:
        """Return the per-equality-constraint :class:`CustomAttribute` for the bare ``name`` (no ``mujoco:`` prefix)."""
        return self.custom_attributes[f"mujoco:{name}"]

    def _eq_values_raw(self, name: str) -> list[Any]:
        """Backing values list for equality field ``name`` (no default-filling); empty list if unset.

        Internal callers (``finalize`` validation/collapse) read this instead of :meth:`_eq_list`
        to avoid materializing a dense, default-filled copy of every equality row up front.
        """
        return self._eq_attr(name).values or []

    def _eq_list(self, name: str) -> list[Any]:
        """Dense list of equality-constraint ``name`` values, default-filled to match :meth:`finalize`."""
        attr = self._eq_attr(name)
        count = self._equality_constraint_count
        if not attr.values:
            return [attr.default] * count
        return [
            (attr.values[i] if i < len(attr.values) and attr.values[i] is not None else attr.default)
            for i in range(count)
        ]

    @property
    def _equality_constraint_count(self) -> int:
        """Number of equality constraints added to this builder (from the ``mujoco:equality_constraint`` counter)."""
        return self._custom_frequency_counts.get("mujoco:equality_constraint", 0)

    @property
    def shape_collision_filter_pairs(self) -> list[tuple[int, int]]:
        """Shape collision filter pairs accumulated for :attr:`Model.shape_collision_filter_pairs`."""
        if isinstance(self._shape_collision_filter_pairs, _BuilderShapeCollisionFilterPairs):
            self._shape_collision_filter_pairs = list(self._shape_collision_filter_pairs)
        return self._shape_collision_filter_pairs

    @shape_collision_filter_pairs.setter
    def shape_collision_filter_pairs(self, pairs: list[tuple[int, int]]) -> None:
        self._shape_collision_filter_pairs = pairs

    def _materialized_filter_template(self) -> tuple[tuple[int, int], ...]:
        """This builder's filter pairs as one tuple, stable across repeated merges.

        Merging a source builder world-by-world (one :meth:`add_builder` per world) must
        hand out the *same* tuple object every time: the collision-filter and
        contact-pair template caches in :meth:`finalize` are keyed by object identity, so
        a freshly built tuple per world silently disables them and makes finalization
        scale with world count instead of with the number of distinct sources.
        """
        pairs = self._shape_collision_filter_pairs
        if isinstance(pairs, _BuilderShapeCollisionFilterPairs):
            return pairs.template_pairs()
        cached = self._merge_filter_template
        if cached is not None and cached[0] is pairs and cached[1] == len(pairs):
            return cached[2]
        template = tuple(pairs)
        self._merge_filter_template = (pairs, len(pairs), template)
        return template

    def add_shape_collision_filter_pair(self, shape_a: int, shape_b: int) -> None:
        """Add a collision filter pair in canonical order.

        Args:
            shape_a: First shape index
            shape_b: Second shape index
        """
        self._shape_collision_filter_pairs.append((min(shape_a, shape_b), max(shape_a, shape_b)))

    @staticmethod
    def _default_filter_parent(joint_type: JointType, parent: int) -> bool:
        """Default ``collision_filter_parent``: ``False`` for non-fixed joints to world; ``True`` otherwise."""
        if parent == -1:
            return joint_type == JointType.FIXED
        return True

    @staticmethod
    def _custom_attribute_specs_match(existing: CustomAttribute, incoming: CustomAttribute) -> bool:
        return (
            existing.frequency == incoming.frequency
            and existing.dtype == incoming.dtype
            and existing.assignment == incoming.assignment
            and existing.namespace == incoming.namespace
            and existing.references == incoming.references
        )

    @staticmethod
    def _custom_frequency_specs_match(existing: CustomFrequency, incoming: CustomFrequency) -> bool:
        return (
            existing.usd_prim_filter is incoming.usd_prim_filter
            and existing.usd_entry_expander is incoming.usd_entry_expander
            and existing.articulation_owner_attribute == incoming.articulation_owner_attribute
            and existing.articulation_owner_resolver is incoming.articulation_owner_resolver
            and existing.label_attribute == incoming.label_attribute
        )

    def add_custom_attribute(self, attribute: CustomAttribute) -> None:
        """
        Define a custom per-entity attribute to be added to the Model.
        See :ref:`custom_attributes` for more information.

        For attributes with custom string frequencies (not enum frequencies like BODY, SHAPE, etc.),
        the frequency must be registered first via :meth:`add_custom_frequency`. This ensures
        explicit declaration of custom entity types and enables USD parsing support.

        Args:
            attribute: The custom attribute to add.

        Raises:
            ValueError: If the attribute key already exists with incompatible specification,
                if the attribute uses a custom string frequency that hasn't been registered,
                or if ``usd_attribute_name`` is ``"*"`` without a ``usd_value_transformer``.

        Example:

            .. doctest::

                builder = newton.ModelBuilder()
                builder.add_custom_attribute(
                    newton.ModelBuilder.CustomAttribute(
                        name="my_attribute",
                        frequency=newton.Model.AttributeFrequency.BODY,
                        dtype=wp.float32,
                        default=20.0,
                        assignment=newton.Model.AttributeAssignment.MODEL,
                        namespace="my_namespace",
                    )
                )
                builder.add_body(custom_attributes={"my_namespace:my_attribute": 30.0})
                builder.add_body()  # we leave out the custom_attributes, so the attribute will use the default value 20.0
                model = builder.finalize()
                # the model has now a Model.AttributeNamespace object with the name "my_namespace"
                # and an attribute "my_attribute" that is a wp.array of shape (body_count, 1)
                # with the default value 20.0
                assert np.allclose(model.my_namespace.my_attribute.numpy(), [30.0, 20.0])
        """
        key = attribute.key

        existing = self.custom_attributes.get(key)
        if existing:
            if not self._custom_attribute_specs_match(existing, attribute):
                raise ValueError(f"Custom attribute '{key}' already exists with incompatible spec")
            return

        # Validate that custom frequencies are registered before use
        if attribute.is_custom_frequency:
            freq_key = attribute.frequency
            if freq_key not in self.custom_frequencies:
                raise ValueError(
                    f"Custom frequency '{freq_key}' is not registered. "
                    f"Please register it first using add_custom_frequency() before adding attributes with this frequency."
                )

        # Validate that wildcard USD attributes have a transformer
        if attribute.usd_attribute_name == "*" and attribute.usd_value_transformer is None:
            raise ValueError(
                f"Custom attribute '{key}' uses usd_attribute_name='*' but no usd_value_transformer is provided. "
                f"A wildcard USD attribute requires a usd_value_transformer to compute values from prim data."
            )

        self.custom_attributes[key] = attribute
        self._custom_schema_epoch += 1

    def _add_custom_attribute_model_finalizer(
        self,
        key: str,
        finalizer: Callable[[ModelBuilder, Model, ModelBuilder.CustomAttribute], None],
    ) -> None:
        """Register a callback that finalizes a model custom attribute itself."""
        existing = self._custom_attribute_model_finalizers.get(key)
        if existing is not None and existing is not finalizer:
            raise ValueError(
                f"Custom attribute finalizer '{key}' is already registered with a different callback "
                f"({existing!r} != {finalizer!r})."
            )
        self._custom_attribute_model_finalizers[key] = finalizer

    def add_custom_frequency(self, frequency: CustomFrequency) -> None:
        """
        Register a custom frequency for the builder.

        Custom frequencies must be registered before adding any custom attributes that use them.
        This enables explicit declaration of custom entity types and optionally provides USD
        parsing support via the ``usd_prim_filter`` callback.

        This method is idempotent: registering the same frequency multiple times is silently
        ignored (useful when loading multiple files that all register the same frequencies).

        Args:
            frequency: A :class:`CustomFrequency` object with full configuration.

        Example:

            .. code-block:: python

                # Full registration with USD parsing support
                builder.add_custom_frequency(
                    ModelBuilder.CustomFrequency(
                        name="actuator",
                        namespace="mujoco",
                        usd_prim_filter=is_actuator_prim,
                    )
                )
        """
        freq_obj = frequency

        freq_key = freq_obj.key
        if freq_key in self.custom_frequencies:
            existing = self.custom_frequencies[freq_key]
            if not self._custom_frequency_specs_match(existing, freq_obj):
                raise ValueError(
                    f"Custom frequency '{freq_key}' is already registered with different callbacks or metadata."
                )
            # Already registered with equivalent callbacks - silently skip
            return

        self.custom_frequencies[freq_key] = freq_obj
        self._custom_schema_epoch += 1
        if freq_key not in self._custom_frequency_counts:
            self._custom_frequency_counts[freq_key] = 0

    def has_custom_attribute(self, key: str) -> bool:
        """Check if a custom attribute is defined."""
        return key in self.custom_attributes

    def get_custom_attributes_by_frequency(
        self, frequencies: Sequence[Model.AttributeFrequency | str]
    ) -> list[CustomAttribute]:
        """
        Get custom attributes by frequency.
        This is useful for processing custom attributes for different kinds of simulation objects.
        For example, you can get all the custom attributes for bodies, shapes, joints, etc.

        Args:
            frequencies: The frequencies to get custom attributes for.

        Returns:
            Custom attributes matching the requested frequencies.
        """
        return [attr for attr in self.custom_attributes.values() if attr.frequency in frequencies]

    def get_custom_frequency_keys(self) -> set[str]:
        """Return set of custom frequency keys (string frequencies) defined in this builder."""
        return set(self._custom_frequency_counts.keys())

    @staticmethod
    def _get_namespaced_attribute(source: Any, key: str) -> Any:
        """Return an attribute addressed by its colon-delimited key."""
        value = source
        for component in key.split(":"):
            value = getattr(value, component)
        return value

    def _resolve_custom_frequency_articulation_owners(self) -> None:
        """Populate declared owner attributes using frequency-local callbacks."""
        for frequency_key, frequency in self.custom_frequencies.items():
            resolver = frequency.articulation_owner_resolver
            if resolver is None:
                continue

            count = self._custom_frequency_counts.get(frequency_key, 0)
            resolved_count = self._custom_frequency_owner_resolved_counts.get(frequency_key, 0)
            if resolved_count == count:
                continue
            if resolved_count > count:
                raise RuntimeError(
                    f"Custom frequency '{frequency_key}' has {count} rows but tracks "
                    f"{resolved_count} resolved owner rows"
                )

            owner_key = frequency.articulation_owner_attribute
            assert owner_key is not None
            owner_attribute = self.custom_attributes.get(owner_key)
            if owner_attribute is None:
                raise ValueError(
                    f"Custom frequency '{frequency_key}' declares unknown articulation owner attribute '{owner_key}'"
                )

            resolved_owners = list(resolver(self))
            if len(resolved_owners) != count:
                raise ValueError(
                    f"Articulation owner resolver for custom frequency '{frequency_key}' returned "
                    f"{len(resolved_owners)} values, expected {count}"
                )
            if resolved_count > 0:
                if not isinstance(owner_attribute.values, list) or len(owner_attribute.values) < resolved_count:
                    value_count = len(owner_attribute.values) if owner_attribute.values is not None else 0
                    raise ValueError(
                        f"Articulation owner attribute '{owner_key}' has {value_count} values but "
                        f"{resolved_count} merged rows must be preserved"
                    )
                owners = list(owner_attribute.values[:resolved_count])
            else:
                owners = []
            for row in range(resolved_count, count):
                owner = resolved_owners[row]
                if not self._is_integer_scalar(owner):
                    raise ValueError(
                        f"Articulation owner resolver for custom frequency '{frequency_key}' returned "
                        f"non-integer value {owner!r} at row {row}"
                    )
                owner_index = int(owner)
                if owner_index < -1 or owner_index >= self.articulation_count:
                    raise ValueError(
                        f"Articulation owner resolver for custom frequency '{frequency_key}' returned "
                        f"invalid articulation index {owner_index} at row {row}"
                    )
                owners.append(owner_index)
            owner_attribute.values = owners
            self._custom_frequency_owner_resolved_counts[frequency_key] = count

    def _finalize_custom_frequency_metadata(self, model: Model, device: Devicelike | None) -> None:
        """Materialize articulation ownership and label metadata on a model."""
        for frequency_key, frequency in self.custom_frequencies.items():
            owner_key = frequency.articulation_owner_attribute
            if owner_key is not None:
                owner_attribute = self.custom_attributes.get(owner_key)
                if owner_attribute is None:
                    raise ValueError(
                        f"Custom frequency '{frequency_key}' declares unknown articulation owner attribute "
                        f"'{owner_key}'"
                    )
                if owner_attribute.frequency != frequency_key:
                    raise ValueError(
                        f"Articulation owner attribute '{owner_key}' uses frequency "
                        f"'{owner_attribute.frequency}', expected '{frequency_key}'"
                    )
                if owner_attribute.assignment != Model.AttributeAssignment.MODEL:
                    raise ValueError(f"Articulation owner attribute '{owner_key}' must be assigned to Model")
                if owner_attribute.references != "articulation":
                    raise ValueError(
                        f"Articulation owner attribute '{owner_key}' must declare references='articulation'"
                    )
                if not wp.types.type_is_int(owner_attribute.dtype):
                    raise ValueError(f"Articulation owner attribute '{owner_key}' must use an integer dtype")

                count = model.custom_frequency_counts.get(frequency_key, 0)
                if count == 0:
                    owners = wp.empty(0, dtype=owner_attribute.dtype, device=device)
                else:
                    owners = self._get_namespaced_attribute(model, owner_key)
                    if not isinstance(owners, wp.array) or owners.ndim != 1:
                        raise ValueError(f"Articulation owner attribute '{owner_key}' must be a 1-D Warp array")
                    if len(owners) != count:
                        raise ValueError(
                            f"Articulation owner attribute '{owner_key}' has {len(owners)} values but "
                            f"frequency '{frequency_key}' expects {count}"
                        )
                    owner_values = owners.numpy()
                    invalid = np.flatnonzero((owner_values < -1) | (owner_values >= model.articulation_count))
                    if len(invalid) > 0:
                        row = int(invalid[0])
                        raise ValueError(
                            f"Articulation owner attribute '{owner_key}' contains invalid articulation "
                            f"index {int(owner_values[row])} at row {row}"
                        )
                model.custom_frequency_articulation[frequency_key] = owners

            label_key = frequency.label_attribute
            if label_key is None:
                continue
            label_attribute = self.custom_attributes.get(label_key)
            if label_attribute is None:
                raise ValueError(f"Custom frequency '{frequency_key}' declares unknown label attribute '{label_key}'")
            if label_attribute.frequency != frequency_key:
                raise ValueError(
                    f"Label attribute '{label_key}' uses frequency '{label_attribute.frequency}', "
                    f"expected '{frequency_key}'"
                )
            if label_attribute.assignment != Model.AttributeAssignment.MODEL:
                raise ValueError(f"Label attribute '{label_key}' must be assigned to Model")
            if label_attribute.dtype is not str:
                raise ValueError(f"Label attribute '{label_key}' must use dtype=str")
            model.custom_frequency_label_attributes[frequency_key] = label_key

    def add_custom_values(self, **kwargs: Any) -> dict[str, int]:
        """Append values to custom attributes with custom string frequencies.

        Each keyword argument specifies an attribute key and the value to append. Values are
        stored in a list and appended sequentially for robust indexing. Only works with
        attributes that have a custom string frequency (not built-in enum frequencies).

        This is useful for custom entity types that aren't built into the model,
        such as user-defined groupings or solver-specific data.

        Args:
            **kwargs: Mapping of attribute keys to values. Keys should be the full
                attribute key (e.g., ``"mujoco:pair_geom1"`` or just ``"my_attr"`` if no namespace).

        Returns:
            A mapping from attribute keys to the index where each value was added.
            If all attributes had the same count before the call, all indices will be equal.

        Raises:
            AttributeError: If an attribute key is not defined.
            TypeError: If an attribute has an enum frequency (must have custom frequency).

        Example:
            .. code-block:: python

                builder.add_custom_values(
                    **{
                        "mujoco:pair_geom1": 0,
                        "mujoco:pair_geom2": 1,
                        "mujoco:pair_world": builder.current_world,
                    }
                )
                # Returns: {'mujoco:pair_geom1': 0, 'mujoco:pair_geom2': 0, 'mujoco:pair_world': 0}
        """
        indices: dict[str, int] = {}
        frequency_indices: dict[str, int] = {}  # Track indices assigned per frequency in this call

        for key, value in kwargs.items():
            attr = self.custom_attributes.get(key)
            if attr is None:
                raise AttributeError(
                    f"Custom attribute '{key}' is not defined. Please declare it first using add_custom_attribute()."
                )
            if not attr.is_custom_frequency:
                raise TypeError(
                    f"Custom attribute '{key}' has frequency={attr.frequency}, "
                    f"but add_custom_values() only works with custom frequency attributes."
                )

            # Ensure attr.values is initialized
            if attr.values is None:
                attr.values = []

            freq_key = attr.frequency
            assert isinstance(freq_key, str), f"Custom frequency '{freq_key}' is not a string"

            # Determine index for this frequency (same index for all attrs with same frequency in this call)
            if freq_key not in frequency_indices:
                # First attribute with this frequency - use authoritative counter
                current_count = self._custom_frequency_counts.get(freq_key, 0)
                frequency_indices[freq_key] = current_count

                # Update authoritative counter for this frequency
                self._custom_frequency_counts[freq_key] = current_count + 1

            idx = frequency_indices[freq_key]

            # Ensure attr.values has length at least idx+1, padding with None as needed
            while len(attr.values) <= idx:
                attr.values.append(None)

            # Assign value at the correct index
            attr.values[idx] = value
            indices[key] = idx
        return indices

    def add_custom_values_batch(self, entries: Sequence[dict[str, Any]]) -> list[dict[str, int]]:
        """Append multiple custom-frequency rows in a single call.

        Args:
            entries: Sequence of rows where each row maps custom attribute keys to values.
                Each row is forwarded to :meth:`add_custom_values`.

        Returns:
            Index maps returned by :meth:`add_custom_values` for each row.
        """
        out: list[dict[str, int]] = []
        for row in entries:
            out.append(self.add_custom_values(**row))
        return out

    def _process_custom_attributes(
        self,
        entity_index: int | list[int],
        custom_attrs: dict[str, Any],
        expected_frequency: Model.AttributeFrequency,
    ) -> None:
        """Process custom attributes from kwargs and assign them to an entity.

        This method validates that custom attributes exist with the correct frequency,
        then assigns values to the specific entity. The assignment is inferred from the
        attribute definition.

        Attribute names can optionally include a namespace prefix in the format "namespace:attr_name".
        If no namespace prefix is provided, the attribute is assumed to be in the default namespace (None).

        Args:
            entity_index: Index of the entity (body, shape, joint, etc.). Can be a single index or a list of indices.
            custom_attrs: Dictionary of custom attribute names to values.
                Keys can be "attr_name" or "namespace:attr_name". Values can be a single value or a list of values.
            expected_frequency: Expected frequency for these attributes.
        """
        for attr_key, value in custom_attrs.items():
            # Parse namespace prefix if present (format: "namespace:attr_name" or "attr_name")
            full_key = attr_key

            # Ensure the custom attribute is defined
            custom_attr = self.custom_attributes.get(full_key)
            if custom_attr is None:
                raise AttributeError(
                    f"Custom attribute '{full_key}' is not defined. "
                    f"Please declare it first using add_custom_attribute()."
                )

            # Validate frequency matches
            if custom_attr.frequency != expected_frequency:
                raise ValueError(
                    f"Custom attribute '{full_key}' has frequency {custom_attr.frequency}, "
                    f"but expected {expected_frequency} for this entity type"
                )

            # Set the value for this specific entity. The values container shape depends on
            # the attribute's frequency: string-frequency attributes use a dense ``list``
            # (sequential indices, ``None``-padded), enum-frequency attributes use a sparse
            # ``dict``.
            is_string_freq = custom_attr.is_custom_frequency
            if custom_attr.values is None:
                custom_attr.values = [] if is_string_freq else {}

            def _assign_one(idx: int, val: Any, _attr=custom_attr, _list=is_string_freq) -> None:
                if _list:
                    while len(_attr.values) <= idx:
                        _attr.values.append(None)
                _attr.values[idx] = val

            # Fill in the value(s)
            if isinstance(entity_index, list):
                value_is_sequence = isinstance(value, (list, tuple))
                if isinstance(value, np.ndarray):
                    value_is_sequence = value.ndim != 0
                if value_is_sequence:
                    if len(value) != len(entity_index):
                        raise ValueError(f"Expected {len(entity_index)} values, got {len(value)}")
                    for idx, val in zip(entity_index, value, strict=False):
                        _assign_one(idx, val)
                else:
                    for idx in entity_index:
                        _assign_one(idx, value)
            else:
                _assign_one(entity_index, value)

    def _process_joint_custom_attributes(
        self,
        joint_index: int,
        custom_attrs: dict[str, Any],
    ) -> None:
        """Process custom attributes from kwargs for joints, supporting multiple frequencies.

        Joint attributes are processed based on their declared frequency:
        - JOINT frequency: Single value per joint
        - JOINT_DOF frequency: List or dict of values for each DOF
        - JOINT_COORD frequency: List or dict of values for each coordinate

        For DOF and COORD attributes, values can be:
        - A list with length matching the joint's DOF/coordinate count (all DOFs get values)
        - A dict mapping DOF/coord indices to values (only specified indices get values, rest use defaults)
        - A single scalar value, which is broadcast (replicated) to all DOFs/coordinates of the joint

        For joints with zero DOFs (e.g., fixed joints), JOINT_DOF attributes are silently skipped
        regardless of the value passed.

        When using dict format, unspecified indices will be filled with the attribute's default value by
        :meth:`finalize <ModelBuilder.finalize>`.

        Args:
            joint_index: Index of the joint
            custom_attrs: Dictionary of custom attribute names to values
        """

        def apply_indexed_values(
            *,
            value: Any,
            attr_key: str,
            expected_frequency: Model.AttributeFrequency,
            index_start: int,
            index_count: int,
            index_label: str,
            count_label: str,
            length_error_template: str,
        ) -> None:
            # For joints with zero DOFs/coords (e.g., fixed joints), there is nothing to assign.
            if index_count == 0:
                return

            if isinstance(value, dict):
                for offset, offset_value in value.items():
                    if not isinstance(offset, int):
                        raise TypeError(
                            f"{expected_frequency.name} attribute '{attr_key}' dict keys must be integers "
                            f"({index_label} indices), got {type(offset)}"
                        )
                    if offset < 0 or offset >= index_count:
                        raise ValueError(
                            f"{expected_frequency.name} attribute '{attr_key}' has invalid {index_label} index "
                            f"{offset} (joint has {index_count} {count_label})"
                        )
                    self._process_custom_attributes(
                        entity_index=index_start + offset,
                        custom_attrs={attr_key: offset_value},
                        expected_frequency=expected_frequency,
                    )
                return

            value_sanitized = value
            if isinstance(value_sanitized, np.ndarray):
                if value_sanitized.ndim == 0:
                    value_sanitized = value_sanitized.item()
                else:
                    value_sanitized = value_sanitized.tolist()
            if not isinstance(value_sanitized, (list, tuple)):
                # Broadcast a single scalar value to all DOFs/coords of the joint.
                value_sanitized = [value_sanitized] * index_count

            actual = len(value_sanitized)
            if actual != index_count:
                raise ValueError(length_error_template.format(attr_key=attr_key, actual=actual, expected=index_count))

            for i, indexed_value in enumerate(value_sanitized):
                self._process_custom_attributes(
                    entity_index=index_start + i,
                    custom_attrs={attr_key: indexed_value},
                    expected_frequency=expected_frequency,
                )

        for attr_key, value in custom_attrs.items():
            # Look up the attribute to determine its frequency
            custom_attr = self.custom_attributes.get(attr_key)
            if custom_attr is None:
                raise AttributeError(
                    f"Custom attribute '{attr_key}' is not defined. "
                    f"Please declare it first using add_custom_attribute()."
                )

            # Process based on declared frequency
            if custom_attr.frequency == Model.AttributeFrequency.JOINT:
                # Single value per joint
                self._process_custom_attributes(
                    entity_index=joint_index,
                    custom_attrs={attr_key: value},
                    expected_frequency=Model.AttributeFrequency.JOINT,
                )

            elif custom_attr.frequency in (
                Model.AttributeFrequency.JOINT_DOF,
                Model.AttributeFrequency.JOINT_COORD,
                Model.AttributeFrequency.JOINT_CONSTRAINT,
            ):
                freq = custom_attr.frequency
                freq_config = {
                    Model.AttributeFrequency.JOINT_DOF: (
                        self.joint_qd_start,
                        self.joint_dof_count,
                        "DOF",
                        "DOFs",
                    ),
                    Model.AttributeFrequency.JOINT_COORD: (
                        self.joint_q_start,
                        self.joint_coord_count,
                        "coord",
                        "coordinates",
                    ),
                    Model.AttributeFrequency.JOINT_CONSTRAINT: (
                        self.joint_cts_start,
                        self.joint_constraint_count,
                        "constraint",
                        "constraints",
                    ),
                }
                start_array, total_count, index_label, count_label = freq_config[freq]

                index_start = start_array[joint_index]
                if joint_index + 1 < len(start_array):
                    index_end = start_array[joint_index + 1]
                else:
                    index_end = total_count

                apply_indexed_values(
                    value=value,
                    attr_key=attr_key,
                    expected_frequency=freq,
                    index_start=index_start,
                    index_count=index_end - index_start,
                    index_label=index_label,
                    count_label=count_label,
                    length_error_template=(
                        f"{freq.name} attribute '{{attr_key}}' has {{actual}} values "
                        f"but joint has {{expected}} {count_label}"
                    ),
                )

            else:
                raise ValueError(
                    f"Custom attribute '{attr_key}' has unsupported frequency {custom_attr.frequency} for joints"
                )

    def add_actuator(
        self,
        drive_class: type[DriveBase] | None = None,
        index: int | None = None,
        clamping: list[tuple[type[ClampingBase], dict[str, Any]]] | None = None,
        delay_steps: int | None = None,
        pos_index: int | None = None,
        *,
        controller_class: type[DriveBase] | object = _DEPRECATED_ACTUATOR_DRIVE_UNSET,
        **kwargs: Any,
    ) -> None:
        """Add an external actuator for a single DOF.

        External actuators apply forces computed outside the physics engine.
        Multiple calls with the same *drive_class*, *clamping*
        types, and identical shared parameters are accumulated into one
        :class:`~newton.actuators.Actuator` instance during
        :meth:`finalize <ModelBuilder.finalize>`.  Different delay
        values are supported within the same group; the buffer is
        sized to ``max(delay_step_values)``.

        Args:
            drive_class: Drive class (e.g. :class:`~newton.actuators.DrivePD`).
            index: DOF index into ``joint_qd``-shaped arrays (velocities,
                velocity targets, feedforward, forces).
            clamping: Optional list of ``(ClampingClass, kwargs)`` tuples applied
                post-drive. E.g. ``[(ClampingMaxEffort, {'max_effort': 50.0})]``.
            delay_steps: Optional number of timesteps [timesteps] to delay inputs.
            pos_index: DOF index into ``joint_q``-shaped arrays (positions,
                position targets). Defaults to *index*. Differs from
                *index* for floating-base or ball-joint articulations
                where ``joint_q`` and ``joint_qd`` have different layouts.
            controller_class: Deprecated in Newton 1.6; use ``drive_class`` instead.
            **kwargs: Per-DOF drive parameters (e.g. ``kp``, ``kd``).
        """
        if controller_class is not _DEPRECATED_ACTUATOR_DRIVE_UNSET:
            if drive_class is not None:
                raise TypeError("Specify only one of 'drive_class' and deprecated 'controller_class'.")
            warnings.warn(_ACTUATOR_CONTROLLER_CLASS_DEPRECATION_MSG, DeprecationWarning, stacklevel=2)
            drive_class = controller_class
        if drive_class is None:
            raise TypeError("add_actuator() requires 'drive_class'")

        if index is None:
            raise TypeError("add_actuator() missing required argument: 'index'")

        clamping = clamping or []

        # --- Resolve drive kwargs and separate shared from per-DOF ---
        resolved_drive = drive_class.resolve_arguments(kwargs)
        unrecognized = set(kwargs) - set(resolved_drive)
        if unrecognized:
            warnings.warn(
                f"add_actuator: {drive_class.__name__} ignoring "
                f"unrecognized parameter(s): {', '.join(sorted(unrecognized))}",
                stacklevel=2,
            )
        drive_shared_names = getattr(drive_class, "SHARED_PARAMS", set())
        drive_shared = {k: resolved_drive[k] for k in drive_shared_names if k in resolved_drive}
        drive_array_params = {k: v for k, v in resolved_drive.items() if k not in drive_shared_names}

        # --- Resolve per-clamping kwargs and separate shared from per-DOF ---
        clamping_classes = tuple(cc for cc, _ in clamping)
        clamping_shared_list = []
        clamping_array_params_list = []
        for comp_class, comp_kwargs in clamping:
            resolved_comp = comp_class.resolve_arguments(comp_kwargs)
            comp_shared_names = getattr(comp_class, "SHARED_PARAMS", set())
            comp_shared = {k: resolved_comp[k] for k in comp_shared_names if k in resolved_comp}
            comp_array = {k: v for k, v in resolved_comp.items() if k not in comp_shared_names}
            clamping_shared_list.append(comp_shared)
            clamping_array_params_list.append(comp_array)

        clamping_shared_kwargs = tuple(clamping_shared_list)

        # --- Build entry key: identifies a group of compatible actuators ---
        # Groups differ when drive class, presence of delay, clamping
        # types/shared-params, or drive shared params differ.
        # Delay values are per-DOF; the buffer is sized to max(delays).
        def _make_hashable(v: Any) -> Any:
            if isinstance(v, list):
                return tuple(v)
            return v

        drive_shared_key = tuple(sorted((k, _make_hashable(v)) for k, v in drive_shared.items()))
        clamping_key = tuple(
            (cc, tuple(sorted((k, _make_hashable(v)) for k, v in shared.items())))
            for cc, shared in zip(clamping_classes, clamping_shared_list, strict=True)
        )
        entry_key = (drive_class, delay_steps is not None, clamping_key, drive_shared_key)

        entry = self.actuator_entries.setdefault(
            entry_key,
            ModelBuilder.ActuatorEntry(
                drive_class=drive_class,
                clamping_classes=clamping_classes,
                clamping_shared_kwargs=clamping_shared_kwargs,
                drive_shared_kwargs=drive_shared,
                indices=[],
                pos_indices=[],
                drive_args=[],
                delay_args=[],
                clamping_args=[],
            ),
        )

        entry.indices.append(index)
        entry.pos_indices.append(pos_index if pos_index is not None else index)
        entry.drive_args.append(drive_array_params)
        if delay_steps is not None:
            entry.delay_args.append({"delay_steps": delay_steps})
        entry.clamping_args.append(clamping_array_params_list)

    def _stack_args_to_arrays(
        self,
        args_list: list[dict[str, Any]],
        device: Devicelike | None = None,
        requires_grad: bool = False,
        default_dtype: type = wp.float32,
    ) -> dict[str, wp.array]:
        """Convert list of per-index arg dicts into dict of warp arrays.

        Args:
            args_list: List of dicts, one per index. Each dict has same keys.
            device: Device for warp arrays.
            requires_grad: Whether the arrays require gradients.
            default_dtype: Warp dtype used for columns where all values are
                numeric.  Defaults to ``wp.float32`` so that Python ``int``
                gains (e.g. ``kp=100``) produce float arrays as controllers
                expect.  Pass ``wp.int32`` when integer semantics are needed
                (e.g. delay steps).

        Returns:
            Mapping from parameter names to warp arrays.
        """
        if not args_list:
            return {}

        result = {}
        for key in args_list[0].keys():
            values = [args[key] for args in args_list]
            for v in values:
                if not isinstance(v, int | float):
                    raise TypeError(
                        f"add_actuator expects scalar per-DOF params, but "
                        f"parameter '{key}' got {type(v).__name__}; pass one "
                        f"scalar per add_actuator call"
                    )
            if default_dtype == wp.int32 and all(isinstance(v, int) for v in values):
                result[key] = wp.array(values, dtype=wp.int32, device=device)
            else:
                rg = requires_grad and default_dtype != wp.int32
                result[key] = wp.array(values, dtype=wp.float32, device=device, requires_grad=rg)

        return result

    @staticmethod
    def _build_index_array(indices: list[int], device: Devicelike) -> wp.array[wp.uint32]:
        """Build a 1-D warp index array from a flat list of DOF indices.

        Args:
            indices: Flat list of DOF indices, one per actuator.
            device: Device for the warp array.

        Returns:
            Array with shape ``(N,)``.
        """
        if not indices:
            return wp.array([], dtype=wp.uint32, device=device)
        return wp.array(indices, dtype=wp.uint32, device=device)

    @property
    def default_site_cfg(self) -> ShapeConfig:
        """Returns a ShapeConfig configured for sites (non-colliding reference points).

        This config has all site invariants enforced:
        - is_site = True
        - has_shape_collision = False
        - has_particle_collision = False
        - density = 0.0
        - collision_group = 0

        Returns:
            A new configuration suitable for creating sites.
        """
        cfg = self.ShapeConfig()
        cfg.mark_as_site()
        return cfg

    @property
    def up_vector(self) -> tuple[float, float, float]:
        """
        Returns the 3D unit vector corresponding to the current up axis (read-only).

        This property computes the up direction as a 3D vector based on the value of :attr:`up_axis`.
        For example, if ``up_axis`` is ``Axis.Z``, this returns ``(0, 0, 1)``.

        Returns:
            The 3D up vector corresponding to the current up axis.
        """
        return self.up_axis.to_vector()

    @up_vector.setter
    def up_vector(self, _):
        raise AttributeError(
            "The 'up_vector' property is read-only and cannot be set. Instead, use 'up_axis' to set the up axis."
        )

    @property
    def gravity(self) -> float | wp.vec3:
        """Global/default gravity vector [m/s^2], or a deprecated scalar along :attr:`up_axis`."""
        if np.isscalar(self._gravity):
            warnings.warn(_SCALAR_GRAVITY_DEPRECATION_MSG, DeprecationWarning, stacklevel=2)
            return self._gravity
        return self._gravity_as_vector()

    @gravity.setter
    def gravity(self, value: float | Vec3) -> None:
        self._set_gravity(value, stacklevel=3)

    def _set_gravity(self, value: float | Vec3, stacklevel: int) -> None:
        if np.isscalar(value):
            warnings.warn(_SCALAR_GRAVITY_DEPRECATION_MSG, DeprecationWarning, stacklevel=stacklevel)
            self._gravity = float(value)
            return
        gravity = np.asarray(value, dtype=np.float32)
        if gravity.shape != (3,):
            raise ValueError(f"Expected gravity with shape (3,), got {gravity.shape}")
        self._gravity = wp.vec3(*gravity)

    def _gravity_as_vector(self) -> wp.vec3:
        """Resolve gravity to a fresh vector so callers never alias builder state."""
        if self._gravity is None or np.isscalar(self._gravity):
            magnitude = -9.81 if self._gravity is None else self._gravity
            return wp.vec3(*(component * magnitude for component in self.up_vector))
        return wp.vec3(*self._gravity)

    @property
    def current_world(self) -> int:
        """Returns the builder-managed world context for subsequently added entities.

        A value of ``-1`` means newly added entities are global. Use
        :meth:`begin_world`, :meth:`end_world`, :meth:`add_world`, or
        :meth:`replicate` to manage world assignment.

        Returns:
            The current world index for newly added entities.
        """
        return self._current_world

    @current_world.setter
    def current_world(self, _):
        message = (
            "The 'current_world' property is read-only and cannot be set. "
            + "Use 'begin_world()', 'end_world()', 'add_world()', or "
            + "'replicate()' to manage worlds."
        )
        raise AttributeError(message)

    # region counts
    @property
    def shape_count(self):
        """
        The number of shapes in the model.
        """
        return len(self.shape_type)

    @property
    def body_count(self):
        """
        The number of rigid bodies in the model.
        """
        return len(self.body_q)

    @property
    def joint_count(self):
        """
        The number of joints in the model.
        """
        return len(self.joint_type)

    @property
    def particle_count(self):
        """
        The number of particles in the model.
        """
        return len(self.particle_q)

    @property
    def tri_count(self):
        """
        The number of triangles in the model.
        """
        return len(self.tri_poses)

    @property
    def tet_count(self):
        """
        The number of tetrahedra in the model.
        """
        return len(self.tet_poses)

    @property
    def edge_count(self):
        """
        The number of edges (for bending) in the model.
        """
        return len(self.edge_rest_angle)

    @property
    def spring_count(self):
        """
        The number of springs in the model.
        """
        return len(self.spring_rest_length)

    @property
    def muscle_count(self):
        """
        The number of muscles in the model.
        """
        return len(self.muscle_start)

    @property
    def articulation_count(self):
        """
        The number of articulations in the model.
        """
        return len(self.articulation_start)

    # Tombstones so that assigning the 1.3-era names fails loudly instead of
    # creating an unused instance attribute whose targets are never applied.
    joint_target_pos = RemovedAttribute("joint_target_q", removed_in="1.5")
    joint_target_vel = RemovedAttribute("joint_target_qd", removed_in="1.5")

    def _project_target_q_to_dof(self) -> list[float]:
        """Drop the quat-w padding slot for FREE/BALL/DISTANCE joints to turn
        the coord-sized :attr:`joint_target_q` buffer into a DOF-shaped list.

        Under :data:`newton.use_coord_layout_targets` ``False`` the builder
        stores raw per-axis angles (extrinsic ZYX) in the first 3 quat slots
        and a placeholder ``1.0`` in the 4th — this method just slices the
        placeholder off to produce the legacy DOF-shaped ``Model.joint_target_q``.
        """
        result: list[float] = []
        for j, jtype in enumerate(self.joint_type):
            q_start = self.joint_q_start[j]
            if jtype == JointType.BALL:
                result.extend(self.joint_target_q[q_start : q_start + 3])
            elif jtype == JointType.FREE or jtype == JointType.DISTANCE:
                result.extend(self.joint_target_q[q_start : q_start + 6])
            elif jtype == JointType.FIXED:
                pass
            else:
                num_lin, num_ang = self.joint_dof_dim[j]
                result.extend(self.joint_target_q[q_start : q_start + num_lin + num_ang])
        return result

    @staticmethod
    def _quat_from_axis_targets(t_x: float, t_y: float, t_z: float) -> tuple[float, float, float, float]:
        """Compose per-axis angles into a unit quaternion using extrinsic ZYX
        (yaw-pitch-roll) — equivalent to
        ``wp.quat_from_euler(wp.vec3(t_x, t_y, t_z), 2, 1, 0)``. Matches
        Kamino's ``target_dofs_to_coords_conversion_kernel`` convention.

        Args:
            t_x: Rotation around X [rad].
            t_y: Rotation around Y [rad].
            t_z: Rotation around Z [rad].

        Returns:
            ``(qx, qy, qz, qw)`` in Newton/Warp's vector-first storage order.
        """
        import math  # noqa: PLC0415

        cx = math.cos(t_x * 0.5)
        sx = math.sin(t_x * 0.5)
        cy = math.cos(t_y * 0.5)
        sy = math.sin(t_y * 0.5)
        cz = math.cos(t_z * 0.5)
        sz = math.sin(t_z * 0.5)
        return (
            sx * cy * cz + cx * sy * sz,  # qx
            cx * sy * cz - sx * cy * sz,  # qy
            cx * cy * sz + sx * sy * cz,  # qz
            cx * cy * cz - sx * sy * sz,  # qw
        )

    # endregion

    def replicate(
        self,
        builder: ModelBuilder,
        world_count: int,
        spacing: tuple[float, float, float] = (0.0, 0.0, 0.0),
        *,
        xforms: Sequence[Transform] | None = None,
        label_prefixes: Sequence[str | None] | None = None,
    ):
        """
        Replicates the given builder multiple times, offsetting each copy according to the supplied spacing.

        This method is useful for creating multiple instances of a sub-model (e.g., robots, scenes)
        arranged in a regular grid or along a line. Each copy is offset in space by a multiple of the
        specified spacing vector, and all entities from each copy are assigned to a new world.

        All copies are merged in a single batched pass; subclass overrides of
        :meth:`add_world` or :meth:`add_builder` are not invoked during replication.
        Merged entries may share objects with ``builder`` and across the replicated
        worlds; see :meth:`add_builder` for the supported life-cycle.

        Note:
            For visual separation of worlds, it is recommended to use the viewer's
            `set_world_offsets()` method instead of physical spacing. This improves numerical
            stability by keeping all worlds at the origin in the physics simulation.

        .. important::
            To approximate mesh shapes, call
            :meth:`~newton.ModelBuilder.approximate_meshes` on ``builder`` before
            passing it here. Replication copies mesh references, so approximating
            first yields a single simplified copy shared across all worlds;
            approximating afterwards allocates one copy per replicated shape.

        Args:
            builder: The builder to replicate. All entities from this builder will be copied.
            world_count: The number of worlds to create.
            spacing: The spacing between each copy along each axis. Ignored when
                ``xforms`` is provided.
                For example, (5.0, 5.0, 0.0) arranges copies in a 2D grid in the XY plane.
                Defaults to (0.0, 0.0, 0.0).
            xforms: Optional sequence of transforms, one per replicated world.
                When provided, its length must equal ``world_count``.
            label_prefixes: Optional prefix prepended to all labels from the source builder,
                one per replicated world, applied as :meth:`add_builder` applies its
                ``label_prefix``. Labels are joined with ``/``. A ``None`` entry leaves that
                world's labels as they are in ``builder``; an empty source label remains
                unlabeled.
        """
        if world_count <= 0:
            return
        if self.current_world != -1:
            raise RuntimeError(
                f"Cannot begin a new world: already in world context (current_world={self.current_world}). "
                "Call end_world() first to close the current world context."
            )
        if xforms is None:
            offsets = compute_world_offsets(world_count, spacing, self.up_axis)
            xforms = [wp.transform(offset, wp.quat_identity()) for offset in offsets]
        elif len(xforms) != world_count:
            raise ValueError(f"xforms must contain {world_count} entries, got {len(xforms)}")
        if label_prefixes is None:
            label_prefixes = [None] * world_count
        elif len(label_prefixes) != world_count:
            raise ValueError(f"label_prefixes must contain {world_count} entries, got {len(label_prefixes)}")

        base_world = self.world_count
        worlds = list(range(base_world, base_world + world_count))
        self._merge_builder_copies(builder, worlds, xforms, label_prefixes)

        self.world_gravity.extend(builder._gravity_as_vector() for _ in range(world_count))
        self.world_count += world_count

    def _merge_builder_copies(
        self,
        builder: ModelBuilder,
        worlds: Sequence[int],
        xforms: Sequence[Transform | None],
        label_prefixes: Sequence[str | None],
    ) -> None:
        if builder.up_axis != self.up_axis:
            raise ValueError("Cannot add a builder with a different up axis.")

        world_count = len(worlds)
        if len(xforms) != world_count or len(label_prefixes) != world_count:
            raise ValueError("worlds, xforms, and label_prefixes must have the same length")

        worlds = np.asarray(worlds, dtype=np.int64)

        def normalize_xform(xform: Transform | None) -> wp.transform | None:
            if xform is None:
                return None
            xform = wp.transform(*xform)
            # Identity behaves as None: skips the per-world transform loops and keeps copies
            # bit-exact (identity transform_mul round-trips are not exact for free-root joint_q).
            return None if np.array_equal(np.asarray(xform), _IDENTITY_TRANSFORM) else xform

        xforms = [normalize_xform(xform) for xform in xforms]
        offsets = np.asarray(
            [np.zeros(3, dtype=np.float32) if xform is None else xform.p for xform in xforms], dtype=np.float32
        )
        translations_only = all(
            xform is None or np.array_equal(np.asarray(xform.q), _IDENTITY_ROTATION) for xform in xforms
        )

        def source_list(attr: str) -> list:
            values = getattr(builder, attr)
            # Tolerate array-valued fields assigned in place of lists (list-repeat and
            # extend would silently misbehave on ndarrays).
            return values if isinstance(values, list) else list(values)

        transform_mul_cfunc = wp._src.context.runtime.core.wp_builtin_mul_transformf_transformf

        def transform_mul(a: wp.transform, b: wp.transform) -> wp.transform:
            out = wp.transform.from_buffer(np.empty(7, dtype=np.float32))
            transform_mul_cfunc(a, b, ctypes.byref(out))
            return out

        counts = self._builder_merge_counts(builder)
        self._validate_builder_merge(builder, set(counts))
        attribute_specs = self._builder_merge_attribute_specs()
        bases = self._builder_merge_counts(self)

        world_range = np.arange(world_count, dtype=np.int64)
        start_arrays = {kind: base + world_range * counts[kind] for kind, base in bases.items()}
        start_arrays["muscle_point"] = len(self.muscle_bodies) + world_range * len(builder.muscle_bodies)

        def starts(kind: str) -> np.ndarray:
            return start_arrays[kind]

        def extend_referenced(dst: list, values: Sequence[Any], kind: str) -> None:
            if not values:
                return
            source = np.asarray(values, dtype=np.int64)
            if world_count == 1:
                start = int(start_arrays[kind][0])
                dst.extend(np.where(source >= 0, source + start, source).tolist())
                return
            tiled = np.tile(source, (world_count,) + (1,) * (source.ndim - 1))
            offset_shape = (world_count * len(source),) + (1,) * (source.ndim - 1)
            offsets = np.repeat(starts(kind), len(source)).reshape(offset_shape)
            translated = np.where(tiled >= 0, tiled + offsets, tiled)
            dst.extend(translated.tolist())

        self._requested_contact_attributes.update(builder._requested_contact_attributes)
        self._requested_state_attributes.update(builder._requested_state_attributes)

        attribute_specs.pop("particle_q")
        if counts["particle"]:
            self.particle_max_velocity = builder.particle_max_velocity
            particle_q = np.tile(np.asarray(builder.particle_q, dtype=np.float32), (world_count, 1))
            particle_q += np.repeat(offsets, counts["particle"], axis=0)
            self.particle_q.extend(particle_q.tolist())

        shape_starts = starts("shape")
        body_starts = starts("body")

        attribute_specs.pop("shape_transform")
        shape_transform_start = len(self.shape_transform)
        self.shape_transform.extend(source_list("shape_transform") * world_count)
        if counts["shape"]:
            static_shapes = np.flatnonzero(np.asarray(builder.shape_body, dtype=np.int64) == -1)
            for world_index, xform in enumerate(xforms):
                if xform is None:
                    continue
                for shape in static_shapes.tolist():
                    source = wp.transform(*builder.shape_transform[shape])
                    target = shape_transform_start + world_index * counts["shape"] + shape
                    self.shape_transform[target] = transform_mul(xform, source)

        for body_start, shape_start in zip(body_starts, shape_starts, strict=True):
            for body, shapes in builder.body_shapes.items():
                translated_shapes = [shape + int(shape_start) for shape in shapes]
                if body == -1:
                    self.body_shapes[-1].extend(translated_shapes)
                else:
                    self.body_shapes[body + int(body_start)] = translated_shapes

        joint_starts = starts("joint")
        joint_coord_starts = starts("joint_coord")
        joint_dof_starts = starts("joint_dof")

        attribute_specs.pop("joint_X_p")
        attribute_specs.pop("joint_q")
        joint_X_p_start = len(self.joint_X_p)
        self.joint_X_p.extend(source_list("joint_X_p") * world_count)
        joint_q = np.tile(np.asarray(builder.joint_q, dtype=np.float32), world_count)
        if counts["joint"]:
            joint_types = np.asarray(builder.joint_type, dtype=np.int64)
            joint_parents = np.asarray(builder.joint_parent, dtype=np.int64)
            nonfree_roots = np.flatnonzero((joint_parents == -1) & (joint_types != int(JointType.FREE)))
            for world_index, xform in enumerate(xforms):
                if xform is None:
                    continue
                for joint in nonfree_roots.tolist():
                    source = wp.transform(*builder.joint_X_p[joint])
                    target = joint_X_p_start + world_index * counts["joint"] + joint
                    self.joint_X_p[target] = transform_mul(xform, source)

            free_roots = np.flatnonzero((joint_parents == -1) & (joint_types == int(JointType.FREE)))
            if len(free_roots) and any(xform is not None for xform in xforms):
                # Per-joint frames are invariant across worlds; compute them once.
                free_root_frames = []
                for joint in free_roots.tolist():
                    source_q = builder.joint_q_start[joint]
                    xform_prev = wp.transform(*builder.joint_q[source_q : source_q + 7])
                    X_pj = wp.transform(*builder.joint_X_p[joint])
                    free_root_frames.append((source_q, X_pj, wp.transform_inverse(X_pj), xform_prev))
                for world_index, xform in enumerate(xforms):
                    if xform is None:
                        continue
                    coord_base = world_index * counts["joint_coord"]
                    for source_q, X_pj, X_pj_inv, xform_prev in free_root_frames:
                        xform_local = transform_mul(transform_mul(X_pj_inv, xform), X_pj)
                        transformed = transform_mul(xform_local, xform_prev)
                        target_q = coord_base + source_q
                        joint_q[target_q : target_q + 7] = np.asarray(transformed, dtype=np.float32)

        self.joint_q.extend(joint_q.tolist())

        for world_index, joint_start in enumerate(joint_starts.tolist()):
            body_start = int(body_starts[world_index])
            for joint, (parent, child) in enumerate(
                zip(builder.joint_parent, builder.joint_child, strict=True), start=int(joint_start)
            ):
                new_parent = parent + body_start if parent != -1 else -1
                new_child = child + body_start
                self.joint_parents.setdefault(new_child, []).append((new_parent, joint))
                self.joint_children.setdefault(new_parent, []).append((new_child, joint))

        attribute_specs.pop("body_q")
        if counts["body"]:
            if translations_only:
                body_q = np.tile(np.asarray(builder.body_q, dtype=np.float32).reshape((-1, 7)), (world_count, 1))
                if np.any(offsets):
                    body_q[:, :3] += np.repeat(offsets, counts["body"], axis=0)
                # Own each transform without retaining per-row views into the tiled array.
                self.body_q.extend(wp.transform.from_buffer_copy(row) for row in body_q)
            else:
                for xform in xforms:
                    if xform is None:
                        self.body_q.extend(wp.transform(*body_q) for body_q in builder.body_q)
                    else:
                        self.body_q.extend(transform_mul(xform, wp.transform(*body_q)) for body_q in builder.body_q)

        source_filter_pairs = builder._shape_collision_filter_pairs
        if source_filter_pairs:
            template_pairs = builder._materialized_filter_template()
            for world, shape_start in zip(worlds.tolist(), shape_starts.tolist(), strict=True):
                if isinstance(self._shape_collision_filter_pairs, _BuilderShapeCollisionFilterPairs):
                    self._shape_collision_filter_pairs.extend_offset(
                        template_pairs,
                        shape_start,
                        world=world if world >= 0 else None,
                        shape_count=builder.shape_count,
                    )
                else:
                    self._shape_collision_filter_pairs.extend(
                        (shape_a + shape_start, shape_b + shape_start) for shape_a, shape_b in template_pairs
                    )

        for attr, spec in attribute_specs.items():
            if spec.compaction_policy in {"world_start", "passthrough"}:
                continue
            source = source_list(attr)
            if not source:
                continue
            destination = getattr(self, attr)
            if spec.compaction_policy == "color_groups":
                kind = self._builder_frequency_key(spec.frequency)
                source_groups = [np.asarray(group, dtype=np.int64) for group in source]
                # Combine (size, chunk) plans per world and materialize once: same
                # composition as sequential add_world() merges in O(total) instead
                # of O(worlds^2). Destination chunks carry no offset (None).
                plan = [(len(group), [(group, None)]) for group in destination]
                for start in starts(kind).tolist():
                    plan = combine_independent_coloring_plan(
                        plan, [(len(group), [(group, start)]) for group in source_groups]
                    )
                merged_groups = []
                for _, chunks in plan:
                    parts = [group if offset is None else group + offset for group, offset in chunks]
                    merged_groups.append(parts[0] if len(parts) == 1 else np.concatenate(parts))
                setattr(self, attr, merged_groups)
            elif attr.endswith("_label"):
                for label_prefix in label_prefixes:
                    if label_prefix:
                        rooted = label_prefix + "/"
                        destination.extend([rooted + label if label else label for label in source])
                    else:
                        destination.extend(source)
            elif spec.references in {Model.AttributeFrequency.WORLD, "world"}:
                source_count = counts.get(self._builder_frequency_key(spec.frequency), len(source))
                destination.extend(np.repeat(worlds, source_count).tolist())
            elif spec.references is not None:
                extend_referenced(destination, source, self._builder_frequency_key(spec.references))
            else:
                destination.extend(source * world_count)

        self.joint_dof_count += world_count * counts["joint_dof"]
        self.joint_coord_count += world_count * counts["joint_coord"]
        self.joint_constraint_count += world_count * counts["joint_constraint"]

        for world_index, world in enumerate(worlds.tolist()):
            entity_offsets = {kind: int(starts(kind)[world_index]) for kind in counts}
            self._merge_builder_custom_attributes(builder, entity_offsets, world, label_prefixes[world_index])
            self._merge_builder_actuators(
                builder,
                int(joint_dof_starts[world_index]),
                int(joint_coord_starts[world_index]),
            )

    @staticmethod
    @functools.cache
    def _builder_frequency_key(frequency: Model.AttributeFrequency | str) -> str:
        return frequency.name.lower() if isinstance(frequency, Model.AttributeFrequency) else frequency

    @classmethod
    def _builder_merge_counts(cls, builder: ModelBuilder) -> dict[str, int]:
        counts = {}
        for frequency, count_attr in Model._ATTRIBUTE_FREQUENCY_COUNT_ATTRS.items():
            if frequency == Model.AttributeFrequency.WORLD:
                continue
            key = cls._builder_frequency_key(frequency)
            count = getattr(builder, count_attr, None)
            if count is not None:
                counts[key] = count
            elif frequency == Model.AttributeFrequency.CONSTRAINT_MIMIC:
                counts[key] = len(builder.constraint_mimic_joint0)
        return counts

    @staticmethod
    def _base_builder_attributes() -> tuple[frozenset[str], frozenset[str]]:
        """(all, list-valued) attribute names of a plain ModelBuilder.

        Merge metadata is checked against this class-level snapshot so instance
        or subclass extras cannot change the merge schema.
        """
        if ModelBuilder._BASE_ATTRIBUTES is None:
            base = vars(ModelBuilder())
            ModelBuilder._BASE_ATTRIBUTES = frozenset(base)
            ModelBuilder._BASE_LIST_ATTRIBUTES = frozenset(
                name for name, value in base.items() if isinstance(value, list)
            )
        return ModelBuilder._BASE_ATTRIBUTES, ModelBuilder._BASE_LIST_ATTRIBUTES

    @classmethod
    def _builder_merge_attribute_specs(cls) -> dict[str, Model.AttributeSpec]:
        import newton  # noqa: PLC0415

        use_coord_layout_targets = bool(newton.use_coord_layout_targets)
        # Stored in cls.__dict__ (not functools.cache) so dynamically created
        # subclasses stay collectable.
        cache = cls.__dict__.get("_MERGE_ATTRIBUTE_SPEC_CACHE")
        if cache is None:
            cache = {}
            cls._MERGE_ATTRIBUTE_SPEC_CACHE = cache
        specs = cache.get(use_coord_layout_targets)
        if specs is None:
            specs = cache[use_coord_layout_targets] = cls._build_builder_merge_attribute_specs(use_coord_layout_targets)
        # Copy: the merge pops entries it handles manually.
        return dict(specs)

    @classmethod
    def _build_builder_merge_attribute_specs(cls, use_coord_layout_targets: bool) -> dict[str, Model.AttributeSpec]:
        """Build and validate the merge schema from class-level constants; cached
        per (class, target layout) by :meth:`_builder_merge_attribute_specs`."""
        base_attributes, list_attributes = cls._base_builder_attributes()
        specs = {name: spec for name, spec in Model._CORE_ATTRIBUTE_SPECS.items() if name in list_attributes}
        specs.update(cls._BUILDER_ATTRIBUTE_SPECS)
        declared_builder_attributes = set(cls._BUILDER_ATTRIBUTE_SPECS)

        target_q_frequency = (
            Model.AttributeFrequency.JOINT_COORD if use_coord_layout_targets else Model.AttributeFrequency.JOINT_DOF
        )
        specs["joint_target_q"] = Model.AttributeSpec(target_q_frequency)

        for group, references in cls._BUILDER_GROUP_REFERENCES.items():
            specs[f"_{group}_label"] = Model.AttributeSpec(group)
            specs[f"_{group}_world"] = Model.AttributeSpec(group, references=Model.AttributeFrequency.WORLD)
            declared_builder_attributes.update((f"_{group}_label", f"_{group}_world"))
            for suffix, reference in references.items():
                name = f"_{group}_{suffix}"
                specs[name] = Model.AttributeSpec(
                    group,
                    references=reference,
                    compaction_policy="start" if suffix.endswith("_start") else "end",
                )
                declared_builder_attributes.add(name)

        stale = declared_builder_attributes.difference(base_attributes)
        if stale:
            raise RuntimeError(f"ModelBuilder merge metadata references missing attributes: {sorted(stale)}")

        non_lists = {
            name
            for name in declared_builder_attributes
            if name != "_shape_collision_filter_pairs" and name not in list_attributes
        }
        if non_lists:
            raise RuntimeError(f"ModelBuilder merge attributes must remain lists: {sorted(non_lists)}")

        missing = list_attributes.difference(specs)
        if missing:
            raise RuntimeError(f"ModelBuilder list attributes are missing merge metadata: {sorted(missing)}")
        return {name: specs[name] for name in list_attributes}

    @staticmethod
    def _is_integer_scalar(value: Any) -> bool:
        """True for Python, NumPy, and Warp integer scalars (index-like values)."""
        return isinstance(value, (int, np.integer)) or wp.types.type_is_int(type(value))

    @staticmethod
    def _custom_attribute_defaults_match(existing: Any, incoming: Any) -> bool:
        # Repeated merges of one source compare identical objects; skip the
        # slow element-wise equality of Warp value types.
        if existing is incoming:
            return True
        try:
            matches = existing == incoming
            if hasattr(matches, "__iter__") and not isinstance(matches, (str, bytes)):
                matches = all(matches)
        except (ValueError, TypeError):
            return False
        return bool(matches)

    def _validate_builder_merge(self, builder: ModelBuilder, entity_kinds: set[str]) -> None:
        # Replication merges the same handful of source builders once per world, and this
        # check is pure schema validation: it compares custom-attribute specs and defaults,
        # which cannot change unless one of the two registries changes. Both are versioned,
        # so a repeat merge of an unchanged pair is skipped. Without this the element-wise
        # equality on Warp-typed defaults runs once per attribute per world.
        # ``valid_references`` only ever grows as merges accumulate frequency counts, so a
        # pair that validated before still validates.
        cache_key = (self._custom_schema_epoch, builder._custom_schema_epoch, frozenset(entity_kinds))
        validated = _MERGE_VALIDATION_CACHE.setdefault(self, weakref.WeakKeyDictionary())
        if validated.get(builder) == cache_key:
            return

        valid_references = entity_kinds | set(self._custom_frequency_counts) | set(builder._custom_frequency_counts)

        for freq_key, frequency in builder.custom_frequencies.items():
            existing = self.custom_frequencies.get(freq_key)
            if existing is not None and not self._custom_frequency_specs_match(existing, frequency):
                raise ValueError(
                    f"Custom frequency '{freq_key}' is already registered with different callbacks or metadata."
                )

        for full_key, attr in builder.custom_attributes.items():
            merged = self.custom_attributes.get(full_key)
            if merged is not None:
                if not self._custom_attribute_specs_match(merged, attr):
                    raise ValueError(f"Custom attribute '{full_key}' already exists with incompatible spec")
                if not self._custom_attribute_defaults_match(merged.default, attr.default):
                    raise ValueError(
                        f"Custom attribute '{full_key}' default mismatch when merging builders: "
                        f"existing={merged.default}, incoming={attr.default}"
                    )

            if attr.values and attr.references not in (None, "world") and attr.references not in valid_references:
                raise ValueError(
                    f"Unknown references value '{attr.references}'. "
                    f"Valid values are: {sorted(entity_kinds)} or custom frequencies."
                )

            if (
                attr.values
                and not isinstance(attr.frequency, str)
                and attr.frequency
                not in (
                    Model.AttributeFrequency.ONCE,
                    Model.AttributeFrequency.WORLD,
                )
            ):
                frequency = attr.frequency.name.lower()
                if frequency not in valid_references:
                    raise ValueError(
                        f"Unknown frequency '{frequency}'. "
                        f"Valid values are: {sorted(entity_kinds)} or custom frequencies."
                    )

        for key, finalizer in builder._custom_attribute_model_finalizers.items():
            existing = self._custom_attribute_model_finalizers.get(key)
            if existing is not None and existing is not finalizer:
                raise ValueError(
                    f"Custom attribute finalizer '{key}' is already registered with a different callback "
                    f"({existing!r} != {finalizer!r})."
                )

        validated[builder] = cache_key

    def add_articulation(
        self, joints: list[int], label: str | None = None, custom_attributes: dict[str, Any] | None = None
    ):
        """
        Adds an articulation to the model from a list of joint indices.

        The articulation is a set of joints that must be contiguous and monotonically increasing.
        Some functions, such as forward kinematics :func:`newton.eval_fk`, are parallelized over articulations.

        Args:
            joints: List of joint indices to include in the articulation. Must be contiguous and monotonic.
            label: The label of the articulation. If None, a default label will be created.
            custom_attributes: Dictionary of custom attribute values for ARTICULATION frequency attributes.

        Raises:
            ValueError: If joints are not contiguous, not monotonic, or belong to different worlds.

        Example:
            .. code-block:: python

                link1 = builder.add_link(...)
                link2 = builder.add_link(...)
                link3 = builder.add_link(...)

                joint1 = builder.add_joint_revolute(parent=-1, child=link1)
                joint2 = builder.add_joint_revolute(parent=link1, child=link2)
                joint3 = builder.add_joint_revolute(parent=link2, child=link3)

                # Create articulation from the joints
                builder.add_articulation([joint1, joint2, joint3])
        """
        if not joints:
            raise ValueError("Cannot create an articulation with no joints")

        # Sort joints to ensure we can validate them properly
        sorted_joints = sorted(joints)

        # Validate joints are monotonically increasing (no duplicates)
        if sorted_joints != joints:
            raise ValueError(
                f"Joints must be provided in monotonically increasing order. Got {joints}, expected {sorted_joints}"
            )

        # Validate joints are contiguous
        for i in range(1, len(sorted_joints)):
            if sorted_joints[i] != sorted_joints[i - 1] + 1:
                raise ValueError(
                    f"Joints must be contiguous. Got indices {sorted_joints}, but there is a gap between "
                    f"{sorted_joints[i - 1]} and {sorted_joints[i]}. Create all joints for an articulation "
                    f"before creating joints for another articulation."
                )

        # Validate all joints exist and don't already belong to an articulation
        for joint_idx in joints:
            if joint_idx < 0 or joint_idx >= len(self.joint_type):
                raise ValueError(
                    f"Joint index {joint_idx} is out of range. Valid range is 0 to {len(self.joint_type) - 1}"
                )
            if self.joint_articulation[joint_idx] >= 0:
                existing_art = self.joint_articulation[joint_idx]
                raise ValueError(
                    f"Joint {joint_idx} ('{self.joint_label[joint_idx]}') already belongs to articulation {existing_art} "
                    f"('{self.articulation_label[existing_art]}'). Each joint can only belong to one articulation."
                )

        # Validate all joints belong to the same world (current world)
        for joint_idx in joints:
            if joint_idx < len(self.joint_world) and self.joint_world[joint_idx] != self.current_world:
                raise ValueError(
                    f"Joint {joint_idx} belongs to world {self.joint_world[joint_idx]}, but current world is "
                    f"{self.current_world}. All joints in an articulation must belong to the same world."
                )

        # Basic tree structure validation (check for cycles, single parent)
        # Build a simple tree structure check - each child should have only one parent in this articulation
        child_to_parent = {}
        for joint_idx in joints:
            child = self.joint_child[joint_idx]
            parent = self.joint_parent[joint_idx]
            if child in child_to_parent and child_to_parent[child] != parent:
                raise ValueError(
                    f"Body {child} has multiple parents in this articulation: {child_to_parent[child]} and {parent}. "
                    f"This creates an invalid tree structure. Loop-closing joints must not be part of an articulation."
                )
            child_to_parent[child] = parent

        # Validate that only root bodies (parent == -1) can be kinematic
        self._validate_kinematic_articulation_joints(joints)

        # Store the articulation using the first joint's index as the start
        articulation_idx = self.articulation_count
        self.articulation_start.append(sorted_joints[0])
        self.articulation_end.append(sorted_joints[-1] + 1)
        self.articulation_label.append(label or f"articulation_{articulation_idx}")
        self.articulation_world.append(self.current_world)

        # Mark all joints as belonging to this articulation
        for joint_idx in joints:
            self.joint_articulation[joint_idx] = articulation_idx

        # Process custom attributes for this articulation
        if custom_attributes:
            self._process_custom_attributes(
                entity_index=articulation_idx,
                custom_attrs=custom_attributes,
                expected_frequency=Model.AttributeFrequency.ARTICULATION,
            )

    def _record_cable_group(
        self,
        label: str,
        body_range: tuple[int, int],
        joint_range: tuple[int, int],
    ) -> None:
        """Register an imported cable as an addressable, world-tagged group."""
        self._cable_label.append(label)
        self._cable_world.append(self.current_world)
        self._cable_body_start.append(body_range[0])
        self._cable_body_end.append(body_range[1])
        self._cable_joint_start.append(joint_range[0])
        self._cable_joint_end.append(joint_range[1])

    def _record_cloth_group(
        self,
        label: str,
        particle_range: tuple[int, int],
        tri_range: tuple[int, int],
        edge_range: tuple[int, int],
    ) -> None:
        """Register an imported cloth as an addressable, world-tagged group."""
        self._cloth_label.append(label)
        self._cloth_world.append(self.current_world)
        self._cloth_particle_start.append(particle_range[0])
        self._cloth_particle_end.append(particle_range[1])
        self._cloth_tri_start.append(tri_range[0])
        self._cloth_tri_end.append(tri_range[1])
        self._cloth_edge_start.append(edge_range[0])
        self._cloth_edge_end.append(edge_range[1])

    def _record_soft_group(
        self,
        label: str,
        particle_range: tuple[int, int],
        tet_range: tuple[int, int],
    ) -> None:
        """Register an imported soft volume as an addressable, world-tagged group."""
        self._soft_label.append(label)
        self._soft_world.append(self.current_world)
        self._soft_particle_start.append(particle_range[0])
        self._soft_particle_end.append(particle_range[1])
        self._soft_tet_start.append(tet_range[0])
        self._soft_tet_end.append(tet_range[1])

    # region importers
    def add_urdf(
        self,
        source: str,
        *,
        xform: Transform | None = None,
        floating: bool | None = None,
        base_joint: dict | None = None,
        parent_body: int = -1,
        scale: float = 1.0,
        hide_visuals: bool = False,
        parse_visuals_as_colliders: bool = False,
        up_axis: AxisType = Axis.Z,
        force_show_colliders: bool = False,
        enable_self_collisions: bool = True,
        ignore_inertial_definitions: bool = False,
        joint_ordering: Literal["bfs", "dfs"] | None = "dfs",
        bodies_follow_joint_ordering: bool = True,
        collapse_fixed_joints: bool = False,
        collapse_massless_fixed_root: bool = False,
        mesh_maxhullvert: int | None = None,
        force_position_velocity_actuation: bool = False,
        override_root_xform: bool = False,
    ):
        """
        Parses a URDF file and adds the bodies and joints to the given ModelBuilder.

        Args:
            source: The filename of the URDF file to parse, or the URDF XML string content.
            xform: The transform to apply to the root body. If None, the transform is set to identity.
            override_root_xform: If ``True``, the articulation root's world-space
                transform is replaced by ``xform`` instead of being composed with it,
                preserving only the internal structure (relative body positions). Useful
                for cloning articulations at explicit positions. When a ``base_joint`` is
                specified, ``xform`` is applied as the full parent transform (including
                rotation) rather than splitting position/rotation. Not intended for
                sources containing multiple articulations, as all roots would be placed
                at the same ``xform``. Defaults to ``False``.
            floating: Controls the base joint type for the root body.

                - ``None`` (default): Uses format-specific default (creates a FIXED joint for URDF).
                - ``True``: Creates a FREE joint with 6 DOF (3 translation + 3 rotation). Only valid when
                  ``parent_body == -1`` since FREE joints must connect to world frame.
                - ``False``: Creates a FIXED joint (0 DOF).

                Cannot be specified together with ``base_joint``.
            base_joint: Custom joint specification for connecting the root body to the world
                (or to ``parent_body`` if specified). This parameter enables hierarchical composition with
                custom mobility. Dictionary with joint parameters as accepted by
                :meth:`ModelBuilder.add_joint` (e.g., joint type, axes, limits, stiffness).

                Cannot be specified together with ``floating``.
            parent_body: Parent body index for hierarchical composition. If specified, attaches the
                imported root body to this existing body, making them part of the same kinematic articulation.
                The connection type is determined by ``floating`` or ``base_joint``. If ``-1`` (default),
                the root connects to the world frame. **Restriction**: Only the most recently added
                articulation can be used as parent; attempting to attach to an older articulation will raise
                a ``ValueError``.

                .. note::
                   Valid combinations of ``floating``, ``base_joint``, and ``parent_body``:

                   .. list-table::
                      :header-rows: 1
                      :widths: 15 15 15 55

                      * - floating
                        - base_joint
                        - parent_body
                        - Result
                      * - ``None``
                        - ``None``
                        - ``-1``
                        - Format default (URDF: FIXED joint)
                      * - ``True``
                        - ``None``
                        - ``-1``
                        - FREE joint to world (6 DOF)
                      * - ``False``
                        - ``None``
                        - ``-1``
                        - FIXED joint to world (0 DOF)
                      * - ``None``
                        - ``{dict}``
                        - ``-1``
                        - Custom joint to world (e.g., D6)
                      * - ``False``
                        - ``None``
                        - ``body_idx``
                        - FIXED joint to parent body
                      * - ``None``
                        - ``{dict}``
                        - ``body_idx``
                        - Custom joint to parent body (e.g., D6)
                      * - *explicitly set*
                        - *explicitly set*
                        - *any*
                        - ❌ Error: mutually exclusive (cannot specify both)
                      * - ``True``
                        - ``None``
                        - ``body_idx``
                        - ❌ Error: FREE joints require world frame

            scale: The scaling factor to apply to the imported mechanism.
            hide_visuals: If True, hide visual shapes.
            parse_visuals_as_colliders: If True, the geometry defined under the `<visual>` tags is used for collision handling instead of the `<collision>` geometries.
            up_axis: The up axis of the URDF. This is used to transform the URDF to the builder's up axis. It also determines the up axis of capsules and cylinders in the URDF. The default is Z.
            force_show_colliders: If True, the collision shapes are always shown, even if there are visual shapes.
            enable_self_collisions: If True, self-collisions are enabled.
            ignore_inertial_definitions: If True, the inertial parameters defined in the URDF are ignored and the inertia is calculated from the shape geometry.
            joint_ordering: The ordering of the joints in the simulation. Can be either "bfs" or "dfs" for breadth-first or depth-first search, or ``None`` to keep joints in the order in which they appear in the URDF. Default is "dfs".
            bodies_follow_joint_ordering: If True, the bodies are added to the builder in the same order as the joints (parent then child body). Otherwise, bodies are added in the order they appear in the URDF. Default is True.
            collapse_fixed_joints: If True, fixed joints are removed and the respective bodies are merged.
            collapse_massless_fixed_root: If True, collapse only the massless fixed-joint chain below an imported free root body. Ignored when ``collapse_fixed_joints`` is True.
            mesh_maxhullvert: Maximum vertices for convex hull approximation of meshes.
            force_position_velocity_actuation: If True and both position (stiffness) and velocity
                (damping) gains are non-zero, joints use :attr:`~newton.JointTargetMode.POSITION_VELOCITY` actuation mode.
                If False (default), actuator modes are inferred per joint via :func:`newton.JointTargetMode.from_gains`:
                :attr:`~newton.JointTargetMode.POSITION` if stiffness > 0, :attr:`~newton.JointTargetMode.VELOCITY` if only
                damping > 0, :attr:`~newton.JointTargetMode.EFFORT` if a drive is present but both gains are zero
                (direct torque control), or :attr:`~newton.JointTargetMode.NONE` if no drive/actuation is applied.
        """
        from ..utils.import_urdf import parse_urdf  # noqa: PLC0415

        return parse_urdf(
            self,
            source,
            xform=xform,
            floating=floating,
            base_joint=base_joint,
            parent_body=parent_body,
            scale=scale,
            hide_visuals=hide_visuals,
            parse_visuals_as_colliders=parse_visuals_as_colliders,
            up_axis=up_axis,
            force_show_colliders=force_show_colliders,
            enable_self_collisions=enable_self_collisions,
            ignore_inertial_definitions=ignore_inertial_definitions,
            joint_ordering=joint_ordering,
            bodies_follow_joint_ordering=bodies_follow_joint_ordering,
            collapse_fixed_joints=collapse_fixed_joints,
            collapse_massless_fixed_root=collapse_massless_fixed_root,
            mesh_maxhullvert=mesh_maxhullvert,
            force_position_velocity_actuation=force_position_velocity_actuation,
            override_root_xform=override_root_xform,
        )

    def add_usd(
        self,
        source: str | UsdStage,
        *,
        xform: Transform | None = None,
        floating: bool | None = None,
        base_joint: dict | None = None,
        parent_body: int = -1,
        only_load_enabled_rigid_bodies: bool = False,
        only_load_enabled_joints: bool = True,
        joint_drive_gains_scaling: float = 1.0,
        verbose: bool = False,
        ignore_paths: list[str] | None = None,
        collapse_fixed_joints: bool = False,
        enable_self_collisions: bool = True,
        apply_up_axis_from_stage: bool = False,
        root_path: str = "/",
        joint_ordering: Literal["bfs", "dfs"] | None = "dfs",
        bodies_follow_joint_ordering: bool = True,
        skip_mesh_approximation: bool = False,
        load_sites: bool = True,
        load_visual_shapes: bool = True,
        load_static_visual_shapes: bool = True,
        hide_collision_shapes: bool = False,
        force_show_colliders: bool = False,
        parse_mujoco_options: bool = True,
        mesh_maxhullvert: int | None = None,
        schema_resolvers: list[SchemaResolver] | None = None,
        force_position_velocity_actuation: bool = False,
        convert_mjc_equality_constraints: bool = True,
        override_root_xform: bool = False,
        legacy_margin_gap: bool = False,
        return_deformable_results: bool = False,
    ) -> dict[str, Any]:
        """Parses a Universal Scene Description (USD) stage and adds rigid bodies, particles, soft bodies, shapes, and joints to the given ModelBuilder.

        The USD description has to be either a path (file name or URL), or an existing USD stage instance that implements the `Stage <https://openusd.org/dev/api/class_usd_stage.html>`_ interface.

        See :ref:`usd_parsing` for more information.

        Args:
            source: The file path to the USD file, or an existing USD stage instance.
            xform: The transform to apply to the entire scene.
            override_root_xform: If ``True``, the articulation root's world-space
                transform is replaced by ``xform`` instead of being composed with it,
                preserving only the internal structure (relative body positions). Useful
                for cloning articulations at explicit positions. Not intended for sources
                containing multiple articulations, as all roots would be placed at the
                same ``xform``. Defaults to ``False``.
            floating: Controls the base joint type for the root body (bodies not connected as
                a child to any joint).

                - ``None`` (default): Uses format-specific default (creates a FREE joint for USD bodies without joints).
                - ``True``: Creates a FREE joint with 6 DOF (3 translation + 3 rotation). Only valid when
                  ``parent_body == -1`` since FREE joints must connect to world frame.
                - ``False``: Creates a FIXED joint (0 DOF).

                Cannot be specified together with ``base_joint``.
            base_joint: Custom joint specification for connecting the root body to the world
                (or to ``parent_body`` if specified). This parameter enables hierarchical composition with
                custom mobility. Dictionary with joint parameters as accepted by
                :meth:`ModelBuilder.add_joint` (e.g., joint type, axes, limits, stiffness).

                Cannot be specified together with ``floating``.
            parent_body: Parent body index for hierarchical composition. If specified, attaches the
                imported root body to this existing body, making them part of the same kinematic articulation.
                The connection type is determined by ``floating`` or ``base_joint``. If ``-1`` (default),
                the root connects to the world frame. **Restriction**: Only the most recently added
                articulation can be used as parent; attempting to attach to an older articulation will raise
                a ``ValueError``.

                .. note::
                   Valid combinations of ``floating``, ``base_joint``, and ``parent_body``:

                   .. list-table::
                      :header-rows: 1
                      :widths: 15 15 15 55

                      * - floating
                        - base_joint
                        - parent_body
                        - Result
                      * - ``None``
                        - ``None``
                        - ``-1``
                        - Format default (USD: FREE joint for bodies without joints)
                      * - ``True``
                        - ``None``
                        - ``-1``
                        - FREE joint to world (6 DOF)
                      * - ``False``
                        - ``None``
                        - ``-1``
                        - FIXED joint to world (0 DOF)
                      * - ``None``
                        - ``{dict}``
                        - ``-1``
                        - Custom joint to world (e.g., D6)
                      * - ``False``
                        - ``None``
                        - ``body_idx``
                        - FIXED joint to parent body
                      * - ``None``
                        - ``{dict}``
                        - ``body_idx``
                        - Custom joint to parent body (e.g., D6)
                      * - *explicitly set*
                        - *explicitly set*
                        - *any*
                        - ❌ Error: mutually exclusive (cannot specify both)
                      * - ``True``
                        - ``None``
                        - ``body_idx``
                        - ❌ Error: FREE joints require world frame

            only_load_enabled_rigid_bodies: If True, only rigid bodies which do not have `physics:rigidBodyEnabled` set to False are loaded.
            only_load_enabled_joints: If True, only joints which do not have `physics:jointEnabled` set to False are loaded.
            joint_drive_gains_scaling: The default scaling of the PD control gains (stiffness and damping), if not set in the PhysicsScene with as "newton:joint_drive_gains_scaling".
            verbose: If True, print additional information about the parsed USD file. Default is False.
            ignore_paths: A list of regular expressions matching prim paths to ignore.
            collapse_fixed_joints: If True, fixed joints are removed and the respective bodies are merged. Only considered if not set on the PhysicsScene as "newton:collapse_fixed_joints".
            enable_self_collisions: Default for whether self-collisions are enabled for all shapes within an articulation. Resolved via the schema resolver from ``newton:selfCollisionEnabled`` (NewtonArticulationRootAPI) or ``physxArticulation:enabledSelfCollisions``; if neither is authored, this value takes precedence.
            apply_up_axis_from_stage: If True, the up axis of the stage will be used to set :attr:`newton.ModelBuilder.up_axis`. Otherwise, the stage will be rotated such that its up axis aligns with the builder's up axis. Default is False.
            root_path: The USD path to import, defaults to "/".
            joint_ordering: The ordering of the joints in the simulation. Can be either "bfs" or "dfs" for breadth-first or depth-first search, or ``None`` to keep joints in the order in which they appear in the USD. Default is "dfs".
            bodies_follow_joint_ordering: If True, the bodies are added to the builder in the same order as the joints (parent then child body). Otherwise, bodies are added in the order they appear in the USD. Default is True.
            skip_mesh_approximation: If True, mesh approximation is skipped. Otherwise, meshes are approximated according to the ``physics:approximation`` attribute defined on the UsdPhysicsMeshCollisionAPI (if it is defined), using the settings from :attr:`~newton.ModelBuilder.default_mesh_approximation_cfg`. Default is False.
            load_sites: If True, sites (prims with ``NewtonSiteAPI`` or ``MjcSiteAPI``) are loaded as non-colliding reference points. If False, sites are ignored. Default is True.
            load_visual_shapes: If True, non-physics visual geometry is loaded. If False, visual-only shapes are ignored (sites are still controlled by ``load_sites``). Default is True.
            load_static_visual_shapes: If True, supported visual-only geometry outside
                rigid-body hierarchies is loaded as static shapes when
                ``load_visual_shapes`` is also True. Default is True.
            hide_collision_shapes: If True, collision shapes on bodies that already
                have visual-only geometry are hidden unconditionally, regardless of
                whether the collider has authored PBR material data. Default is False.
            force_show_colliders: If True, collision shapes get the VISIBLE flag
                regardless of whether visual shapes exist on the same body. Note that
                ``hide_collision_shapes=True`` still suppresses the VISIBLE flag for
                colliders on bodies with visual-only geometry. Default is False.
            parse_mujoco_options: Whether MuJoCo solver options from the PhysicsScene should be parsed. If False, solver options are not loaded and custom attributes retain their default values. Default is True.
            convert_mjc_equality_constraints: Whether MuJoCo equality schemas should be converted to Newton loop
                joints or mimic constraints while preserving MuJoCo equality metadata for SolverMuJoCo. If False,
                equality constraints are preserved in the ``mujoco:equality_constraint`` custom-attribute namespace
                and finalize under ``model.mujoco.equality_constraint_*``.
            mesh_maxhullvert: Maximum vertices for convex hull approximation of meshes. Note that an authored ``newton:maxHullVertices`` attribute on any shape with a ``NewtonMeshCollisionAPI`` will take priority over this value.
            schema_resolvers: Resolver instances in priority order. Default is to only parse Newton-specific attributes.
                Schema resolvers collect per-prim "solver-specific" attributes, see :ref:`schema_resolvers` for more information.
                These include namespaced attributes such as ``newton:*``, ``physx*``
                (e.g., ``physxScene:*``, ``physxRigidBody:*``, ``physxSDFMeshCollision:*``), and ``mjc:*`` that
                are authored in the USD but not strictly required to build the simulation. This is useful for
                inspection, experimentation, or custom pipelines that read these values via
                ``result["schema_attrs"]`` returned from ``parse_usd()``.

                .. experimental::

                    The ``schema_resolvers`` argument may change without prior notice.
            force_position_velocity_actuation: If True and both stiffness (kp) and damping (kd)
                are non-zero, joints use :attr:`~newton.JointTargetMode.POSITION_VELOCITY` actuation mode.
                If False (default), actuator modes are inferred per joint via :func:`newton.JointTargetMode.from_gains`:
                :attr:`~newton.JointTargetMode.POSITION` if stiffness > 0, :attr:`~newton.JointTargetMode.VELOCITY` if only
                damping > 0, :attr:`~newton.JointTargetMode.EFFORT` if a drive is present but both gains are zero
                (direct torque control), or :attr:`~newton.JointTargetMode.NONE` if no drive/actuation is applied.
            legacy_margin_gap: If True, restore pre-MuJoCo-3.9 import behavior
                where ``shape_margin`` is computed as ``mjc_margin - mjc_gap``.
                Use for USD files authored against MuJoCo <= 3.8. Defaults to
                False (identity translation matching MuJoCo 3.9 semantics).

            return_deformable_results: If True, include the experimental deformable entries in the
                returned mapping (``path_cable_map`` / ``path_cloth_map`` / ``path_soft_map`` /
                ``path_attachment_map`` and the matching ``path_*_attrs``). Off by default, so the
                default return shape carries no deformable additions.

        Returns:
            .. experimental::

               ``return_deformable_results`` and its conditional result entries are experimental and
               may change or be removed without prior notice.

            When ``return_deformable_results=True``, imported deformable (cable/cloth/volume) element
            ranges are returned by prim path in the ``path_cable_map`` / ``path_cloth_map`` /
            ``path_soft_map`` entries below, and the material attributes as authored in the
            matching ``path_*_attrs`` entries. The map entries are build-time snapshots of the
            builder immediately after this call (already remapped when this call collapses fixed
            joints); they are not live selections, and a later ``replicate()``, ``add_builder()``,
            or other structural mutation is outside their contract. The ``path_*_attrs`` entries
            hold authored or resolved source values (``material`` as authored,
            ``resolved_density`` as used), while the map entries and ``joint_indices`` inside
            ``path_attachment_attrs`` are realized builder indices; ``unsupported_reason`` is
            diagnostic text, not a stable code, and a prim absent from a realized map may still
            appear in the authored metadata.

            ``path_particle_map`` is always returned. It maps each imported
            ``UsdGeom.Points`` prim carrying ``NewtonPointsDeformableSimAPI`` whose
            governing ``PhysicsDeformableBodyAPI`` resolves to a
            ``NewtonMPMSceneAPI`` owner to its half-open ``[start, end)`` builder
            particle range. These ranges are build-time snapshots and are not
            updated by later structural builder mutations.
            Each resolved whole-prim or point-``GeomSubset`` physics material must
            apply ``NewtonMPMMaterialAPI``, ``PhysicsMaterialAPI``, or
            ``PhysicsVolumeDeformableMaterialAPI``. MPM elasticity is read from
            ``newton:mpm:youngsModulus`` and ``newton:mpm:poissonsRatio``. After
            unit conversion, Young's modulus is in Pa and density is in kg/m^3.
            Unbound Points use Newton's registered material defaults and
            ``ModelBuilder.default_shape_cfg`` density. All Points imported by one
            call must resolve to the same MPM scene; unrelated PhysicsScenes
            and particle systems are ignored. ``particle_scene_path`` contains the
            governing ``UsdPhysics.Scene`` prim path, or ``None`` when no particles
            are imported.

            Particle widths are diameters. Newton converts each radius as
            ``width / 2`` after applying stage units and the prim's uniform world
            scale; converted widths and radii are in meters. Authored
            ``physics:masses`` take precedence over body mass or density, then
            material density. Density-derived mass uses
            ``physics:density * width**3``; converted masses are in kilograms.
            Without widths, it uses ``ModelBuilder.default_particle_radius`` and a
            support width of twice that radius. Non-uniform scale or shear is
            rejected because one scalar width cannot preserve a spherical particle
            under that transform.

            The returned mapping has the following entries:

            .. list-table::
                :widths: 25 75

                * - ``"fps"``
                  - USD stage frames per second
                * - ``"duration"``
                  - Difference between end time code and start time code of the USD stage
                * - ``"up_axis"``
                  - :class:`Axis` representing the stage's up axis ("X", "Y", or "Z")
                * - ``"path_body_map"``
                  - Mapping from prim path (str) of a rigid body prim (e.g. that implements the PhysicsRigidBodyAPI) to the respective body index in :class:`~newton.ModelBuilder`
                * - ``"path_joint_map"``
                  - Mapping from prim path (str) of a joint prim (e.g. that implements the PhysicsJointAPI) to the respective joint index in :class:`~newton.ModelBuilder`
                * - ``"path_shape_map"``
                  - Mapping from prim path (str) of the UsdGeom to the respective shape index in :class:`~newton.ModelBuilder`
                * - ``"path_shape_scale"``
                  - Mapping from prim path (str) of the UsdGeom to its respective 3D world scale
                * - ``"path_particle_map"``
                  - Mapping from an imported particle-simulation ``UsdGeom.Points`` prim path to its half-open ``(particle_start, particle_end)`` builder range
                * - ``"path_cable_map"``
                  - Mapping from prim path (str) of a curve deformable (cable) to its ``(body_indices, joint_indices)`` lists. Curves welded into a rod graph report empty joints (the joints belong to the shared graph articulation). Present only with ``return_deformable_results=True``.
                * - ``"path_cloth_map"``
                  - Mapping from prim path (str) of a surface deformable (cloth) to its ``[start, end)`` index ranges, keyed ``"particle"`` / ``"tri"`` / ``"edge"``. Present only with ``return_deformable_results=True``.
                * - ``"path_soft_map"``
                  - Mapping from prim path (str) of a soft body (a volume deformable, or a legacy bare TetMesh) to its ``[start, end)`` index ranges, keyed ``"particle"`` / ``"tet"``. Present only with ``return_deformable_results=True``.
                * - ``"path_cable_attrs"``
                  - Mapping from prim path (str) of a curve deformable (cable) to its validated, solver-neutral cable import metadata (``material``, ``resolved_density``, ``closed``). ``material`` contains supported per-mode structural values before per-joint discretization: stretch/shear stiffness [N] and damping [N·s]; bend/twist stiffness [N·m²] and damping [N·m²·s]. ``graph_component`` is present only for curves successfully welded into the same rod graph; curves in one graph share the identifier. Present only with ``return_deformable_results=True``.
                * - ``"path_cloth_attrs"``
                  - Mapping from prim path (str) of a surface deformable (cloth) to its as-authored, solver-neutral attributes (``material`` moduli, ``resolved_density``). Present only with ``return_deformable_results=True``.
                * - ``"path_soft_attrs"``
                  - Mapping from prim path (str) of a soft body (a volume deformable, or a legacy bare TetMesh) to its as-authored, solver-neutral attributes (``resolved_density``). Present only with ``return_deformable_results=True``.
                * - ``"path_attachment_map"``
                  - Mapping from prim path (str) of a supported ``PhysicsAttachment`` prim to the created joint indices. Curve-to-curve ``point``->``point`` junctions are consumed as rod-graph topology and are absent from this mapping. Present only with ``return_deformable_results=True``.
                * - ``"path_attachment_attrs"``
                  - Mapping from prim path (str) of a ``PhysicsAttachment`` prim to its parsed, solver-neutral attributes and any unsupported reason. Junctions consumed as rod-graph topology are absent here as well. Present only with ``return_deformable_results=True``.
                * - ``"mass_unit"``
                  - The stage's Kilograms Per Unit (KGPU) definition (1.0 by default)
                * - ``"linear_unit"``
                  - The stage's Meters Per Unit (MPU) definition (1.0 by default)
                * - ``"scene_attributes"``
                  - Dictionary of all attributes applied to the PhysicsScene prim
                * - ``"physics_scene_path"``
                  - Prim path of the PhysicsScene selected during import, or ``None`` if no PhysicsScene was found
                * - ``"collapse_results"``
                  - Dictionary returned by :meth:`newton.ModelBuilder.collapse_fixed_joints` if ``collapse_fixed_joints`` is True, otherwise None.
                * - ``"physics_dt"``
                  - The resolved physics scene time step (float or None)
                * - ``"schema_attrs"``
                  - Dictionary of collected per-prim schema attributes (dict)
                * - ``"max_solver_iterations"``
                  - The resolved maximum solver iterations (int or None)
                * - ``"particle_scene_path"``
                  - Governing ``UsdPhysics.Scene`` prim path for imported particle simulation geometry, or ``None`` when no particles are imported
                * - ``"path_body_relative_transform"``
                  - Mapping from prim path to relative transform for bodies merged via ``collapse_fixed_joints``
                * - ``"path_original_body_map"``
                  - Mapping from prim path to original body index before ``collapse_fixed_joints``
                * - ``"actuator_count"``
                  - Number of external actuators parsed from the USD stage
        """
        from ..utils.import_usd import parse_usd  # noqa: PLC0415

        return parse_usd(
            self,
            source,
            xform=xform,
            floating=floating,
            base_joint=base_joint,
            parent_body=parent_body,
            only_load_enabled_rigid_bodies=only_load_enabled_rigid_bodies,
            only_load_enabled_joints=only_load_enabled_joints,
            joint_drive_gains_scaling=joint_drive_gains_scaling,
            verbose=verbose,
            ignore_paths=ignore_paths,
            collapse_fixed_joints=collapse_fixed_joints,
            enable_self_collisions=enable_self_collisions,
            apply_up_axis_from_stage=apply_up_axis_from_stage,
            root_path=root_path,
            joint_ordering=joint_ordering,
            bodies_follow_joint_ordering=bodies_follow_joint_ordering,
            skip_mesh_approximation=skip_mesh_approximation,
            load_sites=load_sites,
            load_visual_shapes=load_visual_shapes,
            load_static_visual_shapes=load_static_visual_shapes,
            hide_collision_shapes=hide_collision_shapes,
            force_show_colliders=force_show_colliders,
            parse_mujoco_options=parse_mujoco_options,
            mesh_maxhullvert=mesh_maxhullvert,
            schema_resolvers=schema_resolvers,
            force_position_velocity_actuation=force_position_velocity_actuation,
            convert_mjc_equality_constraints=convert_mjc_equality_constraints,
            override_root_xform=override_root_xform,
            legacy_margin_gap=legacy_margin_gap,
            return_deformable_results=return_deformable_results,
        )

    def add_mjcf(
        self,
        source: str,
        *,
        xform: Transform | None = None,
        floating: bool | None = None,
        base_joint: dict | None = None,
        parent_body: int = -1,
        armature_scale: float = 1.0,
        scale: float = 1.0,
        hide_visuals: bool = False,
        parse_visuals_as_colliders: bool = False,
        parse_meshes: bool = True,
        parse_sites: bool = True,
        parse_visuals: bool = True,
        parse_mujoco_options: bool = True,
        up_axis: AxisType = Axis.Z,
        ignore_names: Sequence[str] = (),
        ignore_classes: Sequence[str] = (),
        visual_classes: Sequence[str] = ("visual",),
        collider_classes: Sequence[str] = ("collision",),
        no_class_as_colliders: bool = True,
        force_show_colliders: bool = False,
        enable_self_collisions: bool = True,
        ignore_inertial_definitions: bool = False,
        collapse_fixed_joints: bool = False,
        collapse_massless_fixed_root: bool = False,
        verbose: bool = False,
        skip_equality_constraints: bool = False,
        convert_mjc_equality_constraints: bool = True,
        convert_3d_hinge_to_ball_joints: bool = False,
        mesh_maxhullvert: int | None = None,
        ctrl_direct: bool = False,
        path_resolver: Callable[[str | None, str], str] | None = None,
        override_root_xform: bool = False,
        legacy_margin_gap: bool = False,
    ):
        """
        Parses MuJoCo XML (MJCF) file and adds the bodies and joints to the given ModelBuilder.
        MuJoCo-specific custom attributes are registered on the builder automatically.

        Args:
            source: The filename of the MuJoCo file to parse, or the MJCF XML string content.
            xform: The transform to apply to the imported mechanism.
            override_root_xform: If ``True``, the articulation root's world-space
                transform is replaced by ``xform`` instead of being composed with it,
                preserving only the internal structure (relative body positions). Useful
                for cloning articulations at explicit positions. Not intended for sources
                containing multiple articulations, as all roots would be placed at the
                same ``xform``. Defaults to ``False``.
            floating: Controls the base joint type for the root body.

                - ``None`` (default): Uses format-specific default (honors ``<freejoint>`` tags in MJCF,
                  otherwise creates a FIXED joint).
                - ``True``: Creates a FREE joint with 6 DOF (3 translation + 3 rotation). Only valid when
                  ``parent_body == -1`` since FREE joints must connect to world frame.
                - ``False``: Creates a FIXED joint (0 DOF).

                Cannot be specified together with ``base_joint``.
            base_joint: Custom joint specification for connecting the root body to the world
                (or to ``parent_body`` if specified). This parameter enables hierarchical composition with
                custom mobility. Dictionary with joint parameters as accepted by
                :meth:`ModelBuilder.add_joint` (e.g., joint type, axes, limits, stiffness).

                Cannot be specified together with ``floating``.
            parent_body: Parent body index for hierarchical composition. If specified, attaches the
                imported root body to this existing body, making them part of the same kinematic articulation.
                The connection type is determined by ``floating`` or ``base_joint``. If ``-1`` (default),
                the root connects to the world frame. **Restriction**: Only the most recently added
                articulation can be used as parent; attempting to attach to an older articulation will raise
                a ``ValueError``.

                .. note::
                   Valid combinations of ``floating``, ``base_joint``, and ``parent_body``:

                   .. list-table::
                      :header-rows: 1
                      :widths: 15 15 15 55

                      * - floating
                        - base_joint
                        - parent_body
                        - Result
                      * - ``None``
                        - ``None``
                        - ``-1``
                        - Format default (MJCF: honors ``<freejoint>``, else FIXED)
                      * - ``True``
                        - ``None``
                        - ``-1``
                        - FREE joint to world (6 DOF)
                      * - ``False``
                        - ``None``
                        - ``-1``
                        - FIXED joint to world (0 DOF)
                      * - ``None``
                        - ``{dict}``
                        - ``-1``
                        - Custom joint to world (e.g., D6)
                      * - ``False``
                        - ``None``
                        - ``body_idx``
                        - FIXED joint to parent body
                      * - ``None``
                        - ``{dict}``
                        - ``body_idx``
                        - Custom joint to parent body (e.g., D6)
                      * - *explicitly set*
                        - *explicitly set*
                        - *any*
                        - ❌ Error: mutually exclusive (cannot specify both)
                      * - ``True``
                        - ``None``
                        - ``body_idx``
                        - ❌ Error: FREE joints require world frame

            armature_scale: Scaling factor to apply to the MJCF-defined joint armature values.
            scale: The scaling factor to apply to the imported mechanism.
            hide_visuals: If True, hide visual shapes after loading them (affects visibility, not loading).
            parse_visuals_as_colliders: If True, the geometry defined under the `visual_classes` tags is used for collision handling instead of the `collider_classes` geometries.
            parse_meshes: Whether geometries of type `"mesh"` should be parsed. If False, geometries of type `"mesh"` are ignored.
            parse_sites: Whether sites (non-colliding reference points) should be parsed. If False, sites are ignored.
            parse_visuals: Whether visual geometries (non-collision shapes) should be loaded. If False, visual shapes are not loaded (different from `hide_visuals` which loads but hides them). Default is True.
            parse_mujoco_options: Whether solver options from the MJCF `<option>` tag should be parsed. If False, solver options are not loaded and custom attributes retain their default values. Default is True.
            up_axis: The up axis of the MuJoCo scene. The default is Z up.
            ignore_names: A list of regular expressions. Bodies and joints with a name matching one of the regular expressions will be ignored.
            ignore_classes: A list of regular expressions. Bodies and joints with a class matching one of the regular expressions will be ignored.
            visual_classes: A list of regular expressions. Visual geometries with a class matching one of the regular expressions will be parsed.
            collider_classes: A list of regular expressions. Collision geometries with a class matching one of the regular expressions will be parsed.
            no_class_as_colliders: If True, geometries without a class are parsed as collision geometries. If False, geometries without a class are parsed as visual geometries.
            force_show_colliders: If True, the collision shapes are always shown, even if there are visual shapes.
            enable_self_collisions: If True, self-collisions are enabled.
            ignore_inertial_definitions: If True, the inertial parameters defined in the MJCF are ignored and the inertia is calculated from the shape geometry.
            collapse_fixed_joints: If True, fixed joints are removed and the respective bodies are merged.
            collapse_massless_fixed_root: If True, collapse only the massless fixed-joint chain below an imported free root body. Ignored when ``collapse_fixed_joints`` is True.
            verbose: If True, print additional information about parsing the MJCF.
            skip_equality_constraints: Whether <equality> tags should be parsed. If True, equality constraints are ignored.
            convert_mjc_equality_constraints: Whether MuJoCo equality constraints should be converted to Newton loop
                joints or mimic constraints while preserving MuJoCo equality metadata for SolverMuJoCo. If False,
                equality constraints are preserved in the ``mujoco:equality_constraint`` custom-attribute namespace
                and finalize under ``model.mujoco.equality_constraint_*``.
            convert_3d_hinge_to_ball_joints: If True, series of three hinge joints are converted to a single ball joint. Default is False.
            mesh_maxhullvert: Maximum vertices for convex hull approximation of meshes.
            ctrl_direct: If True, all actuators use :attr:`~newton.solvers.SolverMuJoCo.CtrlSource.CTRL_DIRECT` mode
                where control comes directly from ``control.mujoco.ctrl`` (MuJoCo-native behavior).
                See :ref:`custom_attributes` for details on custom attributes. If False (default), position/velocity
                actuators use :attr:`~newton.solvers.SolverMuJoCo.CtrlSource.JOINT_TARGET` mode where control comes
                from :attr:`newton.Control.joint_target_q` and :attr:`newton.Control.joint_target_qd`.
            path_resolver: Callback to resolve file paths. Takes (base_dir, file_path) and returns a resolved path. For <include> elements, can return either a file path or XML content directly. For asset elements (mesh, texture, etc.), must return an absolute file path. The default resolver joins paths and returns absolute file paths.
            legacy_margin_gap: If True, restore pre-MuJoCo-3.9 import behavior
                where ``shape_margin`` is computed as ``mj_margin - mj_gap``.
                Use for MJCF files authored against MuJoCo <= 3.8. Defaults
                to False (identity translation matching MuJoCo 3.9 semantics).
        """
        from ..solvers.mujoco.solver_mujoco import SolverMuJoCo  # noqa: PLC0415
        from ..utils.import_mjcf import parse_mjcf  # noqa: PLC0415

        SolverMuJoCo.register_custom_attributes(self)
        return parse_mjcf(
            self,
            source,
            xform=xform,
            floating=floating,
            base_joint=base_joint,
            parent_body=parent_body,
            armature_scale=armature_scale,
            scale=scale,
            hide_visuals=hide_visuals,
            parse_visuals_as_colliders=parse_visuals_as_colliders,
            parse_meshes=parse_meshes,
            parse_sites=parse_sites,
            parse_visuals=parse_visuals,
            parse_mujoco_options=parse_mujoco_options,
            up_axis=up_axis,
            ignore_names=ignore_names,
            ignore_classes=ignore_classes,
            visual_classes=visual_classes,
            collider_classes=collider_classes,
            no_class_as_colliders=no_class_as_colliders,
            force_show_colliders=force_show_colliders,
            enable_self_collisions=enable_self_collisions,
            ignore_inertial_definitions=ignore_inertial_definitions,
            collapse_fixed_joints=collapse_fixed_joints,
            collapse_massless_fixed_root=collapse_massless_fixed_root,
            verbose=verbose,
            skip_equality_constraints=skip_equality_constraints,
            convert_mjc_equality_constraints=convert_mjc_equality_constraints,
            convert_3d_hinge_to_ball_joints=convert_3d_hinge_to_ball_joints,
            mesh_maxhullvert=mesh_maxhullvert,
            ctrl_direct=ctrl_direct,
            path_resolver=path_resolver,
            override_root_xform=override_root_xform,
            legacy_margin_gap=legacy_margin_gap,
        )

    # endregion

    # region World management methods

    def begin_world(
        self,
        label: str | None = None,
        attributes: dict[str, Any] | None = None,
        gravity: Vec3 | None = None,
    ):
        """Begin a new world context for adding entities.

        This method starts a new world scope where all subsequently added entities
        (bodies, shapes, joints, particles, etc.) will be assigned to this world.
        Use :meth:`end_world` to close the world context and return to the global scope.

        **Important:** Worlds cannot be nested. You must call :meth:`end_world` before
        calling :meth:`begin_world` again.

        Args:
            label: Optional unique identifier for this world. If None,
                a default label "world_{index}" will be generated.
            attributes: Optional custom attributes to associate
                with this world for later use.
            gravity: Optional gravity vector [m/s^2] for this world. If None,
                the world uses the builder's default :attr:`gravity`.

        Raises:
            RuntimeError: If called when already inside a world context
                (:attr:`current_world` is not ``-1``).

        Example::

            builder = ModelBuilder()

            # Add global ground plane
            builder.add_ground_plane()  # Added to world -1 (global)

            # Create world 0 with default gravity
            builder.begin_world(label="robot_0")
            builder.add_body(...)  # Added to world 0
            builder.add_shape_box(...)  # Added to world 0
            builder.end_world()

            # Create world 1 with custom zero gravity
            builder.begin_world(label="robot_1", gravity=(0.0, 0.0, 0.0))
            builder.add_body(...)  # Added to world 1
            builder.add_shape_box(...)  # Added to world 1
            builder.end_world()
        """
        if self.current_world != -1:
            raise RuntimeError(
                f"Cannot begin a new world: already in world context (current_world={self.current_world}). "
                "Call end_world() first to close the current world context."
            )

        # Set the current world to the next available world index
        self._current_world = self.world_count
        self.world_count += 1

        # Store world metadata if needed (for future use)
        # Note: We might want to add world_label and world_attributes lists in __init__ if needed
        # For now, we just track the world index

        # Initialize this world's gravity
        if gravity is not None:
            self.world_gravity.append(wp.vec3(*gravity))
        else:
            self.world_gravity.append(self._gravity_as_vector())

    def end_world(self):
        """End the current world context and return to global scope.

        After calling this method, subsequently added entities will be assigned
        to the global world (-1) until :meth:`begin_world` is called again.

        Raises:
            RuntimeError: If called when not in a world context
                (:attr:`current_world` is ``-1``).

        Example::

            builder = ModelBuilder()
            builder.begin_world()
            builder.add_body(...)  # Added to current world
            builder.end_world()  # Return to global scope
            builder.add_ground_plane()  # Added to world -1 (global)
        """
        if self.current_world == -1:
            raise RuntimeError("Cannot end world: not currently in a world context (current_world is already -1).")

        # Reset to global world
        self._current_world = -1

    def add_world(
        self,
        builder: ModelBuilder,
        xform: Transform | None = None,
        label_prefix: str | None = None,
    ):
        """Add a builder as a new world.

        This is a convenience method that combines :meth:`begin_world`,
        :meth:`add_builder`, and :meth:`end_world` into a single call.
        It's the recommended way to add homogeneous worlds (multiple instances
        of the same scene/robot).

        Args:
            builder: The builder containing entities to add as a new world.
            xform: Optional transform to apply to all root bodies
                in the builder. Useful for spacing out worlds visually.
            label_prefix: Optional prefix prepended to all entity labels
                from the source builder. Useful for distinguishing multiple instances
                of the same model (e.g., ``"left_arm"`` vs ``"right_arm"``).

        Raises:
            RuntimeError: If called when already in a world context (via begin_world).

        Example::

            # Create a robot blueprint
            robot = ModelBuilder()
            robot.add_body(...)
            robot.add_shape_box(...)

            # Create main scene with multiple robot instances
            scene = ModelBuilder()
            scene.add_ground_plane()  # Global ground plane

            # Add multiple robot worlds
            for i in range(3):
                scene.add_world(robot)  # Each robot is a separate world
        """
        xform = None if xform is None else wp.transform(*xform)
        self.begin_world()
        try:
            self.add_builder(builder, xform=xform, label_prefix=label_prefix)
        except BaseException:
            # Roll back begin_world() so a failed merge cannot leave a world context open.
            self._current_world = -1
            self.world_count -= 1
            self.world_gravity.pop()
            raise
        self.end_world()

    # endregion

    def _merge_builder_custom_attributes(
        self,
        builder: ModelBuilder,
        entity_offsets: dict[str, int],
        world: int,
        label_prefix: str | None,
    ) -> None:
        # Resolve source rows before ordinary reference remapping copies them.
        # Resolve existing destination rows too, since its topology may have
        # changed since the rows were first added.
        builder._resolve_custom_frequency_articulation_owners()
        self._resolve_custom_frequency_articulation_owners()
        custom_frequency_offsets = dict(self._custom_frequency_counts)

        # Builders allocate MJCF mask-domain IDs independently. Remap every
        # incoming domain as one unit so its IDs cannot collide with domains
        # already present in the destination builder.
        collision_mask_domain_key = "mujoco:collision_mask_domain"
        collision_mask_domain_remap: dict[int, int] = {}
        source_domain_attr = builder.custom_attributes.get(collision_mask_domain_key)
        if source_domain_attr is not None and source_domain_attr.values:
            source_items = (
                source_domain_attr.values.items()
                if isinstance(source_domain_attr.values, dict)
                else enumerate(source_domain_attr.values)
            )
            # Copied shape ranges never overlap, so the first destination shape
            # in each source domain is already a unique, deterministic ID. This
            # avoids rescanning the growing destination during replication.
            shape_offset = entity_offsets["shape"]
            for shape, value in source_items:
                if value is None:
                    continue
                source_domain = int(value)
                if source_domain >= 0:
                    collision_mask_domain_remap.setdefault(source_domain, shape_offset + shape)

        def get_offset(entity_or_key: str | None) -> int:
            if entity_or_key is None:
                return 0
            if entity_or_key in entity_offsets:
                return entity_offsets[entity_or_key]
            if entity_or_key in custom_frequency_offsets:
                return custom_frequency_offsets[entity_or_key]
            if entity_or_key in builder._custom_frequency_counts:
                return 0
            raise ValueError(
                f"Unknown references value '{entity_or_key}'. "
                f"Valid values are: {list(entity_offsets.keys())} or custom frequencies."
            )

        for full_key, attr in builder.custom_attributes.items():
            if not attr.values:
                if full_key not in self.custom_attributes:
                    freq_key = attr.frequency
                    mapped_values = [] if isinstance(freq_key, str) else {}
                    self.custom_attributes[full_key] = replace(attr, values=mapped_values)
                    self._custom_schema_epoch += 1
                continue

            freq_key = attr.frequency
            if isinstance(freq_key, str):
                index_offset = custom_frequency_offsets.get(freq_key, 0)
            elif attr.frequency == Model.AttributeFrequency.ONCE:
                index_offset = 0
            elif attr.frequency == Model.AttributeFrequency.WORLD:
                index_offset = 0 if world == -1 else world
            else:
                index_offset = get_offset(attr.frequency.name.lower())

            use_current_world = attr.references == "world"
            value_offset = 0 if use_current_world else get_offset(attr.references)
            is_equality_target_attr = full_key == "mujoco:equality_constraint_target"
            is_collision_mask_domain_attr = full_key == collision_mask_domain_key and bool(collision_mask_domain_remap)
            needs_remap = (
                value_offset != 0 or use_current_world or is_equality_target_attr or is_collision_mask_domain_attr
            )

            if needs_remap:

                def transform_equality_target_value(entity_idx: int, value: Any) -> Any:
                    try:
                        target = int(value)
                    except (TypeError, ValueError):
                        return value
                    if target < 0:
                        return value

                    target_kind_attr = builder.custom_attributes.get("mujoco:equality_constraint_target_kind")
                    target_kind = 0
                    if (
                        target_kind_attr is not None
                        and target_kind_attr.values
                        and entity_idx < len(target_kind_attr.values)
                        and target_kind_attr.values[entity_idx] is not None
                    ):
                        try:
                            target_kind = int(target_kind_attr.values[entity_idx])
                        except (TypeError, ValueError):
                            target_kind = 0

                    if target_kind == 1:
                        return target + entity_offsets["joint"]
                    if target_kind == 2:
                        return target + entity_offsets["constraint_mimic"]
                    return value

                def transform_value(
                    value: Any,
                    offset: int = value_offset,
                    replace_with_world: bool = use_current_world,
                ) -> Any:
                    if replace_with_world:
                        return world
                    if offset == 0:
                        return value
                    if self._is_integer_scalar(value):
                        return value + offset if value >= 0 else value
                    if isinstance(value, (list, tuple)):
                        transformed = [
                            item + offset if self._is_integer_scalar(item) and item >= 0 else item for item in value
                        ]
                        return type(value)(transformed)
                    try:
                        return value + offset
                    except TypeError:
                        return value

                def transform_enum_value(
                    entity_idx: int,
                    value: Any,
                    is_equality_target: bool = is_equality_target_attr,
                    is_collision_mask_domain: bool = is_collision_mask_domain_attr,
                ) -> Any:
                    if is_equality_target:
                        return transform_equality_target_value(entity_idx, value)
                    if is_collision_mask_domain:
                        return collision_mask_domain_remap.get(int(value), value)
                    return transform_value(value)

            merged = self.custom_attributes.get(full_key)
            if merged is None:
                if isinstance(freq_key, str):
                    mapped_values = [None] * index_offset
                    if needs_remap:
                        mapped_values.extend(transform_enum_value(idx, value) for idx, value in enumerate(attr.values))
                    else:
                        mapped_values.extend(attr.values)
                elif needs_remap:
                    mapped_values = {
                        index_offset + idx: transform_enum_value(idx, value) for idx, value in attr.values.items()
                    }
                else:
                    mapped_values = {index_offset + idx: value for idx, value in attr.values.items()}
                self.custom_attributes[full_key] = replace(attr, values=mapped_values)
                self._custom_schema_epoch += 1
                continue

            if not self._custom_attribute_defaults_match(merged.default, attr.default):
                raise ValueError(
                    f"Custom attribute '{full_key}' default mismatch when merging builders: "
                    f"existing={merged.default}, incoming={attr.default}"
                )

            if merged.values is None:
                merged.values = [] if isinstance(freq_key, str) else {}

            if isinstance(freq_key, str):
                if len(merged.values) < index_offset:
                    merged.values.extend([None] * (index_offset - len(merged.values)))
                if needs_remap:
                    merged.values.extend(transform_enum_value(idx, value) for idx, value in enumerate(attr.values))
                else:
                    merged.values.extend(attr.values)
            elif needs_remap:
                merged.values.update(
                    {index_offset + idx: transform_enum_value(idx, value) for idx, value in attr.values.items()}
                )
            else:
                merged.values.update({index_offset + idx: value for idx, value in attr.values.items()})

        if label_prefix:
            for frequency_key, frequency in builder.custom_frequencies.items():
                label_key = frequency.label_attribute
                if label_key is None:
                    continue
                source_label_attribute = builder.custom_attributes.get(label_key)
                if source_label_attribute is None or source_label_attribute.frequency != frequency_key:
                    continue
                label_attribute = self.custom_attributes.get(label_key)
                if (
                    label_attribute is None
                    or not isinstance(label_attribute.values, list)
                    or not label_attribute.values
                ):
                    continue
                start = custom_frequency_offsets.get(frequency_key, 0)
                count = builder._custom_frequency_counts.get(frequency_key, 0)
                for row in range(start, min(start + count, len(label_attribute.values))):
                    label = label_attribute.values[row]
                    if label:
                        label_attribute.values[row] = f"{label_prefix}/{label}"

            if builder._equality_constraint_count > 0:
                label_attr = self.custom_attributes.get("mujoco:equality_constraint_label")
                if label_attr is not None and label_attr.values:
                    start = self._equality_constraint_count
                    for i in range(start, start + builder._equality_constraint_count):
                        if i < len(label_attr.values):
                            label = label_attr.values[i]
                            if label:
                                label_attr.values[i] = f"{label_prefix}/{label}"

        for freq_key, freq_obj in builder.custom_frequencies.items():
            if freq_key not in self.custom_frequencies:
                self.custom_frequencies[freq_key] = freq_obj
                self._custom_schema_epoch += 1

        for freq_key, builder_count in builder._custom_frequency_counts.items():
            offset = custom_frequency_offsets.get(freq_key, 0)
            self._custom_frequency_counts[freq_key] = offset + builder_count
            frequency = builder.custom_frequencies.get(freq_key)
            if frequency is not None and frequency.articulation_owner_resolver is not None:
                # Source owner values were resolved above and remapped as regular
                # articulation references, so the merged rows are already current.
                self._custom_frequency_owner_resolved_counts[freq_key] = offset + builder_count

        for key, finalizer in builder._custom_attribute_model_finalizers.items():
            self._add_custom_attribute_model_finalizer(key, finalizer)

    def _merge_builder_actuators(
        self,
        builder: ModelBuilder,
        joint_dof_offset: int,
        joint_coord_offset: int,
    ) -> None:
        for entry_key, sub_entry in builder.actuator_entries.items():
            entry = self.actuator_entries.setdefault(
                entry_key,
                ModelBuilder.ActuatorEntry(
                    drive_class=sub_entry.drive_class,
                    clamping_classes=sub_entry.clamping_classes,
                    clamping_shared_kwargs=sub_entry.clamping_shared_kwargs,
                    drive_shared_kwargs=sub_entry.drive_shared_kwargs,
                    indices=[],
                    pos_indices=[],
                    drive_args=[],
                    delay_args=[],
                    clamping_args=[],
                ),
            )
            entry.indices.extend(idx + joint_dof_offset for idx in sub_entry.indices)
            entry.pos_indices.extend(idx + joint_coord_offset for idx in sub_entry.pos_indices)
            entry.drive_args.extend(sub_entry.drive_args)
            entry.delay_args.extend(sub_entry.delay_args)
            entry.clamping_args.extend(sub_entry.clamping_args)

    def add_builder(
        self,
        builder: ModelBuilder,
        xform: Transform | None = None,
        label_prefix: str | None = None,
    ):
        """Copies the data from another `ModelBuilder` into this `ModelBuilder`.

        All entities from the source builder are added to this builder's current world context
        (the value of :attr:`current_world`). Any world assignments that existed in the source
        builder are overwritten - all entities will be assigned to the active world context.

        Use :meth:`begin_world`, :meth:`end_world`, :meth:`add_world`, or
        :meth:`replicate` to manage world assignment. :attr:`current_world`
        is read-only and should not be set directly.

        The source builder acts as a template: merged entries may share objects
        with it (and across copies when replicating). Mutating such entries in
        place afterwards (e.g. ``xform.p = ...``) writes through to every
        builder sharing them and is unsupported; reassign entries instead
        (``shape_transform[i] = xform``).

        Example::

            main_builder = ModelBuilder()
            sub_builder = ModelBuilder()
            sub_builder.add_body(...)
            sub_builder.add_shape_box(...)

            # Adds all entities from sub_builder to main_builder's active
            # world context (-1 by default)
            main_builder.add_builder(sub_builder)

            # With transform and label prefix
            main_builder.add_builder(sub_builder, xform=wp.transform((1, 0, 0)), label_prefix="left")

        Args:
            builder: The model builder to copy data from.
            xform: Optional offset transform applied to root bodies.
            label_prefix: Optional prefix prepended to all entity labels
                from the source builder. Labels are joined with ``/``
                (e.g., ``"left/panda/base_link"``).
        """

        self._merge_builder_copies(builder, [self.current_world], [xform], [label_prefix])

        if self.current_world >= 0 and self.current_world < len(self.world_gravity):
            # We're in a world context, update this world's gravity vector
            self.world_gravity[self.current_world] = builder._gravity_as_vector()
        elif self.current_world < 0:
            # No world context (add_builder called directly), copy default gravity
            self._gravity = copy.copy(builder._gravity)

    @staticmethod
    def _coerce_mat33(value: Any) -> wp.mat33:
        """Coerce a mat33-like value into a wp.mat33 without triggering Warp row-vector constructor warnings."""
        if wp.types.type_is_matrix(type(value)):
            return value

        if isinstance(value, (list, tuple)) and len(value) == 3:
            rows = []
            is_rows = True
            for r in value:
                if wp.types.type_is_vector(type(r)):
                    rows.append(wp.vec3(*r))
                elif isinstance(r, (list, tuple, np.ndarray)) and len(r) == 3:
                    rows.append(wp.vec3(*r))
                else:
                    is_rows = False
                    break
            if is_rows:
                return wp.matrix_from_rows(*rows)

        if isinstance(value, np.ndarray) and value.shape == (3, 3):
            return wp.mat33(*value.reshape(-1).tolist())

        return wp.mat33(*value)

    def add_link(
        self,
        *,
        xform: Transform | None = None,
        com: Vec3 | None = None,
        inertia: Mat33 | None = None,
        mass: float = 0.0,
        label: str | None = None,
        lock_inertia: bool = False,
        is_kinematic: bool = False,
        custom_attributes: dict[str, Any] | None = None,
    ) -> int:
        """Adds a link (rigid body) to the model within an articulation.

        This method creates a link without automatically adding a joint. To connect this link
        to the articulation structure, you must explicitly call one of the joint methods
        (e.g., :meth:`add_joint_revolute`, :meth:`add_joint_fixed`, etc.) after creating the link.

        After calling this method and one of the joint methods, ensure that an articulation is created using :meth:`add_articulation`.

        Args:
            xform: The location of the body in the world frame.
            com: The center of mass of the body w.r.t its origin. If None, the center of mass is assumed to be at the origin.
            inertia: The 3x3 inertia tensor of the body (specified relative to the center of mass). If None, the inertia tensor is assumed to be zero.
            mass: Mass of the body.
            label: Label of the body (optional).
            lock_inertia: If True, prevents subsequent shape additions from modifying this body's mass,
                center of mass, or inertia. This does not affect merging behavior in
                :meth:`collapse_fixed_joints`, which always accumulates mass and inertia across merged bodies.
            is_kinematic: If True, the body is kinematic and does not respond to forces.
                Only root bodies (bodies whose joint parent is ``-1``) may be kinematic.
            custom_attributes: Dictionary of custom attribute names to values.

        Returns:
            The index of the body in the model.

        """
        if xform is None:
            xform = wp.transform()
        else:
            xform = wp.transform(*xform)
        if com is None:
            com = wp.vec3()
        else:
            com = axis_to_vec3(com)
        if inertia is None:
            inertia = wp.mat33()
        else:
            inertia = self._coerce_mat33(inertia)

        body_id = len(self.body_mass)

        # body data
        self.body_inertia.append(inertia)
        self.body_mass.append(mass)
        self.body_com.append(com)
        self.body_lock_inertia.append(lock_inertia)
        self.body_flags.append(int(BodyFlags.KINEMATIC) if is_kinematic else int(BodyFlags.DYNAMIC))

        if mass > 0.0:
            self.body_inv_mass.append(1.0 / mass)
        else:
            self.body_inv_mass.append(0.0)

        if any(x for x in inertia):
            self.body_inv_inertia.append(wp.inverse(inertia))
        else:
            self.body_inv_inertia.append(inertia)

        self.body_q.append(xform)
        self.body_qd.append(wp.spatial_vector())

        self.body_label.append(label or f"body_{body_id}")
        self.body_shapes[body_id] = []
        self.body_world.append(self.current_world)
        # Process custom attributes
        if custom_attributes:
            self._process_custom_attributes(
                entity_index=body_id,
                custom_attrs=custom_attributes,
                expected_frequency=Model.AttributeFrequency.BODY,
            )

        return body_id

    def add_body(
        self,
        *,
        xform: Transform | None = None,
        com: Vec3 | None = None,
        inertia: Mat33 | None = None,
        mass: float = 0.0,
        label: str | None = None,
        lock_inertia: bool = False,
        is_kinematic: bool = False,
        custom_attributes: dict[str, Any] | None = None,
    ) -> int:
        """Adds a stand-alone free-floating rigid body to the model.

        This is a convenience method that creates a single-body articulation with a free joint,
        allowing the body to move freely in 6 degrees of freedom. This is equivalent to calling:

        1. :meth:`add_link` to create the body
        2. :meth:`add_joint_free` to add a free joint connecting the body to the world
        3. :meth:`add_articulation` to create a new articulation from the joint

        For creating articulations with multiple linked bodies, use :meth:`add_link`,
        the appropriate joint methods, and :meth:`add_articulation` directly.

        Args:
            xform: The location of the body in the world frame.
            com: The center of mass of the body w.r.t its origin. If None, the center of mass is assumed to be at the origin.
            inertia: The 3x3 inertia tensor of the body (specified relative to the center of mass). If None, the inertia tensor is assumed to be zero.
            mass: Mass of the body.
            label: Label of the body. When provided, the auto-created free joint and articulation
                are assigned labels ``{label}_free_joint`` and ``{label}_articulation`` respectively.
            lock_inertia: If True, prevents subsequent shape additions from modifying this body's mass,
                center of mass, or inertia. This does not affect merging behavior in
                :meth:`collapse_fixed_joints`, which always accumulates mass and inertia across merged bodies.
            is_kinematic: If True, the body is kinematic and does not respond to forces.
            custom_attributes: Dictionary of custom attribute names to values.

        Returns:
            The index of the body in the model.

        """
        body_id = self.add_link(
            xform=xform,
            com=com,
            inertia=inertia,
            mass=mass,
            label=label,
            lock_inertia=lock_inertia,
            is_kinematic=is_kinematic,
            custom_attributes=custom_attributes,
        )

        # Add a free joint to make it float
        joint_id = self.add_joint_free(
            child=body_id,
            label=f"{label}_free_joint" if label else None,
        )

        # Create an articulation from the joint
        articulation_label = f"{label}_articulation" if label else None
        self.add_articulation([joint_id], label=articulation_label)

        return body_id

    # region joints

    def add_joint(
        self,
        joint_type: JointType,
        parent: int,
        child: int,
        *,
        linear_axes: list[JointDofConfig] | None = None,
        angular_axes: list[JointDofConfig] | None = None,
        label: str | None = None,
        parent_xform: Transform | None = None,
        child_xform: Transform | None = None,
        collision_filter_parent: bool | None = None,
        enabled: bool = True,
        custom_attributes: dict[str, Any] | None = None,
    ) -> int:
        """
        Generic method to add any type of joint to this ModelBuilder.

        Args:
            joint_type: The type of joint to add (see :ref:`Joint types`).
            parent: The index of the parent body (-1 is the world).
            child: The index of the child body.
            linear_axes: The linear axes (see :class:`JointDofConfig`) of the joint,
                defined in the joint parent anchor frame.
            angular_axes: The angular axes (see :class:`JointDofConfig`) of the joint,
                defined in the joint parent anchor frame.
            label: The label of the joint (optional).
            parent_xform: The transform from the parent body frame to the joint parent anchor frame.
                If None, the identity transform is used.
            child_xform: The transform from the child body frame to the joint child anchor frame.
                If None, the identity transform is used.
            collision_filter_parent: Whether to filter collisions between shapes of the parent and child bodies. Defaults to ``False`` for non-fixed joints to world, ``True`` otherwise.
            enabled: Whether the joint is enabled (not considered by :class:`SolverFeatherstone`).
            custom_attributes: Dictionary of custom attribute keys (see :attr:`CustomAttribute.key`) to values. Note that custom attributes with frequency :attr:`Model.AttributeFrequency.JOINT_DOF` or :attr:`Model.AttributeFrequency.JOINT_COORD` can be provided as: (1) lists with length equal to the joint's DOF or coordinate count, (2) dicts mapping DOF/coordinate indices to values, or (3) a single scalar value that is broadcast to all DOFs/coordinates of the joint. For joints with zero DOFs (e.g., fixed joints), JOINT_DOF attributes are silently skipped. Custom attributes with frequency :attr:`Model.AttributeFrequency.JOINT` require a single value to be defined.

        Returns:
            The index of the added joint.

        .. note::
            Avoid creating several joints between the same pair of bodies, as this is ambiguous and may be handled
            differently by different solvers. Bodies created with :meth:`add_body` are implicitly connected to the
            world by a free joint. To connect a body to the world with a different joint type, use :meth:`add_link`
            instead.
        """
        if linear_axes is None:
            linear_axes = []
        if angular_axes is None:
            angular_axes = []

        if collision_filter_parent is None:
            collision_filter_parent = self._default_filter_parent(joint_type, parent)

        if parent_xform is None:
            parent_xform = wp.transform()
        else:
            parent_xform = wp.transform(*parent_xform)
        if child_xform is None:
            child_xform = wp.transform()
        else:
            child_xform = wp.transform(*child_xform)

        # Validate that parent and child bodies belong to the current world
        if parent != -1:  # -1 means world/ground
            if parent < 0 or parent >= len(self.body_world):
                raise ValueError(f"Parent body index {parent} is out of range")
            if self.body_world[parent] != self.current_world:
                raise ValueError(
                    f"Cannot create joint: parent body {parent} belongs to world {self.body_world[parent]}, "
                    f"but current world is {self.current_world}"
                )

        if child < 0 or child >= len(self.body_world):
            raise ValueError(f"Child body index {child} is out of range")
        if self.body_world[child] != self.current_world:
            raise ValueError(
                f"Cannot create joint: child body {child} belongs to world {self.body_world[child]}, "
                f"but current world is {self.current_world}"
            )

        has_parallel_joint = False
        parallel_free = False
        for existing_body, existing_joint_idx in (
            *self.joint_parents.get(child, ()),
            *self.joint_children.get(child, ()),
        ):
            if existing_body == parent:
                has_parallel_joint = True
                parallel_free = joint_type == JointType.FREE or self.joint_type[existing_joint_idx] == JointType.FREE
                if parallel_free:
                    break

        if has_parallel_joint:
            if parallel_free:
                warnings.warn(
                    f"Adding a {joint_type.name} joint between parent {parent} and "
                    f"child {child} (label: {self.body_label[child]!r}), but another joint already connects these "
                    f"bodies. A FREE joint parallel to another joint is inconsistent. Use add_link() "
                    f"with the appropriate joint type instead of add_body().",
                    UserWarning,
                    stacklevel=self._external_warning_stacklevel(),
                )
            else:
                warnings.warn(
                    f"Adding a {joint_type.name} joint between parent {parent} and "
                    f"child {child} (label: {self.body_label[child]!r}), but another joint already connects these "
                    f"bodies. Parallel joints between the same pair of bodies have undefined semantics and may not "
                    f"behave as expected.",
                    UserWarning,
                    stacklevel=self._external_warning_stacklevel(),
                )

        self.joint_type.append(joint_type)
        joint_idx = self.joint_count - 1
        self.joint_parent.append(parent)
        if child not in self.joint_parents:
            self.joint_parents[child] = [(parent, joint_idx)]
        else:
            self.joint_parents[child].append((parent, joint_idx))
        if parent not in self.joint_children:
            self.joint_children[parent] = [(child, joint_idx)]
        else:
            self.joint_children[parent].append((child, joint_idx))
        self.joint_child.append(child)
        self.joint_X_p.append(parent_xform)
        self.joint_X_c.append(child_xform)
        self.joint_label.append(label or f"joint_{self.joint_count}")
        self.joint_dof_dim.append((len(linear_axes), len(angular_axes)))
        self.joint_enabled.append(enabled)
        self.joint_collision_filter_parent.append(collision_filter_parent)
        self.joint_world.append(self.current_world)
        self.joint_articulation.append(-1)

        def add_axis_dim(dim: ModelBuilder.JointDofConfig):
            self.joint_axis.append(dim.axis)
            self.joint_target_qd.append(dim.target_vel)

            # Use actuator_mode if explicitly set, otherwise infer from gains
            if dim.actuator_mode is not None:
                mode = int(dim.actuator_mode)
            else:
                # Infer has_drive from whether gains are non-zero: non-zero gains imply a drive exists.
                # This ensures freejoints (gains=0) get NONE, while joints with gains get appropriate mode.
                has_drive = dim.target_ke != 0.0 or dim.target_kd != 0.0
                mode = int(JointTargetMode.from_gains(dim.target_ke, dim.target_kd, has_drive=has_drive))

            # Store per-DOF actuator properties
            self.joint_target_mode.append(mode)
            self.joint_target_ke.append(dim.target_ke)
            self.joint_target_kd.append(dim.target_kd)
            self.joint_damping.append(dim.damping)
            self.joint_limit_ke.append(dim.limit_ke)
            self.joint_limit_kd.append(dim.limit_kd)
            self.joint_armature.append(dim.armature)
            self.joint_effort_limit.append(dim.effort_limit)
            self.joint_velocity_limit.append(dim.velocity_limit)
            self.joint_friction.append(dim.friction)
            if np.isfinite(dim.limit_lower):
                self.joint_limit_lower.append(dim.limit_lower)
            else:
                self.joint_limit_lower.append(-MAXVAL)
            if np.isfinite(dim.limit_upper):
                self.joint_limit_upper.append(dim.limit_upper)
            else:
                self.joint_limit_upper.append(MAXVAL)

        for dim in linear_axes:
            add_axis_dim(dim)
        for dim in angular_axes:
            add_axis_dim(dim)

        dof_count, coord_count = joint_type.dof_count(len(linear_axes) + len(angular_axes))
        cts_count = joint_type.constraint_count(len(linear_axes) + len(angular_axes))

        for _ in range(coord_count):
            self.joint_q.append(0.0)
        target_q_offset = len(self.joint_target_q)
        for _ in range(coord_count):
            self.joint_target_q.append(0.0)
        for _ in range(dof_count):
            self.joint_qd.append(0.0)
            self.joint_f.append(0.0)
            self.joint_act.append(0.0)
        for _ in range(cts_count):
            self.joint_cts.append(0.0)

        if joint_type == JointType.FREE or joint_type == JointType.DISTANCE or joint_type == JointType.BALL:
            # ensure that a valid quaternion is used for the angular dofs
            self.joint_q[-1] = 1.0

        if joint_type == JointType.BALL or joint_type == JointType.FREE or joint_type == JointType.DISTANCE:
            if joint_type == JointType.BALL:
                quat_offset = target_q_offset
            else:
                for i, dim in enumerate(linear_axes):
                    self.joint_target_q[target_q_offset + i] = dim.target_pos
                quat_offset = target_q_offset + 3

            import newton  # noqa: PLC0415

            if newton.use_coord_layout_targets:
                qx, qy, qz, qw = self._quat_from_axis_targets(
                    angular_axes[0].target_pos,
                    angular_axes[1].target_pos,
                    angular_axes[2].target_pos,
                )
                self.joint_target_q[quat_offset + 0] = qx
                self.joint_target_q[quat_offset + 1] = qy
                self.joint_target_q[quat_offset + 2] = qz
                self.joint_target_q[quat_offset + 3] = qw
            else:
                for i, dim in enumerate(angular_axes):
                    self.joint_target_q[quat_offset + i] = dim.target_pos
                self.joint_target_q[quat_offset + 3] = 1.0
        elif joint_type != JointType.FIXED:
            for i, dim in enumerate(linear_axes):
                self.joint_target_q[target_q_offset + i] = dim.target_pos
            for i, dim in enumerate(angular_axes):
                self.joint_target_q[target_q_offset + len(linear_axes) + i] = dim.target_pos

        self.joint_q_start.append(self.joint_coord_count)
        self.joint_qd_start.append(self.joint_dof_count)
        self.joint_cts_start.append(self.joint_constraint_count)

        self.joint_dof_count += dof_count
        self.joint_coord_count += coord_count
        self.joint_constraint_count += cts_count

        if collision_filter_parent:
            for child_shape in self.body_shapes[child]:
                if not self.shape_flags[child_shape] & ShapeFlags.COLLIDE_SHAPES:
                    continue
                for parent_shape in self.body_shapes[parent]:
                    if not self.shape_flags[parent_shape] & ShapeFlags.COLLIDE_SHAPES:
                        continue
                    self.add_shape_collision_filter_pair(parent_shape, child_shape)

        joint_index = self.joint_count - 1

        # Process custom attributes
        if custom_attributes:
            self._process_joint_custom_attributes(
                joint_index=joint_index,
                custom_attrs=custom_attributes,
            )

        return joint_index

    def add_joint_revolute(
        self,
        parent: int,
        child: int,
        *,
        parent_xform: Transform | None = None,
        child_xform: Transform | None = None,
        axis: AxisType | Vec3 | JointDofConfig | None = None,
        target_pos: float | None = None,
        target_vel: float | None = None,
        target_ke: float | None = None,
        target_kd: float | None = None,
        damping: float | None = None,
        limit_lower: float | None = None,
        limit_upper: float | None = None,
        limit_ke: float | None = None,
        limit_kd: float | None = None,
        armature: float | None = None,
        effort_limit: float | None = None,
        velocity_limit: float | None = None,
        friction: float | None = None,
        actuator_mode: JointTargetMode | None = None,
        label: str | None = None,
        collision_filter_parent: bool | None = None,
        enabled: bool = True,
        custom_attributes: dict[str, Any] | None = None,
        **kwargs,
    ) -> int:
        """Adds a revolute (hinge) joint to the model. It has one degree of freedom.

        Args:
            parent: The index of the parent body.
            child: The index of the child body.
            parent_xform: The transform from the parent body frame to the joint parent anchor frame.
            child_xform: The transform from the child body frame to the joint child anchor frame.
            axis: The axis of rotation in the joint parent anchor frame, which is
                the parent body's local frame transformed by `parent_xform`. It can be a :class:`JointDofConfig` object
                whose settings will be used instead of the other arguments.
            target_pos: The target position of the joint.
            target_vel: The target velocity of the joint.
            target_ke: The stiffness of the joint target.
            target_kd: The damping of the joint target.
            damping: Passive velocity damping [N·s/m or N·m·s/rad, depending on joint type] always active on the joint. If None, the default value from ``ModelBuilder.default_joint_cfg.damping`` is used.
            limit_lower: The lower limit of the joint. If None, the default value from ``ModelBuilder.default_joint_cfg.limit_lower`` is used.
            limit_upper: The upper limit of the joint. If None, the default value from ``ModelBuilder.default_joint_cfg.limit_upper`` is used.
            limit_ke: The stiffness of the joint limit. If None, the default value from ``ModelBuilder.default_joint_cfg.limit_ke`` is used.
            limit_kd: The damping of the joint limit. If None, the default value from ``ModelBuilder.default_joint_cfg.limit_kd`` is used.
            armature: Artificial inertia added around the joint axis. If None, the default value from ``ModelBuilder.default_joint_cfg.armature`` is used.
            effort_limit: Maximum effort (force/torque) the joint axis can exert. If None, the default value from ``ModelBuilder.default_joint_cfg.effort_limit`` is used.
            velocity_limit: Maximum velocity the joint axis can achieve. If None, the default value from ``ModelBuilder.default_joint_cfg.velocity_limit`` is used.
            friction: Friction coefficient for the joint axis. If None, the default value from ``ModelBuilder.default_joint_cfg.friction`` is used.
            label: The label of the joint.
            collision_filter_parent: Whether to filter collisions between shapes of the parent and child bodies. Defaults to ``False`` for joints to world, ``True`` otherwise.
            enabled: Whether the joint is enabled.
            custom_attributes: Dictionary of custom attribute values for JOINT, JOINT_DOF, or JOINT_COORD frequency attributes.

        Returns:
            The index of the added joint.

        """

        if axis is None:
            axis = self.default_joint_cfg.axis
        if isinstance(axis, ModelBuilder.JointDofConfig):
            ax = axis
        else:
            ax = ModelBuilder.JointDofConfig(
                axis=axis,
                limit_lower=limit_lower if limit_lower is not None else self.default_joint_cfg.limit_lower,
                limit_upper=limit_upper if limit_upper is not None else self.default_joint_cfg.limit_upper,
                target_pos=target_pos if target_pos is not None else self.default_joint_cfg.target_pos,
                target_vel=target_vel if target_vel is not None else self.default_joint_cfg.target_vel,
                target_ke=target_ke if target_ke is not None else self.default_joint_cfg.target_ke,
                target_kd=target_kd if target_kd is not None else self.default_joint_cfg.target_kd,
                damping=damping if damping is not None else self.default_joint_cfg.damping,
                limit_ke=limit_ke if limit_ke is not None else self.default_joint_cfg.limit_ke,
                limit_kd=limit_kd if limit_kd is not None else self.default_joint_cfg.limit_kd,
                armature=armature if armature is not None else self.default_joint_cfg.armature,
                effort_limit=effort_limit if effort_limit is not None else self.default_joint_cfg.effort_limit,
                velocity_limit=velocity_limit if velocity_limit is not None else self.default_joint_cfg.velocity_limit,
                friction=friction if friction is not None else self.default_joint_cfg.friction,
                actuator_mode=actuator_mode if actuator_mode is not None else self.default_joint_cfg.actuator_mode,
            )
        return self.add_joint(
            JointType.REVOLUTE,
            parent,
            child,
            parent_xform=parent_xform,
            child_xform=child_xform,
            angular_axes=[ax],
            label=label,
            collision_filter_parent=collision_filter_parent,
            enabled=enabled,
            custom_attributes=custom_attributes,
            **kwargs,
        )

    def add_joint_prismatic(
        self,
        parent: int,
        child: int,
        *,
        parent_xform: Transform | None = None,
        child_xform: Transform | None = None,
        axis: AxisType | Vec3 | JointDofConfig = Axis.X,
        target_pos: float | None = None,
        target_vel: float | None = None,
        target_ke: float | None = None,
        target_kd: float | None = None,
        damping: float | None = None,
        limit_lower: float | None = None,
        limit_upper: float | None = None,
        limit_ke: float | None = None,
        limit_kd: float | None = None,
        armature: float | None = None,
        effort_limit: float | None = None,
        velocity_limit: float | None = None,
        friction: float | None = None,
        actuator_mode: JointTargetMode | None = None,
        label: str | None = None,
        collision_filter_parent: bool | None = None,
        enabled: bool = True,
        custom_attributes: dict[str, Any] | None = None,
    ) -> int:
        """Adds a prismatic (sliding) joint to the model. It has one degree of freedom.

        Args:
            parent: The index of the parent body.
            child: The index of the child body.
            parent_xform: The transform from the parent body frame to the joint parent anchor frame.
            child_xform: The transform from the child body frame to the joint child anchor frame.
            axis: The axis of translation in the joint parent anchor frame, which is
                the parent body's local frame transformed by `parent_xform`. It can be a :class:`JointDofConfig` object
                whose settings will be used instead of the other arguments.
            target_pos: The target position of the joint.
            target_vel: The target velocity of the joint.
            target_ke: The stiffness of the joint target.
            target_kd: The damping of the joint target.
            damping: Passive velocity damping [N·s/m or N·m·s/rad, depending on joint type] always active on the joint. If None, the default value from ``ModelBuilder.default_joint_cfg.damping`` is used.
            limit_lower: The lower limit of the joint. If None, the default value from ``ModelBuilder.default_joint_cfg.limit_lower`` is used.
            limit_upper: The upper limit of the joint. If None, the default value from ``ModelBuilder.default_joint_cfg.limit_upper`` is used.
            limit_ke: The stiffness of the joint limit. If None, the default value from ``ModelBuilder.default_joint_cfg.limit_ke`` is used.
            limit_kd: The damping of the joint limit. If None, the default value from ``ModelBuilder.default_joint_cfg.limit_kd`` is used.
            armature: Artificial inertia added around the joint axis. If None, the default value from ``ModelBuilder.default_joint_cfg.armature`` is used.
            effort_limit: Maximum effort (force) the joint axis can exert. If None, the default value from ``ModelBuilder.default_joint_cfg.effort_limit`` is used.
            velocity_limit: Maximum velocity the joint axis can achieve. If None, the default value from ``ModelBuilder.default_joint_cfg.velocity_limit`` is used.
            friction: Friction coefficient for the joint axis. If None, the default value from ``ModelBuilder.default_joint_cfg.friction`` is used.
            label: The label of the joint.
            collision_filter_parent: Whether to filter collisions between shapes of the parent and child bodies. Defaults to ``False`` for joints to world, ``True`` otherwise.
            enabled: Whether the joint is enabled.
            custom_attributes: Dictionary of custom attribute values for JOINT, JOINT_DOF, or JOINT_COORD frequency attributes.

        Returns:
            The index of the added joint.

        """

        if axis is None:
            axis = self.default_joint_cfg.axis
        if isinstance(axis, ModelBuilder.JointDofConfig):
            ax = axis
        else:
            ax = ModelBuilder.JointDofConfig(
                axis=axis,
                limit_lower=limit_lower if limit_lower is not None else self.default_joint_cfg.limit_lower,
                limit_upper=limit_upper if limit_upper is not None else self.default_joint_cfg.limit_upper,
                target_pos=target_pos if target_pos is not None else self.default_joint_cfg.target_pos,
                target_vel=target_vel if target_vel is not None else self.default_joint_cfg.target_vel,
                target_ke=target_ke if target_ke is not None else self.default_joint_cfg.target_ke,
                target_kd=target_kd if target_kd is not None else self.default_joint_cfg.target_kd,
                damping=damping if damping is not None else self.default_joint_cfg.damping,
                limit_ke=limit_ke if limit_ke is not None else self.default_joint_cfg.limit_ke,
                limit_kd=limit_kd if limit_kd is not None else self.default_joint_cfg.limit_kd,
                armature=armature if armature is not None else self.default_joint_cfg.armature,
                effort_limit=effort_limit if effort_limit is not None else self.default_joint_cfg.effort_limit,
                velocity_limit=velocity_limit if velocity_limit is not None else self.default_joint_cfg.velocity_limit,
                friction=friction if friction is not None else self.default_joint_cfg.friction,
                actuator_mode=actuator_mode if actuator_mode is not None else self.default_joint_cfg.actuator_mode,
            )
        return self.add_joint(
            JointType.PRISMATIC,
            parent,
            child,
            parent_xform=parent_xform,
            child_xform=child_xform,
            linear_axes=[ax],
            label=label,
            collision_filter_parent=collision_filter_parent,
            enabled=enabled,
            custom_attributes=custom_attributes,
        )

    def add_joint_ball(
        self,
        parent: int,
        child: int,
        *,
        parent_xform: Transform | None = None,
        child_xform: Transform | None = None,
        armature: float | None = None,
        friction: float | None = None,
        damping: float | None = None,
        label: str | None = None,
        collision_filter_parent: bool | None = None,
        enabled: bool = True,
        custom_attributes: dict[str, Any] | None = None,
        actuator_mode: JointTargetMode | None = None,
    ) -> int:
        """Adds a ball (spherical) joint to the model. Its position is defined by a 4D quaternion (xyzw) and its velocity is a 3D vector.

        Args:
            parent: The index of the parent body.
            child: The index of the child body.
            parent_xform: The transform from the parent body frame to the joint parent anchor frame.
            child_xform: The transform from the child body frame to the joint child anchor frame.
            armature: Artificial inertia added around the joint axes. If None, the default value from ``ModelBuilder.default_joint_cfg.armature`` is used.
            friction: Friction coefficient for the joint axes. If None, the default value from ``ModelBuilder.default_joint_cfg.friction`` is used.
            damping: Passive angular velocity damping [N·s/m or N·m·s/rad, depending on joint type] always active on all three BALL joint angular DOFs. If None, the default value from ``ModelBuilder.default_joint_cfg.damping`` is used.
            label: The label of the joint.
            collision_filter_parent: Whether to filter collisions between shapes of the parent and child bodies. Defaults to ``False`` for joints to world, ``True`` otherwise.
            enabled: Whether the joint is enabled.
            custom_attributes: Dictionary of custom attribute values for JOINT, JOINT_DOF, or JOINT_COORD frequency attributes.
            actuator_mode: The actuator mode for this joint's DOFs. If None, defaults to NONE.

        Returns:
            The index of the added joint.

        .. note:: Target position and velocity control for ball joints is currently only supported in :class:`newton.solvers.SolverMuJoCo`.

        """

        if armature is None:
            armature = self.default_joint_cfg.armature
        if friction is None:
            friction = self.default_joint_cfg.friction
        if damping is None:
            damping = self.default_joint_cfg.damping

        x = ModelBuilder.JointDofConfig(
            axis=Axis.X,
            armature=armature,
            friction=friction,
            damping=damping,
            actuator_mode=actuator_mode,
        )
        y = ModelBuilder.JointDofConfig(
            axis=Axis.Y,
            armature=armature,
            friction=friction,
            damping=damping,
            actuator_mode=actuator_mode,
        )
        z = ModelBuilder.JointDofConfig(
            axis=Axis.Z,
            armature=armature,
            friction=friction,
            damping=damping,
            actuator_mode=actuator_mode,
        )

        return self.add_joint(
            JointType.BALL,
            parent,
            child,
            parent_xform=parent_xform,
            child_xform=child_xform,
            angular_axes=[x, y, z],
            label=label,
            collision_filter_parent=collision_filter_parent,
            enabled=enabled,
            custom_attributes=custom_attributes,
        )

    def add_joint_fixed(
        self,
        parent: int,
        child: int,
        *,
        parent_xform: Transform | None = None,
        child_xform: Transform | None = None,
        label: str | None = None,
        collision_filter_parent: bool | None = None,
        enabled: bool = True,
        custom_attributes: dict[str, Any] | None = None,
    ) -> int:
        """Adds a fixed (static) joint to the model. It has no degrees of freedom.
        See :meth:`collapse_fixed_joints` for a helper function that removes these fixed joints and merges the connecting bodies to simplify the model and improve stability.

        Args:
            parent: The index of the parent body.
            child: The index of the child body.
            parent_xform: The transform of the joint in the parent body's local frame.
            child_xform: The transform of the joint in the child body's local frame.
            label: The label of the joint.
            collision_filter_parent: Whether to filter collisions between shapes of the parent and child bodies. Defaults to ``True``.
            enabled: Whether the joint is enabled.
            custom_attributes: Dictionary of custom attribute values for JOINT frequency attributes.

        Returns:
            The index of the added joint

        """

        joint_index = self.add_joint(
            JointType.FIXED,
            parent,
            child,
            parent_xform=parent_xform,
            child_xform=child_xform,
            label=label,
            collision_filter_parent=collision_filter_parent,
            enabled=enabled,
        )

        # Process custom attributes (only JOINT frequency is valid for fixed joints)
        if custom_attributes:
            self._process_joint_custom_attributes(joint_index, custom_attributes)

        return joint_index

    def add_joint_free(
        self,
        child: int,
        *,
        parent_xform: Transform | None = None,
        child_xform: Transform | None = None,
        parent: int = -1,
        label: str | None = None,
        collision_filter_parent: bool | None = None,
        enabled: bool = True,
        custom_attributes: dict[str, Any] | None = None,
    ) -> int:
        """Adds a free joint to the model.
        It has 7 positional degrees of freedom (first 3 linear and then 4 angular dimensions for the orientation quaternion in `xyzw` notation) and 6 velocity degrees of freedom (see :ref:`Twist conventions in Newton <Twist conventions>`).
        The positional dofs are initialized so that forward kinematics reproduces the child body's transform, accounting for the parent body and both joint anchor transforms (see :attr:`body_q` and the ``xform`` argument to :meth:`add_body`).

        Args:
            child: The index of the child body.
            parent_xform: The transform of the joint in the parent body's local frame.
            child_xform: The transform of the joint in the child body's local frame.
            parent: The index of the parent body (-1 by default to use the world frame, e.g. to make the child body and its children a floating-base mechanism).
            label: The label of the joint.
            collision_filter_parent: Whether to filter collisions between shapes of the parent and child bodies. Defaults to ``False`` for joints to world, ``True`` otherwise.
            enabled: Whether the joint is enabled.
            custom_attributes: Dictionary of custom attribute values for JOINT, JOINT_DOF, or JOINT_COORD frequency attributes.

        Returns:
            The index of the added joint.

        """

        joint_id = self.add_joint(
            JointType.FREE,
            parent,
            child,
            parent_xform=parent_xform,
            child_xform=child_xform,
            label=label,
            collision_filter_parent=collision_filter_parent,
            enabled=enabled,
            linear_axes=[
                ModelBuilder.JointDofConfig.create_unlimited(Axis.X),
                ModelBuilder.JointDofConfig.create_unlimited(Axis.Y),
                ModelBuilder.JointDofConfig.create_unlimited(Axis.Z),
            ],
            angular_axes=[
                ModelBuilder.JointDofConfig.create_unlimited(Axis.X),
                ModelBuilder.JointDofConfig.create_unlimited(Axis.Y),
                ModelBuilder.JointDofConfig.create_unlimited(Axis.Z),
            ],
            custom_attributes=custom_attributes,
        )
        q_start = self.joint_q_start[joint_id]
        # Initialize the coordinates so FK preserves the authored child pose.
        parent_body_xform = wp.transform_identity() if parent == -1 else self.body_q[parent]
        parent_anchor_world = parent_body_xform * self.joint_X_p[joint_id]
        joint_q = wp.transform_inverse(parent_anchor_world) * self.body_q[child] * self.joint_X_c[joint_id]
        self.joint_q[q_start : q_start + 7] = list(joint_q)
        return joint_id

    def add_joint_distance(
        self,
        parent: int,
        child: int,
        *,
        parent_xform: Transform | None = None,
        child_xform: Transform | None = None,
        min_distance: float = -1.0,
        max_distance: float = 1.0,
        collision_filter_parent: bool | None = None,
        enabled: bool = True,
        custom_attributes: dict[str, Any] | None = None,
        label: str | None = None,
    ) -> int:
        """Adds a distance joint to the model. The distance joint constraints the distance between the joint anchor points on the two bodies (see :ref:`FK-IK`) it connects to the interval [`min_distance`, `max_distance`].
        It has 7 positional degrees of freedom (first 3 linear and then 4 angular dimensions for the orientation quaternion in `xyzw` notation) and 6 velocity degrees of freedom (first 3 linear and then 3 angular velocity dimensions).

        Args:
            parent: The index of the parent body.
            child: The index of the child body.
            parent_xform: The transform of the joint in the parent body's local frame.
            child_xform: The transform of the joint in the child body's local frame.
            min_distance: The minimum distance between the bodies (no limit if negative).
            max_distance: The maximum distance between the bodies (no limit if negative).
            collision_filter_parent: Whether to filter collisions between shapes of the parent and child bodies. Defaults to ``False`` for joints to world, ``True`` otherwise.
            enabled: Whether the joint is enabled.
            custom_attributes: Dictionary of custom attribute values for JOINT, JOINT_DOF, or JOINT_COORD frequency attributes.
            label: The label of the joint.

        Returns:
            The index of the added joint.

        .. note:: Distance joints are currently only supported in :class:`newton.solvers.SolverXPBD`.

        """

        ax = ModelBuilder.JointDofConfig(
            axis=(1.0, 0.0, 0.0),
            limit_lower=min_distance,
            limit_upper=max_distance,
        )
        return self.add_joint(
            JointType.DISTANCE,
            parent,
            child,
            parent_xform=parent_xform,
            child_xform=child_xform,
            label=label,
            linear_axes=[
                ax,
                ModelBuilder.JointDofConfig.create_unlimited(Axis.Y),
                ModelBuilder.JointDofConfig.create_unlimited(Axis.Z),
            ],
            angular_axes=[
                ModelBuilder.JointDofConfig.create_unlimited(Axis.X),
                ModelBuilder.JointDofConfig.create_unlimited(Axis.Y),
                ModelBuilder.JointDofConfig.create_unlimited(Axis.Z),
            ],
            collision_filter_parent=collision_filter_parent,
            enabled=enabled,
            custom_attributes=custom_attributes,
        )

    def add_joint_d6(
        self,
        parent: int,
        child: int,
        *,
        linear_axes: Sequence[JointDofConfig] | None = None,
        angular_axes: Sequence[JointDofConfig] | None = None,
        label: str | None = None,
        parent_xform: Transform | None = None,
        child_xform: Transform | None = None,
        collision_filter_parent: bool | None = None,
        enabled: bool = True,
        custom_attributes: dict[str, Any] | None = None,
        **kwargs,
    ) -> int:
        """Adds a generic joint with custom linear and angular axes. The number of axes determines the number of degrees of freedom of the joint.

        Args:
            parent: The index of the parent body.
            child: The index of the child body.
            linear_axes: A list of linear axes.
            angular_axes: A list of angular axes.
            label: The label of the joint.
            parent_xform: The transform from the parent body frame to the joint parent anchor frame.
            child_xform: The transform from the child body frame to the joint child anchor frame.
            armature: Artificial inertia added around the joint axes. If None, the default value from ``ModelBuilder.default_joint_cfg.armature`` is used.
            collision_filter_parent: Whether to filter collisions between shapes of the parent and child bodies. Defaults to ``False`` for joints to world, ``True`` otherwise.
            enabled: Whether the joint is enabled.
            custom_attributes: Dictionary of custom attribute values for JOINT, JOINT_DOF, or JOINT_COORD frequency attributes.

        Returns:
            The index of the added joint.

        """
        if linear_axes is None:
            linear_axes = []
        if angular_axes is None:
            angular_axes = []

        return self.add_joint(
            JointType.D6,
            parent,
            child,
            parent_xform=parent_xform,
            child_xform=child_xform,
            linear_axes=list(linear_axes),
            angular_axes=list(angular_axes),
            label=label,
            collision_filter_parent=collision_filter_parent,
            enabled=enabled,
            custom_attributes=custom_attributes,
            **kwargs,
        )

    def add_joint_rod(
        self,
        parent: int,
        child: int,
        *,
        parent_xform: Transform | None = None,
        child_xform: Transform | None = None,
        stretch_stiffness: float | None = None,
        stretch_damping: float | None = None,
        shear_stiffness: float | None = None,
        shear_damping: float | None = None,
        bend_stiffness: float | None = None,
        bend_damping: float | None = None,
        twist_stiffness: float | None = None,
        twist_damping: float | None = None,
        label: str | None = None,
        collision_filter_parent: bool | None = None,
        enabled: bool = True,
        custom_attributes: dict[str, Any] | None = None,
        **kwargs,
    ) -> int:
        """Adds a rod joint to the model.

        Rod joints have split linear stretch/shear material slots plus separate
        angular bend and twist material slots. When both ``shear_stiffness`` and
        ``shear_damping`` are omitted, shear uses the stretch stiffness /
        damping, reproducing the isotropic linear energy while using the
        split layout. When both ``twist_stiffness`` and ``twist_damping`` are
        omitted, twist uses the bend stiffness / damping, reproducing the
        isotropic angular energy while using the split layout.

        .. note::

            Rod joints are supported by :class:`newton.solvers.SolverVBD`, which uses an
            AVBD backend for rigid bodies. They are represented in the joint data
            model as VBD stretch, shear, bend, and twist constraint slots rather
            than ``joint_q`` coordinates. Rod body transforms are
            integrated directly by :class:`newton.solvers.SolverVBD`; they are
            not reconstructed by :func:`newton.eval_fk`.

            Rod joints use each anchor frame's local ``+Z`` as the material
            tangent axis for separating axial stretch from shear and twist from
            bend. For a body-to-body rod span, the parent anchor ``+Z`` should
            point from the parent attachment toward the child attachment.
            :meth:`add_rod` and :meth:`add_rod_graph` satisfy the tangent
            convention automatically.

        Args:
            parent: The index of the parent body.
            child: The index of the child body.
            parent_xform: The transform from the parent body frame to the joint parent anchor frame; its
                translation is the attachment point and its local ``+Z`` axis is the parent-side material
                tangent.
            child_xform: The transform from the child body frame to the joint child anchor frame; its
                translation is the attachment point and its local ``+Z`` axis is the child-side material
                tangent.
            stretch_stiffness: Rod stretch stiffness (stored as ``target_ke``) [N/m]. If None, defaults to 1.0e5.
            stretch_damping: Rod stretch damping [N·s/m] (stored as ``target_kd``). If None,
                defaults to 0.0.
            shear_stiffness: Optional transverse shear stiffness [N/m]. If None,
                defaults to ``stretch_stiffness``.
            shear_damping: Optional transverse shear damping [N·s/m]. If None, defaults to
                ``stretch_damping`` only when both ``shear_stiffness`` and ``shear_damping`` are None. Otherwise
                defaults to 0.0.
            bend_stiffness: Rod bend stiffness (stored as ``target_ke``) [N·m/rad].
                If None, defaults to 0.0.
            bend_damping: Rod bend damping [N·m·s/rad] (stored as ``target_kd``). If None, defaults to 0.0.
            twist_stiffness: Optional twist stiffness [N·m/rad]. If None,
                defaults to ``bend_stiffness``.
            twist_damping: Optional twist damping [N·m·s/rad]. If None, defaults to ``bend_damping`` only when
                both ``twist_stiffness`` and ``twist_damping`` are None. Otherwise defaults to 0.0.
            label: The label of the joint.
            collision_filter_parent: Whether to filter collisions between shapes of the parent and child bodies. Defaults to ``False`` for joints to world, ``True`` otherwise.
            enabled: Whether the joint is enabled.
            custom_attributes: Dictionary of custom attribute values for JOINT, JOINT_DOF, or JOINT_COORD
                frequency attributes.

        Returns:
            The index of the added joint.

        """
        # Linear material slots (stretch and shear). Default shear to stretch so omitted
        # shear reproduces the isotropic linear anchor energy in the split layout.
        stretch_ke = 1.0e5 if stretch_stiffness is None else stretch_stiffness
        stretch_kd = 0.0 if stretch_damping is None else stretch_damping
        stretch_axis = ModelBuilder.JointDofConfig(target_ke=stretch_ke, target_kd=stretch_kd)
        if shear_stiffness is None and shear_damping is None:
            shear_ke = stretch_ke
            shear_kd = stretch_kd
        else:
            shear_ke = stretch_ke if shear_stiffness is None else shear_stiffness
            shear_kd = 0.0 if shear_damping is None else shear_damping
        shear_axis = ModelBuilder.JointDofConfig(target_ke=shear_ke, target_kd=shear_kd)

        # Angular material slots (bend and twist). Default twist to bend so omitted twist
        # reproduces the isotropic angular energy in the split layout.
        bend_ke = 0.0 if bend_stiffness is None else bend_stiffness
        bend_kd = 0.0 if bend_damping is None else bend_damping
        bend_axis = ModelBuilder.JointDofConfig(target_ke=bend_ke, target_kd=bend_kd)
        if twist_stiffness is None and twist_damping is None:
            twist_ke = bend_ke
            twist_kd = bend_kd
        else:
            twist_ke = bend_ke if twist_stiffness is None else twist_stiffness
            twist_kd = 0.0 if twist_damping is None else twist_damping
        if stretch_ke < 0.0 or shear_ke < 0.0 or bend_ke < 0.0 or twist_ke < 0.0:
            raise ValueError(
                "add_joint_rod: stretch_stiffness, shear_stiffness, bend_stiffness, and twist_stiffness must be >= 0"
            )
        twist_axis = ModelBuilder.JointDofConfig(target_ke=twist_ke, target_kd=twist_kd)

        return self.add_joint(
            JointType.ROD,
            parent,
            child,
            parent_xform=parent_xform,
            child_xform=child_xform,
            linear_axes=[stretch_axis, shear_axis],
            angular_axes=[bend_axis, twist_axis],
            label=label,
            collision_filter_parent=collision_filter_parent,
            enabled=enabled,
            custom_attributes=custom_attributes,
            **kwargs,
        )

    @deprecate_nonkeyword_arguments
    def add_joint_cable(
        self,
        parent: int,
        child: int,
        *,
        parent_xform: Transform | None = None,
        child_xform: Transform | None = None,
        stretch_stiffness: float | None = None,
        stretch_damping: float | None = None,
        shear_stiffness: float | None = None,
        shear_damping: float | None = None,
        bend_stiffness: float | None = None,
        bend_damping: float | None = None,
        twist_stiffness: float | None = None,
        twist_damping: float | None = None,
        label: str | None = None,
        collision_filter_parent: bool | None = None,
        enabled: bool = True,
        custom_attributes: dict[str, Any] | None = None,
        **kwargs,
    ) -> int:
        """Deprecated alias for :meth:`add_joint_rod`.

        .. deprecated:: 1.6
            Use :meth:`add_joint_rod` instead.
        """
        warnings.warn(
            "ModelBuilder.add_joint_cable() is deprecated in Newton 1.6; use add_joint_rod() instead.",
            DeprecationWarning,
            stacklevel=self._external_warning_stacklevel(),
        )
        return self.add_joint_rod(
            parent=parent,
            child=child,
            parent_xform=parent_xform,
            child_xform=child_xform,
            stretch_stiffness=stretch_stiffness,
            stretch_damping=stretch_damping,
            shear_stiffness=shear_stiffness,
            shear_damping=shear_damping,
            bend_stiffness=bend_stiffness,
            bend_damping=bend_damping,
            twist_stiffness=twist_stiffness,
            twist_damping=twist_damping,
            label=label,
            collision_filter_parent=collision_filter_parent,
            enabled=enabled,
            custom_attributes=custom_attributes,
            **kwargs,
        )

    def _set_joint_rod_material_gains(
        self,
        joint: int,
        *,
        stretch_stiffness: float | None = None,
        stretch_damping: float | None = None,
        shear_stiffness: float | None = None,
        shear_damping: float | None = None,
        bend_stiffness: float | None = None,
        bend_damping: float | None = None,
        twist_stiffness: float | None = None,
        twist_damping: float | None = None,
    ) -> None:
        """Overwrite non-None material gains and target modes in :meth:`add_joint_rod` slot order.

        Args:
            joint: Rod joint index.
            stretch_stiffness: Per-joint stretch stiffness [N/m], or ``None`` to preserve it.
            stretch_damping: Per-joint stretch damping [N·s/m], or ``None`` to preserve it.
            shear_stiffness: Per-joint shear stiffness [N/m], or ``None`` to preserve it.
            shear_damping: Per-joint shear damping [N·s/m], or ``None`` to preserve it.
            bend_stiffness: Per-joint bend stiffness [N·m/rad], or ``None`` to preserve it.
            bend_damping: Per-joint bend damping [N·m·s/rad], or ``None`` to preserve it.
            twist_stiffness: Per-joint twist stiffness [N·m/rad], or ``None`` to preserve it.
            twist_damping: Per-joint twist damping [N·m·s/rad], or ``None`` to preserve it.
        """
        joint_type = self.joint_type[joint]
        joint_dof_dim = self.joint_dof_dim[joint]
        if joint_type != JointType.ROD or joint_dof_dim != (2, 2):
            raise ValueError(
                "_set_joint_rod_material_gains() expected the four-slot ROD layout "
                f"(2 linear, 2 angular); got joint type {JointType(joint_type).name} with dimensions "
                f"{joint_dof_dim}. Update the ROD material-slot mapping when changing its slot layout."
            )
        dof_start = self.joint_qd_start[joint]
        stiffnesses = (stretch_stiffness, shear_stiffness, bend_stiffness, twist_stiffness)
        dampings = (stretch_damping, shear_damping, bend_damping, twist_damping)
        for offset, (stiffness, damping) in enumerate(zip(stiffnesses, dampings, strict=True)):
            if stiffness is not None or damping is not None:
                dof = dof_start + offset
                if stiffness is not None:
                    self.joint_target_ke[dof] = stiffness
                if damping is not None:
                    self.joint_target_kd[dof] = damping
                resolved_stiffness = self.joint_target_ke[dof]
                resolved_damping = self.joint_target_kd[dof]
                self.joint_target_mode[dof] = int(
                    JointTargetMode.from_gains(
                        resolved_stiffness,
                        resolved_damping,
                        has_drive=resolved_stiffness != 0.0 or resolved_damping != 0.0,
                    )
                )

    @staticmethod
    def _validate_rod_stiffness_inputs(
        method_name: str,
        *,
        stretch_stiffness: float | None,
        shear_stiffness: float | None,
        bend_stiffness: float | None,
        twist_stiffness: float | None,
    ) -> None:
        """Validate direct per-joint rod stiffness inputs."""
        stiffnesses = (
            ("stretch_stiffness", stretch_stiffness),
            ("shear_stiffness", shear_stiffness),
            ("bend_stiffness", bend_stiffness),
            ("twist_stiffness", twist_stiffness),
        )
        for name, stiffness in stiffnesses:
            if stiffness is not None and (not math.isfinite(stiffness) or stiffness < 0.0):
                raise ValueError(f"{method_name}: {name} must be finite and >= 0")

    @staticmethod
    def _validate_rod_rigidity_topology(
        point_count: int,
        edges: np.ndarray,
        *,
        wrap_in_articulation: bool,
    ) -> None:
        """Validate topology for automatic section-rigidity discretization."""
        if len(edges) >= 2 and Rod._is_ordered_chain_topology(point_count, edges):
            return

        degrees = np.bincount(edges.reshape(-1), minlength=point_count)
        if np.any(degrees > 2):
            raise ValueError(
                "add_rod: automatic section-rigidity discretization requires at most 2 incident segments per point; "
                "provide explicit builder stiffnesses for a branched graph"
            )
        if not wrap_in_articulation:
            return

        parents = list(range(point_count))

        def find(point: int) -> int:
            while parents[point] != point:
                parents[point] = parents[parents[point]]
                point = parents[point]
            return point

        for start, end in edges:
            start_root = find(int(start))
            end_root = find(int(end))
            if start_root == end_root:
                raise ValueError(
                    "add_rod: automatic section-rigidity discretization for a cyclic graph requires "
                    "wrap_in_articulation=False so every adjacency joint is retained; otherwise provide "
                    "explicit builder stiffnesses"
                )
            parents[end_root] = start_root

    def _set_joint_rod_stiffnesses_from_rigidities(
        self,
        segment_lengths: Sequence[float],
        body_indices: list[int],
        joint_indices: list[int],
        *,
        stretch_rigidity: float | None,
        shear_rigidity: float | None,
        bend_rigidity: float | None,
        twist_rigidity: float | None,
    ) -> None:
        """Convert section rigidities into joint stiffnesses using local dual lengths."""
        if stretch_rigidity is None and shear_rigidity is None and bend_rigidity is None and twist_rigidity is None:
            return

        segment_length_by_body = dict(zip(body_indices, segment_lengths, strict=True))
        for joint in joint_indices:
            dual_length = float(
                0.5
                * (segment_length_by_body[self.joint_parent[joint]] + segment_length_by_body[self.joint_child[joint]])
            )
            self._set_joint_rod_material_gains(
                joint,
                stretch_stiffness=None if stretch_rigidity is None else stretch_rigidity / dual_length,
                shear_stiffness=None if shear_rigidity is None else shear_rigidity / dual_length,
                bend_stiffness=None if bend_rigidity is None else bend_rigidity / dual_length,
                twist_stiffness=None if twist_rigidity is None else twist_rigidity / dual_length,
            )

    def add_constraint_mimic(
        self,
        joint0: int,
        joint1: int,
        coef0: float = 0.0,
        coef1: float = 1.0,
        enabled: bool = True,
        label: str | None = None,
        custom_attributes: dict[str, Any] | None = None,
    ) -> int:
        """Adds a mimic constraint to the model.

        A mimic constraint enforces that ``joint0 = coef0 + coef1 * joint1``,
        following URDF mimic joint semantics. Both scalar (prismatic, revolute) and
        multi-DOF joints are supported. For multi-DOF joints, the mimic behavior is
        applied equally to all degrees of freedom.

        Args:
            joint0: Index of the follower joint (the one being constrained)
            joint1: Index of the leader joint (the one being mimicked)
            coef0: Offset added after scaling
            coef1: Scale factor applied to joint1's position/angle
            enabled: Whether constraint is active
            label: Optional constraint label
            custom_attributes: Custom attributes to set on the constraint

        Returns:
            Constraint index
        """
        joint_count = self.joint_count
        if joint0 < 0 or joint0 >= joint_count:
            raise ValueError(f"Invalid follower joint index {joint0}; expected 0..{joint_count - 1}")
        if joint1 < 0 or joint1 >= joint_count:
            raise ValueError(f"Invalid leader joint index {joint1}; expected 0..{joint_count - 1}")
        if self.joint_world[joint0] != self.current_world or self.joint_world[joint1] != self.current_world:
            raise ValueError(
                "Mimic constraint joints must belong to the current world. "
                f"joint0_world={self.joint_world[joint0]}, joint1_world={self.joint_world[joint1]}, "
                f"current_world={self.current_world}."
            )

        self.constraint_mimic_joint0.append(joint0)
        self.constraint_mimic_joint1.append(joint1)
        self.constraint_mimic_coef0.append(coef0)
        self.constraint_mimic_coef1.append(coef1)
        self.constraint_mimic_enabled.append(enabled)
        self.constraint_mimic_label.append(label or "")
        self.constraint_mimic_world.append(self.current_world)

        constraint_idx = len(self.constraint_mimic_joint0) - 1

        # Process custom attributes
        if custom_attributes:
            self._process_custom_attributes(
                entity_index=constraint_idx,
                custom_attrs=custom_attributes,
                expected_frequency=Model.AttributeFrequency.CONSTRAINT_MIMIC,
            )

        return constraint_idx

    # endregion

    def plot_articulation(
        self,
        show_body_labels: bool = True,
        show_joint_labels: bool = True,
        show_joint_types: bool = True,
        plot_shapes: bool = True,
        show_shape_labels: bool = True,
        show_shape_types: bool = True,
        show_legend: bool = True,
    ) -> None:
        """
        Visualizes the model's articulation graph using matplotlib and networkx.
        Uses the spring layout algorithm from networkx to arrange the nodes.
        Bodies are shown as orange squares, shapes are shown as blue circles.

        Args:
            show_body_labels: Whether to show the body labels or indices
            show_joint_labels: Whether to show the joint labels or indices
            show_joint_types: Whether to show the joint types
            plot_shapes: Whether to render the shapes connected to the rigid bodies
            show_shape_labels: Whether to show the shape labels or indices
            show_shape_types: Whether to show the shape geometry types
            show_legend: Whether to show a legend
        """
        import matplotlib.pyplot as plt
        import networkx as nx

        def joint_type_str(type):
            if type == JointType.FREE:
                return "free"
            elif type == JointType.BALL:
                return "ball"
            elif type == JointType.PRISMATIC:
                return "prismatic"
            elif type == JointType.REVOLUTE:
                return "revolute"
            elif type == JointType.D6:
                return "D6"
            elif type == JointType.FIXED:
                return "fixed"
            elif type == JointType.DISTANCE:
                return "distance"
            elif type == JointType.ROD:
                return "rod"
            return "unknown"

        def shape_type_str(type):
            if type == GeoType.SPHERE:
                return "sphere"
            if type == GeoType.BOX:
                return "box"
            if type == GeoType.CAPSULE:
                return "capsule"
            if type == GeoType.CYLINDER:
                return "cylinder"
            if type == GeoType.CONE:
                return "cone"
            if type == GeoType.MESH:
                return "mesh"
            if type == GeoType.PLANE:
                return "plane"
            if type == GeoType.CONVEX_MESH:
                return "convex_hull"
            if type == GeoType.NONE:
                return "none"
            return "unknown"

        if show_body_labels:
            vertices = ["world", *self.body_label]
        else:
            vertices = ["-1"] + [str(i) for i in range(self.body_count)]
        if plot_shapes:
            for i in range(self.shape_count):
                shape_label = []
                if show_shape_labels:
                    shape_label.append(self.shape_label[i])
                if show_shape_types:
                    shape_label.append(f"({shape_type_str(self.shape_type[i])})")
                vertices.append("\n".join(shape_label))
        edges = []
        edge_labels = []
        edge_colors = []
        for i in range(self.joint_count):
            edge = (self.joint_child[i] + 1, self.joint_parent[i] + 1)
            edges.append(edge)
            if show_joint_labels:
                joint_label = self.joint_label[i]
            else:
                joint_label = str(i)
            if show_joint_types:
                joint_label += f"\n({joint_type_str(self.joint_type[i])})"
            edge_labels.append(joint_label)
            art_id = self.joint_articulation[i]
            if art_id == -1:
                edge_colors.append("r")
            else:
                edge_colors.append("k")

        if plot_shapes:
            for i in range(self.shape_count):
                edges.append((len(self.body_label) + i + 1, self.shape_body[i] + 1))

        # plot graph
        G = nx.DiGraph()
        for i in range(len(vertices)):
            G.add_node(i, label=vertices[i])
        for i in range(len(edges)):
            label = edge_labels[i] if i < len(edge_labels) else ""
            G.add_edge(edges[i][0], edges[i][1], label=label)
        pos = nx.spring_layout(G, iterations=250)
        # pos = nx.kamada_kawai_layout(G)
        nx.draw_networkx_edges(G, pos, node_size=100, edgelist=edges, edge_color=edge_colors, arrows=True)
        # render body vertices
        draw_args = {"node_size": 100}
        bodies = nx.subgraph(G, list(range(self.body_count + 1)))
        nx.draw_networkx_nodes(bodies, pos, node_color="orange", node_shape="s", **draw_args)
        if plot_shapes:
            # render shape vertices
            shapes = nx.subgraph(G, list(range(self.body_count + 1, len(vertices))))
            nx.draw_networkx_nodes(shapes, pos, node_color="skyblue", **draw_args)
            nx.draw_networkx_edges(
                G, pos, node_size=0, edgelist=edges[self.joint_count :], edge_color="gray", style="dashed"
            )
        edge_labels = nx.get_edge_attributes(G, "label")
        nx.draw_networkx_edge_labels(
            G, pos, edge_labels=edge_labels, font_size=6, bbox={"alpha": 0.6, "color": "w", "lw": 0}
        )
        # add node labels
        nx.draw_networkx_labels(G, pos, dict(enumerate(vertices)), font_size=6)
        if show_legend:
            plt.plot([], [], "s", color="orange", label="body")
            plt.plot([], [], "k->", label="joint (child -> parent)")
            if plot_shapes:
                plt.plot([], [], "o", color="skyblue", label="shape")
                plt.plot([], [], "k--", label="shape-body connection")
            plt.legend(loc="upper left", fontsize=6)
        plt.show()

    def collapse_fixed_joints(
        self,
        verbose: bool = False,
        joints_to_keep: Sequence[str | int] | None = None,
    ) -> dict[str, Any]:
        """Removes fixed joints from the model and merges the bodies they connect. This is useful for simplifying the model for faster and more stable simulation.

        Args:
            verbose: If True, print additional information about the collapsed joints.
            joints_to_keep: An optional sequence of joint labels or original joint indices to be excluded from
                the collapse process.
        """
        joints_to_keep = set(joints_to_keep or ())

        body_data = {}
        body_children = {-1: []}
        visited = {}
        merged_body_data = {}
        for i in range(self.body_count):
            body_lbl = self.body_label[i]
            inertia_i = self._coerce_mat33(self.body_inertia[i])
            body_data[i] = {
                "shapes": self.body_shapes[i],
                "q": self.body_q[i],
                "qd": self.body_qd[i],
                "mass": self.body_mass[i],
                "inertia": inertia_i,
                "inv_mass": self.body_inv_mass[i],
                "inv_inertia": self.body_inv_inertia[i],
                "com": axis_to_vec3(self.body_com[i]),
                "lock_inertia": self.body_lock_inertia[i],
                "flags": self.body_flags[i],
                "label": body_lbl,
                "original_id": i,
            }
            visited[i] = False
            body_children[i] = []

        joint_data = {}
        for i in range(self.joint_count):
            joint_lbl = self.joint_label[i]
            parent = self.joint_parent[i]
            child = self.joint_child[i]
            body_children[parent].append(child)

            q_start = self.joint_q_start[i]
            qd_start = self.joint_qd_start[i]
            cts_start = self.joint_cts_start[i]
            if i < self.joint_count - 1:
                q_dim = self.joint_q_start[i + 1] - q_start
                qd_dim = self.joint_qd_start[i + 1] - qd_start
                cts_dim = self.joint_cts_start[i + 1] - cts_start
            else:
                q_dim = len(self.joint_q) - q_start
                qd_dim = len(self.joint_qd) - qd_start
                cts_dim = len(self.joint_cts) - cts_start

            data = {
                "type": self.joint_type[i],
                "q": self.joint_q[q_start : q_start + q_dim],
                "target_q": self.joint_target_q[q_start : q_start + q_dim],
                "qd": self.joint_qd[qd_start : qd_start + qd_dim],
                "target_qd": self.joint_target_qd[qd_start : qd_start + qd_dim],
                "cts": self.joint_cts[cts_start : cts_start + cts_dim],
                "armature": self.joint_armature[qd_start : qd_start + qd_dim],
                "q_start": q_start,
                "qd_start": qd_start,
                "cts_start": cts_start,
                "label": joint_lbl,
                "parent_xform": wp.transform_expand(self.joint_X_p[i]),
                "child_xform": wp.transform_expand(self.joint_X_c[i]),
                "enabled": self.joint_enabled[i],
                "collision_filter_parent": self.joint_collision_filter_parent[i],
                "axes": [],
                "axis_dim": self.joint_dof_dim[i],
                "parent": parent,
                "child": child,
                "original_id": i,
            }
            num_lin_axes, num_ang_axes = self.joint_dof_dim[i]
            for j in range(qd_start, qd_start + num_lin_axes + num_ang_axes):
                data["axes"].append(
                    {
                        "axis": self.joint_axis[j],
                        "actuator_mode": self.joint_target_mode[j],
                        "target_ke": self.joint_target_ke[j],
                        "target_kd": self.joint_target_kd[j],
                        "damping": self.joint_damping[j],
                        "limit_ke": self.joint_limit_ke[j],
                        "limit_kd": self.joint_limit_kd[j],
                        "limit_lower": self.joint_limit_lower[j],
                        "limit_upper": self.joint_limit_upper[j],
                        "effort_limit": self.joint_effort_limit[j],
                    }
                )

            joint_data.setdefault((parent, child), []).append(data)

        # sort body children so we traverse the tree in the same order as the bodies are listed
        for children in body_children.values():
            children.sort(key=lambda x: body_data[x]["original_id"])

        # Find bodies referenced in equality constraints that shouldn't be merged into world
        bodies_in_constraints = set()
        for body1, body2 in zip(
            self._eq_list("equality_constraint_body1"),
            self._eq_list("equality_constraint_body2"),
            strict=False,
        ):
            if body1 >= 0:
                bodies_in_constraints.add(body1)
            if body2 >= 0:
                bodies_in_constraints.add(body2)

        retained_joints = []
        retained_bodies = []
        body_remap = {-1: -1}
        body_merged_parent = {}
        body_merged_transform = {}
        velocity_updated_bodies: set[int] = set()

        # Joints already retained as loop-closing edges (by original id), so a joint
        # reachable through several traversal paths is kept exactly once.
        retained_loop_joint_ids = set()

        def retain_loop_joints(joints_for_pair, child, incoming_xform, last_dynamic_body):
            # Loop-closing joints: the child was already visited via another path (or the
            # pair has parallel joints). Retain them without re-processing the child body.
            for loop_joint in joints_for_pair:
                if loop_joint["type"] == JointType.FIXED or loop_joint["original_id"] in retained_loop_joint_ids:
                    continue
                retained_loop_joint_ids.add(loop_joint["original_id"])
                loop_joint["parent_xform"] = incoming_xform * loop_joint["parent_xform"]
                loop_joint["parent"] = last_dynamic_body
                if child in body_merged_parent:
                    # Child was merged into another body -- remap child and adjust child_xform
                    merge_xform = body_merged_transform[child]
                    loop_joint["child_xform"] = merge_xform * loop_joint["child_xform"]
                    loop_joint["child"] = body_merged_parent[child]
                retained_joints.append(loop_joint)

        # depth first search over the joint graph
        def dfs(parent_body: int, child_body: int, incoming_xform: wp.transform, last_dynamic_body: int):
            nonlocal visited
            nonlocal retained_joints
            nonlocal retained_bodies
            nonlocal body_data

            # The first joint of the pair is the tree edge; parallel joints between the
            # same pair (e.g. an attachment with several point sites) close loops. They are
            # retained via retain_loop_joints() after the tree edge is processed, so a fixed
            # tree joint's merge is already recorded when their child endpoint is remapped.
            entry_xform = incoming_xform
            entry_last_dynamic_body = last_dynamic_body
            joint = joint_data[(parent_body, child_body)][0]
            # Don't merge fixed joints if the child body is referenced in an equality constraint
            # and would be merged into world (last_dynamic_body == -1)
            should_skip_merge = child_body in bodies_in_constraints and last_dynamic_body == -1

            # Don't merge fixed joints listed in joints_to_keep list
            joint_in_keep_list = joint["label"] in joints_to_keep or joint["original_id"] in joints_to_keep

            if should_skip_merge and joint["type"] == JointType.FIXED:
                # Skip merging this fixed joint because the body is referenced in an equality constraint
                if verbose:
                    parent_lbl = self.body_label[parent_body] if parent_body > -1 else "world"
                    child_lbl = self.body_label[child_body]
                    print(
                        f"Skipping collapse of fixed joint {joint['label']} between {parent_lbl} and {child_lbl}: "
                        f"{child_lbl} is referenced in an equality constraint and cannot be merged into world"
                    )

            if joint_in_keep_list and joint["type"] == JointType.FIXED:
                # Skip merging this joint if it is listed in the joints_to_keep list
                parent_lbl = self.body_label[parent_body] if parent_body > -1 else "world"
                child_lbl = self.body_label[child_body]
                if verbose:
                    print(
                        f"Skipping collapse of joint {joint['label']} between {parent_lbl} and {child_lbl}: "
                        f"{child_lbl} is listed in joints_to_keep and this fixed joint will be preserved"
                    )
                # Warn if the child_body of skipped joint has zero or negative mass
                if body_data[child_body]["mass"] <= 0:
                    warnings.warn(
                        f"Skipped joint {joint['label']} has a child {child_lbl} with zero or negative mass ({body_data[child_body]['mass']}). "
                        f"This may cause unexpected behavior.",
                        UserWarning,
                        stacklevel=3,
                    )

            if joint["type"] == JointType.FIXED and not should_skip_merge and not joint_in_keep_list:
                joint_xform = joint["parent_xform"] * wp.transform_inverse(joint["child_xform"])
                incoming_xform = incoming_xform * joint_xform
                parent_lbl = self.body_label[parent_body] if parent_body > -1 else "world"
                child_lbl = self.body_label[child_body]
                last_dynamic_body_label = self.body_label[last_dynamic_body] if last_dynamic_body > -1 else "world"
                if verbose:
                    print(
                        f"Remove fixed joint {joint['label']} between {parent_lbl} and {child_lbl}, "
                        f"merging {child_lbl} into {last_dynamic_body_label}"
                    )
                child_id = body_data[child_body]["original_id"]
                relative_xform = incoming_xform
                merged_body_data[self.body_label[child_body]] = {
                    "relative_xform": relative_xform,
                    "parent_body": self.body_label[parent_body],
                }
                body_merged_parent[child_body] = last_dynamic_body
                body_merged_transform[child_body] = incoming_xform
                for shape in self.body_shapes[child_id]:
                    shape_tf = self.shape_transform[shape]
                    self.shape_transform[shape] = incoming_xform * shape_tf
                    if verbose:
                        print(
                            f"  Shape {shape} moved to body {last_dynamic_body_label} with transform {self.shape_transform[shape]}"
                        )
                    if last_dynamic_body > -1:
                        self.shape_body[shape] = body_data[last_dynamic_body]["id"]
                        body_data[last_dynamic_body]["shapes"].append(shape)
                    else:
                        self.shape_body[shape] = -1
                        self.body_shapes[-1].append(shape)

                if last_dynamic_body > -1:
                    source_m = body_data[last_dynamic_body]["mass"]
                    source_com = body_data[last_dynamic_body]["com"]
                    # add inertia to last_dynamic_body
                    m = body_data[child_body]["mass"]
                    com = wp.transform_point(incoming_xform, body_data[child_body]["com"])
                    inertia = body_data[child_body]["inertia"]
                    body_data[last_dynamic_body]["inertia"] += transform_inertia(
                        m, inertia, incoming_xform.p, incoming_xform.q
                    )
                    body_data[last_dynamic_body]["mass"] += m
                    total_mass = m + source_m
                    if total_mass > 0.0:
                        merged_com = (m * com + source_m * source_com) / total_mass
                        qd = body_data[last_dynamic_body]["qd"]
                        angular_velocity = wp.spatial_bottom(qd)
                        # Preserve the velocity field when shifting the COM reference.
                        com_offset = wp.transform_vector(body_data[last_dynamic_body]["q"], merged_com - source_com)
                        linear_velocity = wp.spatial_top(qd) + wp.cross(angular_velocity, com_offset)
                        body_data[last_dynamic_body]["qd"] = wp.spatial_vector(*linear_velocity, *angular_velocity)
                        body_data[last_dynamic_body]["com"] = merged_com
                        velocity_updated_bodies.add(last_dynamic_body)
                    # else: both bodies massless; keep parent COM (avoids 0/0).
                    # indicate to recompute inverse mass, inertia for this body
                    body_data[last_dynamic_body]["inv_mass"] = None
            else:
                joint["parent_xform"] = incoming_xform * joint["parent_xform"]
                joint["parent"] = last_dynamic_body
                last_dynamic_body = child_body
                incoming_xform = wp.transform()
                retained_joints.append(joint)
                retained_loop_joint_ids.add(joint["original_id"])
                new_id = len(retained_bodies)
                body_data[child_body]["id"] = new_id
                retained_bodies.append(child_body)
                for shape in body_data[child_body]["shapes"]:
                    self.shape_body[shape] = new_id

            retain_loop_joints(
                joint_data[(parent_body, child_body)][1:], child_body, entry_xform, entry_last_dynamic_body
            )

            visited[parent_body] = True
            if visited[child_body] or child_body not in body_children:
                return
            visited[child_body] = True
            for child in body_children[child_body]:
                if not visited[child]:
                    dfs(child_body, child, incoming_xform, last_dynamic_body)
                elif (child_body, child) in joint_data:
                    retain_loop_joints(joint_data[(child_body, child)], child, incoming_xform, last_dynamic_body)

        for body in body_children[-1]:
            if not visited[body]:
                dfs(-1, body, wp.transform(), -1)
            else:
                # A world joint to an already-visited body (e.g. an attachment anchor)
                # closes a loop; it must not be dropped.
                retain_loop_joints(joint_data[(-1, body)], body, wp.transform(), -1)

        # Handle disconnected subtrees: bodies not reachable from world.
        # This happens when joints only connect bodies to each other (no joint
        # has parent == -1) and free joints to world were not auto-inserted
        # (e.g. when no PhysicsArticulationRootAPI exists but joints are present).
        children_in_joints = {c for p, cs in body_children.items() if p >= 0 for c in cs}

        for body_id in range(self.body_count):
            if visited[body_id]:
                continue
            if body_id in children_in_joints:
                # Not a root — will be visited when its parent root is processed.
                continue
            # This body is a root of a disconnected subtree (or an isolated body).
            new_id = len(retained_bodies)
            body_data[body_id]["id"] = new_id
            retained_bodies.append(body_id)
            for shape in body_data[body_id]["shapes"]:
                self.shape_body[shape] = new_id
            visited[body_id] = True
            for child in body_children[body_id]:
                if not visited[child]:
                    dfs(body_id, child, wp.transform(), body_id)
                else:
                    # The child was reached earlier through a loop-closing path (e.g. an
                    # attachment anchor); this root's joint to it must not be dropped.
                    retain_loop_joints(joint_data[(body_id, child)], child, wp.transform(), body_id)

        # Reindex retained bodies in their original relative order: DFS discovery order
        # would reorder bodies whenever a loop-closing joint (e.g. an attachment anchor)
        # reaches a body before its chain root, breaking parent < child joint ordering
        # and the contiguity of recorded group ranges.
        retained_bodies.sort()
        for new_id, original_id in enumerate(retained_bodies):
            body_data[original_id]["id"] = new_id
            for shape in body_data[original_id]["shapes"]:
                self.shape_body[shape] = new_id

        for joint in retained_joints:
            if joint["child"] not in velocity_updated_bodies or joint["type"] not in (
                JointType.FREE,
                JointType.DISTANCE,
            ):
                continue

            child = joint["child"]
            child_qd = body_data[child]["qd"]
            linear_velocity = wp.spatial_top(child_qd)
            angular_velocity = wp.spatial_bottom(child_qd)
            parent = joint["parent"]
            parent_xform = joint["parent_xform"]
            if parent >= 0:
                parent_xform = body_data[parent]["q"] * parent_xform
                parent_qd = body_data[parent]["qd"]
                parent_angular_velocity = wp.spatial_bottom(parent_qd)
                child_com = wp.transform_point(body_data[child]["q"], body_data[child]["com"])
                parent_com = wp.transform_point(body_data[parent]["q"], body_data[parent]["com"])
                linear_velocity -= wp.spatial_top(parent_qd) + wp.cross(parent_angular_velocity, child_com - parent_com)
                angular_velocity -= parent_angular_velocity

            parent_rotation = wp.transform_get_rotation(parent_xform)
            linear_velocity = wp.quat_rotate_inv(parent_rotation, linear_velocity)
            angular_velocity = wp.quat_rotate_inv(parent_rotation, angular_velocity)
            joint["qd"] = [*linear_velocity, *angular_velocity]

        # repopulate the model
        # save original body groups before clearing
        original_body_group = self.body_world[:] if self.body_world else []

        self.body_label.clear()
        self.body_q.clear()
        self.body_qd.clear()
        self.body_mass.clear()
        self.body_inertia.clear()
        self.body_com.clear()
        self.body_lock_inertia.clear()
        self.body_flags.clear()
        self.body_inv_mass.clear()
        self.body_inv_inertia.clear()
        self.body_world.clear()  # Clear body groups
        static_shapes = self.body_shapes[-1]
        self.body_shapes.clear()
        # restore static shapes
        self.body_shapes[-1] = static_shapes
        for i in retained_bodies:
            body = body_data[i]
            new_id = len(self.body_label)
            body_remap[body["original_id"]] = new_id
            self.body_label.append(body["label"])
            self.body_q.append(body["q"])
            self.body_qd.append(body["qd"])
            m = body["mass"]
            inertia = body["inertia"]
            self.body_mass.append(m)
            self.body_inertia.append(inertia)
            self.body_com.append(body["com"])
            self.body_lock_inertia.append(body["lock_inertia"])
            self.body_flags.append(body["flags"])
            if body["inv_mass"] is None:
                # recompute inverse mass and inertia
                if m > 0.0:
                    self.body_inv_mass.append(1.0 / m)
                    self.body_inv_inertia.append(wp.inverse(inertia))
                else:
                    self.body_inv_mass.append(0.0)
                    self.body_inv_inertia.append(wp.mat33(0.0))
            else:
                self.body_inv_mass.append(body["inv_mass"])
                self.body_inv_inertia.append(body["inv_inertia"])
            self.body_shapes[new_id] = body["shapes"]
            # Rebuild body group - use original group if it exists
            if original_body_group and body["original_id"] < len(original_body_group):
                self.body_world.append(original_body_group[body["original_id"]])
            else:
                # If no group was assigned, use default -1
                self.body_world.append(-1)

        # sort joints so they appear in the same order as before
        retained_joints.sort(key=lambda x: x["original_id"])

        original_articulation_start = self.articulation_start[:]
        original_articulation_label = self.articulation_label[:]
        original_articulation_world = self.articulation_world[:]
        original_joint_articulation = self.joint_articulation[:] if self.joint_articulation else []

        joint_remap = {}
        articulation_first_joint: dict[int, int] = {}
        articulation_last_joint: dict[int, int] = {}
        for i, joint in enumerate(retained_joints):
            old_joint_idx = joint["original_id"]
            joint_remap[old_joint_idx] = i
            if original_joint_articulation and old_joint_idx < len(original_joint_articulation):
                old_articulation = original_joint_articulation[old_joint_idx]
                if old_articulation >= 0 and old_articulation not in articulation_first_joint:
                    articulation_first_joint[old_articulation] = i
                if old_articulation >= 0:
                    articulation_last_joint[old_articulation] = i

        # Update articulation starts from retained joints' original articulation
        # ownership. This preserves articulation order while dropping empty
        # articulations whose joints were fully collapsed away.
        articulation_remap: dict[int, int] = {}
        new_articulation_start: list[int] = []
        new_articulation_end: list[int] = []
        new_articulation_label: list[str] = []
        new_articulation_world: list[int] = []
        for articulation_idx in range(len(original_articulation_start)):
            if articulation_idx not in articulation_first_joint:
                continue

            articulation_remap[articulation_idx] = len(new_articulation_start)
            new_articulation_start.append(articulation_first_joint[articulation_idx])
            new_articulation_end.append(articulation_last_joint[articulation_idx] + 1)
            if articulation_idx < len(original_articulation_label):
                new_articulation_label.append(original_articulation_label[articulation_idx])
            else:
                new_articulation_label.append(f"articulation_{articulation_idx}")
            if articulation_idx < len(original_articulation_world):
                new_articulation_world.append(original_articulation_world[articulation_idx])
            else:
                new_articulation_world.append(self.current_world)

        self.articulation_start = new_articulation_start
        self.articulation_end = new_articulation_end
        self.articulation_label = new_articulation_label
        self.articulation_world = new_articulation_world

        # Remap cable group ranges onto the reindexed bodies/joints. Cable bodies are linked by rod
        # joints (never fixed), so they are not collapsed and their ranges stay contiguous; only their
        # indices shift as other bodies/joints are dropped. Cloth/volume ranges address particles and
        # triangles/tets/edges, which fixed-joint collapse never touches, so they are left untouched.
        def _remap_body_id(body_id: int) -> int:
            # Cable bodies are linked only by non-fixed rod joints, so collapse must never
            # merge or drop them; a violation would silently corrupt every recorded range.
            assert body_id in body_remap, f"cable body {body_id} was collapsed; cable ranges would be corrupt"
            return body_remap[body_id]

        for i in range(len(self._cable_label)):
            if self._cable_body_end[i] > self._cable_body_start[i]:
                new_start = _remap_body_id(self._cable_body_start[i])
                self._cable_body_start[i] = new_start
                self._cable_body_end[i] = _remap_body_id(self._cable_body_end[i] - 1) + 1
            if self._cable_joint_end[i] > self._cable_joint_start[i]:
                first, last = self._cable_joint_start[i], self._cable_joint_end[i] - 1
                assert first in joint_remap and last in joint_remap, (
                    f"rod joints [{first}, {last}] were collapsed; cable ranges would be corrupt"
                )
                self._cable_joint_start[i] = joint_remap[first]
                self._cable_joint_end[i] = joint_remap[last] + 1
            else:
                # A welded-graph curve owns no tree joints, but its empty [b, b) boundary must
                # still shift with the retained joints, else it can point past the collapsed
                # joint array. Map b to the number of retained joints below it.
                boundary = self._cable_joint_start[i]
                new_boundary = sum(1 for old_joint in joint_remap if old_joint < boundary)
                self._cable_joint_start[i] = new_boundary
                self._cable_joint_end[i] = new_boundary

        def remap_articulation_reference(value: Any) -> Any:
            if isinstance(value, bool):
                return value
            if isinstance(value, list):
                return [remap_articulation_reference(v) for v in value]
            if isinstance(value, tuple):
                return tuple(remap_articulation_reference(v) for v in value)
            # Covers Python int as well as Warp scalar integer types (wp.int32 etc.),
            # whose default `dtype(0)` instances are not Python ints.
            try:
                idx = int(value)
            except (TypeError, ValueError):
                return value
            return articulation_remap.get(idx, -1) if idx >= 0 else value

        # ARTICULATION-frequency attributes use dict storage by construction
        # (see CustomAttribute._create_empty_values_container).
        for custom_attr in self.get_custom_attributes_by_frequency([Model.AttributeFrequency.ARTICULATION]):
            custom_attr.values = {
                new_idx: custom_attr.values[old_idx]
                for old_idx, new_idx in articulation_remap.items()
                if old_idx in custom_attr.values
            }

        for custom_attr in self.custom_attributes.values():
            if custom_attr.references != "articulation" or custom_attr.values is None:
                continue
            if isinstance(custom_attr.values, dict):
                custom_attr.values = {
                    entity_idx: remap_articulation_reference(value) for entity_idx, value in custom_attr.values.items()
                }
            else:
                custom_attr.values = [remap_articulation_reference(value) for value in custom_attr.values]

        # save original joint worlds and articulations before clearing
        original_ = self.joint_world[:] if self.joint_world else []

        self.joint_label.clear()
        self.joint_type.clear()
        self.joint_parent.clear()
        self.joint_child.clear()
        self.joint_q.clear()
        self.joint_qd.clear()
        self.joint_cts.clear()
        self.joint_q_start.clear()
        self.joint_qd_start.clear()
        self.joint_cts_start.clear()
        self.joint_enabled.clear()
        self.joint_collision_filter_parent.clear()
        self.joint_armature.clear()
        self.joint_X_p.clear()
        self.joint_X_c.clear()
        self.joint_axis.clear()
        self.joint_target_mode.clear()
        self.joint_target_ke.clear()
        self.joint_target_kd.clear()
        self.joint_damping.clear()
        self.joint_limit_lower.clear()
        self.joint_limit_upper.clear()
        self.joint_limit_ke.clear()
        self.joint_effort_limit.clear()
        self.joint_limit_kd.clear()
        self.joint_dof_dim.clear()
        self.joint_target_q.clear()
        self.joint_target_qd.clear()
        self.joint_world.clear()
        self.joint_articulation.clear()
        for joint in retained_joints:
            self.joint_label.append(joint["label"])
            self.joint_type.append(joint["type"])
            self.joint_parent.append(body_remap[joint["parent"]])
            self.joint_child.append(body_remap[joint["child"]])
            self.joint_q_start.append(len(self.joint_q))
            self.joint_qd_start.append(len(self.joint_qd))
            self.joint_cts_start.append(len(self.joint_cts))
            self.joint_q.extend(joint["q"])
            self.joint_target_q.extend(joint["target_q"])
            self.joint_qd.extend(joint["qd"])
            self.joint_target_qd.extend(joint["target_qd"])
            self.joint_cts.extend(joint["cts"])
            self.joint_armature.extend(joint["armature"])
            self.joint_enabled.append(joint["enabled"])
            self.joint_collision_filter_parent.append(joint["collision_filter_parent"])
            self.joint_X_p.append(joint["parent_xform"])
            self.joint_X_c.append(joint["child_xform"])
            self.joint_dof_dim.append(joint["axis_dim"])
            # Rebuild joint world - use original world if it exists
            if original_ and joint["original_id"] < len(original_):
                self.joint_world.append(original_[joint["original_id"]])
            else:
                # If no world was assigned, use default -1
                self.joint_world.append(-1)
            # Rebuild joint articulation assignment
            if original_joint_articulation and joint["original_id"] < len(original_joint_articulation):
                old_articulation = original_joint_articulation[joint["original_id"]]
                self.joint_articulation.append(articulation_remap.get(old_articulation, -1))
            else:
                self.joint_articulation.append(-1)
            for axis in joint["axes"]:
                self.joint_axis.append(axis["axis"])
                self.joint_target_mode.append(axis["actuator_mode"])
                self.joint_target_ke.append(axis["target_ke"])
                self.joint_target_kd.append(axis["target_kd"])
                self.joint_damping.append(axis["damping"])
                self.joint_limit_lower.append(axis["limit_lower"])
                self.joint_limit_upper.append(axis["limit_upper"])
                self.joint_limit_ke.append(axis["limit_ke"])
                self.joint_limit_kd.append(axis["limit_kd"])
                self.joint_effort_limit.append(axis["effort_limit"])

        # Update DOF and coordinate counts to match the rebuilt arrays
        self.joint_dof_count = len(self.joint_qd)
        self.joint_coord_count = len(self.joint_q)

        # Trim per-DOF arrays that were not cleared/rebuilt above
        for attr_name in ("joint_velocity_limit", "joint_friction"):
            arr = getattr(self, attr_name)
            if len(arr) > self.joint_dof_count:
                setattr(self, attr_name, arr[: self.joint_dof_count])

        # Reset the constraint count based on the retained joints
        self.joint_constraint_count = len(self.joint_cts)

        # Remap equality constraint body/joint indices and transform anchors for merged bodies.
        # Import locally to avoid a cycle while the public simulation package initializes.
        from ..solvers.mujoco.enums import EqType  # noqa: PLC0415

        # Each ``*_values`` is the ``list`` backing the string-frequency CustomAttribute. These
        # lists are sparse: ``add_custom_values`` only populates the fields that were supplied,
        # so an omitted optional field can be ``None``, shorter than the row count, or absent
        # entirely. Reads go through ``_at`` (default fallback), and writes pad the list to the
        # row index before assignment.
        body1_attr = self._eq_attr("equality_constraint_body1")
        body2_attr = self._eq_attr("equality_constraint_body2")
        type_attr = self._eq_attr("equality_constraint_type")
        anchor_attr = self._eq_attr("equality_constraint_anchor")
        relpose_attr = self._eq_attr("equality_constraint_relpose")
        joint1_attr = self._eq_attr("equality_constraint_joint1")
        joint2_attr = self._eq_attr("equality_constraint_joint2")
        enabled_attr = self._eq_attr("equality_constraint_enabled")
        body1_values = body1_attr.values or []
        body2_values = body2_attr.values or []
        type_values = type_attr.values or []
        if anchor_attr.values is None:
            anchor_attr.values = []
        anchor_values = anchor_attr.values
        if relpose_attr.values is None:
            relpose_attr.values = []
        relpose_values = relpose_attr.values
        joint1_values = joint1_attr.values or []
        joint2_values = joint2_attr.values or []
        if enabled_attr.values is None:
            enabled_attr.values = []
        enabled_values = enabled_attr.values

        def _at(values: list, idx: int, default: Any) -> Any:
            if idx >= len(values):
                return default
            return default if values[idx] is None else values[idx]

        # Body/joint index remapping for body1/body2/joint1/joint2 is handled generically below
        # via the ``references`` field. Here we only apply the MuJoCo-specific fixups that depend
        # on the original indices: anchor/relpose frame transforms when a referenced body was
        # merged into its parent, and disabling rows whose joint reference was removed.
        for i in range(self._equality_constraint_count):
            old_body1 = _at(body1_values, i, body1_attr.default)
            old_body2 = _at(body2_values, i, body2_attr.default)
            body1_was_merged = old_body1 in body_merged_parent
            body2_was_merged = old_body2 in body_merged_parent

            constraint_type = _at(type_values, i, type_attr.default)

            # Transform anchor/relpose from merged body's frame to parent body's frame
            if body1_was_merged:
                merge_xform = body_merged_transform[old_body1]
                if constraint_type == EqType.CONNECT:
                    anchor = axis_to_vec3(_at(anchor_values, i, anchor_attr.default))
                    while len(anchor_values) <= i:
                        anchor_values.append(None)
                    anchor_values[i] = wp.transform_point(merge_xform, anchor)
                if constraint_type == EqType.WELD:
                    relpose = _at(relpose_values, i, relpose_attr.default)
                    while len(relpose_values) <= i:
                        relpose_values.append(None)
                    relpose_values[i] = merge_xform * relpose

            if body2_was_merged and constraint_type == EqType.WELD:
                merge_xform = body_merged_transform[old_body2]
                anchor = axis_to_vec3(_at(anchor_values, i, anchor_attr.default))
                relpose = _at(relpose_values, i, relpose_attr.default)
                while len(anchor_values) <= i:
                    anchor_values.append(None)
                while len(relpose_values) <= i:
                    relpose_values.append(None)
                anchor_values[i] = wp.transform_point(merge_xform, anchor)
                relpose_values[i] = relpose * wp.transform_inverse(merge_xform)

            old_joint1 = _at(joint1_values, i, joint1_attr.default)
            old_joint2 = _at(joint2_values, i, joint2_attr.default)

            if old_joint1 != -1 and old_joint1 not in joint_remap:
                if verbose:
                    print(f"Warning: Equality constraint references removed joint {old_joint1}, disabling constraint")
                while len(enabled_values) <= i:
                    enabled_values.append(None)
                enabled_values[i] = False

            if old_joint2 != -1 and old_joint2 not in joint_remap:
                if verbose:
                    print(f"Warning: Equality constraint references removed joint {old_joint2}, disabling constraint")
                while len(enabled_values) <= i:
                    enabled_values.append(None)
                enabled_values[i] = False

        # Remap mimic constraint joint indices
        for i in range(len(self.constraint_mimic_joint0)):
            old_joint0 = self.constraint_mimic_joint0[i]
            old_joint1 = self.constraint_mimic_joint1[i]

            if old_joint0 in joint_remap:
                self.constraint_mimic_joint0[i] = joint_remap[old_joint0]
            elif old_joint0 != -1:
                if verbose:
                    print(f"Warning: Mimic constraint references removed joint {old_joint0}, disabling constraint")
                self.constraint_mimic_enabled[i] = False

            if old_joint1 in joint_remap:
                self.constraint_mimic_joint1[i] = joint_remap[old_joint1]
            elif old_joint1 != -1:
                if verbose:
                    print(f"Warning: Mimic constraint references removed joint {old_joint1}, disabling constraint")
                self.constraint_mimic_enabled[i] = False

        target_kind_attr = self.custom_attributes.get("mujoco:equality_constraint_target_kind")
        target_attr = self.custom_attributes.get("mujoco:equality_constraint_target")
        if target_kind_attr is not None and target_attr is not None and target_attr.values:
            for eq_idx in range(len(target_attr.values)):
                target = target_attr.values[eq_idx]
                if target is None:
                    continue
                target_kind_value = (
                    target_kind_attr.values[eq_idx]
                    if target_kind_attr.values and eq_idx < len(target_kind_attr.values)
                    else None
                )
                try:
                    target_kind = int(target_kind_value) if target_kind_value is not None else 0
                    old_target = int(target)
                except (TypeError, ValueError):
                    continue
                if old_target < 0:
                    continue
                if target_kind == 1:
                    if old_target in joint_remap:
                        target_attr.values[eq_idx] = joint_remap[old_target]
                    else:
                        target_attr.values[eq_idx] = -1
                        target_kind_attr.values[eq_idx] = 0
                elif target_kind == 2 and old_target >= len(self.constraint_mimic_joint0):
                    target_attr.values[eq_idx] = -1
                    target_kind_attr.values[eq_idx] = 0

        # Generic entity-reference remap for any custom attribute that points at bodies or joints
        # (e.g. ``mujoco:equality_constraint_body1/joint1`` and MuJoCo tendon joint references).
        # Body references follow merges: a reference to a body that was merged into its parent
        # resolves to the surviving parent. Joint references to removed joints collapse to -1.
        # Domain-specific fixups that need the original indices run above, before this rewrite.
        def _remap_body_reference(value: Any) -> Any:
            if value is None:
                return value
            try:
                idx = int(value)
            except (TypeError, ValueError):
                return value
            if idx in body_remap:
                return body_remap[idx]
            if idx in body_merged_parent:
                return body_remap[body_merged_parent[idx]]
            return value

        def _remap_joint_reference(value: Any) -> Any:
            if value is None:
                return value
            try:
                idx = int(value)
            except (TypeError, ValueError):
                return value
            if idx == -1:
                return value
            return joint_remap.get(idx, -1)

        for custom_attr in self.custom_attributes.values():
            if custom_attr.references == "body":
                remap_reference = _remap_body_reference
            elif custom_attr.references == "joint":
                remap_reference = _remap_joint_reference
            else:
                continue
            if custom_attr.values is None:
                continue
            if isinstance(custom_attr.values, dict):
                custom_attr.values = {key: remap_reference(value) for key, value in custom_attr.values.items()}
            else:
                custom_attr.values = [remap_reference(value) for value in custom_attr.values]

        # Rebuild parent/child lookups
        self.joint_parents.clear()
        self.joint_children.clear()
        for i, (p, c) in enumerate(zip(self.joint_parent, self.joint_child, strict=True)):
            if c not in self.joint_parents:
                self.joint_parents[c] = [(p, i)]
            else:
                self.joint_parents[c].append((p, i))

            if p not in self.joint_children:
                self.joint_children[p] = [(c, i)]
            else:
                self.joint_children[p].append((c, i))

        return {
            "body_remap": body_remap,
            "joint_remap": joint_remap,
            "articulation_remap": articulation_remap,
            "body_merged_parent": body_merged_parent,
            "body_merged_transform": body_merged_transform,
            # TODO clean up this data
            "merged_body_data": merged_body_data,
        }

    # muscles
    def add_muscle(
        self, bodies: list[int], positions: list[Vec3], f0: float, lm: float, lt: float, lmax: float, pen: float
    ) -> int:
        """Adds a muscle-tendon activation unit.

        Args:
            bodies: A list of body indices for each waypoint
            positions: A list of positions of each waypoint in the body's local frame
            f0: Force scaling
            lm: Muscle length
            lt: Tendon length
            lmax: Maximally efficient muscle length
            pen: Penalty factor

        Returns:
            The index of the muscle in the model

        .. note:: The simulation support for muscles is in progress and not yet fully functional.

        """

        n = len(bodies)

        self.muscle_start.append(len(self.muscle_bodies))
        self.muscle_params.append((f0, lm, lt, lmax, pen))
        self.muscle_activations.append(0.0)

        for i in range(n):
            self.muscle_bodies.append(bodies[i])
            self.muscle_points.append(positions[i])

        # return the index of the muscle
        return len(self.muscle_start) - 1

    # region shapes

    def add_shape(
        self,
        *,
        body: int,
        type: int,
        xform: Transform | None = None,
        cfg: ShapeConfig | None = None,
        scale: Vec3 | None = None,
        src: Mesh | Gaussian | Heightfield | Any | None = None,
        is_static: bool = False,
        color: Vec3 | None = None,
        opacity: float | None = None,
        label: str | None = None,
        custom_attributes: dict[str, Any] | None = None,
    ) -> int:
        """Adds a generic collision shape to the model.

        This is the base method for adding shapes; prefer using specific helpers like :meth:`add_shape_sphere` where possible.

        Args:
            body: The index of the parent body this shape belongs to. Use -1 for shapes not attached to any specific body (e.g., static world geometry).
            type: The geometry type of the shape (e.g., `GeoType.BOX`, `GeoType.SPHERE`).
            xform: The transform of the shape in the parent body's local frame. If `None`, the identity transform `wp.transform()` is used. Defaults to `None`.
            cfg: The configuration for the shape's physical and collision properties. If `None`, :attr:`default_shape_cfg` is used. Defaults to `None`.
            scale: The scale of the geometry. The interpretation depends on the shape type. Defaults to `(1.0, 1.0, 1.0)` if `None`.
                Negative components are accepted and silently absorbed via ``abs()`` for symmetric primitives
                (sphere, box, capsule, cylinder, ellipsoid, plane, gaussian) since these shapes are point-symmetric.
                Mesh-class shapes (``MESH``, ``CONVEX_MESH``, SDF, hydroelastic) preserve the sign and treat
                ``det(scale) < 0`` as a mirror; the same :class:`Mesh` instance can be shared across shapes with
                different signed scales. Cone and heightfield shapes raise :class:`ValueError` on negative components.
            src: The source geometry data, e.g., a :class:`Mesh` object for `GeoType.MESH`. Defaults to `None`.
            is_static: If `True`, the shape will have zero mass, and its density property in `cfg` will be effectively ignored for mass calculation. Typically used for fixed, non-movable collision geometry. Defaults to `False`.
            color: Optional display RGB color with values in [0, 1]. If `None`, mesh-backed shapes fall back to :attr:`~newton.Mesh.color`; otherwise the per-shape palette sequence is used.
            opacity: Optional display opacity with value in [0, 1]. If `None`, uses full opacity. Mesh-backed shapes fall back to :attr:`~newton.Mesh.opacity`.
            label: An optional unique label for identifying the shape. If `None`, a default label is automatically generated (e.g., "shape_N"). Defaults to `None`.
            custom_attributes: Dictionary of custom attribute names to values.

        Returns:
            The index of the newly added shape.
        """
        if xform is None:
            xform = wp.transform()
        else:
            xform = wp.transform(*xform)
        if cfg is None:
            cfg = self.default_shape_cfg
        cfg.validate(shape_type=type)
        # Both raw meshes and convex-mesh approximations share the mesh-backed
        # SDF code path; cfg.sdf_* fields belong on Mesh.build_sdf, not the
        # ShapeConfig, so reject them for both shape types up front instead of
        # producing empty texture data later in finalize().
        if type in (GeoType.MESH, GeoType.CONVEX_MESH):
            if (
                cfg.sdf_max_resolution is not None
                or cfg.sdf_target_voxel_size is not None
                or cfg.sdf_narrow_band_range != (-0.1, 0.1)
                or cfg.sdf_texture_format != "uint16"
                or cfg.sdf_padding is not None
            ):
                raise ValueError(
                    "Mesh-backed shapes do not use cfg.sdf_* for SDF generation. "
                    "Build and attach an SDF on the mesh via mesh.build_sdf()."
                )
            if cfg.is_hydroelastic and (src is None or getattr(src, "sdf", None) is None):
                raise ValueError(
                    "Hydroelastic mesh-backed shapes require mesh.sdf. "
                    "Call mesh.build_sdf() before adding a mesh-backed hydroelastic shape."
                )
        if scale is None:
            scale = (1.0, 1.0, 1.0)

        # Normalize / validate negative scale components by shape type. Symmetric
        # primitives (sphere, box, capsule, cylinder, ellipsoid, plane, gaussian)
        # are point-symmetric and produce identical geometry under sign flip of any
        # scale component, so we silently absorb the sign. Cones are rotationally
        # symmetric around their height axis (+Z, with apex at +half_height), so
        # the radial sign on scale[0] is silently absorbed (scale[2] is unused);
        # a negative half-height (scale[1]) would swap the apex and base and is
        # rejected. Heightfields are not yet supported with mirroring (row/col
        # ordering semantics). Mesh-class shapes carry signed scale natively
        # through the collision pipeline.
        if type in (
            GeoType.SPHERE,
            GeoType.BOX,
            GeoType.CAPSULE,
            GeoType.CYLINDER,
            GeoType.ELLIPSOID,
            GeoType.PLANE,
            GeoType.GAUSSIAN,
        ):
            scale = (abs(float(scale[0])), abs(float(scale[1])), abs(float(scale[2])))
            site_size_is_display = cfg.is_site and bool(
                custom_attributes and custom_attributes.get("mujoco:site_size_is_display", False)
            )
            if type == GeoType.CYLINDER and not site_size_is_display and scale[2] != 0.0 and scale[2] < scale[1]:
                raise ValueError(f"Cylinder barrel radius must be zero or at least the half-height; got scale={scale}.")
        elif type == GeoType.CONE:
            if float(scale[1]) < 0.0:
                raise ValueError(
                    f"Cone shape requires non-negative height scale (scale[1]); got {tuple(float(s) for s in scale)}. "
                    "A negative height would swap the apex and base."
                )
            scale = (abs(float(scale[0])), float(scale[1]), abs(float(scale[2])))
        elif type == GeoType.HFIELD:
            if any(float(s) < 0.0 for s in scale):
                raise ValueError(
                    f"Heightfield shape requires non-negative scale; got {tuple(float(s) for s in scale)}. "
                    "Mirroring of heightfields is not yet supported."
                )

        # Validate site invariants
        if cfg.is_site:
            shape_label = label or f"shape_{self.shape_count}"

            # Sites must not have collision enabled
            if cfg.has_shape_collision or cfg.has_particle_collision:
                raise ValueError(
                    f"Site shape '{shape_label}' cannot have collision enabled. "
                    f"Sites must be non-colliding reference points. "
                    f"has_shape_collision={cfg.has_shape_collision}, "
                    f"has_particle_collision={cfg.has_particle_collision}"
                )

            # Sites must have zero density (no mass contribution)
            if cfg.density != 0.0:
                raise ValueError(
                    f"Site shape '{shape_label}' must have zero density. "
                    f"Sites do not contribute to body mass. "
                    f"Got density={cfg.density}"
                )

            # Sites must have collision group 0 (no collision filtering)
            if cfg.collision_group != 0:
                raise ValueError(
                    f"Site shape '{shape_label}' must have collision_group=0. "
                    f"Sites do not participate in collision detection. "
                    f"Got collision_group={cfg.collision_group}"
                )

        resolved_opacity = opacity
        if resolved_opacity is None and src is not None:
            resolved_opacity = getattr(src, "opacity", None)
        if resolved_opacity is None:
            resolved_opacity = 1.0
        resolved_opacity = _validate_opacity(resolved_opacity, "Shape opacity")

        self.shape_body.append(body)
        shape = self.shape_count
        if cfg.has_shape_collision:
            # no contacts between shapes of the same body
            for same_body_shape in self.body_shapes[body]:
                if not self.shape_flags[same_body_shape] & ShapeFlags.COLLIDE_SHAPES:
                    continue
                self.add_shape_collision_filter_pair(same_body_shape, shape)
        self.body_shapes[body].append(shape)
        self.shape_label.append(label or f"shape_{shape}")
        self.shape_transform.append(xform)
        # Get flags and clear HYDROELASTIC for unsupported shape types (PLANE, HFIELD)
        shape_flags = cfg.flags
        if (shape_flags & ShapeFlags.HYDROELASTIC) and (type == GeoType.PLANE or type == GeoType.HFIELD):
            shape_flags &= (
                ~ShapeFlags.HYDROELASTIC
            )  # Falling back to mesh/primitive collisions for plane and hfield shapes

        resolved_color = ModelBuilder._coerce_shape_color(color)
        if resolved_color is None and src is not None:
            resolved_color = ModelBuilder._coerce_shape_color(getattr(src, "color", None))
        if resolved_color is None:
            resolved_color = ModelBuilder._shape_palette_color(shape)

        self.shape_flags.append(shape_flags)
        self.shape_type.append(type)
        self.shape_scale.append((float(scale[0]), float(scale[1]), float(scale[2])))
        self.shape_source.append(src)
        self.shape_color.append(resolved_color)
        self.shape_opacity.append(resolved_opacity)
        self.shape_margin.append(cfg.margin)
        self.shape_is_solid.append(cfg.is_solid)
        self.shape_material_ke.append(cfg.ke)
        self.shape_material_kd.append(cfg.kd)
        self.shape_material_kf.append(cfg.kf)
        self.shape_material_ka.append(cfg.ka)
        self.shape_material_mu.append(cfg.mu)
        self.shape_material_restitution.append(cfg.restitution)
        self.shape_material_mu_torsional.append(cfg.mu_torsional)
        self.shape_material_mu_rolling.append(cfg.mu_rolling)
        self.shape_material_kh.append(cfg.kh)
        self.shape_gap.append(cfg.gap if cfg.gap is not None else self.rigid_gap)
        self.shape_collision_group.append(cfg.collision_group)
        self.shape_collision_radius.append(compute_shape_radius(type, scale, src))
        self.shape_world.append(self.current_world)
        self.shape_sdf_narrow_band_range.append(cfg.sdf_narrow_band_range)
        self.shape_sdf_target_voxel_size.append(cfg.sdf_target_voxel_size)
        self.shape_sdf_max_resolution.append(cfg.sdf_max_resolution)
        self.shape_force_sdf.append(cfg.force_sdf)
        self.shape_sdf_texture_format.append(cfg.sdf_texture_format)
        self.shape_sdf_padding.append(cfg.sdf_padding)

        if cfg.has_shape_collision and cfg.collision_filter_parent:
            for parent_body, joint_idx in self.joint_parents.get(body, ()):
                if not self.joint_collision_filter_parent[joint_idx]:
                    continue
                for parent_shape in self.body_shapes[parent_body]:
                    if not self.shape_flags[parent_shape] & ShapeFlags.COLLIDE_SHAPES:
                        continue
                    self.add_shape_collision_filter_pair(parent_shape, shape)
            for child_body, joint_idx in self.joint_children.get(body, ()):
                if not self.joint_collision_filter_parent[joint_idx]:
                    continue
                for child_shape in self.body_shapes[child_body]:
                    if not self.shape_flags[child_shape] & ShapeFlags.COLLIDE_SHAPES:
                        continue
                    self.add_shape_collision_filter_pair(shape, child_shape)

        if not is_static and cfg.density > 0.0 and body >= 0 and not self.body_lock_inertia[body]:
            (m, c, inertia) = compute_inertia_shape(type, scale, src, cfg.density, cfg.is_solid, cfg.margin)
            com_body = wp.transform_point(xform, c)
            self._update_body_mass(body, m, inertia, com_body, xform.q)

        # Process custom attributes
        if custom_attributes:
            self._process_custom_attributes(
                entity_index=shape,
                custom_attrs=custom_attributes,
                expected_frequency=Model.AttributeFrequency.SHAPE,
            )

        return shape

    def add_shape_plane(
        self,
        plane: Vec4 | None = (0.0, 0.0, 1.0, 0.0),
        *,
        xform: Transform | None = None,
        width: float = 10.0,
        length: float = 10.0,
        body: int = -1,
        cfg: ShapeConfig | None = None,
        color: Vec3 | None = None,
        opacity: float | None = None,
        label: str | None = None,
        custom_attributes: dict[str, Any] | None = None,
    ) -> int:
        """
        Adds a plane collision shape to the model.

        If `xform` is provided, it directly defines the plane's position and orientation. The plane's collision normal
        is assumed to be along the local Z-axis of this `xform`.
        If `xform` is `None`, it will be derived from the `plane` equation `a*x + b*y + c*z + d = 0`.
        Plane shapes added via this method are always static (massless).

        Args:
            plane: The plane equation `(a, b, c, d)`. If `xform` is `None`, this defines the plane.
                The normal is `(a,b,c)`. If `(a,b,c)` is unit-length, `d` is the negative signed offset from the
                origin along that normal, so `(0.0, 0.0, 1.0, -h)` defines the plane `z = h`. Defaults to
                `(0.0, 0.0, 1.0, 0.0)` (an XY ground plane at Z=0) if `xform` is also `None`.
            xform: The transform of the plane in the world or parent body's frame. If `None`, transform is derived from `plane`. Defaults to `None`.
            width: The visual/collision extent of the plane along its local X-axis. If `0.0`, considered infinite for collision. Defaults to `10.0`.
            length: The visual/collision extent of the plane along its local Y-axis. If `0.0`, considered infinite for collision. Defaults to `10.0`.
            body: The index of the parent body this shape belongs to. Use -1 for world-static planes. Defaults to `-1`.
            cfg: The configuration for the shape's physical and collision properties. If `None`, :attr:`default_shape_cfg` is used. Defaults to `None`.
            color: Optional display RGB color with values in [0, 1]. If `None`, uses the per-shape palette color.
            opacity: Optional display opacity with value in [0, 1]. If `None`, uses full opacity.
            label: An optional unique label for identifying the shape. If `None`, a default label is automatically generated. Defaults to `None`.
            custom_attributes: Dictionary of custom attribute values for SHAPE frequency attributes.

        Returns:
            The index of the newly added shape.
        """
        if xform is None:
            assert plane is not None, "Either xform or plane must be provided"
            # compute position and rotation from plane equation
            # For plane equation ax + by + cz + d = 0, the closest point to the origin is
            # -(d/||n||) * (n/||n||), so the signed offset along the normalized normal is -d/||n||.
            normal = np.array(plane[:3])
            norm = np.linalg.norm(normal)
            normal /= norm
            d_normalized = plane[3] / norm
            pos = -d_normalized * normal
            # compute rotation from local +Z axis to plane normal
            rot = wp.quat_between_vectors(wp.vec3(0.0, 0.0, 1.0), wp.vec3(*normal))
            xform = wp.transform(pos, rot)
        if cfg is None:
            cfg = self.default_shape_cfg
        scale = wp.vec3(width, length, 0.0)
        return self.add_shape(
            body=body,
            type=GeoType.PLANE,
            xform=xform,
            cfg=cfg,
            scale=scale,
            is_static=True,
            label=label,
            custom_attributes=custom_attributes,
            color=color,
            opacity=opacity,
        )

    def add_ground_plane(
        self,
        *,
        height: float = 0.0,
        cfg: ShapeConfig | None = None,
        color: Vec3 | None = _DEFAULT_GROUND_PLANE_COLOR,
        opacity: float | None = None,
        label: str | None = None,
    ) -> int:
        """Adds a ground plane collision shape to the model.

        Args:
            height: The vertical offset of the ground plane along the up-vector axis. Positive values raise the plane, negative values lower it. Defaults to `0.0`.
            cfg: The configuration for the shape's physical and collision properties. If `None`, :attr:`default_shape_cfg` is used. Defaults to `None`.
            color: Optional display RGB color with values in [0, 1]. Defaults to the ground plane color ``(0.125, 0.125, 0.15)``. Pass ``None`` to use the per-shape palette color instead.
            opacity: Optional display opacity with value in [0, 1]. If `None`, uses full opacity.
            label: An optional unique label for identifying the shape. If `None`, a default label is automatically generated. Defaults to `None`.

        Returns:
            The index of the newly added shape.
        """
        return self.add_shape_plane(
            plane=(*self.up_vector, -height),
            width=0.0,
            length=0.0,
            cfg=cfg,
            label=label or "ground_plane",
            color=color,
            opacity=opacity,
        )

    def add_shape_sphere(
        self,
        body: int,
        *,
        xform: Transform | None = None,
        radius: float = 1.0,
        cfg: ShapeConfig | None = None,
        as_site: bool = False,
        color: Vec3 | None = None,
        opacity: float | None = None,
        label: str | None = None,
        custom_attributes: dict[str, Any] | None = None,
    ) -> int:
        """Adds a sphere collision shape or site to a body.

        Args:
            body: The index of the parent body this shape belongs to. Use -1 for shapes not attached to any specific body.
            xform: The transform of the sphere in the parent body's local frame. The sphere is centered at this transform's position. If `None`, the identity transform `wp.transform()` is used. Defaults to `None`.
            radius: The radius of the sphere. Defaults to `1.0`.
            cfg: The configuration for the shape's properties. If `None`, uses :attr:`default_shape_cfg` (or :attr:`default_site_cfg` when `as_site=True`). If `as_site=True` and `cfg` is provided, a copy is made and site invariants are enforced via `mark_as_site()`. Defaults to `None`.
            as_site: If `True`, creates a site (non-colliding reference point) instead of a collision shape. Defaults to `False`.
            color: Optional display RGB color with values in [0, 1]. If `None`, uses the per-shape palette color.
            opacity: Optional display opacity with value in [0, 1]. If `None`, uses full opacity.
            label: An optional unique label for identifying the shape. If `None`, a default label is automatically generated. Defaults to `None`.
            custom_attributes: Dictionary of custom attribute names to values.

        Returns:
            The index of the newly added shape or site.
        """
        if cfg is None:
            cfg = self.default_site_cfg if as_site else self.default_shape_cfg
        elif as_site:
            cfg = cfg.copy()
            cfg.mark_as_site()

        scale: Vec3 = wp.vec3(radius, 0.0, 0.0)
        return self.add_shape(
            body=body,
            type=GeoType.SPHERE,
            xform=xform,
            cfg=cfg,
            scale=scale,
            label=label,
            custom_attributes=custom_attributes,
            color=color,
            opacity=opacity,
        )

    def add_shape_ellipsoid(
        self,
        body: int,
        *,
        xform: Transform | None = None,
        rx: float = 1.0,
        ry: float = 0.75,
        rz: float = 0.5,
        cfg: ShapeConfig | None = None,
        as_site: bool = False,
        color: Vec3 | None = None,
        opacity: float | None = None,
        label: str | None = None,
        custom_attributes: dict[str, Any] | None = None,
    ) -> int:
        """Adds an ellipsoid collision shape or site to a body.

        The ellipsoid is centered at its local origin as defined by `xform`, with semi-axes
        `rx`, `ry`, `rz` along the local X, Y, Z axes respectively.

        Note:
            Ellipsoid collision is handled by the GJK/MPR collision pipeline,
            which provides accurate collision detection for all convex shape pairs.

        Args:
            body: The index of the parent body this shape belongs to. Use -1 for shapes not attached to any specific body.
            xform: The transform of the ellipsoid in the parent body's local frame. If `None`, the identity transform `wp.transform()` is used. Defaults to `None`.
            rx: The semi-axis of the ellipsoid along its local X-axis [m]. Defaults to `1.0`.
            ry: The semi-axis of the ellipsoid along its local Y-axis [m]. Defaults to `0.75`.
            rz: The semi-axis of the ellipsoid along its local Z-axis [m]. Defaults to `0.5`.
            cfg: The configuration for the shape's properties. If `None`, uses :attr:`default_shape_cfg` (or :attr:`default_site_cfg` when `as_site=True`). If `as_site=True` and `cfg` is provided, a copy is made and site invariants are enforced via `mark_as_site()`. Defaults to `None`.
            as_site: If `True`, creates a site (non-colliding reference point) instead of a collision shape. Defaults to `False`.
            color: Optional display RGB color with values in [0, 1]. If ``None``, uses the per-shape palette color.
            opacity: Optional display opacity with value in [0, 1]. If `None`, uses full opacity.
            label: An optional unique label for identifying the shape. If `None`, a default label is automatically generated. Defaults to `None`.
            custom_attributes: Dictionary of custom attribute names to values.

        Returns:
            The index of the newly added shape or site.

        Example:
            Create an ellipsoid with different semi-axes:

            .. doctest::

                builder = newton.ModelBuilder()
                body = builder.add_body()

                # Add an ellipsoid with semi-axes 1.0, 0.5, 0.25
                builder.add_shape_ellipsoid(
                    body=body,
                    rx=1.0,  # X semi-axis
                    ry=0.5,  # Y semi-axis
                    rz=0.25,  # Z semi-axis
                )

                # A sphere is a special case where rx = ry = rz
                builder.add_shape_ellipsoid(body=body, rx=0.5, ry=0.5, rz=0.5)
        """
        if cfg is None:
            cfg = self.default_site_cfg if as_site else self.default_shape_cfg
        elif as_site:
            cfg = cfg.copy()
            cfg.mark_as_site()

        scale = wp.vec3(rx, ry, rz)
        return self.add_shape(
            body=body,
            type=GeoType.ELLIPSOID,
            xform=xform,
            cfg=cfg,
            scale=scale,
            label=label,
            custom_attributes=custom_attributes,
            color=color,
            opacity=opacity,
        )

    def add_shape_box(
        self,
        body: int,
        *,
        xform: Transform | None = None,
        hx: float = 0.5,
        hy: float = 0.5,
        hz: float = 0.5,
        cfg: ShapeConfig | None = None,
        as_site: bool = False,
        color: Vec3 | None = None,
        opacity: float | None = None,
        label: str | None = None,
        custom_attributes: dict[str, Any] | None = None,
    ) -> int:
        """Adds a box collision shape or site to a body.

        The box is centered at its local origin as defined by `xform`.

        Args:
            body: The index of the parent body this shape belongs to. Use -1 for shapes not attached to any specific body.
            xform: The transform of the box in the parent body's local frame. If `None`, the identity transform `wp.transform()` is used. Defaults to `None`.
            hx: The half-extent of the box along its local X-axis. Defaults to `0.5`.
            hy: The half-extent of the box along its local Y-axis. Defaults to `0.5`.
            hz: The half-extent of the box along its local Z-axis. Defaults to `0.5`.
            cfg: The configuration for the shape's properties. If `None`, uses :attr:`default_shape_cfg` (or :attr:`default_site_cfg` when `as_site=True`). If `as_site=True` and `cfg` is provided, a copy is made and site invariants are enforced via `mark_as_site()`. Defaults to `None`.
            as_site: If `True`, creates a site (non-colliding reference point) instead of a collision shape. Defaults to `False`.
            color: Optional display RGB color with values in [0, 1]. If ``None``, uses the per-shape palette color.
            opacity: Optional display opacity with value in [0, 1]. If `None`, uses full opacity.
            label: An optional unique label for identifying the shape. If `None`, a default label is automatically generated. Defaults to `None`.
            custom_attributes: Dictionary of custom attribute names to values.

        Returns:
            The index of the newly added shape or site.
        """
        if cfg is None:
            cfg = self.default_site_cfg if as_site else self.default_shape_cfg
        elif as_site:
            cfg = cfg.copy()
            cfg.mark_as_site()

        scale = wp.vec3(hx, hy, hz)
        return self.add_shape(
            body=body,
            type=GeoType.BOX,
            xform=xform,
            cfg=cfg,
            scale=scale,
            label=label,
            custom_attributes=custom_attributes,
            color=color,
            opacity=opacity,
        )

    def add_shape_capsule(
        self,
        body: int,
        *,
        xform: Transform | None = None,
        radius: float = 1.0,
        half_height: float = 0.5,
        cfg: ShapeConfig | None = None,
        as_site: bool = False,
        color: Vec3 | None = None,
        opacity: float | None = None,
        label: str | None = None,
        custom_attributes: dict[str, Any] | None = None,
    ) -> int:
        """Adds a capsule collision shape or site to a body.

        The capsule is centered at its local origin as defined by `xform`. Its length extends along the Z-axis.

        Args:
            body: The index of the parent body this shape belongs to. Use -1 for shapes not attached to any specific body.
            xform: The transform of the capsule in the parent body's local frame. If `None`, the identity transform `wp.transform()` is used. Defaults to `None`.
            radius: The radius of the capsule's hemispherical ends and its cylindrical segment. Defaults to `1.0`.
            half_height: The half-length of the capsule's central cylindrical segment (excluding the hemispherical ends). Defaults to `0.5`.
            cfg: The configuration for the shape's properties. If `None`, uses :attr:`default_shape_cfg` (or :attr:`default_site_cfg` when `as_site=True`). If `as_site=True` and `cfg` is provided, a copy is made and site invariants are enforced via `mark_as_site()`. Defaults to `None`.
            as_site: If `True`, creates a site (non-colliding reference point) instead of a collision shape. Defaults to `False`.
            color: Optional display RGB color with values in [0, 1]. If ``None``, uses the per-shape palette color.
            opacity: Optional display opacity with value in [0, 1]. If `None`, uses full opacity.
            label: An optional unique label for identifying the shape. If `None`, a default label is automatically generated. Defaults to `None`.
            custom_attributes: Dictionary of custom attribute names to values.

        Returns:
            The index of the newly added shape or site.
        """
        if cfg is None:
            cfg = self.default_site_cfg if as_site else self.default_shape_cfg
        elif as_site:
            cfg = cfg.copy()
            cfg.mark_as_site()

        if xform is None:
            xform = wp.transform()
        else:
            xform = wp.transform(*xform)

        scale = wp.vec3(radius, half_height, 0.0)
        return self.add_shape(
            body=body,
            type=GeoType.CAPSULE,
            xform=xform,
            cfg=cfg,
            scale=scale,
            label=label,
            custom_attributes=custom_attributes,
            color=color,
            opacity=opacity,
        )

    def add_shape_cylinder(
        self,
        body: int,
        *,
        xform: Transform | None = None,
        radius: float = 1.0,
        half_height: float = 0.5,
        barrel_radius: float = 0.0,
        cfg: ShapeConfig | None = None,
        as_site: bool = False,
        color: Vec3 | None = None,
        opacity: float | None = None,
        label: str | None = None,
        custom_attributes: dict[str, Any] | None = None,
    ) -> int:
        """Adds a cylinder collision shape or site to a body.

        The cylinder is centered at its local origin as defined by `xform`. Its length extends along the Z-axis.

        Args:
            body: The index of the parent body this shape belongs to. Use -1 for shapes not attached to any specific body.
            xform: The transform of the cylinder in the parent body's local frame. If `None`, the identity transform `wp.transform()` is used. Defaults to `None`.
            radius: The radius of the cylinder at its ends [m]. Defaults to `1.0`.
            half_height: The half-length of the cylinder along the Z-axis [m]. Defaults to `0.5`.
            barrel_radius: The radius of the symmetric circular arc revolved around the Z-axis to form
                the cylinder's side [m]. Use `0.0` for a straight-sided cylinder. Nonzero values must be
                at least `half_height`. Defaults to `0.0`.
            cfg: The configuration for the shape's properties. If `None`, uses :attr:`default_shape_cfg` (or :attr:`default_site_cfg` when `as_site=True`). If `as_site=True` and `cfg` is provided, a copy is made and site invariants are enforced via `mark_as_site()`. Defaults to `None`.
            as_site: If `True`, creates a site (non-colliding reference point) instead of a collision shape. Defaults to `False`.
            color: Optional display RGB color with values in [0, 1]. If ``None``, uses the per-shape palette color.
            opacity: Optional display opacity with value in [0, 1]. If `None`, uses full opacity.
            label: An optional unique label for identifying the shape. If `None`, a default label is automatically generated. Defaults to `None`.
            custom_attributes: Dictionary of custom attribute values for SHAPE frequency attributes.

        Returns:
            The index of the newly added shape or site.
        """
        if cfg is None:
            cfg = self.default_site_cfg if as_site else self.default_shape_cfg
        elif as_site:
            cfg = cfg.copy()
            cfg.mark_as_site()

        if xform is None:
            xform = wp.transform()
        else:
            xform = wp.transform(*xform)

        scale = wp.vec3(radius, half_height, barrel_radius)
        return self.add_shape(
            body=body,
            type=GeoType.CYLINDER,
            xform=xform,
            cfg=cfg,
            scale=scale,
            label=label,
            custom_attributes=custom_attributes,
            color=color,
            opacity=opacity,
        )

    def add_shape_cone(
        self,
        body: int,
        *,
        xform: Transform | None = None,
        radius: float = 1.0,
        half_height: float = 0.5,
        cfg: ShapeConfig | None = None,
        as_site: bool = False,
        color: Vec3 | None = None,
        opacity: float | None = None,
        label: str | None = None,
        custom_attributes: dict[str, Any] | None = None,
    ) -> int:
        """Adds a cone collision shape to a body.

        The cone's origin is at its geometric center, with the base at -half_height and apex at +half_height along the Z-axis.
        The center of mass is located at -half_height/2 from the origin (1/4 of the total height from the base toward the apex).

        Args:
            body: The index of the parent body this shape belongs to. Use -1 for shapes not attached to any specific body.
            xform: The transform of the cone in the parent body's local frame. If `None`, the identity transform `wp.transform()` is used. Defaults to `None`.
            radius: The radius of the cone's base. Defaults to `1.0`.
            half_height: The half-height of the cone (distance from the geometric center to either the base or apex). The total height is 2*half_height. Defaults to `0.5`.
            cfg: The configuration for the shape's physical and collision properties. If `None`, :attr:`default_shape_cfg` is used. Defaults to `None`.
            as_site: If `True`, creates a site (non-colliding reference point) instead of a collision shape. Defaults to `False`.
            color: Optional display RGB color with values in [0, 1]. If ``None``, uses the per-shape palette color.
            opacity: Optional display opacity with value in [0, 1]. If `None`, uses full opacity.
            label: An optional unique label for identifying the shape. If `None`, a default label is automatically generated. Defaults to `None`.
            custom_attributes: Dictionary of custom attribute values for SHAPE frequency attributes.

        Returns:
            The index of the newly added shape.
        """
        if cfg is None:
            cfg = self.default_site_cfg if as_site else self.default_shape_cfg
        elif as_site:
            cfg = cfg.copy()
            cfg.mark_as_site()

        if xform is None:
            xform = wp.transform()
        else:
            xform = wp.transform(*xform)

        scale = wp.vec3(radius, half_height, 0.0)
        return self.add_shape(
            body=body,
            type=GeoType.CONE,
            xform=xform,
            cfg=cfg,
            scale=scale,
            label=label,
            custom_attributes=custom_attributes,
            color=color,
            opacity=opacity,
        )

    def add_shape_mesh(
        self,
        body: int,
        *,
        xform: Transform | None = None,
        mesh: Mesh | None = None,
        scale: Vec3 | None = None,
        cfg: ShapeConfig | None = None,
        color: Vec3 | None = None,
        opacity: float | None = None,
        label: str | None = None,
        custom_attributes: dict[str, Any] | None = None,
    ) -> int:
        """Adds a triangle mesh collision shape to a body.

        Args:
            body: The index of the parent body this shape belongs to. Use -1 for shapes not attached to any specific body.
            xform: The transform of the mesh in the parent body's local frame. If `None`, the identity transform `wp.transform()` is used. Defaults to `None`.
            mesh: The :class:`Mesh` object containing the vertex and triangle data. Defaults to `None`.
            scale: The scale of the mesh. Defaults to `None`, in which case the scale is `(1.0, 1.0, 1.0)`.
            cfg: The configuration for the shape's physical and collision properties. If `None`, :attr:`default_shape_cfg` is used. Defaults to `None`.
            color: Optional display RGB color with values in [0, 1]. If `None`, falls back to :attr:`~newton.Mesh.color` when available.
            opacity: Optional display opacity with value in [0, 1]. If `None`, falls back to :attr:`~newton.Mesh.opacity` when available.
            label: An optional unique label for identifying the shape. If `None`, a default label is automatically generated. Defaults to `None`.
            custom_attributes: Dictionary of custom attribute values for SHAPE frequency attributes.

        Returns:
            The index of the newly added shape.
        """

        if cfg is None:
            cfg = self.default_shape_cfg
        return self.add_shape(
            body=body,
            type=GeoType.MESH,
            xform=xform,
            cfg=cfg,
            scale=scale,
            src=mesh,
            label=label,
            custom_attributes=custom_attributes,
            color=color,
            opacity=opacity,
        )

    def add_shape_convex_hull(
        self,
        body: int,
        *,
        xform: Transform | None = None,
        mesh: Mesh | None = None,
        scale: Vec3 | None = None,
        cfg: ShapeConfig | None = None,
        color: Vec3 | None = None,
        opacity: float | None = None,
        label: str | None = None,
        custom_attributes: dict[str, Any] | None = None,
    ) -> int:
        """Adds a convex hull collision shape to a body.

        Args:
            body: The index of the parent body this shape belongs to. Use -1 for shapes not attached to any specific body.
            xform: The transform of the convex hull in the parent body's local frame. If `None`, the identity transform `wp.transform()` is used. Defaults to `None`.
            mesh: The :class:`Mesh` object containing the vertex data for the convex hull. Defaults to `None`.
            scale: The scale of the convex hull. Defaults to `None`, in which case the scale is `(1.0, 1.0, 1.0)`.
            cfg: The configuration for the shape's physical and collision properties. If `None`, :attr:`default_shape_cfg` is used. Defaults to `None`.
            color: Optional display RGB color with values in [0, 1]. If `None`, falls back to :attr:`~newton.Mesh.color` when available.
            opacity: Optional display opacity with value in [0, 1]. If `None`, falls back to :attr:`~newton.Mesh.opacity` when available.
            label: An optional unique label for identifying the shape. If `None`, a default label is automatically generated. Defaults to `None`.
            custom_attributes: Dictionary of custom attribute values for SHAPE frequency attributes.

        Returns:
            The index of the newly added shape.
        """

        if cfg is None:
            cfg = self.default_shape_cfg
        return self.add_shape(
            body=body,
            type=GeoType.CONVEX_MESH,
            xform=xform,
            cfg=cfg,
            scale=scale,
            src=mesh,
            label=label,
            color=color,
            opacity=opacity,
            custom_attributes=custom_attributes,
        )

    def add_shape_heightfield(
        self,
        *,
        xform: Transform | None = None,
        heightfield: Heightfield | None = None,
        scale: Vec3 | None = None,
        cfg: ShapeConfig | None = None,
        color: Vec3 | None = None,
        opacity: float | None = None,
        label: str | None = None,
        custom_attributes: dict[str, Any] | None = None,
    ) -> int:
        """Adds a heightfield (2D elevation grid) collision shape to the model.

        Heightfields are efficient representations of terrain using a 2D grid of elevation values.
        They are always static (``body=-1``) and more memory-efficient than
        equivalent triangle meshes.

        Args:
            xform: The transform of the heightfield in world frame. If `None`, the identity transform `wp.transform()` is used. Defaults to `None`.
            heightfield: The :class:`Heightfield` object containing the elevation grid data. Defaults to `None`.
            scale: Per-instance scale applied to the heightfield extents (``hx``, ``hy``, ``min_z``, ``max_z``). Lets the same :class:`Heightfield` asset be reused at different sizes across shapes. Defaults to ``None``, which is treated as ``(1.0, 1.0, 1.0)``.
            cfg: The configuration for the shape's physical and collision properties. If `None`, :attr:`default_shape_cfg` is used. Defaults to `None`.
            color: Optional display RGB color with values in [0, 1]. If ``None``, uses the per-shape palette color.
            opacity: Optional display opacity with value in [0, 1]. If `None`, uses full opacity.
            label: An optional label for identifying the shape. If `None`, a default label is automatically generated. Defaults to `None`.
            custom_attributes: Dictionary of custom attribute values for SHAPE frequency attributes.

        Returns:
            The index of the newly added shape.
        """
        if heightfield is None:
            raise ValueError("add_shape_heightfield() requires a Heightfield instance.")
        if cfg is None:
            cfg = self.default_shape_cfg

        return self.add_shape(
            body=-1,
            type=GeoType.HFIELD,
            xform=xform,
            cfg=cfg,
            scale=scale,
            src=heightfield,
            is_static=True,
            label=label,
            custom_attributes=custom_attributes,
            color=color,
            opacity=opacity,
        )

    def add_shape_gaussian(
        self,
        body: int,
        *,
        xform: Transform | None = None,
        gaussian: Gaussian | None = None,
        scale: Vec3 | None = None,
        cfg: ShapeConfig | None = None,
        collision_proxy: str | Mesh | None = None,
        color: Vec3 | None = None,
        opacity: float | None = None,
        label: str | None = None,
        custom_attributes: dict[str, Any] | None = None,
    ) -> int:
        """Adds a Gaussian splat shape to a body.

        The Gaussian is attached as a ``GeoType.GAUSSIAN`` shape for rendering.
        Collision is handled separately via *collision_proxy*.

        Args:
            body: The index of the parent body this shape belongs to.
                Use ``-1`` for static world geometry.
            xform: Transform in parent body's local frame. Defaults to identity.
            gaussian: The :class:`Gaussian` splat asset.
            scale: 3D scale applied to Gaussian positions. Defaults to ``(1, 1, 1)``.
            cfg: Shape configuration. If ``None``, uses :attr:`default_shape_cfg`
                with ``has_shape_collision=False`` (Gaussians are render-only by
                default).
            collision_proxy: Collision strategy. Options:

                - ``None``: no collision (render-only).
                - ``"convex_hull"``: auto-generate convex hull from Gaussian positions.
                - A :class:`Mesh` instance: use the provided mesh as collision proxy.
            color: Optional display RGB color with values in [0, 1]. If ``None``, uses the per-shape palette color.
            opacity: Optional display opacity with value in [0, 1]. If `None`, uses full opacity.
            label: Optional unique label for identifying the shape.
            custom_attributes: Dictionary of custom attribute values for SHAPE
                frequency attributes.

        Returns:
            The index of the Gaussian shape.
        """
        if gaussian is None:
            raise TypeError("'gaussian' is required when adding a Gaussian shape.")

        if cfg is None:
            cfg = self.default_shape_cfg.copy()
        else:
            cfg = cfg.copy()

        # Gaussian shape is render-only; collisions are represented by optional proxy geometry.
        proxy_cfg_base = cfg.copy()
        cfg.has_shape_collision = False
        cfg.has_particle_collision = False
        cfg.density = 0.0

        # Optionally add a collision proxy alongside the Gaussian shape
        if collision_proxy is not None:
            if isinstance(collision_proxy, str):
                proxy_mesh = gaussian.compute_proxy_mesh(method=collision_proxy)
            elif isinstance(collision_proxy, Mesh):
                proxy_mesh = collision_proxy
            else:
                raise TypeError(f"collision_proxy must be None, a string, or a Mesh, got {type(collision_proxy)}")

            proxy_cfg = proxy_cfg_base.copy()
            proxy_cfg.is_visible = False
            proxy_cfg.has_shape_collision = True
            self.add_shape_convex_hull(
                body=body,
                xform=xform,
                mesh=proxy_mesh,
                scale=scale,
                cfg=proxy_cfg,
                label=f"{label or 'gaussian'}_collision_proxy",
            )

        return self.add_shape(
            body=body,
            type=GeoType.GAUSSIAN,
            xform=xform,
            cfg=cfg,
            scale=scale,
            src=gaussian,
            is_static=True,
            label=label,
            custom_attributes=custom_attributes,
            color=color,
            opacity=opacity,
        )

    def add_site(
        self,
        body: int,
        *,
        xform: Transform | None = None,
        type: int = GeoType.SPHERE,
        scale: Vec3 = (0.01, 0.01, 0.01),
        label: str | None = None,
        visible: bool = False,
        custom_attributes: dict[str, Any] | None = None,
    ) -> int:
        """Adds a site (non-colliding reference point) to a body.

        Sites are abstract markers that don't participate in physics simulation or collision detection.
        They are useful for:
        - Sensor attachment points (IMU, camera, etc.)
        - Frame of reference definitions
        - Debugging and visualization markers
        - Spatial tendon attachment points (when exported to MuJoCo)

        Args:
            body: The index of the parent body this site belongs to. Use -1 for sites not attached to any specific body (for sites defined a at static world position).
            xform: The transform of the site in the parent body's local frame. If `None`, the identity transform `wp.transform()` is used. Defaults to `None`.
            type: The geometry type for visualization (e.g., `GeoType.SPHERE`, `GeoType.BOX`). Defaults to `GeoType.SPHERE`.
            scale: The scale/size of the site for visualization. Defaults to `(0.01, 0.01, 0.01)`.
            label: An optional unique label for identifying the site. If `None`, a default label is automatically generated. Defaults to `None`.
            visible: If True, the site will be visible for debugging. If False (default), the site is hidden.
            custom_attributes: Dictionary of custom attribute names to values.

        Returns:
            The index of the newly added site (which is stored as a shape internally).

        Example:
            Add an IMU sensor site to a robot torso::

                body = builder.add_body()
                imu_site = builder.add_site(
                    body,
                    xform=wp.transform((0.0, 0.0, 0.1), wp.quat_identity()),
                    label="imu_sensor",
                    visible=True,  # Show for debugging
                )
        """
        # Create config for non-colliding site
        cfg = self.default_site_cfg.copy()
        cfg.is_visible = visible

        return self.add_shape(
            body=body,
            type=type,
            xform=xform,
            cfg=cfg,
            scale=scale,
            label=label,
            custom_attributes=custom_attributes,
        )

    def approximate_meshes(
        self,
        method: Literal["coacd", "vhacd", "bounding_sphere", "bounding_box"] | RemeshingMethod = "convex_hull",
        shape_indices: list[int] | None = None,
        raise_on_failure: bool = False,
        keep_visual_shapes: bool = False,
        **remeshing_kwargs: dict[str, Any],
    ) -> set[int]:
        """Approximates the mesh shapes of the model.

        The following methods are supported:

        +------------------------+-------------------------------------------------------------------------------+
        | Method                 | Description                                                                   |
        +========================+===============================================================================+
        | ``"coacd"``            | Convex decomposition using `CoACD <https://github.com/wjakob/coacd>`_         |
        +------------------------+-------------------------------------------------------------------------------+
        | ``"vhacd"``            | Convex decomposition using `V-HACD <https://github.com/trimesh/vhacdx>`_      |
        +------------------------+-------------------------------------------------------------------------------+
        | ``"bounding_sphere"``  | Approximate the mesh with a sphere                                            |
        +------------------------+-------------------------------------------------------------------------------+
        | ``"bounding_box"``     | Approximate the mesh with an oriented bounding box                            |
        +------------------------+-------------------------------------------------------------------------------+
        | ``"convex_hull"``      | Approximate the mesh with a convex hull (default)                             |
        +------------------------+-------------------------------------------------------------------------------+
        | ``<remeshing_method>`` | Any remeshing method supported by :func:`newton.utils.remesh_mesh`            |
        +------------------------+-------------------------------------------------------------------------------+

        .. note::

            The ``coacd`` and ``vhacd`` methods require additional dependencies (``coacd`` or ``trimesh`` and ``vhacdx`` respectively) to be installed.
            The convex hull approximation requires ``scipy`` to be installed.
            For ``coacd`` and ``vhacd``, each geometrically connected component
            is decomposed separately and may produce one or more convex shapes.

        The ``raise_on_failure`` parameter controls the behavior when the remeshing fails:
            - If `True`, an exception is raised when the remeshing fails.
            - If `False`, a warning is logged, and the method falls back to the next available method in the order of preference:
                - If convex decomposition via CoACD or V-HACD fails or dependencies are not available, the method will fall back to using the ``convex_hull`` method.
                - If convex hull approximation fails, it will fall back to the ``bounding_box`` method.

        .. important::

            Apply this method to a builder **before** passing it to
            :meth:`~newton.ModelBuilder.replicate` or
            :meth:`~newton.ModelBuilder.add_world`, not to the parent builder
            afterwards. Replication copies mesh *references*, not mesh data, so
            ``N`` worlds share one :class:`~newton.Mesh` object. Approximating
            first produces a single simplified copy that is shared across all
            replicated worlds; approximating afterwards allocates one copy per
            replicated shape — up to ``N`` times the memory for identical data.

            Recommended:

            .. code-block:: python

                arm = newton.ModelBuilder()
                # ... populate arm ...
                arm.approximate_meshes(method="convex_hull")

                scene = newton.ModelBuilder()
                scene.replicate(arm, world_count=N)

        Args:
            method: The method to use for approximating the mesh shapes.
            shape_indices: The indices of the shapes to simplify. Entries that are not ``MESH`` or ``CONVEX_MESH`` shapes are ignored. If `None`, all mesh shapes that have the :attr:`ShapeFlags.COLLIDE_SHAPES` flag set are simplified.
            raise_on_failure: If `True`, raises an exception if the remeshing fails. If `False`, it will log a warning and continue with the fallback method.
            **remeshing_kwargs: Additional keyword arguments passed to the remeshing function.

        Returns:
            Indices of the shapes that were successfully remeshed.
        """
        remeshing_methods = [*RemeshingMethod.__args__, "coacd", "vhacd", "bounding_sphere", "bounding_box"]
        if method not in remeshing_methods:
            raise ValueError(
                f"Unsupported remeshing method: {method}. Supported methods are: {', '.join(remeshing_methods)}."
            )

        def get_shape_custom_attributes(shape: int) -> dict[str, Any] | None:
            custom_attributes = {
                full_key: custom_attr.values[shape]
                for full_key, custom_attr in self.custom_attributes.items()
                if custom_attr.frequency == Model.AttributeFrequency.SHAPE
                and isinstance(custom_attr.values, dict)
                and shape in custom_attr.values
            }
            return custom_attributes or None

        if shape_indices is None:
            shape_indices = [
                i
                for i, stype in enumerate(self.shape_type)
                if stype == GeoType.MESH and self.shape_flags[i] & ShapeFlags.COLLIDE_SHAPES
            ]
        else:
            # primitives have no mesh source; preserve explicit re-approximation of convex meshes
            shape_indices = [i for i in shape_indices if self.shape_type[i] in (GeoType.MESH, GeoType.CONVEX_MESH)]

        # These methods rewrite shape_type away from MESH; any SDF/hydro state
        # would be silently dropped at finalize. The USD importer intercepts
        # this earlier; this guard catches direct Python API misuse.
        if method in {"coacd", "vhacd", "convex_hull", "bounding_box", "bounding_sphere"}:
            for shape in shape_indices:
                has_sdf_state = (
                    self.shape_sdf_max_resolution[shape] is not None
                    or self.shape_sdf_target_voxel_size[shape] is not None
                    or self.shape_sdf_padding[shape] is not None
                    or bool(self.shape_flags[shape] & ShapeFlags.HYDROELASTIC)
                )
                if has_sdf_state:
                    raise ValueError(
                        f"Shape {shape}: method '{method}' replaces the mesh with non-mesh "
                        f"geometry; SDF / hydroelastic configuration cannot be preserved."
                    )

        if keep_visual_shapes:
            # if keeping visual shapes, first copy input shapes, mark the copies as visual-only,
            # and mark the originals as non-visible.
            # in the rare event that approximation fails, we end up with two identical shapes,
            # one collision-only, one visual-only, but this simplifies the logic below.
            for shape in shape_indices:
                if not (self.shape_flags[shape] & ShapeFlags.VISIBLE):
                    continue

                body = self.shape_body[shape]
                xform = self.shape_transform[shape]
                color = self.shape_color[shape]
                opacity = self.shape_opacity[shape]
                custom_attributes = get_shape_custom_attributes(shape)
                cfg = ModelBuilder.ShapeConfig(
                    density=0.0,  # do not add extra mass / inertia
                    margin=self.shape_margin[shape],
                    is_solid=self.shape_is_solid[shape],
                    has_shape_collision=False,
                    has_particle_collision=False,
                    is_visible=True,
                )
                self.add_shape_mesh(
                    body=body,
                    xform=xform,
                    cfg=cfg,
                    mesh=self.shape_source[shape],
                    color=color,
                    opacity=opacity,
                    label=f"{self.shape_label[shape]}_visual",
                    scale=self.shape_scale[shape],
                    custom_attributes=custom_attributes,
                )

                # disable visibility of the original shape
                self.shape_flags[shape] &= ~ShapeFlags.VISIBLE

        # keep track of remeshed shapes to handle fallbacks
        remeshed_shapes = set()

        if method == "coacd" or method == "vhacd":
            empty_decomposition_shape = None
            decomposition_failed = False
            try:
                if method == "coacd":
                    # convex decomposition using CoACD
                    import coacd
                else:
                    # convex decomposition using V-HACD
                    import trimesh

                decompositions = {}
                filtered_shapes_by_shape: dict[int, set[int]] = {}
                convex_parts_by_shape: dict[int, list[int]] = {}
                source_shapes = set(shape_indices)
                # Snapshot source filters before adding convex parts, without materializing compact storage.
                for shape_a, shape_b in self._shape_collision_filter_pairs:
                    if shape_a in source_shapes:
                        filtered_shapes_by_shape.setdefault(shape_a, set()).add(shape_b)
                    if shape_b in source_shapes:
                        filtered_shapes_by_shape.setdefault(shape_b, set()).add(shape_a)

                for shape in shape_indices:
                    mesh: Mesh = self.shape_source[shape]
                    scale = self.shape_scale[shape]
                    hash_m = hash(mesh)
                    if hash_m in decompositions:
                        decomposition = decompositions[hash_m]
                    else:
                        decomposition = []
                        # Decomposition backends may merge disconnected convex parts into one hull.
                        for component_vertices, component_faces in split_mesh_components(mesh):
                            if method == "coacd":
                                cmesh = coacd.Mesh(component_vertices, component_faces)
                                coacd_settings = {
                                    "threshold": self.default_mesh_approximation_cfg.coacd_threshold,
                                    "mcts_nodes": 20,
                                    "mcts_iterations": 5,
                                    "mcts_max_depth": 1,
                                    "merge": False,
                                    "max_convex_hull": mesh.maxhullvert,
                                }
                                coacd_settings.update(remeshing_kwargs)
                                decomposition.extend(coacd.run_coacd(cmesh, **coacd_settings))
                            else:
                                tmesh = trimesh.Trimesh(component_vertices, component_faces)
                                vhacd_settings = {
                                    "maxNumVerticesPerCH": mesh.maxhullvert,
                                }
                                vhacd_settings.update(remeshing_kwargs)
                                component_decomposition = trimesh.decomposition.convex_decomposition(
                                    tmesh, **vhacd_settings
                                )
                                decomposition.extend((d["vertices"], d["faces"]) for d in component_decomposition)
                        decompositions[hash_m] = decomposition
                    if len(decomposition) == 0:
                        if raise_on_failure:
                            empty_decomposition_shape = shape
                            break
                        warnings.warn(
                            f"Remeshing with method '{method}' failed for shape {shape}: the backend returned no "
                            "convex parts. Falling back to convex_hull.",
                            stacklevel=2,
                        )
                        decomposition_failed = True
                        continue
                    # note we need to copy the mesh to avoid modifying the original mesh
                    replacement_mesh = self.shape_source[shape].copy(
                        vertices=decomposition[0][0], indices=decomposition[0][1]
                    )
                    # Decomposition outputs do not provide attributes remapped to the new vertices.
                    replacement_mesh._normals = None
                    replacement_mesh._uvs = None
                    self.shape_source[shape] = replacement_mesh
                    # mark as convex mesh type
                    self.shape_type[shape] = GeoType.CONVEX_MESH
                    if len(decomposition) > 1:
                        body = self.shape_body[shape]
                        xform = self.shape_transform[shape]
                        color = self.shape_color[shape]
                        opacity = self.shape_opacity[shape]
                        custom_attributes = get_shape_custom_attributes(shape)
                        filtered_shapes = sorted(
                            filtered_shape
                            for filtered_shape in filtered_shapes_by_shape.get(shape, ())
                            if self.shape_body[filtered_shape] != body
                        )
                        cfg = ModelBuilder.ShapeConfig(
                            ke=self.shape_material_ke[shape],
                            kd=self.shape_material_kd[shape],
                            kf=self.shape_material_kf[shape],
                            ka=self.shape_material_ka[shape],
                            mu=self.shape_material_mu[shape],
                            restitution=self.shape_material_restitution[shape],
                            mu_torsional=self.shape_material_mu_torsional[shape],
                            mu_rolling=self.shape_material_mu_rolling[shape],
                            kh=self.shape_material_kh[shape],
                            margin=self.shape_margin[shape],
                            is_solid=self.shape_is_solid[shape],
                            force_sdf=self.shape_force_sdf[shape],
                        )
                        cfg.flags = self.shape_flags[shape]
                        cfg.density = 0.0  # do not add extra mass / inertia
                        cfg.gap = self.shape_gap[shape]
                        cfg.collision_group = self.shape_collision_group[shape]
                        cfg.collision_filter_parent = False
                        for i in range(1, len(decomposition)):
                            # add additional convex parts as convex meshes
                            extra_shape = self.add_shape_convex_hull(
                                body=body,
                                xform=xform,
                                mesh=Mesh(decomposition[i][0], decomposition[i][1]),
                                scale=scale,
                                cfg=cfg,
                                color=color,
                                opacity=opacity,
                                label=f"{self.shape_label[shape]}_convex_{i}",
                                custom_attributes=custom_attributes,
                            )
                            for filtered_shape in filtered_shapes:
                                self.add_shape_collision_filter_pair(filtered_shape, extra_shape)
                                for filtered_part in convex_parts_by_shape.get(filtered_shape, ()):
                                    self.add_shape_collision_filter_pair(filtered_part, extra_shape)
                            convex_parts_by_shape.setdefault(shape, []).append(extra_shape)
                    remeshed_shapes.add(shape)
            except Exception as e:
                if raise_on_failure:
                    raise RuntimeError(f"Remeshing with method '{method}' failed.") from e
                else:
                    warnings.warn(
                        f"Remeshing with method '{method}' failed: {e}. Falling back to convex_hull.", stacklevel=2
                    )
                    method = "convex_hull"
                    # kwargs were addressed to the failed decomposition method
                    remeshing_kwargs = {}
            if empty_decomposition_shape is not None:
                raise RuntimeError(
                    f"Remeshing with method '{method}' failed for shape {empty_decomposition_shape}: "
                    "the backend returned no convex parts."
                )
            if decomposition_failed:
                method = "convex_hull"
                # kwargs were addressed to the failed decomposition method
                remeshing_kwargs = {}

        if method in RemeshingMethod.__args__:
            # remeshing of the individual meshes
            remeshed = {}
            remesh_failed = False
            for shape in shape_indices:
                if shape in remeshed_shapes:
                    # already remeshed with coacd or vhacd
                    continue
                mesh: Mesh = self.shape_source[shape]
                hash_m = hash(mesh)
                rmesh = remeshed.get(hash_m, None)
                if rmesh is None:
                    try:
                        rmesh = remesh_mesh(mesh, method=method, inplace=False, **remeshing_kwargs)
                        remeshed[hash_m] = rmesh
                    except Exception as e:
                        if raise_on_failure:
                            raise RuntimeError(f"Remeshing with method '{method}' failed for shape {shape}.") from e
                        else:
                            warnings.warn(
                                f"Remeshing with method '{method}' failed for shape {shape}: {e}. Falling back to bounding_box.",
                                stacklevel=2,
                            )
                            remesh_failed = True
                            continue
                # note we need to copy the mesh to avoid modifying the original mesh
                self.shape_source[shape] = self.shape_source[shape].copy(vertices=rmesh.vertices, indices=rmesh.indices)
                # mark convex_hull result as convex mesh type for efficient collision detection
                if method == "convex_hull":
                    self.shape_type[shape] = GeoType.CONVEX_MESH
                remeshed_shapes.add(shape)
            if remesh_failed:
                # route the shapes that failed (not in remeshed_shapes) into the fallback below
                method = "bounding_box"

        if method == "bounding_box":
            for shape in shape_indices:
                if shape in remeshed_shapes:
                    continue
                mesh: Mesh = self.shape_source[shape]
                scale = self.shape_scale[shape]
                vertices = mesh.vertices * np.array([*scale])
                tf, scale = compute_inertia_obb(vertices)
                self.shape_type[shape] = GeoType.BOX
                self.shape_source[shape] = None
                self.shape_scale[shape] = scale
                shape_tf = self.shape_transform[shape]
                self.shape_transform[shape] = shape_tf * tf
                remeshed_shapes.add(shape)
        elif method == "bounding_sphere":
            for shape in shape_indices:
                if shape in remeshed_shapes:
                    continue
                mesh: Mesh = self.shape_source[shape]
                scale = self.shape_scale[shape]
                scale_array = np.asarray(scale, dtype=np.float32)
                vertices = np.asarray(mesh.vertices, dtype=np.float32) * scale_array
                center = np.mean(vertices, axis=0, dtype=np.float32)
                radius = float(np.max(np.linalg.norm(vertices - center, axis=1).astype(np.float32, copy=False)))
                self.shape_type[shape] = GeoType.SPHERE
                self.shape_source[shape] = None
                self.shape_scale[shape] = (radius, 0.0, 0.0)
                tf = wp.transform(center, wp.quat_identity())
                shape_tf = self.shape_transform[shape]
                self.shape_transform[shape] = shape_tf * tf
                remeshed_shapes.add(shape)

        # Hide approximated primitives on bodies that have other visible shapes.
        # Primitives (box, sphere) can't carry visual materials, so they should
        # not be visible when the body already has dedicated visual geometry.
        visible_count_per_body = Counter(
            self.shape_body[i] for i in range(len(self.shape_body)) if self.shape_flags[i] & ShapeFlags.VISIBLE
        )
        for shape in remeshed_shapes:
            if self.shape_type[shape] in (GeoType.MESH, GeoType.CONVEX_MESH):
                continue
            if not (self.shape_flags[shape] & ShapeFlags.VISIBLE):
                continue
            body = self.shape_body[shape]
            if visible_count_per_body.get(body, 0) > 1:
                self.shape_flags[shape] &= ~ShapeFlags.VISIBLE
                visible_count_per_body[body] -= 1

        return remeshed_shapes

    def _add_rod_object(
        self,
        rod: Rod,
        *,
        cfg: ShapeConfig | None,
        stretch_stiffness: float | None,
        stretch_damping: float | None,
        shear_stiffness: float | None,
        shear_damping: float | None,
        bend_stiffness: float | None,
        bend_damping: float | None,
        twist_stiffness: float | None,
        twist_damping: float | None,
        label: str | None,
        wrap_in_articulation: bool,
        junction_collision_filter: bool,
        color: Vec3 | None,
        body_frame_origin: Literal["start", "com"] | None,
    ) -> tuple[list[int], list[int]]:
        """Add a Rod object through the established chain or graph path."""
        radius = rod._resolve_radius()
        if radius is None:
            radius = 0.1

        self._validate_rod_stiffness_inputs(
            "add_rod",
            stretch_stiffness=stretch_stiffness,
            shear_stiffness=shear_stiffness,
            bend_stiffness=bend_stiffness,
            twist_stiffness=twist_stiffness,
        )
        body_frame_origin = self._resolve_rod_body_frame_origin("add_rod", body_frame_origin)

        rod_points, rod_edges, rod_frames = rod._normalize_and_validate_geometry()
        uses_chain_assembly = len(rod_edges) >= 2 and Rod._is_ordered_chain_topology(len(rod_points), rod_edges)

        stretch_rigidity: float | None = None
        shear_rigidity: float | None = None
        bend_rigidity: float | None = None
        twist_rigidity: float | None = None
        section_rigidities = rod._resolve_section_rigidities()
        if section_rigidities is not None:
            stretch_rigidity, shear_rigidity, bend_rigidity, twist_rigidity = section_rigidities
            if stretch_stiffness is not None:
                stretch_rigidity = None
            if shear_stiffness is not None:
                shear_rigidity = None
            if bend_stiffness is not None:
                bend_rigidity = None
            if twist_stiffness is not None:
                twist_rigidity = None
            # Zero rigidity is topology-independent; positive gains require a unique joint pairing.
            if any(
                rigidity is not None and rigidity > 0.0
                for rigidity in (stretch_rigidity, shear_rigidity, bend_rigidity, twist_rigidity)
            ):
                self._validate_rod_rigidity_topology(
                    len(rod_points),
                    rod_edges,
                    wrap_in_articulation=wrap_in_articulation,
                )

        segment_vectors = rod_points[rod_edges[:, 1]] - rod_points[rod_edges[:, 0]]
        segment_lengths = np.linalg.norm(segment_vectors, axis=1)
        rod_positions: list[Vec3] = [axis_to_vec3(point) for point in rod_points]
        rod_quaternions: list[Quat] = [
            wp.quat(float(frame[0]), float(frame[1]), float(frame[2]), float(frame[3])) for frame in rod_frames
        ]

        if uses_chain_assembly:
            link_bodies, link_joints = self._add_rod_chain(
                rod_positions,
                quaternions=rod_quaternions,
                radius=radius,
                cfg=cfg,
                stretch_stiffness=stretch_stiffness,
                stretch_damping=stretch_damping,
                shear_stiffness=shear_stiffness,
                shear_damping=shear_damping,
                bend_stiffness=bend_stiffness,
                bend_damping=bend_damping,
                twist_stiffness=twist_stiffness,
                twist_damping=twist_damping,
                closed=rod.closed,
                label=label,
                wrap_in_articulation=wrap_in_articulation,
                color=color,
                body_frame_origin=body_frame_origin,
            )
        else:
            link_bodies, link_joints = self._add_rod_graph(
                node_positions=rod_positions,
                edges=[(int(edge[0]), int(edge[1])) for edge in rod_edges],
                radius=radius,
                cfg=cfg,
                stretch_stiffness=stretch_stiffness,
                stretch_damping=stretch_damping,
                shear_stiffness=shear_stiffness,
                shear_damping=shear_damping,
                bend_stiffness=bend_stiffness,
                bend_damping=bend_damping,
                twist_stiffness=twist_stiffness,
                twist_damping=twist_damping,
                label=label,
                wrap_in_articulation=wrap_in_articulation,
                quaternions=rod_quaternions,
                junction_collision_filter=junction_collision_filter,
                color=color,
                body_frame_origin=body_frame_origin,
            )

        self._set_joint_rod_stiffnesses_from_rigidities(
            segment_lengths,
            link_bodies,
            link_joints,
            stretch_rigidity=stretch_rigidity,
            shear_rigidity=shear_rigidity,
            bend_rigidity=bend_rigidity,
            twist_rigidity=twist_rigidity,
        )
        return link_bodies, link_joints

    def _add_rod_chain(
        self,
        positions: list[Vec3],
        *,
        quaternions: list[Quat] | None,
        radius: float | None,
        cfg: ShapeConfig | None,
        stretch_stiffness: float | None,
        stretch_damping: float | None,
        shear_stiffness: float | None,
        shear_damping: float | None,
        bend_stiffness: float | None,
        bend_damping: float | None,
        twist_stiffness: float | None,
        twist_damping: float | None,
        closed: bool | None,
        label: str | None,
        wrap_in_articulation: bool,
        color: Vec3 | None,
        body_frame_origin: Literal["start", "com"] | None,
    ) -> tuple[list[int], list[int]]:
        """Add an ordered point chain through the established graph path."""
        self._validate_rod_stiffness_inputs(
            "add_rod",
            stretch_stiffness=stretch_stiffness,
            shear_stiffness=shear_stiffness,
            bend_stiffness=bend_stiffness,
            twist_stiffness=twist_stiffness,
        )
        body_frame_origin = self._resolve_rod_body_frame_origin("add_rod", body_frame_origin)
        closed = False if closed is None else closed

        radius = 0.1 if radius is None else radius
        if cfg is None:
            cfg = self.default_shape_cfg

        # Stretch defaults to the cable/rod axial stiffness used by VBD examples.
        stretch_stiffness = 1.0e5 if stretch_stiffness is None else stretch_stiffness
        stretch_damping = 0.0 if stretch_damping is None else stretch_damping

        # Bend defaults: 0.0 (users must explicitly set for bending resistance)
        bend_stiffness = 0.0 if bend_stiffness is None else bend_stiffness
        bend_damping = 0.0 if bend_damping is None else bend_damping

        num_segments = len(positions) - 1
        if num_segments < 1:
            raise ValueError("add_rod: positions must contain at least 2 points")

        # Coerce all input positions to wp.vec3 so arithmetic (p1 - p0), wp.length, wp.normalize
        # always operate on Warp vector types even if the caller passed tuples/lists.
        positions_wp: list[wp.vec3] = [axis_to_vec3(p) for p in positions]

        if quaternions is not None and len(quaternions) != num_segments:
            raise ValueError(
                f"add_rod: quaternions must have {num_segments} elements for {num_segments} segments, "
                f"got {len(quaternions)} quaternions"
            )

        if num_segments < 2:
            # A "rod" in this API is defined as multiple capsules coupled by rod joints.
            # If you want a single capsule, create a body + capsule shape directly.
            raise ValueError(
                f"add_rod: requires at least 2 segments (got {num_segments}); "
                "for a single capsule, create a body and add a capsule shape instead."
            )

        # Build linear graph edges: (0, 1), (1, 2), ..., (N-1, N)
        # Note: positions has N+1 elements for N segments.
        edges = [(i, i + 1) for i in range(num_segments)]

        # Use the graph core to create bodies and internal joints.
        # We use wrap_in_articulation=False and let add_rod manage articulation wrapping so that:
        # - open chains are wrapped into a single articulation (tree), and
        # - closed loops add one extra "loop joint" after wrapping, which must not be part of an articulation.
        link_bodies, link_joints = self._add_rod_graph(
            node_positions=positions_wp,
            edges=edges,
            radius=radius,
            cfg=cfg,
            stretch_stiffness=stretch_stiffness,
            stretch_damping=stretch_damping,
            shear_stiffness=shear_stiffness,
            shear_damping=shear_damping,
            bend_stiffness=bend_stiffness,
            bend_damping=bend_damping,
            twist_stiffness=twist_stiffness,
            twist_damping=twist_damping,
            label=label,
            wrap_in_articulation=False,
            quaternions=quaternions,
            junction_collision_filter=True,
            color=color,
            body_frame_origin=body_frame_origin,
        )

        # Wrap all joints into an articulation if requested.
        if wrap_in_articulation and link_joints:
            rod_art_label = f"{label}_articulation" if label else None
            self.add_articulation(link_joints, label=rod_art_label)

        # For closed loops, add one extra loop-closing rod joint that is intentionally
        # *not* part of an articulation (articulations must be trees/forests).
        if closed:
            if not wrap_in_articulation:
                warnings.warn(
                    "add_rod: wrap_in_articulation=False requires the caller to wrap joints via add_articulation() "
                    "before finalize; closed=True also adds a loop-closing joint that must remain outside any "
                    "articulation.",
                    UserWarning,
                    stacklevel=self._external_warning_stacklevel(),
                )

            if link_bodies:
                first_body = link_bodies[0]
                last_body = link_bodies[-1]

                # Connect the end of the last segment to the start of the first segment.
                L_last = float(wp.length(positions_wp[-1] - positions_wp[-2]))
                min_segment_length = 1.0e-9
                if L_last <= min_segment_length:
                    L_last = min_segment_length

                L_first = float(wp.length(positions_wp[1] - positions_wp[0]))
                if L_first <= min_segment_length:
                    L_first = min_segment_length

                if body_frame_origin == "com":
                    parent_xform = wp.transform(wp.vec3(0.0, 0.0, 0.5 * L_last), wp.quat_identity())
                    child_xform = wp.transform(wp.vec3(0.0, 0.0, -0.5 * L_first), wp.quat_identity())
                else:
                    parent_xform = wp.transform(wp.vec3(0.0, 0.0, L_last), wp.quat_identity())
                    child_xform = wp.transform(wp.vec3(0.0, 0.0, 0.0), wp.quat_identity())

                loop_joint_label = f"{label}_cable_{len(link_joints) + 1}" if label else None
                j_loop = self.add_joint_rod(
                    parent=last_body,
                    child=first_body,
                    parent_xform=parent_xform,
                    child_xform=child_xform,
                    bend_stiffness=bend_stiffness,
                    bend_damping=bend_damping,
                    twist_stiffness=twist_stiffness,
                    twist_damping=twist_damping,
                    stretch_stiffness=stretch_stiffness,
                    stretch_damping=stretch_damping,
                    shear_stiffness=shear_stiffness,
                    shear_damping=shear_damping,
                    label=loop_joint_label,
                    collision_filter_parent=True,
                    enabled=True,
                )
                link_joints.append(j_loop)

        return link_bodies, link_joints

    def add_rod(
        self,
        positions: list[Vec3] | None = None,
        *,
        quaternions: list[Quat] | None = None,
        radius: float | None = None,
        cfg: ShapeConfig | None = None,
        stretch_stiffness: float | None = None,
        stretch_damping: float | None = None,
        shear_stiffness: float | None = None,
        shear_damping: float | None = None,
        bend_stiffness: float | None = None,
        bend_damping: float | None = None,
        twist_stiffness: float | None = None,
        twist_damping: float | None = None,
        closed: bool | None = None,
        label: str | None = None,
        wrap_in_articulation: bool = True,
        color: Vec3 | None = None,
        body_frame_origin: Literal["start", "com"] | None = None,
        rod: Rod | None = None,
        junction_collision_filter: bool = True,
    ) -> tuple[list[int], list[int]]:
        """Adds a rod composed of capsule bodies connected by rod joints.

        Exactly one input form is required:

        - ``positions=...`` constructs an ordered chain. The separate
          ``quaternions`` and ``closed`` arguments belong only to this
          compatibility form.
        - ``rod=...`` uses the geometry, frames, topology, and optional
          constitutive data stored on a :class:`newton.Rod`, which may represent
          an ordered chain or an explicit graph.

        The remaining arguments configure assembly. Each segment becomes a
        capsule body, and incident segments are connected by rod joints with
        separate stretch, shear, bend, and twist slots.

        Args:
            positions: Geometry source for the ordered-chain form: centerline
                node positions (segment endpoints) in world space [m].
                Mutually exclusive with ``rod``.

                .. deprecated:: 1.6
                    Construct a :class:`newton.Rod` and pass it with
                    ``rod=...`` instead.
            quaternions: Optional per-segment (per-edge) orientations in world space. If provided,
                must have ``len(positions) - 1`` elements and each quaternion should align the capsule's
                local +Z with the segment direction ``positions[i+1] - positions[i]``. If None,
                orientations are computed automatically to align +Z with each segment direction.
                Valid only with ``positions``; must be None when ``rod`` is
                supplied.
            radius: Capsule radius [m] for the ``positions`` form. If None,
                defaults to 0.1 m. Must be None with ``rod``; the Rod's radius
                is used, with the same default when it is unset.
            cfg: Shape configuration for the capsules. If None, :attr:`default_shape_cfg` is used.
            stretch_stiffness: Per-joint rod stretch stiffness, stored directly as ``target_ke`` [N/m].
                If None, it is derived locally from Rod material or section rigidity;
                otherwise it defaults to 1.0e5.
            stretch_damping: Stretch damping [N·s/m] for the rod joints (applied per-joint; not length-normalized). If None,
                defaults to 0.0.
            shear_stiffness: Optional per-joint transverse shear stiffness [N/m]. If None, defaults to
                the locally derived Rod shear stiffness, or to
                ``stretch_stiffness`` otherwise.
            shear_damping: Optional per-joint transverse shear damping [N·s/m]. If None, defaults to
                ``stretch_damping`` only when both ``shear_stiffness`` and ``shear_damping`` are None. Otherwise defaults to 0.0.
            bend_stiffness: Per-joint rod bend stiffness, stored directly as ``target_ke`` [N·m/rad].
                If None, it is derived locally from Rod material or section rigidity;
                otherwise it defaults to 0.0.
            bend_damping: Bend damping [N·m·s/rad] for the rod joints (applied per-joint; not length-normalized). If None,
                defaults to 0.0.
            twist_stiffness: Optional per-joint rod twist stiffness [N·m/rad]. If None, defaults to
                the locally derived Rod twist stiffness, or to
                ``bend_stiffness`` otherwise.
            twist_damping: Optional per-joint rod twist damping [N·m·s/rad]. If None, defaults to ``bend_damping``
                only when both ``twist_stiffness`` and ``twist_damping`` are None. Otherwise defaults to 0.0.
            closed: For the ``positions`` form, whether to connect the last
                segment back to the first. Repeat the first position at the end
                to include the closing segment. When using ``rod``, pass
                ``closed=True`` to the :class:`newton.Rod` constructor instead.
            label: Optional label prefix for bodies, shapes, and joints. Generated joint labels
                retain the historical ``{label}_cable_{n}`` form for compatibility.
            wrap_in_articulation: Whether Newton automatically creates
                articulations for the generated tree joints. Defaults to True.
                See the Articulations section below.
            color: Optional display RGB color with values in ``[0, 1]`` applied to all generated
                capsule shapes. If None, the rod uses the default rod color.
            body_frame_origin: Body-frame placement for each generated capsule. ``"start"`` preserves
                the legacy convention where the body origin is at the segment start position
                (``positions[i]`` for segment ``i``), and the COM/shape are offset by half the
                segment length. ``"com"`` places the body origin at the segment midpoint so the
                body origin and COM coincide. If None, preserves ``"start"`` for now with a
                :class:`DeprecationWarning` because the implicit default will change to ``"com"``;
                pass ``"start"`` or ``"com"`` explicitly.
            rod: Geometry, frame, topology, and constitutive-data source for
                the prepared-object form. Mutually exclusive with ``positions``.
            junction_collision_filter: Whether to suppress self-collisions
                between incident, non-jointed segments at graph junctions.
                Has no effect for an ordered chain.

        Returns:
            A pair ``(body_indices, joint_indices)``. Bodies follow segment
            order. An open ordered chain has one fewer joint than segments; a
            closed ordered chain has one joint per segment. Graph joint count
            depends on topology and articulation wrapping.

        Articulations:
            With ``wrap_in_articulation=True`` (the default), Newton places an
            ordered chain's non-closure joints in one articulation; for a
            closed chain, the loop-closing joint remains outside it. For an
            explicit graph, Newton creates one articulation-safe spanning tree
            per connected component; cyclic adjacency joints are omitted. With
            ``wrap_in_articulation=False``, Newton creates no articulations.
            Before :meth:`finalize <ModelBuilder.finalize>`, callers must place
            the tree or forest joints in articulations. Loop-closing joints
            whose child is already reachable through those articulations may
            remain outside them.

        Raises:
            ValueError: If both or neither of ``positions`` and ``rod`` are supplied.
            TypeError: If ``rod`` is not a :class:`newton.Rod`, or a Rod is
                passed as ``positions``.
            ValueError: If ``quaternions``, ``radius``, or ``closed`` is non-None
                with ``rod``.
            ValueError: If ``positions`` and ``quaternions`` lengths are incompatible.
            ValueError: If the ordered point-list form has fewer than 2 segments.
            ValueError: If ``body_frame_origin`` is not ``"start"`` or ``"com"``.
            ValueError: If automatic section-rigidity discretization is requested
                for branching topology or for a wrapped explicit cycle.

        Note:
            - Bend defaults are 0.0 (no bending resistance unless specified). Stretch defaults to 1.0e5;
              pass a larger value when neighboring capsules should remain nearly inextensible.
            - Direct stiffness and damping values are applied unchanged to every generated joint.
            - For a material- or section-rigidity-defined :class:`newton.Rod`,
              stiffness is derived per generated joint as ``R / L_dual``, where
              ``R`` is the corresponding section rigidity and ``L_dual`` is the
              mean rest length of the two adjacent segments. Explicit stiffness
              arguments override the derived value per mode.
            - Each segment is implemented as a capsule primitive. ``half_height`` is the half-length of
              the cylindrical centerline, excluding the hemispherical caps.
            - With ``body_frame_origin="start"``, the body origin is at the first centerline endpoint,
              the COM and shape are at local ``(0, 0, half_height)``, and the second centerline endpoint
              is at local ``(0, 0, 2 * half_height)``.
            - With ``body_frame_origin="com"``, the body origin and COM coincide at the segment
              midpoint, and centerline endpoints are at local ``(0, 0, -half_height)`` and
              ``(0, 0, half_height)``.
        """
        if (positions is None) == (rod is None):
            raise ValueError("add_rod: exactly one of positions and rod must be supplied")

        if isinstance(positions, Rod):
            raise TypeError("add_rod: pass a Rod with the rod keyword, not as positions")

        if rod is not None and not isinstance(rod, Rod):
            raise TypeError(f"add_rod: rod must be a Rod, got {type(rod).__name__}")

        if rod is not None:
            if quaternions is not None:
                raise ValueError("add_rod: quaternions must be None when rod is supplied")
            if radius is not None:
                raise ValueError("add_rod: radius must be None when rod is supplied; set rod.radius instead")
            if closed is not None:
                raise ValueError("add_rod: closed must be None when rod is supplied")
            return self._add_rod_object(
                rod,
                cfg=cfg,
                stretch_stiffness=stretch_stiffness,
                stretch_damping=stretch_damping,
                shear_stiffness=shear_stiffness,
                shear_damping=shear_damping,
                bend_stiffness=bend_stiffness,
                bend_damping=bend_damping,
                twist_stiffness=twist_stiffness,
                twist_damping=twist_damping,
                label=label,
                wrap_in_articulation=wrap_in_articulation,
                junction_collision_filter=junction_collision_filter,
                color=color,
                body_frame_origin=body_frame_origin,
            )

        assert positions is not None
        warnings.warn(
            _ADD_ROD_POSITIONS_DEPRECATION_MSG,
            DeprecationWarning,
            stacklevel=self._external_warning_stacklevel(),
        )
        return self._add_rod_chain(
            positions,
            quaternions=quaternions,
            radius=radius,
            cfg=cfg,
            stretch_stiffness=stretch_stiffness,
            stretch_damping=stretch_damping,
            shear_stiffness=shear_stiffness,
            shear_damping=shear_damping,
            bend_stiffness=bend_stiffness,
            bend_damping=bend_damping,
            twist_stiffness=twist_stiffness,
            twist_damping=twist_damping,
            closed=closed,
            label=label,
            wrap_in_articulation=wrap_in_articulation,
            color=color,
            body_frame_origin=body_frame_origin,
        )

    def add_rod_graph(
        self,
        node_positions: list[Vec3],
        edges: list[tuple[int, int]],
        *,
        radius: float = 0.1,
        cfg: ShapeConfig | None = None,
        stretch_stiffness: float | None = None,
        stretch_damping: float | None = None,
        shear_stiffness: float | None = None,
        shear_damping: float | None = None,
        bend_stiffness: float | None = None,
        bend_damping: float | None = None,
        twist_stiffness: float | None = None,
        twist_damping: float | None = None,
        label: str | None = None,
        wrap_in_articulation: bool = True,
        quaternions: list[Quat] | None = None,
        junction_collision_filter: bool = True,
        color: Vec3 | None = None,
        body_frame_origin: Literal["start", "com"] | None = None,
    ) -> tuple[list[int], list[int]]:
        """Adds a rod *graph* (supports junctions) from nodes + edges.

        .. deprecated:: 1.6
            Construct a :class:`newton.Rod` with ``edges=...`` and pass it to
            :meth:`add_rod` with ``rod=...`` instead.

        Representation:

        - Each *edge* becomes a capsule rigid body spanning from ``node_positions[u]`` to
          ``node_positions[v]`` (local +Z points toward ``v``).
        - Rod joints are created between edge-bodies that share a node, using a spanning-tree
          traversal so that each body has a single parent when wrapped into an articulation.

        Notes:

        - If ``wrap_in_articulation=True`` (default), joints are created as a forest (one
          articulation per connected component). This keeps the joint graph articulation-safe
          (tree/forest), avoiding cycles at junctions.
        - Cycles in the edge adjacency graph are *not* explicitly closed with extra joints when
          ``wrap_in_articulation=True`` (cycles would violate articulation tree constraints). If
          you need closed loops, build them explicitly without articulation wrapping.
        - If ``wrap_in_articulation=False``, joints are created directly at each node to connect
          all incident edges. This can preserve rings/loops, but does not produce an articulation
          tree (edges may effectively have multiple "parents" in the joint graph).

        Args:
            node_positions: Junction node positions in world space.
            edges: List of (u, v) node index pairs defining rod segments. Each edge creates one
                capsule body oriented so its local +Z points from node ``u`` to node ``v``.
            radius: Capsule radius.
            cfg: Shape configuration for the capsules. If None, :attr:`default_shape_cfg` is used.
            stretch_stiffness: Per-joint rod stretch stiffness, stored directly as ``target_ke`` [N/m].
                Defaults to 1.0e5.
            stretch_damping: Stretch damping [N·s/m] (per joint). Defaults to 0.0.
            shear_stiffness: Optional per-joint transverse shear stiffness [N/m]. If None, defaults to
                ``stretch_stiffness``.
            shear_damping: Optional per-joint transverse shear damping [N·s/m]. If None, defaults to
                ``stretch_damping`` only when both ``shear_stiffness`` and ``shear_damping`` are None. Otherwise defaults to 0.0.
            bend_stiffness: Per-joint rod bend stiffness, stored directly as ``target_ke`` [N·m/rad].
                Defaults to 0.0.
            bend_damping: Bend damping [N·m·s/rad] (per joint). Defaults to 0.0.
            twist_stiffness: Optional per-joint rod twist stiffness [N·m/rad]. If None, defaults to
                ``bend_stiffness``.
            twist_damping: Optional per-joint rod twist damping [N·m·s/rad]. If None, defaults to ``bend_damping``
                only when both ``twist_stiffness`` and ``twist_damping`` are None. Otherwise defaults to 0.0.
            label: Optional label prefix for bodies, shapes, joints, and articulations. Generated
                joint labels retain the historical ``{label}_cable_{n}`` form for compatibility.
            wrap_in_articulation: If True, wraps the generated joint forest into one articulation
                per connected component.
            quaternions: Optional per-edge orientations in world space. If provided, must have
                ``len(edges)`` elements and each quaternion must align the capsule's local +Z with
                the corresponding edge direction ``node_positions[v] - node_positions[u]``. If
                None, orientations are computed automatically to align +Z with each edge direction.
            junction_collision_filter: If True, adds collision filters between *non-jointed* segment
                bodies that are incident to a junction node (degree >= 3). This prevents immediate
                self-collision impulses at welded junctions, even though the joint set is a spanning
                tree (so not all incident body pairs are directly jointed).
            color: Optional display RGB color with values in ``[0, 1]`` applied to all generated
                capsule shapes. If None, the graph uses the default rod color.
            body_frame_origin: Body-frame placement for each generated capsule. ``"start"`` preserves
                the legacy convention where the body origin is at the edge start node
                (``node_positions[u]`` for edge ``(u, v)``), and the COM/shape are offset by half
                the edge length. ``"com"`` places the body origin at the edge midpoint so the body
                origin and COM coincide. If None, preserves ``"start"`` for now with a
                :class:`DeprecationWarning` because the implicit default will change to ``"com"``;
                pass ``"start"`` or ``"com"`` explicitly.

        Returns:
            A pair ``(body_indices, joint_indices)`` where bodies correspond to
            edges in the same order as ``edges``.

        Raises:
            ValueError: If ``body_frame_origin`` is not ``"start"`` or ``"com"``.
        """
        warnings.warn(
            _ADD_ROD_GRAPH_DEPRECATION_MSG,
            DeprecationWarning,
            stacklevel=self._external_warning_stacklevel(),
        )
        return self._add_rod_graph(
            node_positions,
            edges,
            radius=radius,
            cfg=cfg,
            stretch_stiffness=stretch_stiffness,
            stretch_damping=stretch_damping,
            shear_stiffness=shear_stiffness,
            shear_damping=shear_damping,
            bend_stiffness=bend_stiffness,
            bend_damping=bend_damping,
            twist_stiffness=twist_stiffness,
            twist_damping=twist_damping,
            label=label,
            wrap_in_articulation=wrap_in_articulation,
            quaternions=quaternions,
            junction_collision_filter=junction_collision_filter,
            color=color,
            body_frame_origin=body_frame_origin,
        )

    def _add_rod_graph(
        self,
        node_positions: list[Vec3],
        edges: list[tuple[int, int]],
        *,
        radius: float,
        cfg: ShapeConfig | None,
        stretch_stiffness: float | None,
        stretch_damping: float | None,
        shear_stiffness: float | None,
        shear_damping: float | None,
        bend_stiffness: float | None,
        bend_damping: float | None,
        twist_stiffness: float | None,
        twist_damping: float | None,
        label: str | None,
        wrap_in_articulation: bool,
        quaternions: list[Quat] | None,
        junction_collision_filter: bool,
        color: Vec3 | None,
        body_frame_origin: Literal["start", "com"] | None,
    ) -> tuple[list[int], list[int]]:
        """Internal graph-assembly implementation shared by the rod input forms."""
        if cfg is None:
            cfg = self.default_shape_cfg

        # Stretch defaults to the cable/rod axial stiffness used by VBD examples.
        stretch_stiffness = 1.0e5 if stretch_stiffness is None else stretch_stiffness
        stretch_damping = 0.0 if stretch_damping is None else stretch_damping

        # Bend defaults: 0.0 (users must explicitly set for bending resistance)
        bend_stiffness = 0.0 if bend_stiffness is None else bend_stiffness
        bend_damping = 0.0 if bend_damping is None else bend_damping

        self._validate_rod_stiffness_inputs(
            "add_rod_graph",
            stretch_stiffness=stretch_stiffness,
            shear_stiffness=shear_stiffness,
            bend_stiffness=bend_stiffness,
            twist_stiffness=twist_stiffness,
        )
        body_frame_origin = self._resolve_rod_body_frame_origin("add_rod_graph", body_frame_origin)
        if len(node_positions) < 2:
            raise ValueError("add_rod_graph: node_positions must contain at least 2 nodes")
        if len(edges) < 1:
            raise ValueError("add_rod_graph: edges must contain at least 1 edge")

        num_nodes = len(node_positions)
        num_edges = len(edges)
        if quaternions is not None and len(quaternions) != num_edges:
            raise ValueError(
                f"add_rod_graph: quaternions must have {num_edges} elements for {num_edges} edges, "
                f"got {len(quaternions)} quaternions"
            )

        # Guard against near-zero lengths: edge length is used for capsule geometry and joint anchors.
        min_segment_length = 1.0e-9

        # Coerce all input node positions to wp.vec3 so arithmetic (p1 - p0), wp.length, wp.normalize
        # always operate on Warp vector types even if the caller passed tuples/lists.
        node_positions_wp: list[wp.vec3] = [axis_to_vec3(p) for p in node_positions]

        # Build per-node incidence for spanning-tree traversal.
        node_incidence: list[list[int]] = [[] for _ in range(num_nodes)]

        # Per-edge data
        edge_u: list[int] = []
        edge_v: list[int] = []
        edge_len: list[float] = []
        edge_bodies: list[int] = []
        rod_color = color if color is not None else ModelBuilder._DEFAULT_ROD_COLOR
        use_com_origin = body_frame_origin == "com"

        # Create all edge bodies first.
        for e_idx, (u, v) in enumerate(edges):
            if u < 0 or u >= num_nodes or v < 0 or v >= num_nodes:
                raise ValueError(
                    f"add_rod_graph: edge {e_idx} has invalid node indices ({u}, {v}) for {num_nodes} nodes"
                )
            if u == v:
                raise ValueError(f"add_rod_graph: edge {e_idx} connects a node to itself ({u} -> {v})")

            p0 = node_positions_wp[u]
            p1 = node_positions_wp[v]
            seg_vec = p1 - p0
            seg_length = float(wp.length(seg_vec))
            if seg_length <= min_segment_length:
                raise ValueError(
                    f"add_rod_graph: edge {e_idx} has a too-small length (length={seg_length:.3e}); "
                    f"segment length must be > {min_segment_length:.1e}"
                )

            if quaternions is None:
                seg_dir = wp.normalize(seg_vec)
                q = quat_between_vectors_robust(wp.vec3(0.0, 0.0, 1.0), seg_dir)
            else:
                q = quaternions[e_idx]

                # Local +Z must align with the segment direction.
                seg_dir = wp.normalize(seg_vec)
                local_z_world = wp.quat_rotate(q, wp.vec3(0.0, 0.0, 1.0))
                alignment = wp.dot(seg_dir, local_z_world)
                if alignment < 0.999:
                    raise ValueError(
                        "add_rod_graph: quaternion at edge index "
                        f"{e_idx} does not align capsule +Z with edge direction (node_positions[v] - node_positions[u]); "
                        "quaternions must be world-space and constructed so that local +Z maps to the "
                        "edge direction node_positions[v] - node_positions[u]."
                    )
            half_height = 0.5 * seg_length

            if use_com_origin:
                # Opt-in convention: place body origin at the segment center so origin and COM coincide.
                center = p0 + seg_vec * 0.5
                body_q = wp.transform(center, q)
                com_offset = wp.vec3(0.0)
                capsule_xform = wp.transform()
            else:
                # Legacy convention: body origin is at node u, with COM and shape offset to the segment center.
                body_q = wp.transform(p0, q)
                com_offset = wp.vec3(0.0, 0.0, half_height)
                capsule_xform = wp.transform(wp.vec3(0.0, 0.0, half_height), wp.quat_identity())

            body_label = f"{label}_edge_body_{e_idx}" if label else None
            shape_label = f"{label}_edge_capsule_{e_idx}" if label else None

            body_id = self.add_link(xform=body_q, com=com_offset, label=body_label)

            self.add_shape_capsule(
                body_id,
                xform=capsule_xform,
                radius=radius,
                half_height=half_height,
                cfg=cfg,
                label=shape_label,
                color=rod_color,
            )

            edge_u.append(u)
            edge_v.append(v)
            edge_len.append(seg_length)
            edge_bodies.append(body_id)

            node_incidence[u].append(e_idx)
            node_incidence[v].append(e_idx)

        def _edge_anchor_xform(e_idx: int, node_idx: int) -> wp.transform:
            if node_idx == edge_u[e_idx]:
                z = -0.5 * edge_len[e_idx] if use_com_origin else 0.0
            elif node_idx == edge_v[e_idx]:
                z = 0.5 * edge_len[e_idx] if use_com_origin else edge_len[e_idx]
            else:
                raise RuntimeError("add_rod_graph: internal error (node not incident to edge)")
            return wp.transform(wp.vec3(0.0, 0.0, float(z)), wp.quat_identity())

        joint_counter = 0
        jointed_body_pairs: set[tuple[int, int]] = set()

        def _remember_jointed_pair(parent_body: int, child_body: int) -> None:
            # Canonical order so lookups are symmetric.
            if parent_body <= child_body:
                jointed_body_pairs.add((parent_body, child_body))
            else:
                jointed_body_pairs.add((child_body, parent_body))

        def _build_joints_star() -> list[int]:
            """Builds joints by connecting incident edges directly at each node."""
            nonlocal joint_counter
            all_joints: list[int] = []

            # No articulation constraints: connect incident edges directly at each node.
            # This preserves cycles (rings/loops) but can create multi-parent relationships, which is
            # fine when not wrapping into an articulation.
            for node_idx in range(num_nodes):
                inc = node_incidence[node_idx]
                if len(inc) < 2:
                    continue

                # Deterministic parent choice: use the first edge in incidence list.
                # Since node_incidence is built by iterating edges in order (0, 1, 2...),
                # this implicitly picks the edge with the lowest index as the parent.
                parent_edge = inc[0]
                parent_body = edge_bodies[parent_edge]
                parent_xform = _edge_anchor_xform(parent_edge, node_idx)

                for child_edge in inc[1:]:
                    child_body = edge_bodies[child_edge]
                    if parent_body == child_body:
                        raise RuntimeError("add_rod_graph: internal error (self-connection)")

                    child_xform = _edge_anchor_xform(child_edge, node_idx)

                    joint_counter += 1
                    joint_label = f"{label}_cable_{joint_counter}" if label else None

                    j = self.add_joint_rod(
                        parent=parent_body,
                        child=child_body,
                        parent_xform=parent_xform,
                        child_xform=child_xform,
                        bend_stiffness=bend_stiffness,
                        bend_damping=bend_damping,
                        twist_stiffness=twist_stiffness,
                        twist_damping=twist_damping,
                        stretch_stiffness=stretch_stiffness,
                        stretch_damping=stretch_damping,
                        shear_stiffness=shear_stiffness,
                        shear_damping=shear_damping,
                        label=joint_label,
                        collision_filter_parent=True,
                        enabled=True,
                    )
                    all_joints.append(j)
                    _remember_jointed_pair(parent_body, child_body)
            return all_joints

        def _build_joints_forest() -> list[int]:
            """Builds joints using a spanning-forest traversal to ensure articulation-safe (tree) topology."""
            nonlocal joint_counter
            all_joints: list[int] = []
            visited = [False] * num_edges
            component_index = 0

            for start_edge in range(num_edges):
                if visited[start_edge]:
                    continue

                # BFS over edges
                queue: deque[int] = deque([start_edge])
                visited[start_edge] = True
                component_joints: list[int] = []
                component_edges: list[int] = []

                while queue:
                    parent_edge = queue.popleft()
                    component_edges.append(parent_edge)
                    parent_body = edge_bodies[parent_edge]

                    for shared_node in (edge_u[parent_edge], edge_v[parent_edge]):
                        for child_edge in node_incidence[shared_node]:
                            if child_edge == parent_edge or visited[child_edge]:
                                continue

                            child_body = edge_bodies[child_edge]
                            if parent_body == child_body:
                                raise RuntimeError("add_rod_graph: internal error (self-connection)")

                            # Anchors at the shared node on each edge body
                            parent_xform = _edge_anchor_xform(parent_edge, shared_node)
                            child_xform = _edge_anchor_xform(child_edge, shared_node)

                            joint_counter += 1
                            joint_label = f"{label}_cable_{joint_counter}" if label else None

                            j = self.add_joint_rod(
                                parent=parent_body,
                                child=child_body,
                                parent_xform=parent_xform,
                                child_xform=child_xform,
                                bend_stiffness=bend_stiffness,
                                bend_damping=bend_damping,
                                twist_stiffness=twist_stiffness,
                                twist_damping=twist_damping,
                                stretch_stiffness=stretch_stiffness,
                                stretch_damping=stretch_damping,
                                shear_stiffness=shear_stiffness,
                                shear_damping=shear_damping,
                                label=joint_label,
                                collision_filter_parent=True,
                                enabled=True,
                            )

                            component_joints.append(j)
                            all_joints.append(j)
                            _remember_jointed_pair(parent_body, child_body)
                            visited[child_edge] = True
                            queue.append(child_edge)

                # If the original node-edge graph contains a cycle, we cannot "close" it with extra
                # joints while keeping an articulation tree. Warn so callers don't assume rings/loops
                # are preserved under `wrap_in_articulation=True`.
                if component_edges:
                    component_nodes: set[int] = set()
                    for e_idx in component_edges:
                        component_nodes.add(edge_u[e_idx])
                        component_nodes.add(edge_v[e_idx])

                    # Undirected graph cycle condition: E > V - 1 (for any connected component).
                    if len(component_edges) > max(0, len(component_nodes) - 1):
                        warnings.warn(
                            "Rod graph contains a cycle (closed loop). "
                            "With wrap_in_articulation=True, joints are built as a tree/forest, so "
                            "cycles are not closed. Use wrap_in_articulation=False to retain every "
                            "cycle adjacency joint.",
                            UserWarning,
                            stacklevel=self._external_warning_stacklevel(),
                        )

                # Wrap the connected component into an articulation.
                if component_joints:
                    if label:
                        art_label = (
                            f"{label}_articulation_{component_index}"
                            if component_index > 0
                            else f"{label}_articulation"
                        )
                    else:
                        art_label = None
                    self.add_articulation(component_joints, label=art_label)

                component_index += 1

            return all_joints

        if not wrap_in_articulation:
            all_joints = _build_joints_star()
        else:
            all_joints = _build_joints_forest()

        if junction_collision_filter:
            # Filter collisions among *non-jointed* sibling bodies incident to each junction node
            # (degree >= 3). Jointed parent/child pairs are already filtered by
            # add_joint_rod(collision_filter_parent=True).
            for inc in node_incidence:
                if len(inc) < 3:
                    continue
                bodies_set = {edge_bodies[e_idx] for e_idx in inc}
                if len(bodies_set) < 2:
                    continue
                bodies = sorted(bodies_set)

                for i in range(len(bodies)):
                    for j in range(i + 1, len(bodies)):
                        bi = bodies[i]
                        bj = bodies[j]
                        if (bi, bj) in jointed_body_pairs:
                            # Already filtered by add_joint_rod(collision_filter_parent=True).
                            continue
                        for si in self.body_shapes.get(bi, []):
                            if not self.shape_flags[si] & ShapeFlags.COLLIDE_SHAPES:
                                continue
                            for sj in self.body_shapes.get(bj, []):
                                if not self.shape_flags[sj] & ShapeFlags.COLLIDE_SHAPES:
                                    continue
                                self.add_shape_collision_filter_pair(int(si), int(sj))

        return edge_bodies, all_joints

    # endregion

    # particles
    def add_particle(
        self,
        pos: Vec3,
        vel: Vec3,
        mass: float,
        radius: float | None = None,
        flags: int = ParticleFlags.ACTIVE,
        custom_attributes: dict[str, Any] | None = None,
    ) -> int:
        """Adds a single particle to the model.

        Args:
            pos: The initial position of the particle.
            vel: The initial velocity of the particle.
            mass: The mass of the particle.
            radius: The radius of the particle used in collision handling. If None, the radius is set to the default value (:attr:`default_particle_radius`).
            flags: The flags that control the dynamical behavior of the particle, see :class:`newton.ParticleFlags`.
            custom_attributes: Dictionary of custom attribute names to values.

        Note:
            Set the mass equal to zero to create a 'kinematic' particle that is not subject to dynamics.

        Returns:
            The index of the particle in the system.
        """
        self.particle_q.append(pos)
        self.particle_qd.append(vel)
        self.particle_mass.append(mass)
        if radius is None:
            radius = self.default_particle_radius
        self.particle_radius.append(radius)
        self.particle_flags.append(flags)
        self.particle_world.append(self.current_world)

        particle_id = self.particle_count - 1

        # Process custom attributes
        if custom_attributes:
            self._process_custom_attributes(
                entity_index=particle_id,
                custom_attrs=custom_attributes,
                expected_frequency=Model.AttributeFrequency.PARTICLE,
            )

        return particle_id

    def add_particles(
        self,
        pos: list[Vec3],
        vel: list[Vec3],
        mass: list[float],
        radius: list[float] | None = None,
        flags: list[int] | None = None,
        custom_attributes: dict[str, Any] | None = None,
    ):
        """Adds a group of particles to the model.

        Args:
            pos: The initial positions of the particles.
            vel: The initial velocities of the particles.
            mass: The mass of the particles.
            radius: The radius of the particles used in collision handling. If None, the radius is set to the default value (:attr:`default_particle_radius`).
            flags: The flags that control the dynamical behavior of the particles, see :class:`newton.ParticleFlags`.
            custom_attributes: Dictionary of custom attribute names to lists of values (one value for each particle).

        Note:
            Set the mass equal to zero to create a 'kinematic' particle that is not subject to dynamics.

        Raises:
            ValueError: If a particle input or custom attribute list has a mismatched length.
        """
        particle_count = len(pos)
        required_inputs = (
            ("vel", vel),
            ("mass", mass),
        )
        optional_inputs = (
            ("radius", radius),
            ("flags", flags),
        )
        for name, values in required_inputs:
            if values is None or len(values) != particle_count:
                actual_count = "None" if values is None else len(values)
                raise ValueError(
                    f"{name} length mismatch: expected {particle_count} values to match pos, got {actual_count}"
                )
        for name, values in optional_inputs:
            if values is not None and len(values) != particle_count:
                raise ValueError(
                    f"{name} length mismatch: expected {particle_count} values to match pos, got {len(values)}"
                )

        particle_start = self.particle_count

        self.particle_q.extend(pos)
        self.particle_qd.extend(vel)
        self.particle_mass.extend(mass)
        if radius is None:
            radius = [self.default_particle_radius] * particle_count
        if flags is None:
            flags = [ParticleFlags.ACTIVE] * particle_count
        self.particle_radius.extend(radius)
        self.particle_flags.extend(flags)
        # Maintain world assignment for bulk particle creation
        self.particle_world.extend([self.current_world] * particle_count)

        # Process custom attributes
        if custom_attributes and particle_count:
            particle_indices = list(range(particle_start, particle_start + particle_count))
            self._process_custom_attributes(
                entity_index=particle_indices,
                custom_attrs=custom_attributes,
                expected_frequency=Model.AttributeFrequency.PARTICLE,
            )

    def add_spring(
        self,
        i: int,
        j: int,
        ke: float,
        kd: float,
        control: float,
        custom_attributes: dict[str, Any] | None = None,
    ):
        """Adds a spring between two particles in the system

        Args:
            i: The index of the first particle
            j: The index of the second particle
            ke: The elastic stiffness of the spring
            kd: The damping coefficient of the spring [N·s/m].
            control: The actuation level of the spring
            custom_attributes: Dictionary of custom attribute names to values.

        Note:
            The spring is created with a rest-length based on the distance
            between the particles in their initial configuration.

        """
        self.spring_indices.append(i)
        self.spring_indices.append(j)
        self.spring_stiffness.append(ke)
        self.spring_damping.append(kd)
        self.spring_control.append(control)

        # compute rest length
        p = np.asarray(self.particle_q[i], dtype=np.float32)
        q = np.asarray(self.particle_q[j], dtype=np.float32)

        delta = np.subtract(p, q)
        l = np.sqrt(np.dot(delta, delta))

        self.spring_rest_length.append(l)

        # Process custom attributes
        if custom_attributes:
            spring_index = len(self.spring_rest_length) - 1
            self._process_custom_attributes(
                entity_index=spring_index,
                custom_attrs=custom_attributes,
                expected_frequency=Model.AttributeFrequency.SPRING,
            )

    def add_triangle(
        self,
        i: int,
        j: int,
        k: int,
        *,
        tri_ke: float | None = None,
        tri_ka: float | None = None,
        tri_kd: float | None = None,
        tri_drag: float | None = None,
        tri_lift: float | None = None,
        color: Vec3 | None = None,
        opacity: float | None = None,
        custom_attributes: dict[str, Any] | None = None,
    ) -> float:
        """Adds a triangular FEM element between three particles in the system.

        Triangles are modeled as viscoelastic elements with elastic stiffness and damping
        parameters specified on the model. See :attr:`~newton.Model.tri_materials`.

        Args:
            i: The index of the first particle.
            j: The index of the second particle.
            k: The index of the third particle.
            tri_ke: The elastic stiffness of the triangle. If None, the default value (:attr:`default_tri_ke`) is used.
            tri_ka: The area stiffness of the triangle. If None, the default value (:attr:`default_tri_ka`) is used.
            tri_kd: The damping coefficient of the triangle. If None, the default value (:attr:`default_tri_kd`) is used.
            tri_drag: The drag coefficient of the triangle. If None, the default value (:attr:`default_tri_drag`) is used.
            tri_lift: The lift coefficient of the triangle. If None, the default value (:attr:`default_tri_lift`) is used.
            color: Display color in [0, 1]. If None, the default triangle color is used.
            opacity: Display opacity in [0, 1]. If None, the triangle is fully opaque.
            custom_attributes: Dictionary of custom attribute names to values.

        Return:
            The area of the triangle

        Note:
            The triangle is created with a rest-length based on the distance
            between the particles in their initial configuration.
        """
        tri_ke = tri_ke if tri_ke is not None else self.default_tri_ke
        tri_ka = tri_ka if tri_ka is not None else self.default_tri_ka
        tri_kd = tri_kd if tri_kd is not None else self.default_tri_kd
        tri_drag = tri_drag if tri_drag is not None else self.default_tri_drag
        tri_lift = tri_lift if tri_lift is not None else self.default_tri_lift
        resolved_color = _validate_color(
            self._DEFAULT_TRI_COLOR if color is None else color,
            "Triangle color",
        )
        resolved_opacity = _validate_opacity(1.0 if opacity is None else opacity, "Triangle opacity")

        # compute basis for 2D rest pose
        p = self.particle_q[i]
        q = self.particle_q[j]
        r = self.particle_q[k]

        qp = q - p
        rp = r - p

        # construct basis aligned with the triangle
        n = wp.normalize(wp.cross(qp, rp))
        e1 = wp.normalize(qp)
        e2 = wp.normalize(wp.cross(n, e1))

        R = np.array((e1, e2))
        M = np.array((qp, rp))

        D = R @ M.T

        area = np.linalg.det(D) / 2.0

        if area <= 0.0:
            print("inverted or degenerate triangle element")
            return 0.0
        else:
            inv_D = np.linalg.inv(D)

            self.tri_indices.append((i, j, k))
            self.tri_poses.append(inv_D.tolist())
            self.tri_activations.append(0.0)
            self.tri_materials.append((tri_ke, tri_ka, tri_kd, tri_drag, tri_lift))
            self.tri_areas.append(area)
            self.tri_color.append(resolved_color)
            self.tri_opacity.append(resolved_opacity)

            # Process custom attributes
            if custom_attributes:
                tri_index = len(self.tri_indices) - 1
                self._process_custom_attributes(
                    entity_index=tri_index,
                    custom_attrs=custom_attributes,
                    expected_frequency=Model.AttributeFrequency.TRIANGLE,
                )
            return area

    def add_triangles(
        self,
        i: list[int] | np.ndarray,
        j: list[int] | np.ndarray,
        k: list[int] | np.ndarray,
        *,
        tri_ke: list[float] | None = None,
        tri_ka: list[float] | None = None,
        tri_kd: list[float] | None = None,
        tri_drag: list[float] | None = None,
        tri_lift: list[float] | None = None,
        color: Vec3 | list[Vec3] | np.ndarray | None = None,
        opacity: float | list[float] | np.ndarray | None = None,
        custom_attributes: dict[str, Any] | None = None,
    ) -> list[float]:
        """Adds triangular FEM elements between groups of three particles in the system.

        Triangles are modeled as viscoelastic elements with elastic stiffness and damping
        Parameters specified on the model. See model.tri_ke, model.tri_kd.

        Args:
            i: The indices of the first particle
            j: The indices of the second particle
            k: The indices of the third particle
            tri_ke: The elastic stiffness of the triangles. If None, the default value (:attr:`default_tri_ke`) is used.
            tri_ka: The area stiffness of the triangles. If None, the default value (:attr:`default_tri_ka`) is used.
            tri_kd: The damping coefficient of the triangles. If None, the default value (:attr:`default_tri_kd`) is used.
            tri_drag: The drag coefficient of the triangles. If None, the default value (:attr:`default_tri_drag`) is used.
            tri_lift: The lift coefficient of the triangles. If None, the default value (:attr:`default_tri_lift`) is used.
            color: Display color in [0, 1]. If a single RGB value, applied to all
                triangles. If array-like, RGB values are applied per triangle.
            opacity: Display opacity in [0, 1]. If scalar, applied to all triangles.
                If array-like, values are applied per triangle.
            custom_attributes: Dictionary of custom attribute names to values.

        Return:
            The areas of the triangles

        Note:
            A triangle is created with a rest-length based on the distance
            between the particles in their initial configuration.

        """
        # compute basis for 2D rest pose
        q_ = np.asarray(self.particle_q)
        p = q_[i]
        q = q_[j]
        r = q_[k]

        qp = q - p
        rp = r - p

        def normalized(a):
            l = np.linalg.norm(a, axis=-1, keepdims=True)
            l[l == 0] = 1.0
            return a / l

        n = normalized(np.cross(qp, rp))
        e1 = normalized(qp)
        e2 = normalized(np.cross(n, e1))

        R = np.concatenate((e1[..., None], e2[..., None]), axis=-1)
        M = np.concatenate((qp[..., None], rp[..., None]), axis=-1)

        D = np.matmul(R.transpose(0, 2, 1), M)

        areas = np.linalg.det(D) / 2.0
        areas[areas < 0.0] = 0.0
        valid_inds = (areas > 0.0).nonzero()[0]
        if len(valid_inds) < len(areas):
            print("inverted or degenerate triangle elements")

        filtered_custom_attributes = None
        if custom_attributes:
            filtered_custom_attributes = {}
            for key, value in custom_attributes.items():
                is_sequence = isinstance(value, (list, tuple)) or (isinstance(value, np.ndarray) and value.ndim != 0)
                if is_sequence:
                    if len(value) != len(areas):
                        raise ValueError(f"Expected {len(areas)} values, got {len(value)}")
                    filtered_custom_attributes[key] = [value[index] for index in valid_inds]
                else:
                    filtered_custom_attributes[key] = value

        D[areas == 0.0] = np.eye(2)[None, ...]
        inv_D = np.linalg.inv(D)

        i_ = np.asarray(i)
        j_ = np.asarray(j)
        k_ = np.asarray(k)

        inds = np.concatenate((i_[valid_inds, None], j_[valid_inds, None], k_[valid_inds, None]), axis=-1)

        color_arr = _broadcast_triangle_colors(color, len(areas), self._DEFAULT_TRI_COLOR)
        opacity_arr = _broadcast_triangle_opacities(opacity, len(areas))

        tri_start = len(self.tri_indices)
        self.tri_indices.extend(inds.tolist())
        self.tri_poses.extend(inv_D[valid_inds].tolist())
        self.tri_activations.extend([0.0] * len(valid_inds))

        def init_if_none(arr, defaultValue):
            if arr is None:
                return [defaultValue] * len(areas)
            return arr

        tri_ke = init_if_none(tri_ke, self.default_tri_ke)
        tri_ka = init_if_none(tri_ka, self.default_tri_ka)
        tri_kd = init_if_none(tri_kd, self.default_tri_kd)
        tri_drag = init_if_none(tri_drag, self.default_tri_drag)
        tri_lift = init_if_none(tri_lift, self.default_tri_lift)

        self.tri_materials.extend(
            zip(
                np.array(tri_ke)[valid_inds],
                np.array(tri_ka)[valid_inds],
                np.array(tri_kd)[valid_inds],
                np.array(tri_drag)[valid_inds],
                np.array(tri_lift)[valid_inds],
                strict=False,
            )
        )
        self.tri_color.extend(color_arr[valid_inds].tolist())
        self.tri_opacity.extend(opacity_arr[valid_inds].tolist())
        areas_list = areas.tolist()
        self.tri_areas.extend(areas[valid_inds].tolist())

        # Process custom attributes
        if filtered_custom_attributes and len(valid_inds) > 0:
            tri_indices = list(range(tri_start, tri_start + len(valid_inds)))
            self._process_custom_attributes(
                entity_index=tri_indices,
                custom_attrs=filtered_custom_attributes,
                expected_frequency=Model.AttributeFrequency.TRIANGLE,
            )
        return areas_list

    def add_tetrahedron(
        self,
        i: int,
        j: int,
        k: int,
        l: int,
        k_mu: float = 1.0e3,
        k_lambda: float = 1.0e3,
        k_damp: float = 0.0,
        custom_attributes: dict[str, Any] | None = None,
    ) -> float:
        """Adds a tetrahedral FEM element between four particles in the system.

        Tetrahedra are modeled as viscoelastic elements with a NeoHookean energy
        density based on [Smith et al. 2018].

        Args:
            i: The index of the first particle
            j: The index of the second particle
            k: The index of the third particle
            l: The index of the fourth particle
            k_mu: The first elastic Lame parameter
            k_lambda: The second elastic Lame parameter
            k_damp: The element's viscous damping coefficient [Pa·s].
            custom_attributes: Dictionary of custom attribute names to values.

        Return:
            The volume of the tetrahedron

        Note:
            The tetrahedron is created with a rest-pose based on the particle's initial configuration

        """
        # compute basis for 2D rest pose
        p = np.array(self.particle_q[i])
        q = np.array(self.particle_q[j])
        r = np.array(self.particle_q[k])
        s = np.array(self.particle_q[l])

        qp = q - p
        rp = r - p
        sp = s - p

        Dm = np.array((qp, rp, sp)).T
        volume = np.linalg.det(Dm) / 6.0

        if volume <= 0.0:
            print("inverted tetrahedral element")
        else:
            inv_Dm = np.linalg.inv(Dm)

            self.tet_indices.append((i, j, k, l))
            self.tet_poses.append(inv_Dm.tolist())
            self.tet_activations.append(0.0)
            self.tet_materials.append((k_mu, k_lambda, k_damp))

            # Process custom attributes
            if custom_attributes:
                tet_index = len(self.tet_indices) - 1
                self._process_custom_attributes(
                    entity_index=tet_index,
                    custom_attrs=custom_attributes,
                    expected_frequency=Model.AttributeFrequency.TETRAHEDRON,
                )

        return volume

    def add_edge(
        self,
        i: int,
        j: int,
        k: int,
        l: int,
        *,
        rest: float | None = None,
        edge_ke: float | None = None,
        edge_kd: float | None = None,
        custom_attributes: dict[str, Any] | None = None,
    ) -> int:
        """Adds a bending edge element between two adjacent triangles in the cloth mesh, defined by four vertices.

        The bending energy model follows the discrete shell formulation from [Grinspun et al. 2003].
        The bending stiffness is controlled by the `edge_ke` parameter, and the bending damping by the `edge_kd` parameter.

        Args:
            i: The index of the first particle, i.e., opposite vertex 0
            j: The index of the second particle, i.e., opposite vertex 1
            k: The index of the third particle, i.e., vertex 0
            l: The index of the fourth particle, i.e., vertex 1
            rest: The rest angle across the edge in radians, if not specified it will be computed
            edge_ke: The bending stiffness coefficient
            edge_kd: The bending damping coefficient
            custom_attributes: Dictionary of custom attribute names to values.

        Return:
            The index of the edge.

        Note:
            The edge lies between the particles indexed by 'k' and 'l' parameters with the opposing
            vertices indexed by 'i' and 'j'. This defines two connected triangles with counterclockwise
            winding: (i, k, l), (j, l, k).

        """
        edge_ke = edge_ke if edge_ke is not None else self.default_edge_ke
        edge_kd = edge_kd if edge_kd is not None else self.default_edge_kd

        # compute rest angle
        x3 = self.particle_q[k]
        x4 = self.particle_q[l]
        if rest is None:
            rest = 0.0
            if i != -1 and j != -1:
                x1 = self.particle_q[i]
                x2 = self.particle_q[j]

                n1 = wp.normalize(wp.cross(x3 - x1, x4 - x1))
                n2 = wp.normalize(wp.cross(x4 - x2, x3 - x2))
                e = wp.normalize(x4 - x3)

                cos_theta = np.clip(np.dot(n1, n2), -1.0, 1.0)
                sin_theta = np.dot(np.cross(n1, n2), e)
                rest = math.atan2(sin_theta, cos_theta)

        self.edge_indices.append((i, j, k, l))
        self.edge_rest_angle.append(rest)
        self.edge_rest_length.append(wp.length(x4 - x3))
        self.edge_bending_properties.append((edge_ke, edge_kd))
        edge_index = len(self.edge_indices) - 1

        # Process custom attributes
        if custom_attributes:
            self._process_custom_attributes(
                entity_index=edge_index,
                custom_attrs=custom_attributes,
                expected_frequency=Model.AttributeFrequency.EDGE,
            )

        return edge_index

    def add_edges(
        self,
        i: list[int],
        j: list[int],
        k: list[int],
        l: list[int],
        *,
        rest: list[float] | None = None,
        edge_ke: list[float] | None = None,
        edge_kd: list[float] | None = None,
        custom_attributes: dict[str, Any] | None = None,
    ) -> None:
        """Adds bending edge elements between two adjacent triangles in the cloth mesh, defined by four vertices.

        The bending energy model follows the discrete shell formulation from [Grinspun et al. 2003].
        The bending stiffness is controlled by the `edge_ke` parameter, and the bending damping by the `edge_kd` parameter.

        Args:
            i: The indices of the first particles, i.e., opposite vertex 0
            j: The indices of the second particles, i.e., opposite vertex 1
            k: The indices of the third particles, i.e., vertex 0
            l: The indices of the fourth particles, i.e., vertex 1
            rest: The rest angles across the edges in radians, if not specified they will be computed
            edge_ke: The bending stiffness coefficients
            edge_kd: The bending damping coefficients
            custom_attributes: Dictionary of custom attribute names to values.

        Note:
            The edge lies between the particles indexed by 'k' and 'l' parameters with the opposing
            vertices indexed by 'i' and 'j'. This defines two connected triangles with counterclockwise
            winding: (i, k, l), (j, l, k).

        """
        # Convert inputs to numpy arrays
        i_ = np.asarray(i)
        j_ = np.asarray(j)
        k_ = np.asarray(k)
        l_ = np.asarray(l)

        # Cache particle positions as numpy array
        particle_q_ = np.asarray(self.particle_q)
        x3 = particle_q_[k_]
        x4 = particle_q_[l_]
        x4_minus_x3 = x4 - x3

        if rest is None:
            rest = np.zeros_like(i_, dtype=float)
            valid_mask = (i_ != -1) & (j_ != -1)

            # compute rest angle
            x1_valid = particle_q_[i_[valid_mask]]
            x2_valid = particle_q_[j_[valid_mask]]
            x3_valid = particle_q_[k_[valid_mask]]
            x4_valid = particle_q_[l_[valid_mask]]

            def normalized(a):
                l = np.linalg.norm(a, axis=-1, keepdims=True)
                l[l == 0] = 1.0
                return a / l

            n1 = normalized(np.cross(x3_valid - x1_valid, x4_valid - x1_valid))
            n2 = normalized(np.cross(x4_valid - x2_valid, x3_valid - x2_valid))
            e = normalized(x4_valid - x3_valid)

            def dot(a, b):
                return (a * b).sum(axis=-1)

            cos_theta = np.clip(dot(n1, n2), -1.0, 1.0)
            sin_theta = dot(np.cross(n1, n2), e)
            rest[valid_mask] = np.arctan2(sin_theta, cos_theta)
            rest = rest.tolist()

        inds = np.concatenate((i_[:, None], j_[:, None], k_[:, None], l_[:, None]), axis=-1)

        edge_start = len(self.edge_indices)
        self.edge_indices.extend(inds.tolist())
        self.edge_rest_angle.extend(rest)
        self.edge_rest_length.extend(np.linalg.norm(x4_minus_x3, axis=1).tolist())

        def init_if_none(arr, defaultValue):
            if arr is None:
                return [defaultValue] * len(i)
            return arr

        edge_ke = init_if_none(edge_ke, self.default_edge_ke)
        edge_kd = init_if_none(edge_kd, self.default_edge_kd)

        self.edge_bending_properties.extend(zip(edge_ke, edge_kd, strict=False))

        # Process custom attributes
        if custom_attributes and len(i) > 0:
            edge_indices = list(range(edge_start, edge_start + len(i)))
            self._process_custom_attributes(
                entity_index=edge_indices,
                custom_attrs=custom_attributes,
                expected_frequency=Model.AttributeFrequency.EDGE,
            )

    @staticmethod
    def _expand_edge_parameter(values: float | Sequence[float] | np.ndarray | None, count: int):
        """Normalize edge parameters to one value per generated edge."""
        if values is None:
            return None
        values_array = np.asarray(values, dtype=np.float32)
        if values_array.ndim == 0:
            return [float(values_array)] * count
        values_flat = values_array.reshape(-1)
        if values_flat.size != count:
            raise ValueError(f"Expected {count} edge parameter values, got {values_flat.size}")
        return values_flat.tolist()

    def _add_soft_mesh_edges_from_triangles(
        self,
        start_tri: int,
        end_tri: int,
        *,
        edge_ke: float | Sequence[float] | np.ndarray | None = None,
        edge_kd: float | Sequence[float] | np.ndarray | None = None,
        custom_attributes: dict[str, Any] | None = None,
    ) -> range:
        """Register bending edges for a triangle range from its derived edge topology.

        Computes the unique edges of the triangle range and registers them as
        bending edges (with material). The edge/triangle adjacency maps are rebuilt
        from the accumulated tables in :meth:`finalize`.

        Returns:
            The range of global edge indices added.
        """
        edge_start = len(self.edge_indices)
        if end_tri > start_tri:
            local = MeshAdjacency(self.tri_indices[start_tri:end_tri])
            edge_count = local.edge_indices.shape[0]
            if edge_count:
                self.add_edges(
                    local.edge_indices[:, 0],
                    local.edge_indices[:, 1],
                    local.edge_indices[:, 2],
                    local.edge_indices[:, 3],
                    edge_ke=self._expand_edge_parameter(edge_ke, edge_count),
                    edge_kd=self._expand_edge_parameter(edge_kd, edge_count),
                    custom_attributes=custom_attributes,
                )
        return range(edge_start, len(self.edge_indices))

    def add_cloth_grid(
        self,
        *,
        pos: Vec3,
        rot: Quat,
        vel: Vec3,
        dim_x: int,
        dim_y: int,
        cell_x: float,
        cell_y: float,
        mass: float,
        reverse_winding: bool = False,
        fix_left: bool = False,
        fix_right: bool = False,
        fix_top: bool = False,
        fix_bottom: bool = False,
        tri_ke: float | None = None,
        tri_ka: float | None = None,
        tri_kd: float | None = None,
        tri_drag: float | None = None,
        tri_lift: float | None = None,
        edge_ke: float | None = None,
        edge_kd: float | None = None,
        add_springs: bool = False,
        spring_ke: float | None = None,
        spring_kd: float | None = None,
        particle_radius: float | None = None,
        color: Vec3 | list[Vec3] | np.ndarray | None = None,
        opacity: float | list[float] | np.ndarray | None = None,
        custom_attributes_particles: dict[str, Any] | None = None,
        custom_attributes_edges: dict[str, Any] | None = None,
        custom_attributes_triangles: dict[str, Any] | None = None,
        label: str | None = None,
    ):
        """Helper to create a regular planar cloth grid

        Creates a rectangular grid of particles with FEM triangles and bending elements
        automatically.

        Args:
            pos: The position of the cloth in world space
            rot: The orientation of the cloth in world space
            vel: The velocity of the cloth in world space
            dim_x_: The number of rectangular cells along the x-axis
            dim_y: The number of rectangular cells along the y-axis
            cell_x: The width of each cell in the x-direction
            cell_y: The width of each cell in the y-direction
            mass: The mass of each particle
            reverse_winding: Flip the winding of the mesh
            fix_left: Make the left-most edge of particles kinematic (fixed in place)
            fix_right: Make the right-most edge of particles kinematic
            fix_top: Make the top-most edge of particles kinematic
            fix_bottom: Make the bottom-most edge of particles kinematic
            label: Optional name forwarded to :func:`newton.utils.validate_triangle_mesh`
                via :meth:`add_cloth_mesh` so a mesh-quality warning can identify
                this cloth.
            color: Display color in [0, 1] for the cloth surface. If a single
                RGB value, applied to all triangles. If array-like, RGB values
                are applied per triangle.
            opacity: Display opacity in [0, 1] for the cloth surface. If scalar,
                applied to all triangles. If array-like, values are applied per
                triangle.
        """

        def grid_index(x, y, dim_x):
            return y * dim_x + x

        indices, vertices = [], []
        for y in range(0, dim_y + 1):
            for x in range(0, dim_x + 1):
                local_pos = wp.vec3(x * cell_x, y * cell_y, 0.0)
                vertices.append(local_pos)
                if x > 0 and y > 0:
                    v0 = grid_index(x - 1, y - 1, dim_x + 1)
                    v1 = grid_index(x, y - 1, dim_x + 1)
                    v2 = grid_index(x, y, dim_x + 1)
                    v3 = grid_index(x - 1, y, dim_x + 1)
                    if reverse_winding:
                        indices.extend([v0, v1, v2])
                        indices.extend([v0, v2, v3])
                    else:
                        indices.extend([v0, v1, v3])
                        indices.extend([v1, v2, v3])

        start_vertex = len(self.particle_q)

        total_mass = mass * (dim_x + 1) * (dim_x + 1)
        total_area = cell_x * cell_y * dim_x * dim_y
        density = total_mass / total_area

        self.add_cloth_mesh(
            pos=pos,
            rot=rot,
            scale=1.0,
            vel=vel,
            vertices=vertices,
            indices=indices,
            density=density,
            tri_ke=tri_ke,
            tri_ka=tri_ka,
            tri_kd=tri_kd,
            tri_drag=tri_drag,
            tri_lift=tri_lift,
            edge_ke=edge_ke,
            edge_kd=edge_kd,
            add_springs=add_springs,
            spring_ke=spring_ke,
            spring_kd=spring_kd,
            particle_radius=particle_radius,
            color=color,
            opacity=opacity,
            custom_attributes_particles=custom_attributes_particles,
            custom_attributes_triangles=custom_attributes_triangles,
            custom_attributes_edges=custom_attributes_edges,
            label=label,
        )

        vertex_id = 0
        for y in range(dim_y + 1):
            for x in range(dim_x + 1):
                particle_mass = mass
                particle_flag = ParticleFlags.ACTIVE

                if (
                    (x == 0 and fix_left)
                    or (x == dim_x and fix_right)
                    or (y == 0 and fix_bottom)
                    or (y == dim_y and fix_top)
                ):
                    particle_flag = particle_flag & ~ParticleFlags.ACTIVE
                    particle_mass = 0.0

                self.particle_flags[start_vertex + vertex_id] = particle_flag
                self.particle_mass[start_vertex + vertex_id] = particle_mass
                vertex_id = vertex_id + 1

    def add_cloth_mesh(
        self,
        *,
        pos: Vec3,
        rot: Quat,
        scale: float,
        vel: Vec3,
        vertices: list[Vec3],
        indices: list[int],
        density: float,
        tri_ke: float | None = None,
        tri_ka: float | None = None,
        tri_kd: float | None = None,
        tri_drag: float | None = None,
        tri_lift: float | None = None,
        edge_ke: float | None = None,
        edge_kd: float | None = None,
        add_springs: bool = False,
        spring_ke: float | None = None,
        spring_kd: float | None = None,
        particle_radius: float | None = None,
        color: Vec3 | list[Vec3] | np.ndarray | None = None,
        opacity: float | list[float] | np.ndarray | None = None,
        custom_attributes_particles: dict[str, Any] | None = None,
        custom_attributes_edges: dict[str, Any] | None = None,
        custom_attributes_triangles: dict[str, Any] | None = None,
        custom_attributes_springs: dict[str, Any] | None = None,
        validate_mesh: bool = False,
        label: str | None = None,
    ) -> None:
        """Helper to create a cloth model from a regular triangle mesh

        Creates one FEM triangle element and one bending element for every face
        and edge in the input triangle mesh

        Args:
            pos: The position of the cloth in world space
            rot: The orientation of the cloth in world space
            vel: The velocity of the cloth in world space
            vertices: A list of vertex positions
            indices: A list of triangle indices, 3 entries per-face
            density: The density per-area of the mesh
            particle_radius: The particle_radius which controls particle based collisions.
            color: Display color in [0, 1] for the cloth surface. If a single
                RGB value, applied to all triangles. If array-like, RGB values
                are applied per triangle.
            opacity: Display opacity in [0, 1] for the cloth surface. If scalar,
                applied to all triangles. If array-like, values are applied per
                triangle.
            custom_attributes_particles: Dictionary of custom attribute names to values for the particles.
            custom_attributes_edges: Dictionary of custom attribute names to values for the edges.
            custom_attributes_triangles: Dictionary of custom attribute names to values for the triangles.
            custom_attributes_springs: Dictionary of custom attribute names to values for the springs.
            validate_mesh: If True, run quality checks on the input mesh and
                emit warnings for degenerate or sliver triangles and
                extreme interior angles. See
                :func:`newton.utils.validate_triangle_mesh`. (Non-manifold
                edges are reported separately by :class:`MeshAdjacency`,
                which is built unconditionally for the bending-edge
                pipeline.)
            label: Optional name forwarded to
                :func:`newton.utils.validate_triangle_mesh` so a mesh-quality
                warning emitted with ``validate_mesh=True`` can identify
                this cloth.

        Note:
            The mesh should be two-manifold.
        """
        tri_ke = tri_ke if tri_ke is not None else self.default_tri_ke
        tri_ka = tri_ka if tri_ka is not None else self.default_tri_ka
        tri_kd = tri_kd if tri_kd is not None else self.default_tri_kd
        tri_drag = tri_drag if tri_drag is not None else self.default_tri_drag
        tri_lift = tri_lift if tri_lift is not None else self.default_tri_lift
        edge_ke = edge_ke if edge_ke is not None else self.default_edge_ke
        edge_kd = edge_kd if edge_kd is not None else self.default_edge_kd
        spring_ke = spring_ke if spring_ke is not None else self.default_spring_ke
        spring_kd = spring_kd if spring_kd is not None else self.default_spring_kd
        particle_radius = particle_radius if particle_radius is not None else self.default_particle_radius

        if validate_mesh:
            from ..utils.mesh import validate_triangle_mesh  # noqa: PLC0415

            verts_np = np.array(vertices, dtype=float) * scale
            inds_np = np.asarray(indices, dtype=np.intp)
            validate_triangle_mesh(verts_np, inds_np, label=label, stacklevel=3)
            if inds_np.size > 0 and inds_np.size % 3 != 0:
                return

        num_verts = int(len(vertices))
        num_tris = int(len(indices) / 3)

        start_vertex = len(self.particle_q)
        start_tri = len(self.tri_indices)

        # particles
        # for v in vertices:
        #     p = wp.quat_rotate(rot, v * scale) + pos
        #     self.add_particle(p, vel, 0.0, radius=particle_radius)
        vertices_np = np.array(vertices) * scale
        rot_mat_np = np.array(wp.quat_to_matrix(rot), dtype=np.float32).reshape(3, 3)
        verts_3d_np = np.dot(vertices_np, rot_mat_np.T) + pos
        self.add_particles(
            verts_3d_np.tolist(),
            [vel] * num_verts,
            mass=[0.0] * num_verts,
            radius=[particle_radius] * num_verts,
            custom_attributes=custom_attributes_particles,
        )

        # triangles
        inds = start_vertex + np.array(indices)
        inds = inds.reshape(-1, 3)
        areas = self.add_triangles(
            inds[:, 0],
            inds[:, 1],
            inds[:, 2],
            tri_ke=[tri_ke] * num_tris,
            tri_ka=[tri_ka] * num_tris,
            tri_kd=[tri_kd] * num_tris,
            tri_drag=[tri_drag] * num_tris,
            tri_lift=[tri_lift] * num_tris,
            color=color,
            opacity=opacity,
            custom_attributes=custom_attributes_triangles,
        )
        for t in range(num_tris):
            area = areas[t]

            self.particle_mass[inds[t, 0]] += density * area / 3.0
            self.particle_mass[inds[t, 1]] += density * area / 3.0
            self.particle_mass[inds[t, 2]] += density * area / 3.0

        end_tri = len(self.tri_indices)

        edge_range = self._add_soft_mesh_edges_from_triangles(
            start_tri,
            end_tri,
            edge_ke=edge_ke,
            edge_kd=edge_kd,
            custom_attributes=custom_attributes_edges,
        )
        edge_indices = np.asarray(self.edge_indices[edge_range.start : edge_range.stop], dtype=np.int32)

        if add_springs:
            spring_indices = set()
            for i, j, k, l in edge_indices:
                spring_indices.add((min(k, l), max(k, l)))
                if i != -1:
                    spring_indices.add((min(i, k), max(i, k)))
                    spring_indices.add((min(i, l), max(i, l)))
                if j != -1:
                    spring_indices.add((min(j, k), max(j, k)))
                    spring_indices.add((min(j, l), max(j, l)))
                if i != -1 and j != -1:
                    spring_indices.add((min(i, j), max(i, j)))

            for i, j in spring_indices:
                self.add_spring(i, j, spring_ke, spring_kd, control=0.0, custom_attributes=custom_attributes_springs)

    def add_particle_grid(
        self,
        *,
        pos: Vec3,
        rot: Quat,
        vel: Vec3,
        dim_x: int,
        dim_y: int,
        dim_z: int,
        cell_x: float,
        cell_y: float,
        cell_z: float,
        mass: float,
        jitter: float,
        radius_mean: float | None = None,
        radius_std: float = 0.0,
        flags: list[int] | int | None = None,
        custom_attributes: dict[str, Any] | None = None,
    ):
        """
        Adds a regular 3D grid of particles to the model.

        This helper function creates a grid of particles arranged in a rectangular lattice,
        with optional random jitter and per-particle radius variation. The grid is defined
        by its dimensions along each axis and the spacing between particles.

        Args:
            pos: The world-space position of the grid origin.
            rot: The rotation to apply to the grid (as a quaternion).
            vel: The initial velocity to assign to each particle.
            dim_x: Number of particles along the X axis.
            dim_y: Number of particles along the Y axis.
            dim_z: Number of particles along the Z axis.
            cell_x: Spacing between particles along the X axis.
            cell_y: Spacing between particles along the Y axis.
            cell_z: Spacing between particles along the Z axis.
            mass: Mass to assign to each particle.
            jitter: Maximum random offset to apply to each particle position.
            radius_mean: Mean radius for particles. If None, uses the builder's default.
            radius_std: Standard deviation for particle radii. If > 0, radii are sampled from a normal distribution.
            flags: Flags to assign to each particle. If None, uses the builder's default.
            custom_attributes: Dictionary of custom attribute names to values for the particles.

        Returns:
            Nothing. The builder is updated in place.
        """

        # local grid
        px = np.arange(dim_x) * cell_x
        py = np.arange(dim_y) * cell_y
        pz = np.arange(dim_z) * cell_z
        points = np.stack(np.meshgrid(px, py, pz)).reshape(3, -1).T

        # apply transform to points
        rot_mat = wp.quat_to_matrix(rot)
        points = points @ np.array(rot_mat).reshape(3, 3).T + np.array(pos)
        velocity = np.broadcast_to(np.array(vel).reshape(1, 3), points.shape)

        # add jitter
        rng = np.random.default_rng(42 + len(self.particle_q))
        points += (rng.random(points.shape) - 0.5) * jitter

        if radius_mean is None:
            radius_mean = self.default_particle_radius

        radii = np.full(points.shape[0], fill_value=radius_mean)
        if radius_std > 0.0:
            radii += rng.standard_normal(radii.shape) * radius_std

        masses = [mass] * points.shape[0]
        if flags is not None:
            flags = [flags] * points.shape[0]

        # Broadcast scalar custom attribute values to all particles
        num_particles = points.shape[0]
        broadcast_custom_attrs = None
        if custom_attributes:
            broadcast_custom_attrs = {}
            for key, value in custom_attributes.items():
                # Check if value is a sequence (but not string/bytes) or numpy array
                is_array = isinstance(value, np.ndarray)
                is_sequence = isinstance(value, Sequence) and not isinstance(value, (str, bytes))

                if is_array or is_sequence:
                    # Value is already a sequence/array - validate length
                    if len(value) != num_particles:
                        raise ValueError(
                            f"Custom attribute '{key}' has {len(value)} values but {num_particles} particles in grid"
                        )
                    broadcast_custom_attrs[key] = list(value) if is_array else value
                else:
                    # Scalar value - broadcast to all particles
                    broadcast_custom_attrs[key] = [value] * num_particles

        self.add_particles(
            pos=points.tolist(),
            vel=velocity.tolist(),
            mass=masses,
            radius=radii.tolist(),
            flags=flags,
            custom_attributes=broadcast_custom_attrs,
        )

    def add_soft_grid(
        self,
        *,
        pos: Vec3,
        rot: Quat,
        vel: Vec3,
        dim_x: int,
        dim_y: int,
        dim_z: int,
        cell_x: float,
        cell_y: float,
        cell_z: float,
        density: float,
        k_mu: float,
        k_lambda: float,
        k_damp: float,
        fix_left: bool = False,
        fix_right: bool = False,
        fix_top: bool = False,
        fix_bottom: bool = False,
        tri_ke: float = 0.0,
        tri_ka: float = 0.0,
        tri_kd: float = 0.0,
        tri_drag: float = 0.0,
        tri_lift: float = 0.0,
        add_surface_mesh_edges: bool = True,
        edge_ke: float = 0.0,
        edge_kd: float = 0.0,
        particle_radius: float | None = None,
        color: Vec3 | list[Vec3] | np.ndarray | None = None,
        opacity: float | list[float] | np.ndarray | None = None,
        label: str | None = None,
    ):
        """Helper to create a rectangular tetrahedral FEM grid

        Creates a regular grid of FEM tetrahedra and surface triangles. Useful for example
        to create beams and sheets. Each hexahedral cell is decomposed into 5
        tetrahedral elements.

        Args:
            pos: The position of the solid in world space
            rot: The orientation of the solid in world space
            vel: The velocity of the solid in world space
            dim_x_: The number of rectangular cells along the x-axis
            dim_y: The number of rectangular cells along the y-axis
            dim_z: The number of rectangular cells along the z-axis
            cell_x: The width of each cell in the x-direction
            cell_y: The width of each cell in the y-direction
            cell_z: The width of each cell in the z-direction
            density: The density of each particle
            k_mu: The first elastic Lame parameter
            k_lambda: The second elastic Lame parameter
            k_damp: The viscous damping coefficient [Pa·s].
            fix_left: Make the left-most edge of particles kinematic (fixed in place)
            fix_right: Make the right-most edge of particles kinematic
            fix_top: Make the top-most edge of particles kinematic
            fix_bottom: Make the bottom-most edge of particles kinematic
            tri_ke: Stiffness for surface mesh triangles. Defaults to 0.0.
            tri_ka: Area stiffness for surface mesh triangles. Defaults to 0.0.
            tri_kd: Damping for surface mesh triangles. Defaults to 0.0.
            tri_drag: Drag coefficient for surface mesh triangles. Defaults to 0.0.
            tri_lift: Lift coefficient for surface mesh triangles. Defaults to 0.0.
            add_surface_mesh_edges: Whether to create zero-stiffness bending edges on the
                generated surface mesh. These edges improve collision robustness for VBD solver. Defaults to True.
            edge_ke: Bending edge stiffness used when ``add_surface_mesh_edges`` is True. Defaults to 0.0.
            edge_kd: Bending edge damping used when ``add_surface_mesh_edges`` is True. Defaults to 0.0.
            particle_radius: particle's contact radius (controls rigidbody-particle contact distance)
            color: Display color in [0, 1] for the generated surface mesh. If a
                single RGB value, applied to all triangles. If array-like, RGB
                values are applied per triangle.
            opacity: Display opacity in [0, 1] for the generated surface mesh.
                If scalar, applied to all triangles. If array-like, values are
                applied per triangle.
            label: Optional name reserved for forwarding to mesh-quality
                diagnostics. Currently unused by ``add_soft_grid`` (the
                generated grid is degenerate-free by construction); kept
                for signature consistency with the other ``add_*`` helpers.

        Note:
            The generated surface triangles and optional edges are for collision purposes.
            Their stiffness and damping values default to zero so they do not introduce additional
            elastic forces. Set the triangle stiffness parameters above to non-zero values if you
            want the surface to behave like a thin skin.
        """
        del label  # currently unused; kept on the signature for API parity
        start_vertex = len(self.particle_q)

        mass = cell_x * cell_y * cell_z * density

        for z in range(dim_z + 1):
            for y in range(dim_y + 1):
                for x in range(dim_x + 1):
                    v = wp.vec3(x * cell_x, y * cell_y, z * cell_z)
                    m = mass

                    if fix_left and x == 0:
                        m = 0.0

                    if fix_right and x == dim_x:
                        m = 0.0

                    if fix_top and y == dim_y:
                        m = 0.0

                    if fix_bottom and y == 0:
                        m = 0.0

                    p = wp.quat_rotate(rot, v) + pos

                    self.add_particle(p, vel, m, particle_radius)

        # dict of open faces
        faces = {}

        def add_face(i: int, j: int, k: int):
            key = tuple(sorted((i, j, k)))

            if key not in faces:
                faces[key] = (i, j, k)
            else:
                del faces[key]

        def add_tet(i: int, j: int, k: int, l: int):
            self.add_tetrahedron(i, j, k, l, k_mu, k_lambda, k_damp)

            add_face(i, k, j)
            add_face(j, k, l)
            add_face(i, j, l)
            add_face(i, l, k)

        def grid_index(x, y, z):
            return (dim_x + 1) * (dim_y + 1) * z + (dim_x + 1) * y + x

        for z in range(dim_z):
            for y in range(dim_y):
                for x in range(dim_x):
                    v0 = grid_index(x, y, z) + start_vertex
                    v1 = grid_index(x + 1, y, z) + start_vertex
                    v2 = grid_index(x + 1, y, z + 1) + start_vertex
                    v3 = grid_index(x, y, z + 1) + start_vertex
                    v4 = grid_index(x, y + 1, z) + start_vertex
                    v5 = grid_index(x + 1, y + 1, z) + start_vertex
                    v6 = grid_index(x + 1, y + 1, z + 1) + start_vertex
                    v7 = grid_index(x, y + 1, z + 1) + start_vertex

                    if (x & 1) ^ (y & 1) ^ (z & 1):
                        add_tet(v0, v1, v4, v3)
                        add_tet(v2, v3, v6, v1)
                        add_tet(v5, v4, v1, v6)
                        add_tet(v7, v6, v3, v4)
                        add_tet(v4, v1, v6, v3)

                    else:
                        add_tet(v1, v2, v5, v0)
                        add_tet(v3, v0, v7, v2)
                        add_tet(v4, v7, v0, v5)
                        add_tet(v6, v5, v2, v7)
                        add_tet(v5, v2, v7, v0)

        # add surface triangles
        start_tri = len(self.tri_indices)
        surface_colors = _broadcast_triangle_colors(color, len(faces), self._DEFAULT_TRI_COLOR)
        surface_opacities = _broadcast_triangle_opacities(opacity, len(faces))
        for face_index, v in enumerate(faces.values()):
            self.add_triangle(
                v[0],
                v[1],
                v[2],
                tri_ke=tri_ke,
                tri_ka=tri_ka,
                tri_kd=tri_kd,
                tri_drag=tri_drag,
                tri_lift=tri_lift,
                color=surface_colors[face_index],
                opacity=surface_opacities[face_index],
            )
        end_tri = len(self.tri_indices)

        if add_surface_mesh_edges:
            # add surface mesh edges (for collision)
            if end_tri > start_tri:
                self._add_soft_mesh_edges_from_triangles(start_tri, end_tri, edge_ke=edge_ke, edge_kd=edge_kd)

    def add_soft_mesh(
        self,
        *,
        pos: Vec3,
        rot: Quat,
        scale: float,
        vel: Vec3,
        mesh: TetMesh | None = None,
        vertices: list[Vec3] | None = None,
        indices: list[int] | None = None,
        density: float | None = None,
        k_mu: float | np.ndarray | None = None,
        k_lambda: float | np.ndarray | None = None,
        k_damp: float | np.ndarray | None = None,
        tri_ke: float = 0.0,
        tri_ka: float = 0.0,
        tri_kd: float = 0.0,
        tri_drag: float = 0.0,
        tri_lift: float = 0.0,
        add_surface_mesh_edges: bool = True,
        edge_ke: float = 0.0,
        edge_kd: float = 0.0,
        particle_radius: float | None = None,
        color: Vec3 | list[Vec3] | np.ndarray | None = None,
        opacity: float | list[float] | np.ndarray | None = None,
        validate_mesh: bool = False,
        label: str | None = None,
    ) -> None:
        """Helper to create a tetrahedral model from an input tetrahedral mesh.

        Can be called with either a :class:`~newton.TetMesh` object or raw
        ``vertices``/``indices`` arrays. When both are provided, explicit
        parameters override the values from the TetMesh.

        Args:
            pos: The position of the solid in world space.
            rot: The orientation of the solid in world space.
            scale: Uniform scale applied to vertex positions.
            vel: The velocity of the solid in world space.
            mesh: A :class:`~newton.TetMesh` object. When provided, its
                vertices, indices, material arrays, density, and pre-computed
                surface triangles are used directly.
            vertices: A list of vertex positions, array of 3D points.
                Required if ``mesh`` is not provided.
            indices: A list of tetrahedron indices, 4 entries per-element,
                flattened array. Required if ``mesh`` is not provided.
            density: The density [kg/m^3] of the mesh. Overrides ``mesh.density``
                if both are provided.
            k_mu: The first elastic Lame parameter [Pa]. Scalar or per-element
                array. Overrides ``mesh.k_mu`` if both are provided.
            k_lambda: The second elastic Lame parameter [Pa]. Scalar or
                per-element array. Overrides ``mesh.k_lambda`` if both are
                provided.
            k_damp: The viscous damping coefficient [Pa·s]. Scalar or per-element array.
                Overrides ``mesh.k_damp`` if both are provided.
            tri_ke: Stiffness for surface mesh triangles. Defaults to 0.0.
            tri_ka: Area stiffness for surface mesh triangles. Defaults to 0.0.
            tri_kd: Damping for surface mesh triangles. Defaults to 0.0.
            tri_drag: Drag coefficient for surface mesh triangles. Defaults to 0.0.
            tri_lift: Lift coefficient for surface mesh triangles. Defaults to 0.0.
            add_surface_mesh_edges: Whether to create zero-stiffness bending edges on the
                generated surface mesh. These edges improve collision robustness for VBD solver. Defaults to True.
            edge_ke: Bending edge stiffness used when ``add_surface_mesh_edges`` is True. Defaults to 0.0.
            edge_kd: Bending edge damping used when ``add_surface_mesh_edges`` is True. Defaults to 0.0.
            particle_radius: particle's contact radius (controls rigidbody-particle contact distance).
            color: Display color in [0, 1] for the generated surface mesh. If a
                single RGB value, applied to all triangles. If array-like, RGB
                values are applied per triangle.
            opacity: Display opacity in [0, 1] for the generated surface mesh.
                If scalar, applied to all triangles. If array-like, values are
                applied per triangle.
            validate_mesh: If True, check for inverted or small-volume
                tetrahedra, sliver tetrahedra, and non-manifold faces, and
                emit warnings. See :func:`newton.utils.validate_tet_mesh`.
            label: Optional name forwarded to
                :func:`newton.utils.validate_tet_mesh` so a mesh-quality
                warning emitted with ``validate_mesh=True`` can identify
                this soft body.

        Note:
            **Parameter resolution order:** explicit argument > :class:`~newton.TetMesh`
            attribute > builder default (:attr:`default_tet_density`,
            :attr:`default_tet_k_mu`, :attr:`default_tet_k_lambda`,
            :attr:`default_tet_k_damp`).

            The generated surface triangles and optional edges are for collision purposes.
            Their stiffness and damping values default to zero so they do not introduce additional
            elastic forces. Set the stiffness parameters above to non-zero values if you
            want the surface to behave like a thin skin.
        """
        from ..geometry.types import TetMesh  # noqa: PLC0415

        # Resolve parameters: explicit args > mesh attributes > error
        if mesh is not None:
            if not isinstance(mesh, TetMesh):
                raise TypeError(f"mesh must be a TetMesh, got {type(mesh).__name__}")
            if vertices is None:
                vertices = mesh.vertices
            if indices is None:
                indices = mesh.tet_indices
            if density is None:
                density = mesh.density
            if k_mu is None:
                k_mu = mesh.k_mu
            if k_lambda is None:
                k_lambda = mesh.k_lambda
            if k_damp is None:
                k_damp = mesh.k_damp

        if vertices is None or indices is None:
            raise ValueError("Either 'mesh' or both 'vertices' and 'indices' must be provided.")

        if validate_mesh:
            from ..utils.mesh import validate_tet_mesh  # noqa: PLC0415

            verts_np = np.array(vertices, dtype=float) * scale
            inds_np = np.asarray(indices, dtype=np.intp)
            validate_tet_mesh(verts_np, inds_np, label=label, stacklevel=3)
            if inds_np.size > 0 and inds_np.size % 4 != 0:
                return

        if density is None:
            density = self.default_tet_density
        if k_mu is None:
            k_mu = self.default_tet_k_mu
        if k_lambda is None:
            k_lambda = self.default_tet_k_lambda
        if k_damp is None:
            k_damp = self.default_tet_k_damp

        num_tets = int(len(indices) / 4)
        k_mu_arr = np.broadcast_to(np.asarray(k_mu, dtype=np.float32).flatten(), num_tets)
        k_lambda_arr = np.broadcast_to(np.asarray(k_lambda, dtype=np.float32).flatten(), num_tets)
        k_damp_arr = np.broadcast_to(np.asarray(k_damp, dtype=np.float32).flatten(), num_tets)

        # Extract custom attributes grouped by frequency, validating against builder registry
        particle_custom: dict[str, np.ndarray] = {}
        tet_custom: dict[str, np.ndarray] = {}
        tri_custom: dict[str, np.ndarray] = {}
        if mesh is not None and mesh.custom_attributes:
            for attr_name, (arr, freq) in mesh.custom_attributes.items():
                registered = self.custom_attributes.get(attr_name)
                if registered is None:
                    raise ValueError(
                        f"TetMesh custom attribute '{attr_name}' is not registered in ModelBuilder. "
                        f"Register it first via add_custom_attribute()."
                    )
                if registered.frequency != freq:
                    raise ValueError(
                        f"Frequency mismatch for custom attribute '{attr_name}': TetMesh has "
                        f"{Model.AttributeFrequency(freq).name} but ModelBuilder expects "
                        f"{registered.frequency.name}."
                    )
                if freq == Model.AttributeFrequency.PARTICLE:
                    particle_custom[attr_name] = arr
                elif freq == Model.AttributeFrequency.TETRAHEDRON:
                    tet_custom[attr_name] = arr
                elif freq == Model.AttributeFrequency.TRIANGLE:
                    tri_custom[attr_name] = arr

        start_vertex = len(self.particle_q)

        pos = wp.vec3(pos[0], pos[1], pos[2])
        # add particles
        for vi, v in enumerate(vertices):
            p = wp.quat_rotate(rot, wp.vec3(v[0], v[1], v[2]) * scale) + pos

            p_custom = {k: arr[vi] for k, arr in particle_custom.items()} if particle_custom else None
            self.add_particle(p, vel, 0.0, particle_radius, custom_attributes=p_custom)

        # add tetrahedra
        for t in range(num_tets):
            v0 = start_vertex + indices[t * 4 + 0]
            v1 = start_vertex + indices[t * 4 + 1]
            v2 = start_vertex + indices[t * 4 + 2]
            v3 = start_vertex + indices[t * 4 + 3]

            t_custom = {k: arr[t] for k, arr in tet_custom.items()} if tet_custom else None
            volume = self.add_tetrahedron(
                v0,
                v1,
                v2,
                v3,
                float(k_mu_arr[t]),
                float(k_lambda_arr[t]),
                float(k_damp_arr[t]),
                custom_attributes=t_custom,
            )

            # distribute volume fraction to particles
            if volume > 0.0:
                self.particle_mass[v0] += density * volume / 4.0
                self.particle_mass[v1] += density * volume / 4.0
                self.particle_mass[v2] += density * volume / 4.0
                self.particle_mass[v3] += density * volume / 4.0

        # Compute surface triangles — reuse pre-computed result from TetMesh
        # only when the caller did not override the indices.
        if mesh is not None and indices is mesh.tet_indices and len(mesh.surface_tri_indices) > 0:
            surface_tri_indices = mesh.surface_tri_indices
        else:
            surface_tri_indices = TetMesh.compute_surface_triangles(indices)

        # add surface triangles
        start_tri = len(self.tri_indices)
        surf = surface_tri_indices.reshape(-1, 3)
        surface_colors = _broadcast_triangle_colors(color, len(surf), self._DEFAULT_TRI_COLOR)
        surface_opacities = _broadcast_triangle_opacities(opacity, len(surf))
        for ti, tri in enumerate(surf):
            tr_custom = {k: arr[ti] for k, arr in tri_custom.items()} if tri_custom else None
            self.add_triangle(
                start_vertex + int(tri[0]),
                start_vertex + int(tri[1]),
                start_vertex + int(tri[2]),
                tri_ke=tri_ke,
                tri_ka=tri_ka,
                tri_kd=tri_kd,
                tri_drag=tri_drag,
                tri_lift=tri_lift,
                color=surface_colors[ti],
                opacity=surface_opacities[ti],
                custom_attributes=tr_custom,
            )
        end_tri = len(self.tri_indices)

        if add_surface_mesh_edges:
            # add surface mesh edges (for collision)
            if end_tri > start_tri:
                self._add_soft_mesh_edges_from_triangles(start_tri, end_tri, edge_ke=edge_ke, edge_kd=edge_kd)

    # incrementally updates rigid body mass with additional mass and inertia expressed at a local to the body
    def _update_body_mass(self, i: int, m: float, inertia: Mat33, p: Vec3, q: Quat):
        if i == -1:
            return

        # find new COM
        new_mass = self.body_mass[i] + m

        if new_mass == 0.0:  # no mass
            return

        new_com = (self.body_com[i] * self.body_mass[i] + p * m) / new_mass

        # shift inertia to new COM
        com_offset = new_com - self.body_com[i]
        shape_offset = new_com - p

        new_inertia = transform_inertia(
            self.body_mass[i], self.body_inertia[i], com_offset, wp.quat_identity()
        ) + transform_inertia(m, inertia, shape_offset, q)

        self.body_mass[i] = new_mass
        self.body_inertia[i] = new_inertia
        self.body_com[i] = new_com

        if new_mass > 0.0:
            self.body_inv_mass[i] = 1.0 / new_mass
        else:
            self.body_inv_mass[i] = 0.0

        if any(x for x in new_inertia):
            self.body_inv_inertia[i] = wp.inverse(new_inertia)
        else:
            self.body_inv_inertia[i] = new_inertia

    def _validate_parent_body(self, parent_body: int, child: int) -> None:
        """
        Validate that parent_body is a valid body index.

        Args:
            parent_body: The parent body index to validate (-1 for world is OK).
            child: The child body index (to check for self-reference).

        Raises:
            ValueError: If validation fails.
        """
        if parent_body == -1:
            return  # -1 is valid (world reference)

        # Check bounds
        if parent_body < -1:
            raise ValueError(f"Invalid parent_body index: {parent_body}. Must be >= -1 (use -1 for world).")

        if parent_body >= len(self.body_mass):
            raise ValueError(
                f"Invalid parent_body index: {parent_body}. "
                f"Body index out of bounds (model has {len(self.body_mass)} bodies)."
            )

        # Check self-reference
        if parent_body == child:
            raise ValueError(f"Cannot attach body {child} to itself (parent_body == child).")

        # Validate body has positive mass (optional warning)
        if self.body_mass[parent_body] <= 0.0:
            warnings.warn(
                f"parent_body {parent_body} has zero or negative mass ({self.body_mass[parent_body]}). "
                f"This may cause unexpected behavior.",
                UserWarning,
                stacklevel=3,
            )

    def _validate_kinematic_joint_attachment(self, child: int, parent: int) -> None:
        """Validate that kinematic bodies only attach to the world."""
        if parent == -1 or not (int(self.body_flags[child]) & int(BodyFlags.KINEMATIC)):
            return

        child_label = self.body_label[child]
        parent_label = self.body_label[parent]
        raise ValueError(
            f"Body {child} ('{child_label}') is kinematic but is attached to parent body {parent} "
            f"('{parent_label}'). Only root bodies (whose joint parent is the world) can be kinematic."
        )

    def _validate_kinematic_articulation_joints(self, joint_indices: Iterable[int]) -> None:
        """Validate that all kinematic joints in an articulation are rooted at the world."""
        for joint_idx in joint_indices:
            self._validate_kinematic_joint_attachment(self.joint_child[joint_idx], self.joint_parent[joint_idx])

    def _find_articulation_for_body(self, body_id: int) -> int | None:
        """
        Find which articulation (if any) contains the given body.

        A body "belongs to" the articulation where it appears as a child in a joint.
        If a body is only a parent (e.g., root body of an articulation), it belongs
        to the articulation of its child joints.

        Args:
            body_id: The body index to search for.

        Returns:
            The articulation index if found, or ``None`` if the body is not in any articulation.

        Algorithm:
            1. Priority 1: Find articulation where body is a child (most common case)
               - A body can only be a child in ONE joint (tree structure)
               - This uniquely identifies the body's home articulation
            2. Priority 2: Find articulation where body is a parent (for root bodies)
               - Root bodies are parents but not children
               - If parent in multiple articulations, returns the first found
               - This should be rare; most bodies are children in exactly one articulation

        Note:
            In valid tree structures, a body should be a child in at most one joint,
            making this lookup deterministic. Bodies that are only parents (root bodies)
            may appear in multiple articulations; in such cases, the first articulation
            found is returned.
        """
        # Priority 1: Check if body is a child in any joint
        # A body should be a child in at most ONE joint (tree structure)
        for joint_idx in range(len(self.joint_child)):
            if self.joint_child[joint_idx] == body_id:
                art_id = self.joint_articulation[joint_idx]
                if art_id >= 0:  # -1 means no articulation
                    return art_id  # Body found as child - this is its home articulation

        # Priority 2: If not found as child, check if body is a parent in any joint
        # This handles root bodies that are parents but not children
        parent_articulations = []
        for joint_idx in range(len(self.joint_parent)):
            if self.joint_parent[joint_idx] == body_id:
                art_id = self.joint_articulation[joint_idx]
                if art_id >= 0 and art_id not in parent_articulations:
                    parent_articulations.append(art_id)

        # Use first articulation found, but warn if multiple (shouldn't happen in valid trees)
        if parent_articulations:
            result = parent_articulations[0]
            if len(parent_articulations) > 1:
                warnings.warn(
                    f"Body {body_id} is a parent in multiple articulations {parent_articulations}. "
                    f"Using articulation {result}. This may indicate an unusual model structure.",
                    UserWarning,
                    stacklevel=3,
                )
            return result

        return None

    @staticmethod
    def _validate_base_joint_params(floating: bool | None, base_joint: dict | None, parent: int) -> None:
        """
        Validate floating and base_joint parameter combinations.

        This is a shared validation function used by all importers (MJCF, URDF, USD)
        to ensure consistent parameter validation.

        Args:
            floating: The floating parameter value (True, False, or None).
            base_joint: Dict with joint parameters (or None).
            parent: The parent body index (-1 for world, >= 0 for a body).

        Raises:
            ValueError: If parameter combinations are invalid:
                - Both floating and base_joint are specified (mutually exclusive)
                - floating=True with parent != -1 (FREE joints require world frame)
                - base_joint dict contains conflicting keys like 'parent', 'child', etc.
        """
        if floating is not None and base_joint is not None:
            raise ValueError(
                f"Cannot specify both 'floating' and 'base_joint' parameters. "
                f"These are mutually exclusive ways to control root attachment:\n"
                f"  - Use 'floating' for simple FREE/FIXED joints\n"
                f"  - Use 'base_joint' dict for custom joint parameters\n"
                f"Current values: floating={floating}, base_joint={{dict}}"
            )

        if floating is True and parent != -1:
            raise ValueError(
                f"Cannot create FREE joint when parent_body={parent} (not world). "
                f"FREE joints must connect to world frame (parent_body=-1).\n"
                f"Did you mean:\n"
                f"  - Use floating=False to create FIXED joint to parent\n"
                f"  - Use base_joint dict with D6 joint parameters for 6-DOF mobility attached to parent"
            )

        # Validate base_joint dict doesn't contain conflicting keys
        if base_joint is not None:
            conflicting_keys = set(base_joint.keys()) & {"parent", "child", "parent_xform", "child_xform"}
            if conflicting_keys:
                raise ValueError(
                    f"base_joint dict cannot specify {conflicting_keys}. "
                    f"These parameters are automatically set based on parent_body and attachment:\n"
                    f"  - 'parent' is set from parent_body parameter (currently {parent})\n"
                    f"  - 'child' is set to the imported root body\n"
                    f"  - 'parent_xform' and 'child_xform' are set from xform parameter\n"
                    f"Please remove {conflicting_keys} from the base_joint dict and use the "
                    f"parent_body argument instead."
                )

    def _check_sequential_composition(self, parent_body: int) -> int | None:
        """
        Check if attaching to parent_body is sequential (most recent articulation).

        Args:
            parent_body: The parent body index to check.

        Returns:
            The parent articulation ID, or None if parent_body is world (-1) or not in an articulation.

        Raises:
            ValueError: If attempting to attach to a non-sequential articulation.
        """
        if parent_body == -1:
            return None

        parent_articulation = self._find_articulation_for_body(parent_body)
        if parent_articulation is None:
            return None

        num_articulations = len(self.articulation_start)
        is_sequential = parent_articulation == num_articulations - 1

        if is_sequential:
            return parent_articulation
        else:
            body_name = self.body_label[parent_body] if parent_body < len(self.body_label) else f"#{parent_body}"
            raise ValueError(
                f"Cannot attach to parent_body {body_name} in articulation #{parent_articulation} "
                f"(most recent is #{num_articulations - 1}). "
                f"Attach to the most recently added articulation or build in order."
            )

    def _finalize_imported_articulation(
        self,
        joint_indices: list[int],
        parent_body: int,
        articulation_label: str | None = None,
        custom_attributes: dict | None = None,
    ) -> None:
        """
        Attach imported joints to parent articulation or create a new articulation.

        This helper method encapsulates the common logic used by all importers (MJCF, URDF, USD)
        for handling articulation creation after importing a model.

        Args:
            joint_indices: List of joint indices from the imported model.
            parent_body: The parent body index (-1 for world, or a body index for hierarchical composition).
            articulation_label: Optional label for the articulation (e.g., model name).
            custom_attributes: Optional custom attributes for the articulation.

        Note:
            - If parent_body != -1 and it belongs to an articulation, the imported joints are added
              to the parent's articulation (only works for sequential composition).
            - If parent_body != -1 but is not in any articulation, raises ValueError.
            - If parent_body == -1, a new articulation is created.
            - If joint_indices is empty, does nothing.

        Raises:
            ValueError: If parent_body is specified but not part of any articulation.
        """
        if not joint_indices:
            return

        if parent_body != -1:
            # Check if attachment is sequential
            parent_articulation = self._check_sequential_composition(parent_body=parent_body)

            if parent_articulation is not None:
                self._validate_kinematic_articulation_joints(joint_indices)
                old_end = self.articulation_end[parent_articulation]
                new_end = max(old_end, max(joint_indices) + 1)
                imported_joints = set(joint_indices)
                for joint_idx in range(old_end, new_end):
                    if joint_idx not in imported_joints:
                        joint_name = (
                            self.joint_label[joint_idx] if joint_idx < len(self.joint_label) else f"#{joint_idx}"
                        )
                        owner = self.joint_articulation[joint_idx]
                        kind = "loop-closing joint" if owner == -1 else f"joint owned by articulation #{owner}"
                        raise ValueError(
                            f"Cannot attach imported joints to articulation #{parent_articulation}: "
                            f"{kind} '{joint_name}' at index {joint_idx} lies between the existing "
                            "regular joints and the imported joints."
                        )
                # Mark all new joints as belonging to the parent's articulation
                for joint_idx in joint_indices:
                    self.joint_articulation[joint_idx] = parent_articulation
                self.articulation_end[parent_articulation] = new_end
            else:
                # Parent body exists but is not in any articulation - this is an error
                # because user explicitly specified parent_body but it can't be used
                body_name = self.body_label[parent_body] if parent_body < len(self.body_label) else f"#{parent_body}"
                raise ValueError(
                    f"Cannot attach to parent_body '{body_name}': body is not part of any articulation. "
                    f"Only bodies within articulations can be used as parent_body. "
                    f"To create an independent articulation, use parent_body=-1 (default)."
                )
        else:
            # No parent_body specified, create a new articulation
            self.add_articulation(
                joints=joint_indices,
                label=articulation_label,
                custom_attributes=custom_attributes,
            )

    def _add_base_joint(
        self,
        child: int,
        floating: bool | None = None,
        base_joint: dict | None = None,
        label: str | None = None,
        parent_xform: Transform | None = None,
        child_xform: Transform | None = None,
        parent: int = -1,
    ) -> int:
        """
        Internal helper for importers to create base joints.

        This method is used by importers (URDF, MJCF, USD) to attach imported bodies
        to the world or to a parent body with the appropriate joint type.

        Args:
            child: The body index to connect.
            floating: If None (default), behavior depends on format-specific defaults.
                If True, creates a FREE joint (only valid when ``parent == -1``).
                If False, always creates a fixed joint.
            base_joint: Dict with joint parameters passed to :meth:`add_joint`.
                Cannot be specified together with ``floating``.
            label: A unique label for the joint.
            parent_xform: The transform of the joint in the parent frame.
                If None, defaults to ``body_q[child]`` when parent is world (-1),
                or identity when parent is another body.
            child_xform: The transform of the joint in the child frame.
                If None, defaults to identity transform.
            parent: The index of the parent body. Use -1 (default) to connect to world.

        Returns:
            The index of the created joint.

        Raises:
            ValueError: If both ``floating`` and ``base_joint`` are specified,
                or if ``floating=True`` with ``parent != -1``, or if parent body
                is not part of any articulation.
        """
        # Validate parameter combinations
        self._validate_base_joint_params(floating, base_joint, parent)
        self._validate_parent_body(parent, child)

        # Validate that parent body is in an articulation (if not world)
        if parent != -1:
            parent_articulation = self._find_articulation_for_body(parent)
            if parent_articulation is None:
                body_name = self.body_label[parent] if parent < len(self.body_label) else f"#{parent}"
                raise ValueError(
                    f"Cannot attach to parent_body '{body_name}': body is not part of any articulation. "
                    f"Only bodies within articulations can be used as parent_body. "
                    f"To create an independent articulation, use parent_body=-1 (default)."
                )

        # Determine transforms
        if parent_xform is None:
            parent_xform = self.body_q[child] if parent == -1 else wp.transform_identity()
        if child_xform is None:
            child_xform = wp.transform_identity()

        # Create joint based on parameters
        if base_joint is not None:
            # Use custom joint parameters from dict
            joint_params = base_joint.copy()
            joint_params["parent"] = parent
            joint_params["child"] = child
            joint_params["parent_xform"] = parent_xform
            joint_params["child_xform"] = child_xform
            if "label" not in joint_params and label is not None:
                joint_params["label"] = label
            return self.add_joint(**joint_params)
        elif floating is True or (floating is None and parent == -1):
            # FREE joint (floating=True always requires parent==-1, validated above)
            # Note: We don't pass parent_xform here because add_joint_free initializes joint_q from body_q[child]
            # and the caller (e.g., URDF importer) will set the correct joint_q values afterward
            return self.add_joint_free(child, label=label)
        else:
            # FIXED joint (floating=False or floating=None with parent body)
            return self.add_joint_fixed(parent, child, parent_xform=parent_xform, child_xform=child_xform, label=label)

    def request_contact_attributes(self, *attributes: str) -> None:
        """
        Request that specific contact attributes be allocated when creating a Contacts object from the finalized Model.

        Args:
            *attributes: Variable number of attribute names (strings).
        """
        # Local import to avoid adding more module-level dependencies in this large file.
        from .contacts import Contacts  # noqa: PLC0415

        Contacts.validate_extended_attributes(attributes)
        self._requested_contact_attributes.update(attributes)

    def request_state_attributes(self, *attributes: str) -> None:
        """
        Request that specific state attributes be allocated when creating a State object from the finalized Model.

        See :ref:`extended_state_attributes` for details and usage.

        Args:
            *attributes: Variable number of attribute names (strings).
        """
        # Local import to avoid adding more module-level dependencies in this large file.
        from .state import State  # noqa: PLC0415

        State.validate_extended_attributes(attributes)
        self._requested_state_attributes.update(attributes)

    def set_coloring(self, particle_color_groups: Iterable[Iterable[int] | np.ndarray]) -> None:
        """
        Sets coloring information with user-provided coloring.

        Args:
            particle_color_groups: A list of list or `np.array` with `dtype`=`int`. The length of the list is the number of colors
                and each list or `np.array` contains the indices of vertices with this color.
        """
        particle_color_groups = [
            color_group if isinstance(color_group, np.ndarray) else np.array(color_group)
            for color_group in particle_color_groups
        ]
        self.particle_color_groups = particle_color_groups

    def color(
        self,
        include_bending: bool = False,
        balance_colors: bool = True,
        target_max_min_color_ratio: float = 1.1,
        coloring_algorithm: ColoringAlgorithm = ColoringAlgorithm.MCS,
    ) -> None:
        """
        Runs coloring algorithm to generate coloring information.

        This populates both :attr:`particle_color_groups` (for particles) and
        :attr:`body_color_groups` (for rigid bodies) on the builder, which are
        consumed by :class:`newton.solvers.SolverVBD`.

        Call :meth:`color` (or :meth:`set_coloring`) before
        :meth:`finalize <ModelBuilder.finalize>` when using
        :class:`newton.solvers.SolverVBD`; :meth:`finalize <ModelBuilder.finalize>` does not
        implicitly color the model.

        Args:
            include_bending: Whether to include bending edges in the coloring graph. Set to `True` if your
                model contains bending edges (added via :meth:`add_edge`) that participate in bending constraints.
                When enabled, the coloring graph includes connections between opposite vertices of each edge (o1-o2),
                ensuring proper dependency handling for parallel bending computations. Leave as `False` if your model
                has no bending edges or if bending edges should not affect the coloring.
            balance_colors: Whether to apply the color balancing algorithm to balance the size of each color
            target_max_min_color_ratio: the color balancing algorithm will stop when the ratio between the largest color and
                the smallest color reaches this value
            coloring_algorithm: Coloring algorithm to use. `ColoringAlgorithm.MCS` uses
                maximum cardinality search (MCS), while `ColoringAlgorithm.GREEDY` uses
                degree-ordered greedy coloring. The MCS algorithm typically generates 30% to
                50% fewer colors compared to the ordered greedy algorithm, while maintaining
                the same linear complexity. Although MCS has a constant overhead that makes
                it about twice as slow as the greedy algorithm, it produces significantly
                better coloring results. We recommend using MCS, especially if coloring is
                only part of preprocessing.

        Note:

            References to the coloring algorithm:

            MCS: Pereira, F. M. Q., & Palsberg, J. (2005, November). Register allocation via coloring of chordal graphs. In Asian Symposium on Programming Languages and Systems (pp. 315-329). Berlin, Heidelberg: Springer Berlin Heidelberg.

            Ordered Greedy: Ton-That, Q. M., Kry, P. G., & Andrews, S. (2023). Parallel block Neo-Hookean XPBD using graph clustering. Computers & Graphics, 110, 1-10.

        """
        if self.particle_count != 0:
            tri_indices = np.array(self.tri_indices, dtype=np.int32) if self.tri_indices else None
            tri_materials = np.array(self.tri_materials)
            tet_indices = np.array(self.tet_indices, dtype=np.int32) if self.tet_indices else None
            tet_materials = np.array(self.tet_materials)

            bending_edge_indices = None
            bending_edge_active_mask = None
            if include_bending and self.edge_indices:
                bending_edge_indices = np.array(self.edge_indices, dtype=np.int32)
                bending_edge_props = np.array(self.edge_bending_properties)
                # Active if either stiffness or damping is non-zero
                bending_edge_active_mask = (bending_edge_props[:, 0] != 0.0) | (bending_edge_props[:, 1] != 0.0)

            graph_edge_indices = construct_particle_graph(
                tri_indices,
                tri_materials[:, 0] * tri_materials[:, 1] if len(tri_materials) else None,
                bending_edge_indices,
                bending_edge_active_mask,
                tet_indices,
                tet_materials[:, 0] * tet_materials[:, 1] if len(tet_materials) else None,
            )

            if len(graph_edge_indices) > 0:
                self.particle_color_groups = color_graph(
                    self.particle_count,
                    graph_edge_indices,
                    balance_colors,
                    target_max_min_color_ratio,
                    coloring_algorithm,
                )
            else:
                # No edges to color - assign all particles to single color group
                if len(self.particle_q) > 0:
                    self.particle_color_groups = [np.arange(len(self.particle_q), dtype=int)]
                else:
                    self.particle_color_groups = []

        # Also color rigid bodies based on joint connectivity
        self.body_color_groups = color_rigid_bodies(
            self.body_count,
            self.joint_parent,
            self.joint_child,
            algorithm=coloring_algorithm,
            balance_colors=balance_colors,
            target_max_min_color_ratio=target_max_min_color_ratio,
        )

    def _validate_world_ordering(self):
        """Validate that world indices are monotonic, contiguous, and properly ordered.

        This method checks:
        1. World indices are monotonic (non-decreasing after first non-negative)
        2. World indices are contiguous (no gaps in sequence)
        3. Global entities (world -1) only appear at beginning or end of arrays
        4. All world indices are in valid range [-1, world_count-1]

        Raises:
            ValueError: If any validation check fails.
        """
        # List of all world arrays to validate
        world_arrays = [
            ("particle_world", self.particle_world),
            ("body_world", self.body_world),
            ("shape_world", self.shape_world),
            ("joint_world", self.joint_world),
            ("articulation_world", self.articulation_world),
            ("equality_constraint_world", self._eq_list("equality_constraint_world")),
            ("constraint_mimic_world", self.constraint_mimic_world),
        ]

        all_world_indices = set()

        for array_name, world_array in world_arrays:
            if not world_array:
                continue

            arr = np.array(world_array, dtype=np.int32)

            # Check for invalid world indices (must be in range [-1, world_count-1])
            max_valid = self.world_count - 1
            invalid_indices = np.where((arr < -1) | (arr > max_valid))[0]
            if len(invalid_indices) > 0:
                invalid_values = arr[invalid_indices]
                raise ValueError(
                    f"Invalid world index in {array_name}: found value(s) {invalid_values.tolist()} "
                    f"at indices {invalid_indices.tolist()}. Valid range is -1 to {max_valid} (world_count={self.world_count})."
                )

            # Check for global entity positioning (world -1)
            # Find first and last occurrence of -1
            negative_indices = np.where(arr == -1)[0]
            if len(negative_indices) > 0:
                # Check that all -1s form contiguous blocks at start and/or end
                # Count -1s at the start
                start_neg_count = 0
                for i in range(len(arr)):
                    if arr[i] == -1:
                        start_neg_count += 1
                    else:
                        break

                # Count -1s at the end (but only if they don't overlap with start)
                end_neg_count = 0
                if start_neg_count < len(arr):  # There are non-negative values after the start block
                    for i in range(len(arr) - 1, -1, -1):
                        if arr[i] == -1:
                            end_neg_count += 1
                        else:
                            break

                expected_neg_count = start_neg_count + end_neg_count
                actual_neg_count = len(negative_indices)

                if expected_neg_count != actual_neg_count:
                    # There are -1s in the middle
                    raise ValueError(
                        f"Invalid world ordering in {array_name}: global entities (world -1) "
                        f"must only appear at the beginning or end of the array, not in the middle. "
                        f"Found -1 values at indices: {negative_indices.tolist()}"
                    )

            # Check monotonic ordering for non-negative values
            non_neg_mask = arr >= 0
            if np.any(non_neg_mask):
                non_neg_values = arr[non_neg_mask]

                # Check that non-negative values are monotonic (non-decreasing)
                if not np.all(non_neg_values[1:] >= non_neg_values[:-1]):
                    # Find where the order breaks
                    for i in range(1, len(non_neg_values)):
                        if non_neg_values[i] < non_neg_values[i - 1]:
                            raise ValueError(
                                f"Invalid world ordering in {array_name}: world indices must be monotonic "
                                f"(non-decreasing). Found world {non_neg_values[i]} after world {non_neg_values[i - 1]}."
                            )

                # Collect all non-negative world indices for contiguity check
                all_world_indices.update(non_neg_values)

        # Check contiguity: all world indices should form a sequence 0, 1, 2, ..., n-1
        if all_world_indices:
            world_list = sorted(all_world_indices)
            expected = list(range(world_list[-1] + 1))

            if world_list != expected:
                missing = set(expected) - set(world_list)
                raise ValueError(
                    f"World indices are not contiguous. Missing world(s): {sorted(missing)}. "
                    f"Found worlds: {world_list}. Worlds must form a continuous sequence starting from 0."
                )

    def _validate_joints(self):
        """Validate that joints belong to an articulation, with two exceptions.

        Loop-closing joints are allowed when their child is already reachable through
        an articulation. Standalone world-root joints (``parent == -1``) are also
        allowed without articulation metadata because supported solvers can consume
        them directly or provide a topology-specific fallback.

        Raises:
            ValueError: If any validation check fails.
        """
        if self.joint_count > 0:
            # First, find all bodies reachable via articulated joints
            articulated_bodies = set()
            articulated_bodies.add(-1)  # World is always reachable
            for i, art in enumerate(self.joint_articulation):
                if art >= 0:  # Joint is in an articulation
                    parent = self.joint_parent[i]
                    child = self.joint_child[i]
                    articulated_bodies.add(parent)
                    articulated_bodies.add(child)

            # Now check for true orphan joints: non-articulated joints whose child
            # is NOT reachable via other articulated joints
            orphan_joints = []
            for i, art in enumerate(self.joint_articulation):
                if art < 0:  # Joint is not in an articulation
                    parent = self.joint_parent[i]
                    child = self.joint_child[i]
                    if parent == -1:
                        # Exception: a standalone world-root joint is valid without
                        # articulation metadata. Supported solvers consume it directly
                        # or provide a topology-specific fallback.
                        continue
                    if child not in articulated_bodies:
                        # This is a true orphan - the child body has no articulated path
                        orphan_joints.append(i)
                    # else: this is a loop joint - child is already reachable, so it's allowed

            if orphan_joints:
                joint_labels = [self.joint_label[i] for i in orphan_joints[:5]]  # Show first 5
                raise ValueError(
                    f"Found {len(orphan_joints)} joint(s) not belonging to any articulation. "
                    f"Call add_articulation() for all joints. Orphan joints: {joint_labels}"
                    + ("..." if len(orphan_joints) > 5 else "")
                )

    def _validate_shapes(self) -> bool:
        """Validate shape gaps for stable broad phase detection.

        Margin is an outward offset from a shape's surface [m], while broad phase uses
        ``margin + gap`` [m] for expansion/filtering. For reliable detection, ``gap`` [m]
        should be non-negative so effective expansion is not reduced below the shape
        margin.

        This check only considers shapes that participate in collisions (with the
        `COLLIDE_SHAPES` or `COLLIDE_PARTICLES` flag).

        Warns:
            UserWarning: If any colliding shape has ``gap < 0``.

        Returns:
            Whether all colliding shapes have non-negative gaps.
        """
        collision_flags_mask = ShapeFlags.COLLIDE_SHAPES | ShapeFlags.COLLIDE_PARTICLES
        shapes_with_bad_gap = []
        for i in range(self.shape_count):
            # Skip shapes that don't participate in any collisions (e.g., sites, visual-only)
            if not (self.shape_flags[i] & collision_flags_mask):
                continue
            margin = self.shape_margin[i]
            gap = self.shape_gap[i]
            sdf_padding = self.shape_sdf_padding[i]
            if (
                self.shape_flags[i] & ShapeFlags.HYDROELASTIC
                and self.shape_flags[i] & ShapeFlags.COLLIDE_SHAPES
                and sdf_padding is not None
                and sdf_padding < margin + gap
                and not math.isclose(sdf_padding, margin + gap, rel_tol=1.0e-9, abs_tol=1.0e-12)
            ):
                raise ValueError(
                    f"Hydroelastic shape {i} requires sdf_padding >= margin + gap "
                    f"({margin + gap:.6g}), got {sdf_padding:.6g}."
                )
            if (
                self.shape_flags[i] & ShapeFlags.HYDROELASTIC
                and self.shape_flags[i] & ShapeFlags.COLLIDE_SHAPES
                and self.shape_type[i] in (GeoType.MESH, GeoType.CONVEX_MESH)
            ):
                shape_src = self.shape_source[i]
                mesh_sdf = getattr(shape_src, "sdf", None) if shape_src is not None else None
                if mesh_sdf is not None:
                    required_sdf_padding = margin + gap
                    construction_padding = getattr(mesh_sdf, "_construction_padding", None)
                    if mesh_sdf.texture_data is not None and construction_padding is None:
                        raise ValueError(
                            f"Hydroelastic shape {i} has precomputed SDF data with unknown construction padding. "
                            "Declare the original padding with "
                            "SDF.create_from_data(construction_padding=...), or rebuild it with "
                            "Mesh.build_sdf(margin=margin + gap)."
                        )
                    if (
                        construction_padding is not None
                        and construction_padding < required_sdf_padding
                        and not math.isclose(
                            construction_padding,
                            required_sdf_padding,
                            rel_tol=1.0e-9,
                            abs_tol=1.0e-12,
                        )
                    ):
                        raise ValueError(
                            f"Hydroelastic shape {i} requires SDF construction padding >= margin + gap "
                            f"({required_sdf_padding:.6g}), but the attached SDF uses "
                            f"{construction_padding:.6g}. Rebuild it with "
                            f"Mesh.build_sdf(margin={required_sdf_padding:.6g})."
                        )
            if gap < 0.0:
                shapes_with_bad_gap.append(
                    f"{self.shape_label[i] or f'shape_{i}'} (margin={margin:.6g}, gap={gap:.6g})"
                )
        if shapes_with_bad_gap:
            example_shapes = shapes_with_bad_gap[:5]
            warnings.warn(
                f"Found {len(shapes_with_bad_gap)} shape(s) with gap < 0. "
                f"This can cause missed collisions in broad phase because effective expansion uses margin + gap. "
                f"Set gap >= 0 for each shape. "
                f"Affected shapes: {example_shapes}" + ("..." if len(shapes_with_bad_gap) > 5 else ""),
                stacklevel=2,
            )
        return len(shapes_with_bad_gap) == 0

    def _validate_structure(self) -> None:
        """Validate structural invariants of the model.

        This method performs consolidated validation of all structural constraints,
        using vectorized numpy operations for efficiency:

        - Body references: shape_body, joint_parent, joint_child, equality_constraint_body1/2
        - Joint references: equality_constraint_joint1/2
        - Particle references: spring, triangle, edge, and tetrahedron connectivity
        - Self-referential joints: joint_parent[i] != joint_child[i]
        - Start array monotonicity: joint_q_start, joint_qd_start, articulation_start, articulation_end
        - Array length consistency: per-DOF and per-coord arrays

        Raises:
            ValueError: If any structural validation check fails.
        """
        body_count = self.body_count
        joint_count = self.joint_count

        # Validate per-body flags: each body must be either dynamic or
        # kinematic. Filter masks such as BodyFlags.ALL are not valid stored
        # body states.
        if len(self.body_flags) != body_count:
            raise ValueError(f"Invalid body_flags length: expected {body_count} entries, got {len(self.body_flags)}.")
        if body_count > 0:
            body_flags = np.array(self.body_flags, dtype=np.int32)
            valid_mask = (body_flags == int(BodyFlags.DYNAMIC)) | (body_flags == int(BodyFlags.KINEMATIC))
            if not np.all(valid_mask):
                idx = int(np.where(~valid_mask)[0][0])
                body_label = self.body_label[idx] if idx < len(self.body_label) else f"body_{idx}"
                raise ValueError(
                    f"Invalid body flag for body {idx} ('{body_label}'): got {int(body_flags[idx])}, "
                    f"but expected exactly one of BodyFlags.DYNAMIC or BodyFlags.KINEMATIC."
                )

        # Validate shape_body references: must be in [-1, body_count-1]
        if self.shape_count > 0:
            shape_body = np.array(self.shape_body, dtype=np.int32)
            invalid_mask = (shape_body < -1) | (shape_body >= body_count)
            if np.any(invalid_mask):
                invalid_indices = np.where(invalid_mask)[0]
                idx = invalid_indices[0]
                shape_label = self.shape_label[idx] or f"shape_{idx}"
                raise ValueError(
                    f"Invalid body reference in shape_body: shape {idx} ('{shape_label}') references body {shape_body[idx]}, "
                    f"but valid range is [-1, {body_count - 1}] (body_count={body_count})."
                )

        # Validate joint_parent references: must be in [-1, body_count-1]
        if joint_count > 0:
            joint_parent = np.array(self.joint_parent, dtype=np.int32)
            invalid_mask = (joint_parent < -1) | (joint_parent >= body_count)
            if np.any(invalid_mask):
                invalid_indices = np.where(invalid_mask)[0]
                idx = invalid_indices[0]
                joint_label = self.joint_label[idx] or f"joint_{idx}"
                raise ValueError(
                    f"Invalid body reference in joint_parent: joint {idx} ('{joint_label}') references parent body {joint_parent[idx]}, "
                    f"but valid range is [-1, {body_count - 1}] (body_count={body_count})."
                )

            # Validate joint_child references: must be in [0, body_count-1] (child cannot be world)
            joint_child = np.array(self.joint_child, dtype=np.int32)
            invalid_mask = (joint_child < 0) | (joint_child >= body_count)
            if np.any(invalid_mask):
                invalid_indices = np.where(invalid_mask)[0]
                idx = invalid_indices[0]
                joint_label = self.joint_label[idx] or f"joint_{idx}"
                raise ValueError(
                    f"Invalid body reference in joint_child: joint {idx} ('{joint_label}') references child body {joint_child[idx]}, "
                    f"but valid range is [0, {body_count - 1}] (body_count={body_count}). Child cannot be the world (-1)."
                )

            # Validate self-referential joints: parent != child
            self_ref_mask = joint_parent == joint_child
            if np.any(self_ref_mask):
                invalid_indices = np.where(self_ref_mask)[0]
                idx = invalid_indices[0]
                joint_label = self.joint_label[idx] or f"joint_{idx}"
                raise ValueError(
                    f"Self-referential joint: joint {idx} ('{joint_label}') has parent and child both set to body {joint_parent[idx]}."
                )

        # Validate equality constraint body/joint references
        equality_count = self._equality_constraint_count
        if equality_count > 0:
            label_values = self._eq_values_raw("equality_constraint_label")

            def _eq_label(idx: int) -> str:
                label = label_values[idx] if idx < len(label_values) and label_values[idx] is not None else None
                return label or f"equality_constraint_{idx}"

            def _eq_index_array(name: str) -> np.ndarray:
                # Coerce raw custom-attribute values straight into the int32 array, applying the
                # attribute default for missing/``None`` rows, without an intermediate Python list.
                values = self._eq_values_raw(name)
                count, default = len(values), self._eq_attr(name).default
                return np.fromiter(
                    (values[i] if i < count and values[i] is not None else default for i in range(equality_count)),
                    dtype=np.int32,
                    count=equality_count,
                )

            eq_body1 = _eq_index_array("equality_constraint_body1")
            invalid_mask = (eq_body1 < -1) | (eq_body1 >= body_count)
            if np.any(invalid_mask):
                idx = int(np.where(invalid_mask)[0][0])
                raise ValueError(
                    f"Invalid body reference in equality_constraint_body1: constraint {idx} ('{_eq_label(idx)}') references body {eq_body1[idx]}, "
                    f"but valid range is [-1, {body_count - 1}] (body_count={body_count})."
                )

            eq_body2 = _eq_index_array("equality_constraint_body2")
            invalid_mask = (eq_body2 < -1) | (eq_body2 >= body_count)
            if np.any(invalid_mask):
                idx = int(np.where(invalid_mask)[0][0])
                raise ValueError(
                    f"Invalid body reference in equality_constraint_body2: constraint {idx} ('{_eq_label(idx)}') references body {eq_body2[idx]}, "
                    f"but valid range is [-1, {body_count - 1}] (body_count={body_count})."
                )

            eq_joint1 = _eq_index_array("equality_constraint_joint1")
            invalid_mask = (eq_joint1 < -1) | (eq_joint1 >= joint_count)
            if np.any(invalid_mask):
                idx = int(np.where(invalid_mask)[0][0])
                raise ValueError(
                    f"Invalid joint reference in equality_constraint_joint1: constraint {idx} ('{_eq_label(idx)}') references joint {eq_joint1[idx]}, "
                    f"but valid range is [-1, {joint_count - 1}] (joint_count={joint_count})."
                )

            eq_joint2 = _eq_index_array("equality_constraint_joint2")
            invalid_mask = (eq_joint2 < -1) | (eq_joint2 >= joint_count)
            if np.any(invalid_mask):
                idx = int(np.where(invalid_mask)[0][0])
                raise ValueError(
                    f"Invalid joint reference in equality_constraint_joint2: constraint {idx} ('{_eq_label(idx)}') references joint {eq_joint2[idx]}, "
                    f"but valid range is [-1, {joint_count - 1}] (joint_count={joint_count})."
                )

        # Validate start array monotonicity
        if joint_count > 0:
            joint_q_start = np.array(self.joint_q_start, dtype=np.int32)
            if len(joint_q_start) > 1:
                diffs = np.diff(joint_q_start)
                if np.any(diffs < 0):
                    idx = np.where(diffs < 0)[0][0]
                    raise ValueError(
                        f"joint_q_start is not monotonically increasing: "
                        f"joint_q_start[{idx}]={joint_q_start[idx]} > joint_q_start[{idx + 1}]={joint_q_start[idx + 1]}."
                    )

            joint_qd_start = np.array(self.joint_qd_start, dtype=np.int32)
            if len(joint_qd_start) > 1:
                diffs = np.diff(joint_qd_start)
                if np.any(diffs < 0):
                    idx = np.where(diffs < 0)[0][0]
                    raise ValueError(
                        f"joint_qd_start is not monotonically increasing: "
                        f"joint_qd_start[{idx}]={joint_qd_start[idx]} > joint_qd_start[{idx + 1}]={joint_qd_start[idx + 1]}."
                    )

        articulation_count = self.articulation_count
        if articulation_count > 0:
            if len(self.articulation_end) != articulation_count:
                raise ValueError(
                    f"Invalid articulation_end length: expected {articulation_count} entries, "
                    f"got {len(self.articulation_end)}."
                )
            articulation_start = np.array(self.articulation_start, dtype=np.int32)
            articulation_end = np.array(self.articulation_end, dtype=np.int32)
            if len(articulation_start) > 1:
                diffs = np.diff(articulation_start)
                if np.any(diffs < 0):
                    idx = np.where(diffs < 0)[0][0]
                    raise ValueError(
                        f"articulation_start is not monotonically increasing: "
                        f"articulation_start[{idx}]={articulation_start[idx]} > articulation_start[{idx + 1}]={articulation_start[idx + 1]}."
                    )
            invalid_end_mask = (articulation_end < articulation_start) | (articulation_end > joint_count)
            if np.any(invalid_end_mask):
                idx = int(np.where(invalid_end_mask)[0][0])
                raise ValueError(
                    f"Invalid articulation_end[{idx}]={articulation_end[idx]} for "
                    f"articulation_start[{idx}]={articulation_start[idx]} and joint_count={joint_count}."
                )
            next_start = np.empty_like(articulation_start)
            if articulation_count > 1:
                next_start[:-1] = articulation_start[1:]
            next_start[-1] = joint_count
            invalid_loop_boundary_mask = articulation_end > next_start
            if np.any(invalid_loop_boundary_mask):
                idx = int(np.where(invalid_loop_boundary_mask)[0][0])
                raise ValueError(
                    f"articulation_end[{idx}]={articulation_end[idx]} exceeds the next articulation start "
                    f"{next_start[idx]}."
                )

        particle_count = self.particle_count
        particle_arrays = (
            ("particle_qd", self.particle_qd),
            ("particle_mass", self.particle_mass),
            ("particle_radius", self.particle_radius),
            ("particle_flags", self.particle_flags),
            ("particle_world", self.particle_world),
        )
        for name, values in particle_arrays:
            if len(values) != particle_count:
                raise ValueError(
                    f"Array length mismatch: {name} has length {len(values)}, "
                    f"but expected {particle_count} (particle_count)."
                )

        def _topology_array(name: str, values: list, expected_shape: tuple[int, ...]) -> np.ndarray:
            try:
                source = np.asarray(values)
                if np.iscomplexobj(source):
                    raise ValueError
                array = np.asarray(values, dtype=np.int64)
                if not np.array_equal(source, array):
                    raise ValueError
            except (OverflowError, TypeError, ValueError) as exc:
                raise ValueError(
                    f"Invalid {name}: expected integer indices representable as int32 with shape {expected_shape}."
                ) from exc
            if array.size == 0 and expected_shape[0] == 0:
                return array.reshape(expected_shape)
            if array.shape != expected_shape:
                raise ValueError(f"Invalid {name} shape: expected {expected_shape}, got {array.shape}.")
            int32_info = np.iinfo(np.int32)
            if array.size > 0 and (int(array.min()) < int32_info.min or int(array.max()) > int32_info.max):
                raise ValueError(
                    f"Invalid {name}: expected integer indices representable as int32 with shape {expected_shape}."
                )
            return array

        def _validate_particle_topology(name: str, indices: np.ndarray) -> None:
            invalid_mask = (indices < 0) | (indices >= particle_count)
            if np.any(invalid_mask):
                element, slot = np.argwhere(invalid_mask)[0]
                index = int(indices[element, slot])
                raise ValueError(
                    f"Invalid particle reference in {name}: element {element}, slot {slot} references particle "
                    f"{index}, but valid range is [0, {particle_count - 1}] (particle count={particle_count})."
                )

        spring_indices = _topology_array("spring_indices", self.spring_indices, (self.spring_count * 2,)).reshape(-1, 2)
        tri_indices = _topology_array("tri_indices", self.tri_indices, (self.tri_count, 3))
        edge_indices = _topology_array("edge_indices", self.edge_indices, (self.edge_count, 4))
        tet_indices = _topology_array("tet_indices", self.tet_indices, (self.tet_count, 4))

        _validate_particle_topology("spring_indices", spring_indices)
        _validate_particle_topology("tri_indices", tri_indices)
        _validate_particle_topology("tet_indices", tet_indices)

        if edge_indices.size > 0:
            opposite_vertices = edge_indices[:, :2]
            invalid_opposite_mask = (opposite_vertices < -1) | (opposite_vertices >= particle_count)
            if np.any(invalid_opposite_mask):
                element, slot = np.argwhere(invalid_opposite_mask)[0]
                index = int(opposite_vertices[element, slot])
                raise ValueError(
                    f"Invalid particle reference in edge_indices: element {element}, opposite vertex {slot} "
                    f"references particle {index}, but valid values are -1 or [0, {particle_count - 1}] "
                    f"(particle count={particle_count})."
                )
            _validate_particle_topology("edge_indices", edge_indices[:, 2:])

        if joint_count > 0:
            # Per-DOF arrays should have length == joint_dof_count
            dof_arrays = [
                ("joint_axis", self.joint_axis),
                ("joint_armature", self.joint_armature),
                ("joint_target_ke", self.joint_target_ke),
                ("joint_target_kd", self.joint_target_kd),
                ("joint_damping", self.joint_damping),
                ("joint_limit_lower", self.joint_limit_lower),
                ("joint_limit_upper", self.joint_limit_upper),
                ("joint_limit_ke", self.joint_limit_ke),
                ("joint_limit_kd", self.joint_limit_kd),
                ("joint_target_qd", self.joint_target_qd),
                ("joint_effort_limit", self.joint_effort_limit),
                ("joint_velocity_limit", self.joint_velocity_limit),
                ("joint_friction", self.joint_friction),
                ("joint_target_mode", self.joint_target_mode),
            ]
            for name, arr in dof_arrays:
                if len(arr) != self.joint_dof_count:
                    raise ValueError(
                        f"Array length mismatch: {name} has length {len(arr)}, "
                        f"but expected {self.joint_dof_count} (joint_dof_count)."
                    )

            # Per-coord arrays should have length == joint_coord_count
            coord_arrays = [
                ("joint_q", self.joint_q),
                ("joint_target_q", self.joint_target_q),
            ]
            for name, arr in coord_arrays:
                if len(arr) != self.joint_coord_count:
                    raise ValueError(
                        f"Array length mismatch: {name} has length {len(arr)}, "
                        f"but expected {self.joint_coord_count} (joint_coord_count)."
                    )

            # Start arrays should have length == joint_count
            start_arrays = [
                ("joint_q_start", self.joint_q_start),
                ("joint_qd_start", self.joint_qd_start),
            ]
            for name, arr in start_arrays:
                if len(arr) != joint_count:
                    raise ValueError(
                        f"Array length mismatch: {name} has length {len(arr)}, "
                        f"but expected {joint_count} (joint_count)."
                    )

    def validate_joint_ordering(self) -> bool:
        """Validate that joints within articulations follow DFS topological ordering.

        This check ensures that joints are ordered such that parent bodies are processed
        before child bodies within each articulation. This ordering is required by some
        solvers (e.g., MuJoCo) for correct kinematic computations.

        This method is public and opt-in because the check has O(n log n) complexity
        due to topological sorting. It is skipped by default in
        :meth:`finalize <ModelBuilder.finalize>`.

        Warns:
            UserWarning: If joints are not in DFS topological order.

        Returns:
            Whether joints are correctly ordered.
        """
        from ..utils import topological_sort  # noqa: PLC0415

        if self.joint_count == 0:
            return True

        joint_parent = np.array(self.joint_parent, dtype=np.int32)
        joint_child = np.array(self.joint_child, dtype=np.int32)
        joint_articulation = np.array(self.joint_articulation, dtype=np.int32)

        # Get unique articulations (excluding -1 which means not in any articulation)
        articulation_ids = np.unique(joint_articulation)
        articulation_ids = articulation_ids[articulation_ids >= 0]

        all_ordered = True

        for art_id in articulation_ids:
            # Get joints in this articulation
            art_joints = np.where(joint_articulation == art_id)[0]
            if len(art_joints) <= 1:
                continue

            # Build joint list for topological sort
            joints_simple = [(int(joint_parent[i]), int(joint_child[i])) for i in art_joints]

            try:
                joint_order = topological_sort(joints_simple, use_dfs=True, custom_indices=list(art_joints))

                # Check if current order matches expected DFS order
                if any(joint_order[i] != art_joints[i] for i in range(len(joints_simple))):
                    art_key = (
                        self.articulation_label[art_id]
                        if art_id < len(self.articulation_label)
                        else f"articulation_{art_id}"
                    )
                    warnings.warn(
                        f"Joints in articulation '{art_key}' (id={art_id}) are not in DFS topological order. "
                        f"This may cause issues with some solvers (e.g., MuJoCo). "
                        f"Current order: {list(art_joints)}, expected: {joint_order}.",
                        stacklevel=2,
                    )
                    all_ordered = False
            except ValueError as e:
                # Topological sort failed (e.g., cycle detected)
                art_key = (
                    self.articulation_label[art_id]
                    if art_id < len(self.articulation_label)
                    else f"articulation_{art_id}"
                )
                warnings.warn(
                    f"Failed to validate joint ordering for articulation '{art_key}' (id={art_id}): {e}",
                    stacklevel=2,
                )
                all_ordered = False

        return all_ordered

    def _build_world_starts(self):
        """
        Constructs the per-world entity start indices.

        This method validates that the per-world start index lists for various entities
        (particles, bodies, shapes, joints, articulations, equality constraints and joint
        coordinates/DOFs/constraints) are cumulative and match the total counts of those
        entities. Moreover, it appends the start of tail-end global entities and the
        overall total counts to the end of each start index lists.

        The format of the start index lists is as follows (where `*` can be `body`, `shape`, `joint`, etc.):
            .. code-block:: python

                world_*_start = [ start_world_0, start_world_1, ..., start_world_N , start_global_tail, total_count]

        This allows retrieval of per-world counts using:
            .. code-block:: python

                global_*_count = start_world_0 + (total_count - start_global_tail)
                world_*_count[w] = world_*_start[w + 1] - world_*_start[w]

        e.g.
            .. code-block:: python

                body_world = [-1, -1, 0, 0, ..., 1, 1, ..., N - 1, N - 1, ..., -1, -1, -1, ...]
                body_world_start = [2, 15, 25, ..., 50, 60, 72]
                #          world :  -1 |  0 |  1   ... |  N-1 | -1 |  total
        """
        # List of all world starts of entities
        world_entity_start_arrays = [
            (self.particle_world_start, self.particle_count, self.particle_world, "particle"),
            (self.body_world_start, self.body_count, self.body_world, "body"),
            (self.shape_world_start, self.shape_count, self.shape_world, "shape"),
            (self.joint_world_start, self.joint_count, self.joint_world, "joint"),
            (self.articulation_world_start, self.articulation_count, self.articulation_world, "articulation"),
            (
                self._equality_constraint_world_start,
                self._equality_constraint_count,
                self._eq_list("equality_constraint_world"),
                "equality constraint",
            ),
        ]

        def build_entity_start_array(
            entity_count: int, entity_world: list[int], world_entity_start: list[int], name: str
        ):
            # Ensure that entity_world has length equal to entity_count
            if len(entity_world) != entity_count:
                raise ValueError(
                    f"World array for {name}s has incorrect length: expected {entity_count}, found {len(entity_world)}."
                )

            # Initialize world_entity_start with zeros
            world_entity_start.clear()
            world_entity_start.extend([0] * (self.world_count + 2))

            # Count global entities at the front of the entity_world array
            front_global_entity_count = 0
            for w in entity_world:
                if w == -1:
                    front_global_entity_count += 1
                else:
                    break
            world_entity_start[0] = front_global_entity_count

            # Compute per-world cumulative counts
            entity_world_np = np.asarray(entity_world, dtype=np.int32)
            world_counts = np.bincount(entity_world_np[entity_world_np >= 0], minlength=self.world_count)
            for w in range(self.world_count):
                world_entity_start[w + 1] = world_entity_start[w] + int(world_counts[w])

            # Set the last element to the total entity counts over all worlds in the model
            world_entity_start[-1] = entity_count

        # Check that all world offset indices are cumulative and match counts
        for world_start_array, total_count, entity_world_array, name in world_entity_start_arrays:
            # First build the start lists by appending tail-end global and total entity counts
            build_entity_start_array(total_count, entity_world_array, world_start_array, name)

            # Ensure the world_start array has length world_count + 2 (for global entities at start/end)
            expected_length = self.world_count + 2
            if len(world_start_array) != expected_length:
                raise ValueError(
                    f"World start indices for {name}s have incorrect length: "
                    f"expected {expected_length}, found {len(world_start_array)}."
                )

            # Ensure that per-world start indices are non-decreasing and compute sum of per-world counts
            sum_of_counts = world_start_array[0]
            for w in range(self.world_count + 1):
                start_idx = world_start_array[w]
                end_idx = world_start_array[w + 1]
                count = end_idx - start_idx
                if count < 0:
                    raise ValueError(
                        f"Invalid world start indices for {name}s: world {w} has negative count ({count}). "
                        f"Start index: {start_idx}, end index: {end_idx}."
                    )
                sum_of_counts += count

            # Ensure the sum of per-world counts equals the total count
            if sum_of_counts != total_count:
                raise ValueError(
                    f"Sum of per-world {name} counts does not equal total count: "
                    f"expected {total_count}, found {sum_of_counts}."
                )

            # Ensure that the last entry equals the total count
            if world_start_array[-1] != total_count:
                raise ValueError(
                    f"World start indices for {name}s do not match total count: "
                    f"expected final index {total_count}, found {world_start_array[-1]}."
                )

        # List of world starts of joints spaces, i.e. coords/DOFs/constraints
        world_joint_space_start_arrays = [
            (self.joint_dof_world_start, self.joint_qd_start, self.joint_dof_count, "joint DOF"),
            (self.joint_coord_world_start, self.joint_q_start, self.joint_coord_count, "joint coordinate"),
            (self.joint_constraint_world_start, self.joint_cts_start, self.joint_constraint_count, "joint constraint"),
        ]

        def build_joint_space_start_array(
            space_count: int, joint_space_start: list[int], world_space_start: list[int], name: str
        ):
            # Ensure that joint_space_start has length equal to self.joint_count
            if len(joint_space_start) != self.joint_count:
                raise ValueError(
                    f"Joint start array for {name}s has incorrect length: "
                    f"expected {self.joint_count}, found {len(joint_space_start)}."
                )

            # Initialize world_space_start with zeros
            world_space_start.clear()
            world_space_start.extend([0] * (self.world_count + 2))

            # Extend joint_space_start with total count to enable computing per-world counts
            joint_space_start_ext = copy.copy(joint_space_start)
            joint_space_start_ext.append(space_count)

            # Count global entities at the front of the entity_world array
            front_global_space_count = 0
            for j, w in enumerate(self.joint_world):
                if w == -1:
                    front_global_space_count += joint_space_start_ext[j + 1] - joint_space_start_ext[j]
                else:
                    break

            # Compute per-world cumulative joint space counts to initialize world_space_start
            for j, w in enumerate(self.joint_world):
                if w >= 0:
                    world_space_start[w + 1] += joint_space_start_ext[j + 1] - joint_space_start_ext[j]

            # Convert per-world counts to cumulative start indices
            world_space_start[0] += front_global_space_count
            for w in range(self.world_count):
                world_space_start[w + 1] += world_space_start[w]

            # Add total (i.e. final) entity counts to the per-world start indices
            world_space_start[-1] = space_count

        # Check that all world offset indices are cumulative and match counts
        for world_start_array, space_start_array, total_count, name in world_joint_space_start_arrays:
            # First finalize the start array by appending tail-end global and total entity counts
            build_joint_space_start_array(total_count, space_start_array, world_start_array, name)

            # Ensure the world_start array has length world_count + 2 (for global entities at start/end)
            expected_length = self.world_count + 2
            if len(world_start_array) != expected_length:
                raise ValueError(
                    f"World start indices for {name}s have incorrect length: "
                    f"expected {expected_length}, found {len(world_start_array)}."
                )

            # Ensure that per-world start indices are non-decreasing and compute sum of per-world counts
            sum_of_counts = world_start_array[0]
            for w in range(self.world_count + 1):
                start_idx = world_start_array[w]
                end_idx = world_start_array[w + 1]
                count = end_idx - start_idx
                if count < 0:
                    raise ValueError(
                        f"Invalid world start indices for {name}s: world {w} has negative count ({count}). "
                        f"Start index: {start_idx}, end index: {end_idx}."
                    )
                sum_of_counts += count

            # Ensure the sum of per-world counts equals the total count
            if sum_of_counts != total_count:
                raise ValueError(
                    f"Sum of per-world {name} counts does not equal total count: "
                    f"expected {total_count}, found {sum_of_counts}."
                )

            # Ensure that the last entry equals the total count
            if world_start_array[-1] != total_count:
                raise ValueError(
                    f"World start indices for {name}s do not match total count: "
                    f"expected final index {total_count}, found {world_start_array[-1]}."
                )

    def finalize(
        self,
        device: Devicelike | None = None,
        *,
        requires_grad: bool = False,
        skip_all_validations: bool = False,
        skip_validation_worlds: bool = False,
        skip_validation_joints: bool = False,
        skip_validation_shapes: bool = False,
        skip_validation_structure: bool = False,
        skip_validation_joint_ordering: bool = True,
    ) -> Model:
        """
        Finalize the builder and create a concrete :class:`~newton.Model` for simulation.

        This method transfers all simulation data from the builder to device memory,
        returning a Model object ready for simulation. It should be called after all
        elements (particles, bodies, shapes, joints, etc.) have been added to the builder.

        Args:
            device: The simulation device to use (e.g., 'cpu', 'cuda'). If None, uses the current Warp device.
            requires_grad: If True, enables gradient computation for the model (for differentiable simulation).
            skip_all_validations: If True, skips all validation checks. Use for maximum performance when
                you are confident the model is valid. Default is False.
            skip_validation_worlds: If True, skips validation of world ordering and contiguity. Default is False.
            skip_validation_joints: If True, skips articulation-membership validation. By default, non-root joints
                must belong to an articulation or close a loop; standalone world-root joints are allowed.
            skip_validation_shapes: If True, skips validation of shapes having valid contact margins. Default is False.
            skip_validation_structure: If True, skips validation of structural invariants (body/joint references,
                particle topology, array lengths, monotonicity). Default is False.
            skip_validation_joint_ordering: If True, skips validation of DFS topological joint ordering within
                articulations. Default is True (opt-in) because this check has O(n log n) complexity.

        Returns:
            A fully constructed Model object containing all simulation data on the specified device.

        Notes:
            - Performs validation and correction of rigid body inertia and mass properties.
            - Closes all start-index arrays (e.g., for muscles, joints, articulations) with sentinel values.
            - Sets up all arrays and properties required for simulation, including particles, bodies, shapes,
              joints, springs, muscles, constraints, and collision/contact data.
        """

        # ensure the world count is set correctly
        self.world_count = max(1, self.world_count)

        # validate world ordering and contiguity
        if not skip_all_validations and not skip_validation_worlds:
            self._validate_world_ordering()

        # validate joints belong to an articulation
        if not skip_all_validations and not skip_validation_joints:
            self._validate_joints()

        # validate shapes have valid contact margins
        if not skip_all_validations and not skip_validation_shapes:
            self._validate_shapes()

        # validate structural invariants (body/joint references, array lengths)
        if not skip_all_validations and not skip_validation_structure:
            self._validate_structure()

        # validate DFS topological joint ordering (opt-in, skipped by default)
        if not skip_all_validations and not skip_validation_joint_ordering:
            self.validate_joint_ordering()

        # construct world starts by ensuring they are cumulative and appending
        # tail-end global counts and sum total counts over the entire model.
        # This method also performs relevant validation checks on the start.
        self._build_world_starts()

        # construct particle inv masses
        ms = np.array(self.particle_mass, dtype=np.float32)
        # static particles (with zero mass) have zero inverse mass
        particle_inv_mass = np.divide(1.0, ms, out=np.zeros_like(ms), where=ms != 0.0)

        shape_collision_filter_packed = self._build_shape_collision_filter_packed()

        with wp.ScopedDevice(device):
            current_device = wp.get_device()
            sdf_texture_paired_samples = _resolve_paired_samples_flag(self.sdf_texture_paired_samples, current_device)

            # -------------------------------------
            # construct Model (non-time varying) data

            m = Model(device)
            m._sdf_texture_paired_samples = sdf_texture_paired_samples
            m._set_shape_collision_filter_packed(shape_collision_filter_packed)  # pyright: ignore[reportPrivateUsage]
            m.request_contact_attributes(*self._requested_contact_attributes)
            m.request_state_attributes(*self._requested_state_attributes)
            m.requires_grad = requires_grad

            m.world_count = self.world_count

            # ---------------------
            # particles

            # state (initial)
            m.particle_q = wp.array(self.particle_q, dtype=wp.vec3, requires_grad=requires_grad)
            m.particle_qd = wp.array(self.particle_qd, dtype=wp.vec3, requires_grad=requires_grad)
            m.particle_mass = wp.array(self.particle_mass, dtype=wp.float32, requires_grad=requires_grad)
            m.particle_inv_mass = wp.array(particle_inv_mass, dtype=wp.float32, requires_grad=requires_grad)
            m.particle_radius = wp.array(self.particle_radius, dtype=wp.float32, requires_grad=requires_grad)
            m.particle_flags = wp.array([flag_to_int(f) for f in self.particle_flags], dtype=wp.int32)
            m.particle_world = wp.array(self.particle_world, dtype=wp.int32)
            m.particle_max_radius = np.max(self.particle_radius) if len(self.particle_radius) > 0 else 0.0
            m.particle_max_velocity = self.particle_max_velocity

            particle_colors = np.empty(self.particle_count, dtype=int)
            for color in range(len(self.particle_color_groups)):
                particle_colors[self.particle_color_groups[color]] = color
            m.particle_colors = wp.array(particle_colors, dtype=int)
            m.particle_color_groups = [wp.array(group, dtype=int) for group in self.particle_color_groups]

            # hash-grid for particle interactions
            if self.particle_count > 1 and m.particle_max_radius > 0.0:
                m.particle_grid = wp.HashGrid(128, 128, 128)
            else:
                m.particle_grid = None

            # ---------------------
            # collision geometry

            m.shape_label = self.shape_label
            m.shape_transform = wp.array(self.shape_transform, dtype=wp.transform, requires_grad=requires_grad)
            m.shape_body = wp.array(self.shape_body, dtype=wp.int32)
            m.shape_flags = wp.array(self.shape_flags, dtype=wp.int32)
            m.body_shapes = self.body_shapes

            def _shape_requests_planar_sdf(shape_idx: int) -> bool:
                """Whether a shape needs texture SDF data for planar-faced contact."""
                if not (self.shape_flags[shape_idx] & ShapeFlags.COLLIDE_SHAPES):
                    return False
                stype = self.shape_type[shape_idx]
                if stype in (GeoType.MESH, GeoType.CONVEX_MESH):
                    src = self.shape_source[shape_idx]
                    return src is not None and (
                        getattr(src, "sdf", None) is not None
                        or self.shape_sdf_max_resolution[shape_idx] is not None
                        or self.shape_sdf_target_voxel_size[shape_idx] is not None
                    )
                return stype == GeoType.BOX and (
                    self.shape_sdf_max_resolution[shape_idx] is not None
                    or self.shape_sdf_target_voxel_size[shape_idx] is not None
                    or bool(self.shape_flags[shape_idx] & ShapeFlags.HYDROELASTIC)
                )

            generated_shape_sources = list(self.shape_source)
            deduplicated_convex_sources = {}
            for shape_idx, shape_type in enumerate(self.shape_type):
                source = generated_shape_sources[shape_idx]
                if shape_type != GeoType.CONVEX_MESH or not isinstance(source, Mesh):
                    continue
                source_identity = id(source)
                if source_identity in deduplicated_convex_sources:
                    generated_shape_sources[shape_idx] = deduplicated_convex_sources[source_identity]
                    continue
                deduplicated_source = _deduplicate_convex_collision_mesh(source)
                deduplicated_convex_sources[source_identity] = deduplicated_source
                generated_shape_sources[shape_idx] = deduplicated_source
            generated_sdf_edge_meshes = []
            unit_box_edge_mesh = None
            for shape_idx, shape_type in enumerate(self.shape_type):
                if shape_type == GeoType.BOX and _shape_requests_planar_sdf(shape_idx):
                    if unit_box_edge_mesh is None:
                        # The edge mesh is intentionally unscaled; per-shape box
                        # half-extents are still applied through shape_scale.
                        unit_box_edge_mesh = Mesh.create_box(
                            1.0,
                            1.0,
                            1.0,
                            duplicate_vertices=False,
                            compute_normals=False,
                            compute_uvs=False,
                            compute_inertia=False,
                        )
                        unit_box_edge_mesh._build_collision_edges(
                            lower_angle_threshold_rad=1.0e-6,
                            upper_angle_threshold_rad=math.pi,
                            enable_box_absorption=False,
                            half_normal=0.0,
                            half_lateral=0.0,
                        )
                        generated_sdf_edge_meshes.append(unit_box_edge_mesh)
                    generated_shape_sources[shape_idx] = unit_box_edge_mesh

            # build list of ids for geometry sources (meshes, sdfs, heightfields)
            geo_sources = []
            finalized_geos = {}  # content hash -> finalized geometry
            finalized_geos_by_identity = {}  # object id -> finalized geometry
            gaussians = []
            heightfield_meshes = []
            mesh_keep_alive = []
            for geo in generated_shape_sources:
                if not geo:
                    geo_sources.append(0)
                    continue

                # Replicated builders reuse geometry objects across worlds. Use
                # identity for that fast path, but retain content hashes so distinct
                # equivalent geometry objects share one finalized representation.
                geo_identity = id(geo)
                if geo_identity in finalized_geos_by_identity:
                    geo_sources.append(finalized_geos_by_identity[geo_identity])
                    continue

                geo_hash = hash(geo)
                if geo_hash not in finalized_geos and isinstance(geo, Heightfield):
                    # Transpose: create_heightfield uses ij-indexing (i=X, j=Y)
                    # while Heightfield stores row-major data (row=Y, col=X).
                    actual_heights = geo.min_z + geo.data * (geo.max_z - geo.min_z)
                    hf_geo = Mesh.create_heightfield(
                        heightfield=actual_heights.T,
                        extent_x=geo.hx * 2.0,
                        extent_y=geo.hy * 2.0,
                        ground_z=geo.min_z,
                        compute_inertia=False,
                    )
                    finalized_geos[geo_hash] = hf_geo.finalize(
                        device=device,
                        bvh_constructor=self.default_bvh_cfg.mesh_constructor,
                    )
                    # keep mesh alive for the model's lifetime
                    heightfield_meshes.append(hf_geo.mesh)
                elif geo_hash not in finalized_geos:
                    if isinstance(geo, Mesh):
                        finalized_geos[geo_hash] = geo.finalize(
                            device=device,
                            bvh_constructor=self.default_bvh_cfg.mesh_constructor,
                        )
                        # keep mesh alive for the model's lifetime: geometry objects
                        # can be shared with other builders (see replicate() and
                        # add_builder()), so the model must not rely on the geometry
                        # object keeping the finalized wp.Mesh alive
                        mesh_keep_alive.append(geo.mesh)
                    elif isinstance(geo, Gaussian):
                        finalized_geos[geo_hash] = len(gaussians)
                        gaussians.append(
                            geo.finalize(device=device, bvh_constructor=self.default_bvh_cfg.gaussian_constructor)
                        )
                    else:
                        finalized_geos[geo_hash] = geo.finalize()

                finalized_geo = finalized_geos[geo_hash]
                finalized_geos_by_identity[geo_identity] = finalized_geo
                geo_sources.append(finalized_geo)

            # Mesh properties consumed by the collision kernels: watertightness
            # is checked once per unique collidable mesh (content-keyed like
            # finalized_geos above); visual-only shapes are skipped.
            shape_mesh_properties = []
            mesh_properties_by_geo_hash: dict[int, int] = {}
            for shape_type, geo, shape_flags in zip(
                self.shape_type, generated_shape_sources, self.shape_flags, strict=True
            ):
                mesh_properties = 0
                is_collidable = bool(shape_flags & (ShapeFlags.COLLIDE_SHAPES | ShapeFlags.COLLIDE_PARTICLES))
                if is_collidable and shape_type in (GeoType.MESH, GeoType.CONVEX_MESH) and isinstance(geo, Mesh):
                    mesh_properties = mesh_properties_by_geo_hash.get(hash(geo))
                    if mesh_properties is None:
                        mesh_properties = MeshProperties.WATERTIGHT if geo.is_watertight else 0
                        mesh_properties_by_geo_hash[hash(geo)] = mesh_properties
                shape_mesh_properties.append(mesh_properties)

            m.shape_type = wp.array(self.shape_type, dtype=wp.int32)
            m.shape_source_ptr = wp.array(geo_sources, dtype=wp.uint64)
            m._shape_mesh_properties = wp.array(shape_mesh_properties, dtype=wp.int32, device=device)
            m.heightfield_meshes = heightfield_meshes
            m._mesh_keep_alive = mesh_keep_alive

            # Compact convex support data (one copy per shared geometry).
            shape_support_data = []
            support_lut_chunks = []
            support_offset_chunks = []
            support_neighbor_chunks = []
            support_cache = {}
            lut_offset = 0
            vertex_offset = 0
            neighbor_offset = 0
            for shape_type, source, shape_flags in zip(
                self.shape_type, generated_shape_sources, self.shape_flags, strict=True
            ):
                metadata = (-1, -1, -1, 0)
                if (
                    shape_type == GeoType.CONVEX_MESH
                    and isinstance(source, Mesh)
                    and shape_flags & ShapeFlags.COLLIDE_SHAPES
                ):
                    source_key = hash(source)
                    if source_key not in support_cache:
                        acceleration = _build_convex_support_acceleration(source)
                        cached = None
                        if acceleration is not None:
                            lut, offsets, neighbors = acceleration
                            cached = (
                                (lut_offset, vertex_offset, neighbor_offset, _CONVEX_SUPPORT_LUT_RESOLUTION),
                                lut,
                                offsets,
                                neighbors,
                            )
                            support_lut_chunks.append(lut)
                            support_offset_chunks.append(offsets)
                            support_neighbor_chunks.append(neighbors)
                            lut_offset += len(lut)
                            vertex_offset += len(offsets)
                            neighbor_offset += len(neighbors)
                        support_cache[source_key] = cached
                    cached = support_cache[source_key]
                    if cached is not None:
                        metadata = cached[0]
                shape_support_data.append(metadata)

            m._shape_support_data = wp.array(shape_support_data, dtype=wp.vec4i, device=device)
            m._convex_support_lut = wp.array(
                np.concatenate(support_lut_chunks) if support_lut_chunks else np.zeros(1, dtype=np.int32),
                dtype=wp.int32,
                device=device,
            )
            m._convex_support_vertex_offsets = wp.array(
                np.concatenate(support_offset_chunks) if support_offset_chunks else np.zeros(1, dtype=np.int32),
                dtype=wp.int32,
                device=device,
            )
            m._convex_support_neighbors = wp.array(
                np.concatenate(support_neighbor_chunks) if support_neighbor_chunks else np.zeros(1, dtype=np.int32),
                dtype=wp.int32,
                device=device,
            )
            m._generated_sdf_edge_meshes = generated_sdf_edge_meshes
            m.gaussians_count = len(gaussians)
            m.gaussians_data = wp.array(gaussians, dtype=Gaussian.Data)
            m.shape_scale = wp.array(self.shape_scale, dtype=wp.vec3, requires_grad=requires_grad)
            m.shape_is_solid = wp.array(self.shape_is_solid, dtype=wp.bool)
            m.shape_margin = wp.array(self.shape_margin, dtype=wp.float32, requires_grad=requires_grad)
            m.shape_collision_radius = wp.array(
                self.shape_collision_radius, dtype=wp.float32, requires_grad=requires_grad
            )
            m.shape_world = wp.array(self.shape_world, dtype=wp.int32)

            m.shape_source = self.shape_source  # used for rendering
            m.shape_color = wp.array(self.shape_color, dtype=wp.vec3)
            m.shape_opacity = wp.array(self.shape_opacity, dtype=wp.float32)

            m.shape_material_ke = wp.array(self.shape_material_ke, dtype=wp.float32, requires_grad=requires_grad)
            m.shape_material_kd = wp.array(self.shape_material_kd, dtype=wp.float32, requires_grad=requires_grad)
            m.shape_material_kf = wp.array(self.shape_material_kf, dtype=wp.float32, requires_grad=requires_grad)
            m.shape_material_ka = wp.array(self.shape_material_ka, dtype=wp.float32, requires_grad=requires_grad)
            m.shape_material_mu = wp.array(self.shape_material_mu, dtype=wp.float32, requires_grad=requires_grad)
            m.shape_material_restitution = wp.array(
                self.shape_material_restitution, dtype=wp.float32, requires_grad=requires_grad
            )
            m.shape_material_mu_torsional = wp.array(
                self.shape_material_mu_torsional, dtype=wp.float32, requires_grad=requires_grad
            )
            m.shape_material_mu_rolling = wp.array(
                self.shape_material_mu_rolling, dtype=wp.float32, requires_grad=requires_grad
            )
            m.shape_material_kh = wp.array(self.shape_material_kh, dtype=wp.float32, requires_grad=requires_grad)
            m.shape_gap = wp.array(self.shape_gap, dtype=wp.float32, requires_grad=requires_grad)

            m.shape_collision_group = wp.array(self.shape_collision_group, dtype=wp.int32)

            # ---------------------
            # Compute local AABBs and voxel resolutions for contact reduction
            local_aabb_lower = []
            local_aabb_upper = []
            voxel_resolution = []
            from ..geometry.contact_reduction import NUM_VOXEL_DEPTH_SLOTS  # noqa: PLC0415

            voxel_budget = NUM_VOXEL_DEPTH_SLOTS

            # Cache per unique (shape_type, shape_params, margin) to avoid redundant AABB computation
            # for instanced shapes (e.g., 256 robots sharing the same shape parameters)
            shape_aabb_cache = {}

            def compute_voxel_resolution_from_aabb(aabb_lower, aabb_upper, voxel_budget):
                """Compute voxel resolution from AABB with given budget."""
                size = aabb_upper - aabb_lower
                size = np.maximum(size, 1e-6)  # Avoid division by zero

                # Target voxel size for approximately cubic voxels
                volume = size[0] * size[1] * size[2]
                v = (volume / voxel_budget) ** (1.0 / 3.0)
                v = max(v, 1e-6)

                # Initial resolution
                nx = max(1, round(size[0] / v))
                ny = max(1, round(size[1] / v))
                nz = max(1, round(size[2] / v))

                # Reduce until under budget (reduce largest axis first for more cubic voxels)
                while nx * ny * nz > voxel_budget:
                    if nx >= ny and nx >= nz and nx > 1:
                        nx -= 1
                    elif ny >= nz and ny > 1:
                        ny -= 1
                    elif nz > 1:
                        nz -= 1
                    else:
                        break

                return nx, ny, nz

            site_display_size_attr = self.custom_attributes.get("mujoco:site_size_is_display")
            for _shape_idx, (shape_type, shape_src, shape_scale) in enumerate(
                zip(self.shape_type, self.shape_source, self.shape_scale, strict=True)
            ):
                site_size_is_display = bool(
                    site_display_size_attr
                    and site_display_size_attr.values.get(_shape_idx, site_display_size_attr.default)
                )
                # Create cache key based on shape type and parameters
                if (shape_type == GeoType.MESH or shape_type == GeoType.CONVEX_MESH) and shape_src is not None:
                    cache_key = (shape_type, id(shape_src), tuple(shape_scale))
                elif shape_type == GeoType.CYLINDER and site_size_is_display:
                    # MuJoCo cylinder sites may carry an unused third display-size component.
                    # It is not Newton's barrel radius and does not affect their bounds.
                    cache_key = (shape_type, (shape_scale[0], shape_scale[1], 0.0))
                else:
                    cache_key = (shape_type, tuple(shape_scale))

                # Check cache first
                if cache_key in shape_aabb_cache:
                    aabb_lower, aabb_upper, nx, ny, nz = shape_aabb_cache[cache_key]
                else:
                    # Compute AABB based on shape type
                    if shape_type == GeoType.MESH and shape_src is not None:
                        # Compute local AABB from mesh vertices
                        vertices = shape_src.vertices
                        lo = vertices.min(axis=0) * np.array(shape_scale)
                        hi = vertices.max(axis=0) * np.array(shape_scale)
                        aabb_lower = np.minimum(lo, hi)
                        aabb_upper = np.maximum(lo, hi)

                        nx, ny, nz = compute_voxel_resolution_from_aabb(aabb_lower, aabb_upper, voxel_budget)

                    elif shape_type == GeoType.CONVEX_MESH and shape_src is not None:
                        lo = shape_src.vertices.min(axis=0) * np.array(shape_scale)
                        hi = shape_src.vertices.max(axis=0) * np.array(shape_scale)
                        aabb_lower = np.minimum(lo, hi)
                        aabb_upper = np.maximum(lo, hi)

                        nx, ny, nz = compute_voxel_resolution_from_aabb(aabb_lower, aabb_upper, voxel_budget)

                    elif shape_type == GeoType.ELLIPSOID:
                        # Ellipsoid: shape_scale = (semi_axis_x, semi_axis_y, semi_axis_z)
                        sx, sy, sz = shape_scale
                        aabb_lower = np.array([-sx, -sy, -sz])
                        aabb_upper = np.array([sx, sy, sz])
                        nx, ny, nz = compute_voxel_resolution_from_aabb(aabb_lower, aabb_upper, voxel_budget)

                    elif shape_type == GeoType.BOX:
                        # Box: shape_scale = (hx, hy, hz) half-extents
                        hx, hy, hz = shape_scale
                        aabb_lower = np.array([-hx, -hy, -hz])
                        aabb_upper = np.array([hx, hy, hz])
                        nx, ny, nz = compute_voxel_resolution_from_aabb(aabb_lower, aabb_upper, voxel_budget)

                    elif shape_type == GeoType.SPHERE:
                        # Sphere: shape_scale = (radius, radius, radius)
                        r = shape_scale[0]
                        aabb_lower = np.array([-r, -r, -r])
                        aabb_upper = np.array([r, r, r])
                        nx, ny, nz = compute_voxel_resolution_from_aabb(aabb_lower, aabb_upper, voxel_budget)

                    elif shape_type == GeoType.CAPSULE:
                        # Capsule: shape_scale = (radius, half_height, radius)
                        # Capsule is along Z axis with hemispherical caps (matches SDF in kernels.py)
                        r, half_height, _ = shape_scale
                        aabb_lower = np.array([-r, -r, -half_height - r])
                        aabb_upper = np.array([r, r, half_height + r])
                        nx, ny, nz = compute_voxel_resolution_from_aabb(aabb_lower, aabb_upper, voxel_budget)

                    elif shape_type == GeoType.CYLINDER:
                        # Cylinder: shape_scale = (end_radius, half_height, barrel_radius)
                        r, half_height, barrel_radius = shape_scale
                        if site_size_is_display:
                            barrel_radius = 0.0
                        radial_extent = r
                        if barrel_radius > 0.0:
                            radial_extent += (half_height * half_height) / (
                                barrel_radius + np.sqrt(barrel_radius * barrel_radius - half_height * half_height)
                            )
                        aabb_lower = np.array([-radial_extent, -radial_extent, -half_height])
                        aabb_upper = np.array([radial_extent, radial_extent, half_height])
                        nx, ny, nz = compute_voxel_resolution_from_aabb(aabb_lower, aabb_upper, voxel_budget)

                    elif shape_type == GeoType.CONE:
                        # Cone: shape_scale = (radius, half_height, radius)
                        # Cone is along Z axis (matches SDF in kernels.py)
                        r, half_height, _ = shape_scale
                        aabb_lower = np.array([-r, -r, -half_height])
                        aabb_upper = np.array([r, r, half_height])
                        nx, ny, nz = compute_voxel_resolution_from_aabb(aabb_lower, aabb_upper, voxel_budget)

                    elif shape_type == GeoType.HFIELD and shape_src is not None:
                        hx = abs(shape_src.hx * shape_scale[0])
                        hy = abs(shape_src.hy * shape_scale[1])
                        z_lo = shape_src.min_z * shape_scale[2]
                        z_hi = shape_src.max_z * shape_scale[2]
                        aabb_lower = np.array([-hx, -hy, min(z_lo, z_hi)])
                        aabb_upper = np.array([hx, hy, max(z_lo, z_hi)])
                        nx, ny, nz = compute_voxel_resolution_from_aabb(aabb_lower, aabb_upper, voxel_budget)

                    else:
                        # Other shapes (PLANE, etc.): use default unit cube with 1x1x1 voxel grid
                        aabb_lower = np.array([-1.0, -1.0, -1.0])
                        aabb_upper = np.array([1.0, 1.0, 1.0])
                        nx, ny, nz = 1, 1, 1

                    # Cache the result for reuse by identical shapes
                    shape_aabb_cache[cache_key] = (aabb_lower, aabb_upper, nx, ny, nz)

                local_aabb_lower.append(aabb_lower)
                local_aabb_upper.append(aabb_upper)
                voxel_resolution.append([nx, ny, nz])

            m.shape_collision_aabb_lower = wp.array(local_aabb_lower, dtype=wp.vec3, device=device)
            m.shape_collision_aabb_upper = wp.array(local_aabb_upper, dtype=wp.vec3, device=device)
            m._shape_voxel_resolution = wp.array(voxel_resolution, dtype=wp.vec3i, device=device)

            # ---------------------
            # Compute and compact texture SDF resources (shared table + per-shape index indirection)
            is_gpu = current_device.is_cuda

            has_mesh_sdf = any(
                stype in (GeoType.MESH, GeoType.CONVEX_MESH)
                and ssrc is not None
                and sflags & ShapeFlags.COLLIDE_SHAPES
                and getattr(ssrc, "sdf", None) is not None
                for stype, ssrc, sflags in zip(self.shape_type, self.shape_source, self.shape_flags, strict=True)
            )
            # Catch meshes whose SDF is still deferred (built during finalize) so
            # the CPU-runs-into-build_sdf path also raises here, not deeper down.
            has_deferred_mesh_sdf = any(
                stype in (GeoType.MESH, GeoType.CONVEX_MESH, GeoType.BOX)
                and ssrc is not None
                and sflags & ShapeFlags.COLLIDE_SHAPES
                and (stype == GeoType.BOX or getattr(ssrc, "sdf", None) is None)
                and (smax is not None or svox is not None)
                for stype, ssrc, sflags, smax, svox in zip(
                    self.shape_type,
                    generated_shape_sources,
                    self.shape_flags,
                    self.shape_sdf_max_resolution,
                    self.shape_sdf_target_voxel_size,
                    strict=True,
                )
            )
            has_hydroelastic_shapes = any(
                (sflags & ShapeFlags.HYDROELASTIC) and (sflags & ShapeFlags.COLLIDE_SHAPES)
                for sflags in self.shape_flags
            )
            if (has_mesh_sdf or has_deferred_mesh_sdf or has_hydroelastic_shapes) and not is_gpu:
                raise ValueError(
                    "Building texture SDFs requires a CUDA-capable GPU device. "
                    "The texture SDF build path uses wp.Volume.allocate_by_tiles "
                    "and wp.Texture3D, which are CUDA-only."
                )

            from ..geometry.sdf_texture import (  # noqa: PLC0415
                QuantizationMode,
                TextureSDFData,
                create_empty_texture_sdf_data,
                create_texture_sdf_from_mesh,
                create_texture_sdf_from_primitive,
            )

            _tex_fmt_map = {
                "float32": QuantizationMode.FLOAT32,
                "uint16": QuantizationMode.UINT16,
                "uint8": QuantizationMode.UINT8,
            }

            compact_texture_sdf_data = []
            compact_texture_sdf_coarse_textures = []
            compact_texture_sdf_subgrid_textures = []
            compact_texture_sdf_subgrid_start_slots = []
            shape_sdf_index = [-1] * len(self.shape_type)
            sdf_cache = {}
            # Deferred-mesh SDFs are built into a temporary Mesh clone keyed by
            # the parameter tuple. This avoids mutating the user's shared Mesh
            # while still deduplicating identical (Mesh, params) combinations.
            deferred_mesh_sdf_cache = {}
            # Forward simplified collision edges from the deferred SDF clone to
            # the edge-consumption loop below.
            deferred_collision_edges_cache: dict[tuple, Any] = {}
            deferred_collision_edges: dict[int, Any] = {}

            for i in range(len(self.shape_type)):
                shape_type = self.shape_type[i]
                shape_src = self.shape_source[i]
                shape_flags = self.shape_flags[i]
                shape_scale = self.shape_scale[i]
                shape_gap = self.shape_gap[i]
                sdf_narrow_band_range = self.shape_sdf_narrow_band_range[i]
                sdf_target_voxel_size = self.shape_sdf_target_voxel_size[i]
                sdf_max_resolution = self.shape_sdf_max_resolution[i]
                sdf_tex_fmt = self.shape_sdf_texture_format[i]
                sdf_padding = self.shape_sdf_padding[i]
                is_hydroelastic = bool(
                    shape_flags & ShapeFlags.HYDROELASTIC and shape_flags & ShapeFlags.COLLIDE_SHAPES
                )
                required_sdf_padding = shape_gap + self.shape_margin[i] if is_hydroelastic else shape_gap
                sdf_gen_margin = sdf_padding if sdf_padding is not None else required_sdf_padding
                has_shape_collision = bool(shape_flags & ShapeFlags.COLLIDE_SHAPES)

                cache_key = None
                mesh_sdf = None

                if shape_type in (GeoType.MESH, GeoType.CONVEX_MESH) and has_shape_collision and shape_src is not None:
                    mesh_sdf = getattr(shape_src, "sdf", None)
                    # Build on a Mesh clone so shapes sharing one Mesh at different
                    # scale/margin/resolution end up with distinct SDFs.
                    if mesh_sdf is None and (sdf_max_resolution is not None or sdf_target_voxel_size is not None):
                        sdf_kwargs = {"narrow_band_range": tuple(sdf_narrow_band_range)}
                        if sdf_max_resolution is not None:
                            sdf_kwargs["max_resolution"] = sdf_max_resolution
                        if sdf_target_voxel_size is not None:
                            sdf_kwargs["target_voxel_size"] = sdf_target_voxel_size
                        sdf_kwargs["margin"] = sdf_gen_margin
                        sdf_kwargs["scale"] = tuple(shape_scale)
                        sdf_kwargs["texture_format"] = sdf_tex_fmt
                        sdf_kwargs["paired_samples"] = sdf_texture_paired_samples
                        # Convex collision geometry is deduplicated before finalization,
                        # so build and cache its deferred SDF against that same topology.
                        sdf_source = generated_shape_sources[i] if shape_type == GeoType.CONVEX_MESH else shape_src
                        deferred_key = (
                            id(sdf_source),
                            tuple(shape_scale),
                            tuple(sdf_narrow_band_range),
                            sdf_target_voxel_size,
                            sdf_max_resolution,
                            sdf_tex_fmt,
                            sdf_gen_margin,
                        )
                        mesh_sdf = deferred_mesh_sdf_cache.get(deferred_key)
                        if mesh_sdf is None:
                            mesh_copy = sdf_source.copy()
                            mesh_copy.build_sdf(**sdf_kwargs)
                            mesh_sdf = mesh_copy.sdf
                            deferred_mesh_sdf_cache[deferred_key] = mesh_sdf
                            if getattr(mesh_copy, "_collision_edges", None) is not None:
                                deferred_collision_edges_cache[deferred_key] = mesh_copy._collision_edges
                        if deferred_key in deferred_collision_edges_cache:
                            deferred_collision_edges[i] = deferred_collision_edges_cache[deferred_key]
                    if mesh_sdf is not None:
                        coarse_texture = getattr(mesh_sdf, "_coarse_texture", None)
                        if coarse_texture is not None and (
                            (coarse_texture.num_channels == 2) != sdf_texture_paired_samples
                        ):
                            mode = "paired" if sdf_texture_paired_samples else "scalar"
                            raise ValueError(
                                f"ModelBuilder requires {mode} SDF textures, but shape {i} uses a prebuilt SDF "
                                "with a different layout. Rebuild it with mesh.build_sdf(paired_samples="
                                f"{sdf_texture_paired_samples})."
                            )
                        cache_key = ("mesh_sdf", id(mesh_sdf))
                elif has_shape_collision and (
                    is_hydroelastic
                    or (
                        shape_type == GeoType.BOX
                        and (sdf_max_resolution is not None or sdf_target_voxel_size is not None)
                    )
                ):
                    effective_max_resolution = sdf_max_resolution
                    if sdf_target_voxel_size is None and effective_max_resolution is None:
                        effective_max_resolution = 64
                    cache_key = (
                        "primitive_generated",
                        shape_type,
                        sdf_gen_margin,
                        tuple(sdf_narrow_band_range),
                        sdf_target_voxel_size,
                        effective_max_resolution,
                        tuple(shape_scale),
                        sdf_tex_fmt,
                    )

                if cache_key is not None:
                    if cache_key in sdf_cache:
                        shape_sdf_index[i] = sdf_cache[cache_key]
                    else:
                        sdf_idx = len(compact_texture_sdf_data)
                        sdf_cache[cache_key] = sdf_idx
                        shape_sdf_index[i] = sdf_idx

                        if mesh_sdf is not None:
                            tex_data = mesh_sdf.to_texture_kernel_data()
                            if tex_data is not None:
                                compact_texture_sdf_data.append(tex_data)
                                compact_texture_sdf_coarse_textures.append(mesh_sdf._coarse_texture)
                                compact_texture_sdf_subgrid_textures.append(mesh_sdf._subgrid_texture)
                                compact_texture_sdf_subgrid_start_slots.append(tex_data.subgrid_start_slots)
                            else:
                                compact_texture_sdf_data.append(create_empty_texture_sdf_data())
                                compact_texture_sdf_coarse_textures.append(None)
                                compact_texture_sdf_subgrid_textures.append(None)
                                compact_texture_sdf_subgrid_start_slots.append(None)
                        else:
                            try:
                                tex_data, c_tex, s_tex = create_texture_sdf_from_primitive(
                                    shape_type,
                                    shape_scale,
                                    margin=sdf_gen_margin,
                                    narrow_band_range=tuple(sdf_narrow_band_range),
                                    max_resolution=effective_max_resolution,
                                    target_voxel_size=sdf_target_voxel_size,
                                    quantization_mode=_tex_fmt_map[sdf_tex_fmt],
                                    scale_baked=True,
                                    paired_samples=sdf_texture_paired_samples,
                                    device=device,
                                )
                            except NotImplementedError:
                                compact_texture_sdf_data.append(create_empty_texture_sdf_data())
                                compact_texture_sdf_coarse_textures.append(None)
                                compact_texture_sdf_subgrid_textures.append(None)
                                compact_texture_sdf_subgrid_start_slots.append(None)
                                continue
                            except Exception as e:
                                warnings.warn(
                                    f"Texture SDF construction failed for shape {i} "
                                    f"(type={shape_type}): {e}. Falling back to BVH.",
                                    stacklevel=2,
                                )
                                tex_data = create_empty_texture_sdf_data()
                                c_tex = None
                                s_tex = None
                            compact_texture_sdf_data.append(tex_data)
                            compact_texture_sdf_coarse_textures.append(c_tex)
                            compact_texture_sdf_subgrid_textures.append(s_tex)
                            compact_texture_sdf_subgrid_start_slots.append(
                                tex_data.subgrid_start_slots if c_tex is not None else None
                            )

            # Build volume SDFs for participating MESH/CONVEX_MESH shapes that still lack one, when a
            # per-shape SDF is requested -- ShapeConfig.configure_sdf(force_sdf=True), or an sdf
            # resolution/voxel-size set on the shape. Built in unscaled mesh space (scale_baked=False)
            # and cached per source mesh; eval_shape_sdf applies the shape scale at query time. Texture
            # SDFs are CUDA-only, so on CPU (or on any build failure) the SDF is left unprovisioned; a
            # full-surface CollisionPipeline then raises for that shape rather than silently degrading.
            if any(
                self.shape_force_sdf[i]
                or self.shape_sdf_max_resolution[i] is not None
                or self.shape_sdf_target_voxel_size[i] is not None
                for i in range(len(self.shape_type))
            ):
                wt_sdf_cache = {}
                for i in range(len(self.shape_type)):
                    if (
                        shape_sdf_index[i] >= 0
                        or self.shape_type[i] not in (GeoType.MESH, GeoType.CONVEX_MESH)
                        or not (self.shape_flags[i] & ShapeFlags.COLLIDE_PARTICLES)
                        or self.shape_source[i] is None
                        or not (
                            self.shape_force_sdf[i]
                            or self.shape_sdf_max_resolution[i] is not None
                            or self.shape_sdf_target_voxel_size[i] is not None
                        )
                    ):
                        continue
                    src = self.shape_source[i]
                    sdf_padding_i = self.shape_sdf_padding[i]
                    wt_margin = sdf_padding_i if sdf_padding_i is not None else self.shape_gap[i]
                    # Mirror the rigid SDF cache key: shapes sharing one Mesh get distinct SDFs when any
                    # baked generation parameter differs (margin/narrow-band/resolution/voxel/format).
                    # scale stays out (scale_baked=False applies it at query time; the rigid path bakes it).
                    src_key = (
                        id(src),
                        wt_margin,
                        tuple(self.shape_sdf_narrow_band_range[i]),
                        self.shape_sdf_target_voxel_size[i],
                        self.shape_sdf_max_resolution[i],
                        self.shape_sdf_texture_format[i],
                    )
                    if src_key in wt_sdf_cache:
                        shape_sdf_index[i] = wt_sdf_cache[src_key]
                        continue
                    try:
                        wt_wp_mesh = wp.Mesh(
                            points=wp.array(
                                np.asarray(src.vertices, dtype=np.float32).reshape(-1, 3), dtype=wp.vec3, device=device
                            ),
                            indices=wp.array(
                                np.asarray(src.indices, dtype=np.int32).reshape(-1), dtype=wp.int32, device=device
                            ),
                            support_winding_number=True,
                        )
                        wt_tex_data, wt_c_tex, wt_s_tex = create_texture_sdf_from_mesh(
                            wt_wp_mesh,
                            margin=wt_margin,
                            narrow_band_range=tuple(self.shape_sdf_narrow_band_range[i]),
                            max_resolution=(self.shape_sdf_max_resolution[i] or 64),
                            target_voxel_size=self.shape_sdf_target_voxel_size[i],
                            quantization_mode=_tex_fmt_map[self.shape_sdf_texture_format[i]],
                            scale_baked=False,
                            device=device,
                            paired_samples=sdf_texture_paired_samples,
                        )
                    except Exception as e:
                        warnings.warn(
                            f"Full-surface SDF construction failed for mesh shape {i} ({e}); it falls "
                            "back to the legacy per-particle soft-contact path.",
                            stacklevel=2,
                        )
                        continue
                    wt_idx = len(compact_texture_sdf_data)
                    wt_sdf_cache[src_key] = wt_idx
                    shape_sdf_index[i] = wt_idx
                    compact_texture_sdf_data.append(wt_tex_data)
                    compact_texture_sdf_coarse_textures.append(wt_c_tex)
                    compact_texture_sdf_subgrid_textures.append(wt_s_tex)
                    compact_texture_sdf_subgrid_start_slots.append(
                        wt_tex_data.subgrid_start_slots if wt_c_tex is not None else None
                    )

            m._shape_sdf_index = wp.array(shape_sdf_index, dtype=wp.int32, device=device)
            m._texture_sdf_data = (
                wp.array(compact_texture_sdf_data, dtype=TextureSDFData, device=device)
                if compact_texture_sdf_data
                else wp.array([], dtype=TextureSDFData, device=device)
            )
            m._texture_sdf_coarse_textures = compact_texture_sdf_coarse_textures
            m._texture_sdf_subgrid_textures = compact_texture_sdf_subgrid_textures
            m._texture_sdf_subgrid_start_slots = compact_texture_sdf_subgrid_start_slots

            # ---------------------
            # heightfield collision data
            hfield_count = sum(1 for t in self.shape_type if t == GeoType.HFIELD)
            m.heightfield_count = hfield_count
            if hfield_count > 1:
                warnings.warn(
                    "Heightfield-vs-heightfield collision is not supported; "
                    "contacts between heightfield pairs will be skipped.",
                    stacklevel=2,
                )
            from ..utils.heightfield import HeightfieldData, create_empty_heightfield_data  # noqa: PLC0415

            compact_heightfield_data = []
            elevation_chunks = []
            shape_heightfield_index = [-1] * len(self.shape_type)
            offset = 0
            if hfield_count > 0:
                for i in range(len(self.shape_type)):
                    if self.shape_type[i] == GeoType.HFIELD and self.shape_source[i] is not None:
                        hf = self.shape_source[i]
                        hd = HeightfieldData()
                        hd.data_offset = offset
                        hd.nrow = hf.nrow
                        hd.ncol = hf.ncol
                        # Bake the per-instance scale into the extents so narrow-phase
                        # collision (which reads from HeightfieldData) apply
                        # scale consistently. ``abs`` on hx/hy because the
                        # parallel-slab checks assume non-negative planar extents;
                        # z uses raw multiplication so ``sz < 0`` inverts the surface
                        # (``min_z > max_z`` already encodes an inverted heightfield).
                        sx, sy, sz = self.shape_scale[i]
                        hd.hx = abs(hf.hx * sx)
                        hd.hy = abs(hf.hy * sy)
                        hd.min_z = hf.min_z * sz
                        hd.max_z = hf.max_z * sz
                        shape_heightfield_index[i] = len(compact_heightfield_data)
                        compact_heightfield_data.append(hd)
                        elevation_chunks.append(hf.data.flatten())
                        offset += hf.nrow * hf.ncol

            m.shape_heightfield_index = wp.array(
                shape_heightfield_index if shape_heightfield_index else [-1],
                dtype=wp.int32,
                device=device,
            )
            m.heightfield_data = (
                wp.array(compact_heightfield_data, dtype=HeightfieldData, device=device)
                if compact_heightfield_data
                else wp.array([create_empty_heightfield_data()], dtype=HeightfieldData, device=device)
            )
            m.heightfield_elevations = (
                wp.array(np.concatenate(elevation_chunks), dtype=wp.float32, device=device)
                if elevation_chunks
                else wp.zeros(1, dtype=wp.float32, device=device)
            )

            # ---------------------
            # mesh edges (packed array + per-shape slice)

            shape_edge_ranges = []
            edge_chunks = []
            edge_center_chunks = []
            edge_half_chunks = []
            edge_offset = 0
            edge_cache = {}  # mesh python id → (start, count)

            for i in range(len(self.shape_type)):
                if (
                    self.shape_type[i] in (GeoType.MESH, GeoType.CONVEX_MESH, GeoType.BOX)
                    and generated_shape_sources[i] is not None
                    and (self.shape_flags[i] & ShapeFlags.COLLIDE_SHAPES)
                ):
                    mesh = generated_shape_sources[i]
                    shape_scale = np.asarray(self.shape_scale[i], dtype=np.float32)
                    scale_key = tuple(float(value) for value in shape_scale)
                    deferred_edges = deferred_collision_edges.get(i)
                    if deferred_edges is not None:
                        mesh_key = ("deferred", id(deferred_edges), scale_key)
                    else:
                        mesh_key = (id(mesh), scale_key)
                    if mesh_key in edge_cache:
                        shape_edge_ranges.append(edge_cache[mesh_key])
                    else:
                        # ``Mesh.build_sdf()`` caches a simplified edge set on
                        # the mesh for SDF-mesh contact generation; fall back
                        # to the full edge list otherwise.
                        if deferred_edges is not None:
                            edges = deferred_edges
                        elif mesh._collision_edges is not None:
                            edges = mesh._collision_edges
                        else:
                            edges = mesh.edges  # lazily computed and cached on the Mesh
                        start = edge_offset
                        count = len(edges)
                        edge_chunks.append(edges)
                        if count > 0:
                            vertices = np.asarray(mesh.vertices, dtype=np.float32) * shape_scale
                            edge_v0 = vertices[edges[:, 0]]
                            edge_v1 = vertices[edges[:, 1]]
                            edge_halves = np.ascontiguousarray((edge_v1 - edge_v0) * 0.5, dtype=np.float32)
                            edge_centers = np.ascontiguousarray((edge_v0 + edge_v1) * 0.5, dtype=np.float32)
                            edge_radii = np.linalg.norm(edge_halves, axis=1, keepdims=True)
                            canonical_edges = mesh._canonical_vertex_ids()[edges].reshape(-1)
                            endpoint_indices = np.arange(2 * count, dtype=np.int64)
                            first_endpoint = np.full(int(canonical_edges.max()) + 1, 2 * count, dtype=np.int64)
                            np.minimum.at(first_endpoint, canonical_edges, endpoint_indices)
                            owns_endpoint = (first_endpoint[canonical_edges] == endpoint_indices).reshape(-1, 2)
                            # Zero remains the legacy "both endpoints owned" encoding.
                            corner_ownership = (
                                4.0 + owns_endpoint[:, 0].astype(np.float32) + 2.0 * owns_endpoint[:, 1]
                            ).reshape(-1, 1)
                            edge_center_chunks.append(
                                np.ascontiguousarray(
                                    np.concatenate((edge_centers, edge_radii), axis=1), dtype=np.float32
                                )
                            )
                            edge_half_chunks.append(
                                np.ascontiguousarray(np.concatenate((edge_halves, corner_ownership), axis=1))
                            )
                        edge_offset += count
                        entry = (start, count)
                        edge_cache[mesh_key] = entry
                        shape_edge_ranges.append(entry)
                else:
                    shape_edge_ranges.append((-1, 0))

            m.shape_edge_range = wp.array(
                shape_edge_ranges if shape_edge_ranges else [(-1, 0)],
                dtype=wp.vec2i,
                device=device,
            )
            m.mesh_edge_indices = (
                wp.array(np.concatenate(edge_chunks), dtype=wp.vec2i, device=device)
                if edge_offset > 0
                else wp.zeros(1, dtype=wp.vec2i, device=device)
            )
            m.mesh_edge_centers = (
                wp.array(np.concatenate(edge_center_chunks), dtype=wp.vec4, device=device)
                if edge_offset > 0
                else wp.zeros(1, dtype=wp.vec4, device=device)
            )
            m.mesh_edge_halves = (
                wp.array(np.concatenate(edge_half_chunks), dtype=wp.vec4, device=device)
                if edge_offset > 0
                else wp.zeros(1, dtype=wp.vec4, device=device)
            )

            # ---------------------
            # springs

            def _to_wp_array(data, dtype, requires_grad):
                if len(data) == 0:
                    return None
                return wp.array(data, dtype=dtype, requires_grad=requires_grad)

            m.spring_indices = _to_wp_array(self.spring_indices, wp.int32, requires_grad=False)
            m.spring_rest_length = _to_wp_array(self.spring_rest_length, wp.float32, requires_grad=requires_grad)
            m.spring_stiffness = _to_wp_array(self.spring_stiffness, wp.float32, requires_grad=requires_grad)
            m.spring_damping = _to_wp_array(self.spring_damping, wp.float32, requires_grad=requires_grad)
            m.spring_control = _to_wp_array(self.spring_control, wp.float32, requires_grad=requires_grad)

            # ---------------------
            # triangles

            m.tri_indices = _to_wp_array(self.tri_indices, wp.int32, requires_grad=False)
            m.tri_poses = _to_wp_array(self.tri_poses, wp.mat22, requires_grad=requires_grad)
            m.tri_activations = _to_wp_array(self.tri_activations, wp.float32, requires_grad=requires_grad)
            m.tri_materials = _to_wp_array(self.tri_materials, wp.float32, requires_grad=requires_grad)
            m.tri_areas = _to_wp_array(self.tri_areas, wp.float32, requires_grad=requires_grad)
            m.tri_color = _to_wp_array(self.tri_color, wp.vec3, requires_grad=False)
            m.tri_opacity = _to_wp_array(self.tri_opacity, wp.float32, requires_grad=False)

            # ---------------------
            # edges

            m.edge_indices = _to_wp_array(self.edge_indices, wp.int32, requires_grad=False)
            m.edge_rest_angle = _to_wp_array(self.edge_rest_angle, wp.float32, requires_grad=requires_grad)
            m.edge_rest_length = _to_wp_array(self.edge_rest_length, wp.float32, requires_grad=requires_grad)
            m.edge_bending_properties = _to_wp_array(
                self.edge_bending_properties, wp.float32, requires_grad=requires_grad
            )
            # Build the soft-mesh adjacency from the accumulated bending edges and triangles:
            # keep the builder's edge numbering (it stays aligned with the bending materials) and
            # derive the edge/triangle maps against the final triangles.
            edge_indices = (
                np.array(self.edge_indices, dtype=np.int32).reshape(-1, 4)
                if self.edge_indices
                else np.empty((0, 4), dtype=np.int32)
            )
            m.soft_mesh_adjacency = MeshAdjacency(
                tri_indices=self.tri_indices,
                edge_indices=edge_indices,
                spring_indices=self.spring_indices,
                tet_indices=self.tet_indices,
            )
            # Build the vertex adjacency (cheap) and upload one device copy here, so every consumer
            # (VBD solver, collision pipeline) shares a single MeshAdjacencyData rather than each
            # running init_vertex_adjacency + .to() itself.
            m.soft_mesh_adjacency.init_vertex_adjacency(self.particle_count)
            m.soft_mesh_adjacency_device = m.soft_mesh_adjacency.to(device)

            # ---------------------
            # tetrahedra

            m.tet_indices = _to_wp_array(self.tet_indices, wp.int32, requires_grad=False)
            m.tet_poses = _to_wp_array(self.tet_poses, wp.mat33, requires_grad=requires_grad)
            m.tet_activations = _to_wp_array(self.tet_activations, wp.float32, requires_grad=requires_grad)
            m.tet_materials = _to_wp_array(self.tet_materials, wp.float32, requires_grad=requires_grad)

            # -----------------------
            # muscles

            # close the muscle waypoint indices
            muscle_start = copy.copy(self.muscle_start)
            muscle_start.append(len(self.muscle_bodies))

            m.muscle_start = wp.array(muscle_start, dtype=wp.int32)
            m.muscle_params = wp.array(self.muscle_params, dtype=wp.float32, requires_grad=requires_grad)
            m.muscle_bodies = wp.array(self.muscle_bodies, dtype=wp.int32)
            m.muscle_points = wp.array(self.muscle_points, dtype=wp.vec3, requires_grad=requires_grad)
            m.muscle_activations = wp.array(self.muscle_activations, dtype=wp.float32, requires_grad=requires_grad)

            # --------------------------------------
            # rigid bodies

            # Apply inertia verification and correction
            # This catches negative masses/inertias and other critical issues.
            # Neither path mutates the builder — corrected values only appear
            # on the returned Model so that finalize() is side-effect-free.
            if len(self.body_mass) > 0:
                if self.validate_inertia_detailed:
                    # Use detailed Python validation with per-body warnings.
                    # Build corrected copies without modifying builder lists.
                    corrected_mass = list(self.body_mass)
                    corrected_inertia = list(self.body_inertia)
                    corrected_inv_mass = list(self.body_inv_mass)
                    corrected_inv_inertia = list(self.body_inv_inertia)

                    for i in range(len(self.body_mass)):
                        mass = self.body_mass[i]
                        inertia = self.body_inertia[i]
                        body_label = self.body_label[i] if i < len(self.body_label) else f"body_{i}"

                        new_mass, new_inertia, was_corrected = verify_and_correct_inertia(
                            mass,
                            inertia,
                            self.balance_inertia,
                            self.bound_mass,
                            self.bound_inertia,
                            body_label,
                        )

                        if was_corrected:
                            corrected_mass[i] = new_mass
                            corrected_inertia[i] = new_inertia
                            if new_mass > 0.0:
                                corrected_inv_mass[i] = 1.0 / new_mass
                            else:
                                corrected_inv_mass[i] = 0.0

                            if any(x for x in new_inertia):
                                corrected_inv_inertia[i] = wp.inverse(new_inertia)
                            else:
                                corrected_inv_inertia[i] = new_inertia

                    # Create arrays from corrected copies
                    m.body_mass = wp.array(corrected_mass, dtype=wp.float32, requires_grad=requires_grad)
                    m.body_inv_mass = wp.array(corrected_inv_mass, dtype=wp.float32, requires_grad=requires_grad)
                    m.body_inertia = wp.array(corrected_inertia, dtype=wp.mat33, requires_grad=requires_grad)
                    m.body_inv_inertia = wp.array(corrected_inv_inertia, dtype=wp.mat33, requires_grad=requires_grad)
                else:
                    # Use fast Warp kernel validation
                    body_mass_array = wp.array(self.body_mass, dtype=wp.float32, requires_grad=requires_grad)
                    body_inertia_array = wp.array(self.body_inertia, dtype=wp.mat33, requires_grad=requires_grad)
                    body_inv_mass_array = wp.array(self.body_inv_mass, dtype=wp.float32, requires_grad=requires_grad)
                    body_inv_inertia_array = wp.array(
                        self.body_inv_inertia, dtype=wp.mat33, requires_grad=requires_grad
                    )
                    correction_count = wp.zeros(1, dtype=wp.int32)

                    # Launch validation kernel (corrects arrays in-place on device)
                    wp.launch(
                        kernel=validate_and_correct_inertia_kernel,
                        dim=len(self.body_mass),
                        inputs=[
                            body_mass_array,
                            body_inertia_array,
                            body_inv_mass_array,
                            body_inv_inertia_array,
                            self.balance_inertia,
                            self.bound_mass if self.bound_mass is not None else 0.0,
                            self.bound_inertia if self.bound_inertia is not None else 0.0,
                            correction_count,
                        ],
                    )

                    # Check if any corrections were made (single int transfer)
                    num_corrections = int(correction_count.numpy()[0])
                    if num_corrections > 0:
                        warnings.warn(
                            f"Inertia validation corrected {num_corrections} bodies. "
                            f"Set validate_inertia_detailed=True for detailed per-body warnings.",
                            stacklevel=2,
                        )

                    # Use the corrected arrays directly on the Model.
                    # Builder state is intentionally left unchanged — corrected
                    # values live only on the returned Model.
                    m.body_mass = body_mass_array
                    m.body_inv_mass = body_inv_mass_array
                    m.body_inertia = body_inertia_array
                    m.body_inv_inertia = body_inv_inertia_array
            else:
                # No bodies, create empty arrays
                m.body_mass = wp.array(self.body_mass, dtype=wp.float32, requires_grad=requires_grad)
                m.body_inv_mass = wp.array(self.body_inv_mass, dtype=wp.float32, requires_grad=requires_grad)
                m.body_inertia = wp.array(self.body_inertia, dtype=wp.mat33, requires_grad=requires_grad)
                m.body_inv_inertia = wp.array(self.body_inv_inertia, dtype=wp.mat33, requires_grad=requires_grad)

            m.body_q = wp.array(self.body_q, dtype=wp.transform, requires_grad=requires_grad)
            m.body_qd = wp.array(self.body_qd, dtype=wp.spatial_vector, requires_grad=requires_grad)
            m.body_com = wp.array(self.body_com, dtype=wp.vec3, requires_grad=requires_grad)
            m.body_label = self.body_label
            m.body_flags = wp.array(self.body_flags, dtype=wp.int32)
            m.body_world = wp.array(self.body_world, dtype=wp.int32)

            # body colors
            if self.body_color_groups:
                body_colors = np.empty(self.body_count, dtype=int)
                for color in range(len(self.body_color_groups)):
                    body_colors[self.body_color_groups[color]] = color
                m.body_colors = wp.array(body_colors, dtype=int)
                m.body_color_groups = [wp.array(group, dtype=int) for group in self.body_color_groups]

            # joints
            m._has_rod_joints = JointType.ROD in self.joint_type  # pyright: ignore[reportPrivateUsage]
            joint_parent_np = np.asarray(self.joint_parent, dtype=np.int32)
            joint_child_np = np.asarray(self.joint_child, dtype=np.int32)
            joint_articulation_np = np.asarray(self.joint_articulation, dtype=np.int32)

            m.joint_type = wp.array(self.joint_type, dtype=wp.int32)
            m.joint_parent = wp.array(joint_parent_np, dtype=wp.int32)
            m.joint_child = wp.array(joint_child_np, dtype=wp.int32)
            m.joint_X_p = wp.array(self.joint_X_p, dtype=wp.transform, requires_grad=requires_grad)
            m.joint_X_c = wp.array(self.joint_X_c, dtype=wp.transform, requires_grad=requires_grad)
            m.joint_dof_dim = wp.array(np.array(self.joint_dof_dim), dtype=wp.int32, ndim=2)
            m.joint_axis = wp.array(self.joint_axis, dtype=wp.vec3, requires_grad=requires_grad)
            m.joint_q = wp.array(self.joint_q, dtype=wp.float32, requires_grad=requires_grad)
            m.joint_qd = wp.array(self.joint_qd, dtype=wp.float32, requires_grad=requires_grad)
            m.joint_label = self.joint_label
            m.joint_world = wp.array(self.joint_world, dtype=wp.int32)
            # compute joint ancestors
            parent_joint = _build_joint_ancestor(joint_parent_np, joint_child_np)
            m.joint_ancestor = wp.array(parent_joint, dtype=wp.int32)
            m.joint_articulation = wp.array(joint_articulation_np, dtype=wp.int32)

            # dynamics properties
            m.joint_armature = wp.array(self.joint_armature, dtype=wp.float32, requires_grad=requires_grad)
            m.joint_target_mode = wp.array(self.joint_target_mode, dtype=wp.int32)
            m.joint_target_ke = wp.array(self.joint_target_ke, dtype=wp.float32, requires_grad=requires_grad)
            m.joint_target_kd = wp.array(self.joint_target_kd, dtype=wp.float32, requires_grad=requires_grad)
            m.joint_damping = wp.array(self.joint_damping, dtype=wp.float32, requires_grad=requires_grad)
            import newton  # noqa: PLC0415

            if newton.use_coord_layout_targets:
                target_q_values = self.joint_target_q
            else:
                if self.joint_coord_count != self.joint_dof_count:
                    warnings.warn(
                        "The legacy DOF-shaped joint_target_q layout is deprecated for models "
                        "whose joint coordinate and DOF counts differ (free/ball/distance "
                        "joints). In a future release joint_target_q will always use the "
                        "coordinate layout (matching joint_q) and newton.use_coord_layout_targets "
                        "will be removed. Set newton.use_coord_layout_targets = True before "
                        "building models and index targets via Model.joint_target_q_start.",
                        DeprecationWarning,
                        stacklevel=2,
                    )
                target_q_values = self._project_target_q_to_dof()
            m.joint_target_q = wp.array(target_q_values, dtype=wp.float32, requires_grad=requires_grad)
            m.joint_target_qd = wp.array(self.joint_target_qd, dtype=wp.float32, requires_grad=requires_grad)
            m.joint_f = wp.array(self.joint_f, dtype=wp.float32, requires_grad=requires_grad)
            m.joint_act = wp.array(self.joint_act, dtype=wp.float32, requires_grad=requires_grad)
            m.joint_effort_limit = wp.array(self.joint_effort_limit, dtype=wp.float32, requires_grad=requires_grad)
            m.joint_velocity_limit = wp.array(self.joint_velocity_limit, dtype=wp.float32, requires_grad=requires_grad)
            m.joint_friction = wp.array(self.joint_friction, dtype=wp.float32, requires_grad=requires_grad)

            m.joint_limit_lower = wp.array(self.joint_limit_lower, dtype=wp.float32, requires_grad=requires_grad)
            m.joint_limit_upper = wp.array(self.joint_limit_upper, dtype=wp.float32, requires_grad=requires_grad)
            m.joint_limit_ke = wp.array(self.joint_limit_ke, dtype=wp.float32, requires_grad=requires_grad)
            m.joint_limit_kd = wp.array(self.joint_limit_kd, dtype=wp.float32, requires_grad=requires_grad)
            m.joint_enabled = wp.array(self.joint_enabled, dtype=wp.bool)

            # 'close' the start index arrays with a sentinel value
            joint_q_start = copy.copy(self.joint_q_start)
            joint_q_start.append(self.joint_coord_count)
            joint_qd_start = copy.copy(self.joint_qd_start)
            joint_qd_start.append(self.joint_dof_count)
            articulation_start = copy.copy(self.articulation_start)
            articulation_start.append(self.joint_count)
            articulation_end = copy.copy(self.articulation_end)

            # Compute max joints and dofs per articulation for IK/Jacobian kernel launches
            max_joints_per_articulation = 0
            max_dofs_per_articulation = 0
            for art_idx in range(len(self.articulation_start)):
                joint_start = articulation_start[art_idx]
                joint_end = articulation_end[art_idx]
                num_joints = joint_end - joint_start
                max_joints_per_articulation = max(max_joints_per_articulation, num_joints)
                # Compute dofs for this articulation
                dof_start = joint_qd_start[joint_start]
                dof_end = joint_qd_start[joint_end]
                num_dofs = dof_end - dof_start
                max_dofs_per_articulation = max(max_dofs_per_articulation, num_dofs)

            m.joint_q_start = wp.array(joint_q_start, dtype=wp.int32)
            m.joint_qd_start = wp.array(joint_qd_start, dtype=wp.int32)
            m.articulation_start = wp.array(articulation_start, dtype=wp.int32)
            m.articulation_end = wp.array(articulation_end, dtype=wp.int32)
            from .articulation_cuda import FK_TILE_MAX_LEVEL_WIDTH  # noqa: PLC0415

            fk_topology = _build_fk_level_topology(
                self.articulation_count,
                joint_articulation_np,
                joint_parent_np,
                joint_child_np,
            )
            # Non-tree articulations and levels beyond the tile kernel's
            # shared-memory staging capacity retain the serial FK path.
            if fk_topology is not None:
                (
                    fk_articulation_level_start,
                    fk_level_joint_start,
                    fk_level_joints,
                    fk_level_parent_pos,
                ) = fk_topology
                fk_level_capacity = int(np.max(np.diff(fk_level_joint_start), initial=1))
                if fk_level_capacity <= FK_TILE_MAX_LEVEL_WIDTH:
                    m._fk_articulation_level_start = wp.array(fk_articulation_level_start, dtype=wp.int32)
                    m._fk_level_joint_start = wp.array(fk_level_joint_start, dtype=wp.int32)
                    m._fk_level_joints = wp.array(fk_level_joints, dtype=wp.int32)
                    m._fk_level_parent_pos = wp.array(fk_level_parent_pos, dtype=wp.int32)
                    m._fk_level_capacity = fk_level_capacity
            m.articulation_label = self.articulation_label
            m.articulation_world = wp.array(self.articulation_world, dtype=wp.int32)
            m.max_joints_per_articulation = max_joints_per_articulation
            m.max_dofs_per_articulation = max_dofs_per_articulation

            # ---------------------
            # Ensure the ``mujoco`` namespace exists so the equality-constraint count (set below)
            # can live on it. The per-row ``equality_constraint_*`` arrays are materialized by the
            # standard custom-attribute pipeline below, which is exempted from the zero-count skip
            # for this frequency so the arrays stay shape-stable (empty) even with no constraints.
            if not hasattr(m, "mujoco"):
                m.mujoco = Model.AttributeNamespace("mujoco")

            # mimic constraints
            m.constraint_mimic_joint0 = wp.array(self.constraint_mimic_joint0, dtype=wp.int32)
            m.constraint_mimic_joint1 = wp.array(self.constraint_mimic_joint1, dtype=wp.int32)
            m.constraint_mimic_coef0 = wp.array(self.constraint_mimic_coef0, dtype=wp.float32)
            m.constraint_mimic_coef1 = wp.array(self.constraint_mimic_coef1, dtype=wp.float32)
            m.constraint_mimic_enabled = wp.array(self.constraint_mimic_enabled, dtype=wp.bool)
            m.constraint_mimic_label = self.constraint_mimic_label
            m.constraint_mimic_world = wp.array(self.constraint_mimic_world, dtype=wp.int32)

            # ---------------------
            # per-world start indices
            m.particle_world_start = wp.array(self.particle_world_start, dtype=wp.int32)
            m.body_world_start = wp.array(self.body_world_start, dtype=wp.int32)
            m.shape_world_start = wp.array(self.shape_world_start, dtype=wp.int32)
            m.joint_world_start = wp.array(self.joint_world_start, dtype=wp.int32)
            m.articulation_world_start = wp.array(self.articulation_world_start, dtype=wp.int32)
            m.joint_dof_world_start = wp.array(self.joint_dof_world_start, dtype=wp.int32)
            m.joint_coord_world_start = wp.array(self.joint_coord_world_start, dtype=wp.int32)
            m.joint_constraint_world_start = wp.array(self.joint_constraint_world_start, dtype=wp.int32)

            # ---------------------
            # counts
            m.joint_count = self.joint_count
            m.joint_dof_count = self.joint_dof_count
            m.joint_coord_count = self.joint_coord_count
            m.joint_constraint_count = self.joint_constraint_count
            m.particle_count = len(self.particle_q)
            m.body_count = self.body_count
            m.shape_count = len(self.shape_type)
            m.tri_count = len(self.tri_poses)
            m.tet_count = len(self.tet_poses)
            m.edge_count = len(self.edge_rest_angle)
            m.spring_count = len(self.spring_rest_length)
            m.muscle_count = len(self.muscle_start)
            m.articulation_count = len(self.articulation_start)
            m.mujoco.equality_constraint_count = self._equality_constraint_count
            m.mujoco.equality_constraint_world_start = wp.array(self._equality_constraint_world_start, dtype=wp.int32)
            m.constraint_mimic_count = len(self.constraint_mimic_joint0)

            # The packed array was just installed on the model, so builder and
            # model filters are known to match without rebuilding it.
            self._find_shape_contact_pairs(m, allow_filter_blocks=True)

            # enable ground plane
            m.up_axis = self.up_axis

            # Explicit local worlds need a trailing global entry. Implicit
            # single-world models retain their legacy shared gravity entry.
            global_gravity = self._gravity_as_vector()
            if self.world_gravity:
                gravity_vecs = [*self.world_gravity, global_gravity]
            else:
                gravity_vecs = [global_gravity for _ in range(self.world_count)]
            m.gravity = wp.array(
                gravity_vecs,
                dtype=wp.vec3,
                device=device,
                requires_grad=requires_grad,
            )

            # Create actuators from accumulated entries
            from ..actuators.actuator import Actuator  # noqa: PLC0415
            from ..actuators.delay import Delay  # noqa: PLC0415

            m.actuators = []
            for entry in self.actuator_entries.values():
                indices = self._build_index_array(entry.indices, device)

                pos_indices_arg = None
                if entry.pos_indices != entry.indices:
                    pos_indices_arg = self._build_index_array(entry.pos_indices, device)

                # Build drive from stacked per-DOF arrays + shared kwargs
                drive_arrays = self._stack_args_to_arrays(entry.drive_args, device=device, requires_grad=requires_grad)
                drive = entry.drive_class(**drive_arrays, **entry.drive_shared_kwargs)

                delay_obj = None
                if entry.delay_args:
                    delay_arrays = self._stack_args_to_arrays(entry.delay_args, device=device, default_dtype=wp.int32)
                    max_delay = max(d["delay_steps"] for d in entry.delay_args)
                    delay_obj = Delay(**delay_arrays, max_delay=max_delay)

                # Build clamping objects from per-DOF arrays + shared kwargs
                clamping_objs = []
                for i, (comp_class, shared_kw) in enumerate(
                    zip(entry.clamping_classes, entry.clamping_shared_kwargs, strict=True)
                ):
                    comp_args_per_actuator = [per_act[i] for per_act in entry.clamping_args]
                    comp_arrays = self._stack_args_to_arrays(
                        comp_args_per_actuator, device=device, requires_grad=requires_grad
                    )
                    clamping_objs.append(comp_class(**comp_arrays, **shared_kw))

                target_pos_indices_arg = (
                    pos_indices_arg if (pos_indices_arg is not None and m.use_coord_layout_targets) else indices
                )
                actuator = Actuator(
                    indices=indices,
                    drive=drive,
                    delay=delay_obj,
                    clamping=clamping_objs if clamping_objs else None,
                    pos_indices=pos_indices_arg,
                    target_pos_indices=target_pos_indices_arg,
                    requires_grad=requires_grad,
                )

                m.actuators.append(actuator)

            # Add custom attributes onto the model (with lazy evaluation)
            self._resolve_custom_frequency_articulation_owners()

            # Early return if no custom attributes exist to avoid overhead
            if not self.custom_attributes:
                m.custom_frequency_counts = dict(self._custom_frequency_counts)
                self._finalize_custom_frequency_metadata(m, device)
                m.bvh_build_shapes(
                    m,
                    bvh_constructor=self.default_bvh_cfg.shape_constructor,
                    shape_flags=self.default_bvh_cfg.shape_flags,
                )
                m.bvh_build_particles(m)
                return m

            # Resolve authoritative counts for custom frequencies
            # Use incremental _custom_frequency_counts as primary source, with safety fallback
            custom_frequency_counts: dict[str, int] = dict(self._custom_frequency_counts)
            frequency_max_lens: dict[str, int] = {}  # Track max len(values) per frequency as fallback

            # First pass: collect max len(values) per frequency as fallback
            for _full_key, custom_attr in self.custom_attributes.items():
                freq_key = custom_attr.frequency
                if isinstance(freq_key, str):
                    attr_len = len(custom_attr.values) if custom_attr.values else 0
                    frequency_max_lens[freq_key] = max(frequency_max_lens.get(freq_key, 0), attr_len)

            # Determine authoritative counts: prefer _custom_frequency_counts, fallback to max lens
            for freq_key, max_len in frequency_max_lens.items():
                if freq_key not in custom_frequency_counts:
                    # Safety fallback: use max observed length
                    custom_frequency_counts[freq_key] = max_len

            # Only MODEL attributes are checked here; non-MODEL ones are filled at runtime via
            # _add_custom_attributes. An empty values list opts into defaults and stays silent;
            # partial population (some values, but fewer than the frequency expects) usually
            # signals a missed row, so it warns.
            for full_key, custom_attr in self.custom_attributes.items():
                freq_key = custom_attr.frequency
                if isinstance(freq_key, str) and custom_attr.assignment == Model.AttributeAssignment.MODEL:
                    attr_count = len(custom_attr.values) if custom_attr.values else 0
                    expected_count = custom_frequency_counts[freq_key]
                    if 0 < attr_count < expected_count:
                        warnings.warn(
                            f"Custom attribute '{full_key}' has {attr_count} values but frequency '{freq_key}' "
                            f"expects {expected_count}. Missing values will be filled with defaults.",
                            UserWarning,
                            stacklevel=2,
                        )

            # Store custom frequency counts on the model for selection.py and other consumers
            m.custom_frequency_counts = custom_frequency_counts

            # Process custom attributes
            for _full_key, custom_attr in self.custom_attributes.items():
                custom_finalizer = self._custom_attribute_model_finalizers.get(_full_key)
                if custom_finalizer is not None:
                    custom_finalizer(self, m, custom_attr)
                    continue

                freq_key = custom_attr.frequency

                # determine count by frequency
                if isinstance(freq_key, str):
                    # Custom frequency: count determined by validated frequency count
                    count = custom_frequency_counts.get(freq_key, 0)
                elif freq_key == Model.AttributeFrequency.ONCE:
                    count = 1
                elif freq_key == Model.AttributeFrequency.BODY:
                    count = m.body_count
                elif freq_key == Model.AttributeFrequency.SHAPE:
                    count = m.shape_count
                elif freq_key == Model.AttributeFrequency.JOINT:
                    count = m.joint_count
                elif freq_key == Model.AttributeFrequency.JOINT_DOF:
                    count = m.joint_dof_count
                elif freq_key == Model.AttributeFrequency.JOINT_COORD:
                    count = m.joint_coord_count
                elif freq_key == Model.AttributeFrequency.JOINT_CONSTRAINT:
                    count = m.joint_constraint_count
                elif freq_key == Model.AttributeFrequency.ARTICULATION:
                    count = m.articulation_count
                elif freq_key == Model.AttributeFrequency.WORLD:
                    count = m.world_count
                elif freq_key == Model.AttributeFrequency.CONSTRAINT_MIMIC:
                    count = m.constraint_mimic_count
                elif freq_key == Model.AttributeFrequency.PARTICLE:
                    count = m.particle_count
                elif freq_key == Model.AttributeFrequency.EDGE:
                    count = m.edge_count
                elif freq_key == Model.AttributeFrequency.TRIANGLE:
                    count = m.tri_count
                elif freq_key == Model.AttributeFrequency.TETRAHEDRON:
                    count = m.tet_count
                elif freq_key == Model.AttributeFrequency.SPRING:
                    count = m.spring_count
                else:
                    continue

                # Keep canonical MuJoCo equality attributes shape-stable at zero rows. This lets
                # callers consume ``model.mujoco.equality_constraint_*`` without branching on
                # whether the model contains any equality constraints.
                if count == 0 and freq_key != "mujoco:equality_constraint":
                    continue

                result = custom_attr.build_array(count, device=device, requires_grad=requires_grad)
                m.add_attribute(
                    custom_attr.name,
                    result,
                    freq_key,
                    custom_attr.assignment,
                    custom_attr.namespace,
                    custom_attr.references,
                )

            self._finalize_custom_frequency_metadata(m, device)

            m.bvh_build_shapes(
                m,
                bvh_constructor=self.default_bvh_cfg.shape_constructor,
                shape_flags=self.default_bvh_cfg.shape_flags,
            )
            m.bvh_build_particles(m)
            return m

    def _test_group_pair(self, group_a: int, group_b: int) -> bool:
        """Test if two collision groups should interact.

        This matches the exact logic from broad_phase_common.test_group_pair kernel function.

        Args:
            group_a: First collision group ID
            group_b: Second collision group ID

        Returns:
            Whether the groups should collide.
        """
        if group_a == 0 or group_b == 0:
            return False
        if group_a > 0:
            return group_a == group_b or group_b < 0
        if group_a < 0:
            return group_a != group_b
        return False

    def _test_world_and_group_pair(
        self, world_a: int, world_b: int, collision_group_a: int, collision_group_b: int
    ) -> bool:
        """Test if two entities should collide based on world indices and collision groups.

        This matches the exact logic from broad_phase_common.test_world_and_group_pair kernel function.

        Args:
            world_a: World index of first entity
            world_b: World index of second entity
            collision_group_a: Collision group of first entity
            collision_group_b: Collision group of second entity

        Returns:
            Whether the entities should collide.
        """
        # Check world indices first
        if world_a != -1 and world_b != -1 and world_a != world_b:
            return False

        # If same world or at least one is global (-1), check collision groups
        return self._test_group_pair(collision_group_a, collision_group_b)

    def _iter_validated_shape_collision_filter_pairs(self, pairs):
        shape_count = len(self.shape_type)
        for shape_a, shape_b in pairs:
            if shape_a < 0 or shape_a >= shape_count or shape_b < 0 or shape_b >= shape_count:
                raise ValueError(
                    f"shape_collision_filter_pairs contains invalid pair ({shape_a}, {shape_b}); "
                    f"shape indices must be in [0, {shape_count})."
                )
            yield (shape_a, shape_b) if shape_a <= shape_b else (shape_b, shape_a)

    def _build_shape_collision_filter_packed(self) -> np.ndarray:
        """Build the canonical filter store handed to :class:`Model`.

        Returns:
            Sorted unique packed pair codes ``(shape_a << 32) | shape_b`` with
            ``shape_a <= shape_b``, shape [pair_count].
        """
        filter_pairs = self._shape_collision_filter_pairs
        chunks: list[np.ndarray] = []
        if isinstance(filter_pairs, _BuilderShapeCollisionFilterPairs):
            explicit_pairs = tuple(self._iter_validated_shape_collision_filter_pairs(filter_pairs.explicit_pairs))
            if explicit_pairs:
                chunks.append(np.asarray(explicit_pairs, dtype=np.int64).reshape((-1, 2)))
            blocks = filter_pairs.blocks
            self._validate_compact_shape_collision_filter_blocks(blocks)
            # Replicated blocks share one local-pair template; replay each
            # group of blocks as a single broadcast offset add.
            starts_by_template: dict[int, tuple[np.ndarray, list[int]]] = {}
            for block in blocks:
                entry = starts_by_template.get(id(block.local_pairs))
                if entry is None:
                    template = np.asarray(block.local_pairs, dtype=np.int64).reshape((-1, 2))
                    starts_by_template[id(block.local_pairs)] = (template, [block.shape_start])
                else:
                    entry[1].append(block.shape_start)
            for template, starts in starts_by_template.values():
                offsets = np.asarray(starts, dtype=np.int64)
                chunks.append((template[None, :, :] + offsets[:, None, None]).reshape((-1, 2)))
        else:
            pairs = tuple(self._iter_validated_shape_collision_filter_pairs(filter_pairs))
            if pairs:
                chunks.append(np.asarray(pairs, dtype=np.int64).reshape((-1, 2)))
        if not chunks:
            return np.empty(0, dtype=np.int64)
        all_pairs = np.concatenate(chunks, axis=0)
        codes = _pack_shape_pair_codes(all_pairs[:, 0], all_pairs[:, 1])
        # Sort + mask instead of np.unique: NumPy's hash-based unique for 1-D
        # integers degrades badly on packed pair codes, and searchsorted needs
        # the sorted order anyway.
        codes.sort()
        if codes.shape[0] > 1:
            codes = codes[np.concatenate(([True], codes[1:] != codes[:-1]))]
        return codes

    def _validate_compact_shape_collision_filter_blocks(self, compact_filter_blocks) -> None:
        shape_count = len(self.shape_type)
        validated_templates = set()
        for block in compact_filter_blocks:
            if block.shape_start < 0 or block.shape_count < 0 or block.shape_start + block.shape_count > shape_count:
                raise ValueError(
                    "shape_collision_filter_pairs contains an invalid compact block "
                    f"starting at {block.shape_start} with {block.shape_count} shapes; "
                    f"shape indices must be in [0, {shape_count})."
                )

            template_key = (id(block.local_pairs), block.shape_count)
            if template_key in validated_templates:
                continue

            for shape_a, shape_b in block.local_pairs:
                if shape_a < 0 or shape_a >= block.shape_count or shape_b < 0 or shape_b >= block.shape_count:
                    raise ValueError(
                        f"shape_collision_filter_pairs contains invalid compact pair ({shape_a}, {shape_b}); "
                        f"local shape indices must be in [0, {block.shape_count})."
                    )
            validated_templates.add(template_key)

    def find_shape_contact_pairs(self, model: Model):
        """Deprecated method for rebuilding explicit shape contact pairs.

        .. deprecated:: 1.4
            Shape contact pairs are generated automatically by :meth:`finalize`.
            Configure collision filters before finalization instead of rebuilding
            contact pairs manually.

        Identifies and stores all potential shape contact pairs for collision detection.

        This method examines the collision groups and collision masks of all shapes in the model
        to determine which pairs of shapes should be considered for contact generation. It respects
        any user-specified collision filter pairs to avoid redundant or undesired contacts.

        The resulting contact pairs are stored in the model as a 2D array of shape indices.

        Uses the exact same filtering logic as the broad phase kernels (test_world_and_group_pair)
        to ensure consistency between EXPLICIT mode (precomputed pairs) and NXN/SAP modes.

        Args:
            model: The simulation model to which the contact pairs will be assigned.

        Side Effects:
            - Sets `model.shape_contact_pairs` to a wp.array of shape pairs (wp.vec2i).
            - Sets `model.shape_contact_pair_count` to the number of contact pairs found.
        """
        warnings.warn(
            "ModelBuilder.find_shape_contact_pairs() is deprecated; shape contact pairs are generated "
            + "automatically by ModelBuilder.finalize(). Configure collision filters before finalization instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        # Deprecated calls may supply an unrelated model or a builder that has
        # changed since finalization, so always query filters from the model.
        self._find_shape_contact_pairs(model, allow_filter_blocks=False)

    def _find_shape_contact_pairs(self, model: Model, *, allow_filter_blocks: bool) -> None:
        filter_pairs = self._shape_collision_filter_pairs
        world_filter_blocks: tuple[_ShapeCollisionFilterBlock, ...] = ()
        explicit_filter_pairs: tuple[tuple[int, int], ...] = ()
        if isinstance(filter_pairs, _BuilderShapeCollisionFilterPairs):
            blocks = filter_pairs.blocks
            self._validate_compact_shape_collision_filter_blocks(blocks)
            # Compact blocks come from replicated builders; keep this path in
            # world-local coordinates so identical worlds can share one template.
            world_filter_blocks = tuple(block for block in blocks if block.world is not None)
            # Blocks without a world assignment (add_builder outside a world
            # context) are folded into the explicit residual pairs so they do
            # not disable the fast path for the replicated worlds.
            floating_block_pairs = (
                (block.shape_start + shape_a, block.shape_start + shape_b)
                for block in blocks
                if block.world is None
                for shape_a, shape_b in block.local_pairs
            )
            explicit_filter_pairs = tuple(
                self._iter_validated_shape_collision_filter_pairs((*filter_pairs.explicit_pairs, *floating_block_pairs))
            )

        # Builder-side storage is valid only while it describes the model's
        # filters exactly; otherwise the general path queries the model.
        use_world_templates = (
            allow_filter_blocks and self.world_count > 0 and isinstance(filter_pairs, _BuilderShapeCollisionFilterPairs)
        )
        if use_world_templates:
            shape_world_np = np.asarray(self.shape_world, dtype=np.int32)
            starts = self.shape_world_start
            if len(starts) != self.world_count + 2:
                use_world_templates = False
            else:
                segment_worlds = np.full(self.shape_count, -1, dtype=np.int32)
                for world in range(self.world_count):
                    segment_worlds[starts[world] : starts[world + 1]] = world
                use_world_templates = np.array_equal(segment_worlds, shape_world_np)

        if use_world_templates:
            blocks_by_world = {}
            global_filter_pairs = set()
            explicit_filters_by_world = {}
            for block in world_filter_blocks:
                world = block.world
                if world < 0 or world >= self.world_count:
                    use_world_templates = False
                    break

                world_start = self.shape_world_start[world]
                world_end = self.shape_world_start[world + 1]
                if block.shape_start < world_start or block.shape_start + block.shape_count > world_end:
                    use_world_templates = False
                    break

                # Store block starts as world-local offsets for the template cache
                # instead of keying homogeneous worlds by absolute shape ids.
                blocks_by_world.setdefault(world, []).append(
                    (block.shape_start - world_start, block.shape_count, block.local_pairs)
                )

            if use_world_templates:
                # Residual explicit filters may involve global shapes, so split
                # them into globally keyed filters and per-world local filters.
                for shape_a, shape_b in explicit_filter_pairs:
                    world_a = self.shape_world[shape_a]
                    world_b = self.shape_world[shape_b]

                    if world_a == -1 and world_b == -1:
                        global_filter_pairs.add((shape_a, shape_b))
                    elif world_a == -1 and world_b >= 0:
                        explicit_filters_by_world.setdefault(world_b, []).append(
                            ("global_local", shape_a, shape_b - self.shape_world_start[world_b])
                        )
                    elif world_b == -1 and world_a >= 0:
                        explicit_filters_by_world.setdefault(world_a, []).append(
                            ("global_local", shape_b, shape_a - self.shape_world_start[world_a])
                        )
                    elif world_a == world_b and world_a >= 0:
                        world_start = self.shape_world_start[world_a]
                        explicit_filters_by_world.setdefault(world_a, []).append(
                            ("local", shape_a - world_start, shape_b - world_start)
                        )
                    # Cross-world pairs never collide, so filtering them is a no-op.

            if use_world_templates:
                contact_pairs = []
                shape_flags_np = np.asarray(self.shape_flags, dtype=np.int64)
                colliding_np = (shape_flags_np & int(ShapeFlags.COLLIDE_SHAPES)) != 0
                colliding_globals = [
                    (int(shape_idx), self.shape_collision_group[shape_idx])
                    for shape_idx in np.flatnonzero((shape_world_np == -1) & colliding_np)
                ]

                for i1, (shape_a, group_a) in enumerate(colliding_globals):
                    for shape_b, group_b in colliding_globals[i1 + 1 :]:
                        if not self._test_group_pair(group_a, group_b):
                            continue
                        pair = (shape_a, shape_b) if shape_a <= shape_b else (shape_b, shape_a)
                        if pair not in global_filter_pairs:
                            contact_pairs.append(pair)

                shape_group_np = np.asarray(self.shape_collision_group, dtype=np.int64)
                template_cache = {}
                template_runs: list[tuple[list[int], tuple[np.ndarray, np.ndarray]]] = []
                for world in range(self.world_count):
                    world_start = self.shape_world_start[world]
                    world_end = self.shape_world_start[world + 1]
                    if world_start == world_end:
                        continue

                    block_specs = tuple(blocks_by_world.get(world, ()))
                    explicit_filter_specs = tuple(explicit_filters_by_world.get(world, ()))
                    block_key = tuple(
                        (offset, shape_count, id(local_pairs)) for offset, shape_count, local_pairs in block_specs
                    )
                    # Key homogeneous worlds by raw bytes instead of Python
                    # tuples; re-hashing per-shape tuples per world dominates
                    # this loop at high world counts.
                    cache_key = (
                        shape_flags_np[world_start:world_end].tobytes(),
                        shape_group_np[world_start:world_end].tobytes(),
                        block_key,
                        explicit_filter_specs,
                    )
                    cached_pairs = template_cache.get(cache_key)

                    if cached_pairs is None:
                        collision_groups = self.shape_collision_group[world_start:world_end]
                        local_colliding_indices = np.flatnonzero(colliding_np[world_start:world_end]).tolist()

                        # Replicated-block filters are local to the source block;
                        # shift them into this world's local shape coordinates.
                        local_filters = set()
                        for block_offset, _shape_count, local_filter_pairs in block_specs:
                            for shape_a, shape_b in local_filter_pairs:
                                offset_shape_a = block_offset + shape_a
                                offset_shape_b = block_offset + shape_b
                                local_filters.add(
                                    (offset_shape_a, offset_shape_b)
                                    if offset_shape_a <= offset_shape_b
                                    else (offset_shape_b, offset_shape_a)
                                )

                        global_local_filters = set()
                        for kind, shape_a, shape_b in explicit_filter_specs:
                            if kind == "local":
                                local_filters.add((shape_a, shape_b) if shape_a <= shape_b else (shape_b, shape_a))
                            else:
                                global_local_filters.add((shape_a, shape_b))

                        # Cache global/local pairs separately: the global id is
                        # absolute, while the local id is shifted during replay.
                        global_local_pairs = []
                        for global_shape, global_group in colliding_globals:
                            for local_shape in local_colliding_indices:
                                if self._test_group_pair(global_group, collision_groups[local_shape]):
                                    pair = (global_shape, local_shape)
                                    if pair not in global_local_filters:
                                        global_local_pairs.append(pair)

                        local_pairs = []
                        for i1, shape_a in enumerate(local_colliding_indices):
                            group_a = collision_groups[shape_a]
                            for shape_b in local_colliding_indices[i1 + 1 :]:
                                if not self._test_group_pair(group_a, collision_groups[shape_b]):
                                    continue

                                pair = (shape_a, shape_b)
                                if pair not in local_filters:
                                    local_pairs.append(pair)

                        cached_pairs = (
                            np.asarray(global_local_pairs, dtype=np.int32).reshape((-1, 2)),
                            np.asarray(local_pairs, dtype=np.int32).reshape((-1, 2)),
                        )
                        template_cache[cache_key] = cached_pairs

                    # Group runs of consecutive worlds sharing one template so
                    # the replay below is a broadcast add per run, not a Python
                    # loop over millions of per-world tuples.
                    if template_runs and template_runs[-1][1] is cached_pairs:
                        template_runs[-1][0].append(world_start)
                    else:
                        template_runs.append(([world_start], cached_pairs))

                chunks = []
                if contact_pairs:
                    chunks.append(np.asarray(contact_pairs, dtype=np.int32).reshape((-1, 2)))
                for starts, (global_local_pairs, local_pairs) in template_runs:
                    offsets = np.asarray(starts, dtype=np.int32)
                    global_count = global_local_pairs.shape[0]
                    pairs_per_world = global_count + local_pairs.shape[0]
                    if pairs_per_world == 0:
                        continue
                    replay = np.empty((offsets.shape[0], pairs_per_world, 2), dtype=np.int32)
                    if global_count:
                        global_replay = replay[:, :global_count, :]
                        global_replay[:, :, 0] = global_local_pairs[:, 0]
                        # Cached global/local pairs hold an absolute global id
                        # and a world-local id shifted per world during replay.
                        global_replay[:, :, 1] = global_local_pairs[:, 1] + offsets[:, None]
                        global_replay.sort(axis=2)
                    if pairs_per_world > global_count:
                        replay[:, global_count:, :] = local_pairs[None, :, :] + offsets[:, None, None]
                    chunks.append(replay.reshape((-1, 2)))

                if chunks:
                    pair_array = np.concatenate(chunks, axis=0)
                else:
                    pair_array = np.empty((0, 2), dtype=np.int32)
                model.shape_contact_pairs = wp.array(pair_array, dtype=wp.vec2i, device=model.device)
                model.shape_contact_pair_count = len(pair_array)
                return

        contact_pairs: list[tuple[int, int]] = []
        shape_world = self.shape_world
        shape_collision_group = self.shape_collision_group

        # Keep only colliding shapes (those with COLLIDE_SHAPES flag) and sort by world for optimization
        colliding_indices = [i for i, flag in enumerate(self.shape_flags) if flag & ShapeFlags.COLLIDE_SHAPES]
        sorted_indices = sorted(colliding_indices, key=shape_world.__getitem__)

        # Iterate over all pairs of colliding shapes
        for i1 in range(len(sorted_indices)):
            s1 = sorted_indices[i1]
            world1 = shape_world[s1]
            collision_group1 = shape_collision_group[s1]

            for i2 in range(i1 + 1, len(sorted_indices)):
                s2 = sorted_indices[i2]
                world2 = shape_world[s2]
                collision_group2 = shape_collision_group[s2]

                # Early break optimization: if both shapes are in non-global worlds and different worlds,
                # they can never collide. Since shapes are sorted by world, all remaining shapes will also
                # be in different worlds, so we can break early.
                if world1 != -1 and world2 != -1 and world1 != world2:
                    break

                if not self._test_world_and_group_pair(world1, world2, collision_group1, collision_group2):
                    continue

                if s1 > s2:
                    shape_a, shape_b = s2, s1
                else:
                    shape_a, shape_b = s1, s2

                contact_pairs.append((shape_a, shape_b))

        # Drop explicitly filtered pairs with one bulk query instead of a
        # per-pair membership test inside the candidate loop.
        candidate_pairs = np.asarray(contact_pairs, dtype=np.int32).reshape((-1, 2))
        if candidate_pairs.shape[0] > 0:
            filtered = model.shape_collision_filter_mask(candidate_pairs)
            candidate_pairs = candidate_pairs[~filtered]

        model.shape_contact_pairs = wp.array(candidate_pairs, dtype=wp.vec2i, device=model.device)
        model.shape_contact_pair_count = len(candidate_pairs)

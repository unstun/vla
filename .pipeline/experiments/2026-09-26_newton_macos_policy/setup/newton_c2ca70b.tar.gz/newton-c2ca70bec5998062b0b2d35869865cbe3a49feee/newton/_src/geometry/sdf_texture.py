# SPDX-FileCopyrightText: Copyright (c) 2026 The Newton Developers
# SPDX-License-Identifier: Apache-2.0

"""Texture-based (tex3d) sparse SDF construction and sampling.

This module provides a GPU-accelerated sparse SDF implementation using 3D CUDA textures.
Construction mirrors the NanoVDB sparse-volume pattern in ``sdf_utils.py``:

1. Check subgrid occupancy by querying the source SDF at subgrid centers
2. Build the background/coarse SDF by querying the source at subgrid corner positions
3. Populate only occupied subgrid textures by querying the source at each texel

The format uses:
- A coarse 3D texture for background/far-field sampling
- A packed subgrid 3D texture for narrow-band high-resolution sampling
- An indirection array mapping coarse cells to subgrid blocks

Sampling uses analytical trilinear gradient computation from 8 corner texel reads,
providing exact accuracy with only 8 texture reads (vs 56 for finite differences).
"""

from __future__ import annotations

import functools
import types
from collections.abc import Callable, Sequence

import numpy as np
import warp as wp

from ..core.types import Axis
from .kernels import sdf_box, sdf_capsule, sdf_cone, sdf_cylinder, sdf_ellipsoid, sdf_sphere
from .sdf_mc import MC_EDGE_CLAMP_MAX, MC_EDGE_CLAMP_MIN, MC_EDGE_VAL_DIFF_EPS
from .sdf_utils import (
    get_distance_to_mesh,
    get_distance_to_mesh_normal,
    get_distance_to_mesh_parity,
    get_primitive_extents,
)
from .types import GeoType

# Sentinel values for subgrid indirection slots.
# Typed uint32 so kernel codegen doesn't overflow an int32 constant.
SLOT_EMPTY = wp.uint32(0xFFFFFFFF)  # No subgrid data (empty/far-field cell)
SLOT_LINEAR = wp.uint32(0xFFFFFFFE)  # Subgrid demoted to coarse interpolation

# Inside/outside sign strategies for the mesh distance queries during the
# bake. Winding is 0 so a legacy ``use_parity`` boolean maps onto the same
# semantics (False -> winding, True -> parity).
SIGN_MODE_WINDING = 0
SIGN_MODE_PARITY = 1
SIGN_MODE_NORMAL = 2

_SDF_SOURCE_MESH = 0
_SDF_SOURCE_PRIMITIVE = 1

_SUPPORTED_PRIMITIVE_SDF_TYPES = frozenset(
    {
        int(GeoType.SPHERE),
        int(GeoType.BOX),
        int(GeoType.CAPSULE),
        int(GeoType.CYLINDER),
        int(GeoType.ELLIPSOID),
        int(GeoType.CONE),
    }
)


def _validate_primitive_sdf_inputs(
    shape_type: int,
    shape_scale: Sequence[float],
) -> tuple[int, tuple[float, float, float]]:
    shape_type = int(shape_type)
    if shape_type not in _SUPPORTED_PRIMITIVE_SDF_TYPES:
        raise NotImplementedError(f"Texture SDF generation is not implemented for shape type: {shape_type}")
    if len(shape_scale) != 3:
        raise ValueError("shape_scale must contain exactly 3 components")

    scale = tuple(float(v) for v in shape_scale)
    if not np.all(np.isfinite(scale)):
        raise ValueError("shape_scale components must be finite")
    if any(v < 0.0 for v in scale):
        raise ValueError("shape_scale components must be non-negative")
    return shape_type, scale


# ============================================================================
# SDF texture-sampling paths
# ============================================================================
#
# Two pairs of trilinear samplers are provided -- pick at the call site:
#
# * :func:`texture_sample_sdf` / :func:`texture_sample_sdf_grad` --
#   ``"software"`` path. Four point-sampled reads, each returning adjacent
#   X samples, followed by a float32 trilinear blend. Most accurate; avoids
#   the 8-bit fixed-point interpolation weights the texture unit's hardware
#   filter uses. Default for hydroelastic contact, where contact-force
#   precision feeds back into the stress integration over the volume.
#
# * :func:`texture_sample_sdf_hw` / :func:`texture_sample_sdf_grad_hw` --
#   ``"hardware"`` path. One ``wp.texture_sample`` for the value, six
#   centred-difference samples for the gradient. Far fewer texture fetches
#   per query in principle; routes everything through the GPU's filter unit
#   (8-bit fixed-point interpolation weights). Used by the mesh-SDF
#   narrow phase, where the small extra jitter is absorbed by PGS.
#
# Paired storage uses two-channel, ``LINEAR``-filtered textures: channel zero
# stores the sample at X and channel one its +X neighbor. Scalar storage uses
# one channel per texel. Sampling at ``int + 0.5`` resolves to the exact texel
# value in either layout; the selected sampler controls how adjacent X values
# are fetched.

# ============================================================================
# Texture SDF Data Structure
# ============================================================================


class QuantizationMode:
    """Quantization modes for subgrid SDF data."""

    FLOAT32 = 4  # No quantization, full precision
    UINT16 = 2  # 16-bit quantization
    UINT8 = 1  # 8-bit quantization


@wp.struct
class TextureSDFData:
    """Sparse SDF stored in 3D CUDA textures with indirection array.

    Uses a two-level structure:
    - A coarse 3D texture for background/far-field sampling
    - A packed subgrid 3D texture for narrow-band high-resolution sampling
    - An indirection array mapping coarse cells to subgrid texture blocks
    """

    # Textures and indirection
    coarse_texture: wp.Texture3D
    subgrid_texture: wp.Texture3D
    subgrid_start_slots: wp.array3d[wp.uint32]

    # Grid parameters
    sdf_box_lower: wp.vec3
    sdf_box_upper: wp.vec3
    inv_sdf_dx: wp.vec3
    subgrid_size: int
    subgrid_size_f: float  # float(subgrid_size) - avoids int->float conversion
    subgrid_samples_f: float  # float(subgrid_size + 1) - samples per subgrid dimension
    fine_to_coarse: float
    num_subgrids: int  # Number of non-empty narrow-band subgrids

    # Spatial metadata
    voxel_size: wp.vec3
    voxel_radius: wp.float32

    # Quantization parameters for subgrid values
    subgrids_min_sdf_value: float
    subgrids_sdf_value_range: float  # max - min

    paired_samples: wp.bool
    # Whether shape_scale was baked into the SDF
    scale_baked: wp.bool


# ============================================================================
# Sparse SDF Construction Kernels
# ============================================================================


@wp.func
def _idx3d(x: int, y: int, z: int, size_x: int, size_y: int) -> int:
    """Convert 3D coordinates to linear index."""
    return z * size_x * size_y + y * size_x + x


@wp.func
def _id_to_xyz(idx: int, size_x: int, size_y: int) -> wp.vec3i:
    """Convert linear index to 3D coordinates."""
    z = idx // (size_x * size_y)
    rem = idx - z * size_x * size_y
    y = rem // size_x
    x = rem - y * size_x
    return wp.vec3i(x, y, z)


@wp.func
def _query_primitive_sdf(shape_type: wp.int32, shape_scale: wp.vec3, point: wp.vec3) -> float:
    """Evaluate an analytical primitive SDF in the shape-local frame."""
    signed_distance = float(1.0e6)
    if shape_type == GeoType.SPHERE:
        signed_distance = sdf_sphere(point, shape_scale[0])
    elif shape_type == GeoType.BOX:
        signed_distance = sdf_box(point, shape_scale[0], shape_scale[1], shape_scale[2])
    elif shape_type == GeoType.CAPSULE:
        signed_distance = sdf_capsule(point, shape_scale[0], shape_scale[1], int(Axis.Z))
    elif shape_type == GeoType.CYLINDER:
        signed_distance = sdf_cylinder(point, shape_scale[0], shape_scale[1], int(Axis.Z), -1.0, shape_scale[2])
    elif shape_type == GeoType.ELLIPSOID:
        signed_distance = sdf_ellipsoid(point, shape_scale)
    elif shape_type == GeoType.CONE:
        signed_distance = sdf_cone(point, shape_scale[0], shape_scale[1], int(Axis.Z))
    return signed_distance


@wp.func
def _interp_coarse_sdf(
    background_sdf: wp.array[float],
    block_x: int,
    block_y: int,
    block_z: int,
    lx: int,
    ly: int,
    lz: int,
    inv_cells_per_subgrid: float,
    bg_size_x: int,
    bg_size_y: int,
    bg_size_z: int,
) -> float:
    """Trilinear interpolation of the coarse/background SDF at a fine sample."""
    coarse_fx = float(block_x) + float(lx) * inv_cells_per_subgrid
    coarse_fy = float(block_y) + float(ly) * inv_cells_per_subgrid
    coarse_fz = float(block_z) + float(lz) * inv_cells_per_subgrid

    x0 = wp.clamp(int(wp.floor(coarse_fx)), 0, bg_size_x - 2)
    y0 = wp.clamp(int(wp.floor(coarse_fy)), 0, bg_size_y - 2)
    z0 = wp.clamp(int(wp.floor(coarse_fz)), 0, bg_size_z - 2)

    tx = wp.clamp(coarse_fx - float(x0), 0.0, 1.0)
    ty = wp.clamp(coarse_fy - float(y0), 0.0, 1.0)
    tz = wp.clamp(coarse_fz - float(z0), 0.0, 1.0)

    v000 = background_sdf[_idx3d(x0, y0, z0, bg_size_x, bg_size_y)]
    v100 = background_sdf[_idx3d(x0 + 1, y0, z0, bg_size_x, bg_size_y)]
    v010 = background_sdf[_idx3d(x0, y0 + 1, z0, bg_size_x, bg_size_y)]
    v110 = background_sdf[_idx3d(x0 + 1, y0 + 1, z0, bg_size_x, bg_size_y)]
    v001 = background_sdf[_idx3d(x0, y0, z0 + 1, bg_size_x, bg_size_y)]
    v101 = background_sdf[_idx3d(x0 + 1, y0, z0 + 1, bg_size_x, bg_size_y)]
    v011 = background_sdf[_idx3d(x0, y0 + 1, z0 + 1, bg_size_x, bg_size_y)]
    v111 = background_sdf[_idx3d(x0 + 1, y0 + 1, z0 + 1, bg_size_x, bg_size_y)]

    c00 = v000 * (1.0 - tx) + v100 * tx
    c10 = v010 * (1.0 - tx) + v110 * tx
    c01 = v001 * (1.0 - tx) + v101 * tx
    c11 = v011 * (1.0 - tx) + v111 * tx
    c0 = c00 * (1.0 - ty) + c10 * ty
    c1 = c01 * (1.0 - ty) + c11 * ty
    return c0 * (1.0 - tz) + c1 * tz


@wp.func
def _is_in_narrow_band(signed_distance: float, threshold: wp.vec2f) -> wp.bool:
    """Check if a signed distance lies within the narrow band."""
    if wp.sign(signed_distance) > 0.0:
        return signed_distance < threshold[1]
    return signed_distance > threshold[0]


@wp.func
def _write_subgrid_slot(
    subgrid_start_slots: wp.array3d[wp.uint32],
    address: int,
    tex_blocks_per_dim: int,
    block_x: int,
    block_y: int,
    block_z: int,
    local_sample: int,
) -> wp.vec3i:
    """Resolve texture block address to 3D offset and write the indirection slot.

    Returns the block address as ``(addr_x, addr_y, addr_z)`` for the caller
    to combine with the local sample offset.
    """
    addr_coords = _id_to_xyz(address, tex_blocks_per_dim, tex_blocks_per_dim)
    if local_sample == 0:
        start_slot = (
            wp.uint32(addr_coords[0])
            | (wp.uint32(addr_coords[1]) << wp.uint32(10))
            | (wp.uint32(addr_coords[2]) << wp.uint32(20))
        )
        subgrid_start_slots[block_x, block_y, block_z] = start_slot
    return addr_coords


@functools.cache
def _create_source_kernels(source_kind: int, sign_mode: int):
    """Generate bake kernels specialized for one source and sign strategy.

    The query dispatch is resolved at kernel-generation time instead of a
    runtime branch. This keeps analytic primitive queries separate from mesh
    queries and ensures the default parity/winding mesh bakes never compile
    the heavier pseudo-normal query.
    """
    if source_kind == _SDF_SOURCE_PRIMITIVE:

        @wp.func
        def query_sdf(
            mesh: wp.uint64,
            shape_type: wp.int32,
            shape_scale: wp.vec3,
            point: wp.vec3,
            max_dist: wp.float32,
            winding_threshold: wp.float32,
        ) -> float:
            return _query_primitive_sdf(shape_type, shape_scale, point)

    elif sign_mode == SIGN_MODE_PARITY:

        @wp.func
        def query_sdf(
            mesh: wp.uint64,
            shape_type: wp.int32,
            shape_scale: wp.vec3,
            point: wp.vec3,
            max_dist: wp.float32,
            winding_threshold: wp.float32,
        ) -> float:
            return get_distance_to_mesh_parity(mesh, point, max_dist)

    elif sign_mode == SIGN_MODE_NORMAL:

        @wp.func
        def query_sdf(
            mesh: wp.uint64,
            shape_type: wp.int32,
            shape_scale: wp.vec3,
            point: wp.vec3,
            max_dist: wp.float32,
            winding_threshold: wp.float32,
        ) -> float:
            return get_distance_to_mesh_normal(mesh, point, max_dist)

    else:

        @wp.func
        def query_sdf(
            mesh: wp.uint64,
            shape_type: wp.int32,
            shape_scale: wp.vec3,
            point: wp.vec3,
            max_dist: wp.float32,
            winding_threshold: wp.float32,
        ) -> float:
            return get_distance_to_mesh(mesh, point, max_dist, winding_threshold)

    @wp.kernel
    def check_subgrid_occupied_kernel(
        mesh: wp.uint64,
        shape_type: wp.int32,
        shape_scale: wp.vec3,
        threshold: wp.vec2f,
        winding_threshold: float,
        subgrid_required: wp.array[wp.int32],
        cells_per_subgrid: int,
        num_subgrids_x: int,
        num_subgrids_y: int,
        min_corner: wp.vec3,
        cell_size: wp.vec3,
    ):
        """Mark subgrids that overlap the narrow band by checking the source SDF at the center."""
        tid = wp.tid()
        coords = _id_to_xyz(tid, num_subgrids_x, num_subgrids_y)
        sample_pos = min_corner + wp.vec3(
            (float(coords[0] * cells_per_subgrid) + float(cells_per_subgrid) * 0.5) * cell_size[0],
            (float(coords[1] * cells_per_subgrid) + float(cells_per_subgrid) * 0.5) * cell_size[1],
            (float(coords[2] * cells_per_subgrid) + float(cells_per_subgrid) * 0.5) * cell_size[2],
        )

        signed_distance = query_sdf(mesh, shape_type, shape_scale, sample_pos, 10000.0, winding_threshold)
        if _is_in_narrow_band(signed_distance, threshold):
            subgrid_required[tid] = 1
        else:
            subgrid_required[tid] = 0

    @wp.kernel
    def accumulate_subgrid_linearity_error_kernel(
        mesh: wp.uint64,
        shape_type: wp.int32,
        shape_scale: wp.vec3,
        background_sdf: wp.array[float],
        subgrid_required: wp.array[wp.int32],
        linearity_errors: wp.array[float],
        cells_per_subgrid: int,
        min_corner: wp.vec3,
        cell_size: wp.vec3,
        winding_threshold: float,
        num_subgrids_x: int,
        num_subgrids_y: int,
        num_subgrids_z: int,
        bg_size_x: int,
        bg_size_y: int,
        bg_size_z: int,
    ):
        """Sample the source SDF at every fine-grid point of every occupied subgrid and
        accumulate the maximum absolute deviation from the trilinearly interpolated
        coarse SDF via ``wp.atomic_max``.

        Launched over ``total_subgrids * samples_per_subgrid`` threads so the 9^3
        inner loop is parallelized across the GPU — a per-subgrid launch would
        serialize the inner sampling loop on SM occupancy when mesh BVH queries
        dominate throughput.
        """
        tid = wp.tid()

        total_subgrids = num_subgrids_x * num_subgrids_y * num_subgrids_z
        samples_per_dim = cells_per_subgrid + 1
        samples_per_subgrid = samples_per_dim * samples_per_dim * samples_per_dim

        subgrid_idx = tid // samples_per_subgrid
        local_sample = tid - subgrid_idx * samples_per_subgrid

        if subgrid_idx >= total_subgrids:
            return
        if subgrid_required[subgrid_idx] == 0:
            return

        subgrid_coords = _id_to_xyz(subgrid_idx, num_subgrids_x, num_subgrids_y)
        block_x = subgrid_coords[0]
        block_y = subgrid_coords[1]
        block_z = subgrid_coords[2]

        local_coords = _id_to_xyz(local_sample, samples_per_dim, samples_per_dim)
        lx = local_coords[0]
        ly = local_coords[1]
        lz = local_coords[2]

        gx = block_x * cells_per_subgrid + lx
        gy = block_y * cells_per_subgrid + ly
        gz = block_z * cells_per_subgrid + lz

        pos = min_corner + wp.vec3(
            float(gx) * cell_size[0],
            float(gy) * cell_size[1],
            float(gz) * cell_size[2],
        )
        sdf_value = query_sdf(mesh, shape_type, shape_scale, pos, 10000.0, winding_threshold)

        inv_cpsg = 1.0 / float(cells_per_subgrid)
        coarse_val = _interp_coarse_sdf(
            background_sdf,
            block_x,
            block_y,
            block_z,
            lx,
            ly,
            lz,
            inv_cpsg,
            bg_size_x,
            bg_size_y,
            bg_size_z,
        )

        wp.atomic_max(linearity_errors, subgrid_idx, wp.abs(sdf_value - coarse_val))

    @wp.kernel
    def build_coarse_sdf_kernel(
        mesh: wp.uint64,
        shape_type: wp.int32,
        shape_scale: wp.vec3,
        background_sdf: wp.array[float],
        min_corner: wp.vec3,
        cell_size: wp.vec3,
        cells_per_subgrid: int,
        bg_size_x: int,
        bg_size_y: int,
        bg_size_z: int,
        winding_threshold: float,
    ):
        """Populate the background SDF by querying the source at subgrid corner positions."""
        tid = wp.tid()

        total_bg = bg_size_x * bg_size_y * bg_size_z
        if tid >= total_bg:
            return

        coords = _id_to_xyz(tid, bg_size_x, bg_size_y)
        x_block = coords[0]
        y_block = coords[1]
        z_block = coords[2]

        pos = min_corner + wp.vec3(
            float(x_block * cells_per_subgrid) * cell_size[0],
            float(y_block * cells_per_subgrid) * cell_size[1],
            float(z_block * cells_per_subgrid) * cell_size[2],
        )

        background_sdf[tid] = query_sdf(mesh, shape_type, shape_scale, pos, 10000.0, winding_threshold)

    @wp.kernel
    def populate_subgrid_texture_float32_kernel(
        mesh: wp.uint64,
        shape_type: wp.int32,
        shape_scale: wp.vec3,
        subgrid_required: wp.array[wp.int32],
        subgrid_addresses: wp.array[wp.int32],
        subgrid_start_slots: wp.array3d[wp.uint32],
        subgrid_texture: wp.array[float],
        cells_per_subgrid: int,
        min_corner: wp.vec3,
        cell_size: wp.vec3,
        winding_threshold: float,
        num_subgrids_x: int,
        num_subgrids_y: int,
        num_subgrids_z: int,
        tex_blocks_per_dim: int,
        tex_size: int,
    ):
        """Populate the subgrid texture by querying the source SDF (float32 version)."""
        tid = wp.tid()

        total_subgrids = num_subgrids_x * num_subgrids_y * num_subgrids_z
        samples_per_dim = cells_per_subgrid + 1
        samples_per_subgrid = samples_per_dim * samples_per_dim * samples_per_dim

        subgrid_idx = tid // samples_per_subgrid
        local_sample = tid - subgrid_idx * samples_per_subgrid

        if subgrid_idx >= total_subgrids:
            return
        if subgrid_required[subgrid_idx] == 0:
            return

        subgrid_coords = _id_to_xyz(subgrid_idx, num_subgrids_x, num_subgrids_y)
        block_x = subgrid_coords[0]
        block_y = subgrid_coords[1]
        block_z = subgrid_coords[2]

        local_coords = _id_to_xyz(local_sample, samples_per_dim, samples_per_dim)
        lx = local_coords[0]
        ly = local_coords[1]
        lz = local_coords[2]

        gx = block_x * cells_per_subgrid + lx
        gy = block_y * cells_per_subgrid + ly
        gz = block_z * cells_per_subgrid + lz

        pos = min_corner + wp.vec3(
            float(gx) * cell_size[0],
            float(gy) * cell_size[1],
            float(gz) * cell_size[2],
        )
        sdf_val = query_sdf(mesh, shape_type, shape_scale, pos, 10000.0, winding_threshold)

        address = subgrid_addresses[subgrid_idx]
        if address < 0:
            return

        ac = _write_subgrid_slot(
            subgrid_start_slots, address, tex_blocks_per_dim, block_x, block_y, block_z, local_sample
        )
        tex_idx = _idx3d(
            ac[0] * samples_per_dim + lx, ac[1] * samples_per_dim + ly, ac[2] * samples_per_dim + lz, tex_size, tex_size
        )
        subgrid_texture[tex_idx] = sdf_val

    @wp.kernel
    def populate_subgrid_texture_uint16_kernel(
        mesh: wp.uint64,
        shape_type: wp.int32,
        shape_scale: wp.vec3,
        subgrid_required: wp.array[wp.int32],
        subgrid_addresses: wp.array[wp.int32],
        subgrid_start_slots: wp.array3d[wp.uint32],
        subgrid_texture: wp.array[wp.uint16],
        cells_per_subgrid: int,
        min_corner: wp.vec3,
        cell_size: wp.vec3,
        winding_threshold: float,
        num_subgrids_x: int,
        num_subgrids_y: int,
        num_subgrids_z: int,
        tex_blocks_per_dim: int,
        tex_size: int,
        sdf_min: float,
        sdf_range_inv: float,
    ):
        """Populate the subgrid texture by querying the source SDF (uint16 quantized version)."""
        tid = wp.tid()

        total_subgrids = num_subgrids_x * num_subgrids_y * num_subgrids_z
        samples_per_dim = cells_per_subgrid + 1
        samples_per_subgrid = samples_per_dim * samples_per_dim * samples_per_dim

        subgrid_idx = tid // samples_per_subgrid
        local_sample = tid - subgrid_idx * samples_per_subgrid

        if subgrid_idx >= total_subgrids:
            return
        if subgrid_required[subgrid_idx] == 0:
            return

        subgrid_coords = _id_to_xyz(subgrid_idx, num_subgrids_x, num_subgrids_y)
        block_x = subgrid_coords[0]
        block_y = subgrid_coords[1]
        block_z = subgrid_coords[2]

        local_coords = _id_to_xyz(local_sample, samples_per_dim, samples_per_dim)
        lx = local_coords[0]
        ly = local_coords[1]
        lz = local_coords[2]

        gx = block_x * cells_per_subgrid + lx
        gy = block_y * cells_per_subgrid + ly
        gz = block_z * cells_per_subgrid + lz

        pos = min_corner + wp.vec3(
            float(gx) * cell_size[0],
            float(gy) * cell_size[1],
            float(gz) * cell_size[2],
        )
        sdf_val = query_sdf(mesh, shape_type, shape_scale, pos, 10000.0, winding_threshold)

        address = subgrid_addresses[subgrid_idx]
        if address < 0:
            return

        ac = _write_subgrid_slot(
            subgrid_start_slots, address, tex_blocks_per_dim, block_x, block_y, block_z, local_sample
        )
        tex_idx = _idx3d(
            ac[0] * samples_per_dim + lx, ac[1] * samples_per_dim + ly, ac[2] * samples_per_dim + lz, tex_size, tex_size
        )
        v_normalized = wp.clamp((sdf_val - sdf_min) * sdf_range_inv, 0.0, 1.0)
        subgrid_texture[tex_idx] = wp.uint16(v_normalized * 65535.0)

    @wp.kernel
    def populate_subgrid_texture_uint8_kernel(
        mesh: wp.uint64,
        shape_type: wp.int32,
        shape_scale: wp.vec3,
        subgrid_required: wp.array[wp.int32],
        subgrid_addresses: wp.array[wp.int32],
        subgrid_start_slots: wp.array3d[wp.uint32],
        subgrid_texture: wp.array[wp.uint8],
        cells_per_subgrid: int,
        min_corner: wp.vec3,
        cell_size: wp.vec3,
        winding_threshold: float,
        num_subgrids_x: int,
        num_subgrids_y: int,
        num_subgrids_z: int,
        tex_blocks_per_dim: int,
        tex_size: int,
        sdf_min: float,
        sdf_range_inv: float,
    ):
        """Populate the subgrid texture by querying the source SDF (uint8 quantized version)."""
        tid = wp.tid()

        total_subgrids = num_subgrids_x * num_subgrids_y * num_subgrids_z
        samples_per_dim = cells_per_subgrid + 1
        samples_per_subgrid = samples_per_dim * samples_per_dim * samples_per_dim

        subgrid_idx = tid // samples_per_subgrid
        local_sample = tid - subgrid_idx * samples_per_subgrid

        if subgrid_idx >= total_subgrids:
            return
        if subgrid_required[subgrid_idx] == 0:
            return

        subgrid_coords = _id_to_xyz(subgrid_idx, num_subgrids_x, num_subgrids_y)
        block_x = subgrid_coords[0]
        block_y = subgrid_coords[1]
        block_z = subgrid_coords[2]

        local_coords = _id_to_xyz(local_sample, samples_per_dim, samples_per_dim)
        lx = local_coords[0]
        ly = local_coords[1]
        lz = local_coords[2]

        gx = block_x * cells_per_subgrid + lx
        gy = block_y * cells_per_subgrid + ly
        gz = block_z * cells_per_subgrid + lz

        pos = min_corner + wp.vec3(
            float(gx) * cell_size[0],
            float(gy) * cell_size[1],
            float(gz) * cell_size[2],
        )
        sdf_val = query_sdf(mesh, shape_type, shape_scale, pos, 10000.0, winding_threshold)

        address = subgrid_addresses[subgrid_idx]
        if address < 0:
            return

        ac = _write_subgrid_slot(
            subgrid_start_slots, address, tex_blocks_per_dim, block_x, block_y, block_z, local_sample
        )
        tex_idx = _idx3d(
            ac[0] * samples_per_dim + lx, ac[1] * samples_per_dim + ly, ac[2] * samples_per_dim + lz, tex_size, tex_size
        )
        v_normalized = wp.clamp((sdf_val - sdf_min) * sdf_range_inv, 0.0, 1.0)
        subgrid_texture[tex_idx] = wp.uint8(v_normalized * 255.0)

    # ============================================================================
    # Volume Sampling Kernel (for NanoVDB → texture conversion)
    # ============================================================================

    return types.SimpleNamespace(
        check_subgrid_occupied_kernel=check_subgrid_occupied_kernel,
        accumulate_subgrid_linearity_error_kernel=accumulate_subgrid_linearity_error_kernel,
        build_coarse_sdf_kernel=build_coarse_sdf_kernel,
        populate_subgrid_texture_float32_kernel=populate_subgrid_texture_float32_kernel,
        populate_subgrid_texture_uint16_kernel=populate_subgrid_texture_uint16_kernel,
        populate_subgrid_texture_uint8_kernel=populate_subgrid_texture_uint8_kernel,
    )


@wp.kernel
def _apply_subgrid_linearity_kernel(
    subgrid_required: wp.array[wp.int32],
    linearity_errors: wp.array[float],
    subgrid_is_linear: wp.array[wp.int32],
    error_threshold: float,
):
    """Demote occupied subgrids whose max linearity error is below threshold.

    Consumes the per-subgrid maxima produced by
    :func:`_accumulate_subgrid_linearity_error_kernel` and clears the
    corresponding ``subgrid_required`` entries, so linear subgrids occupy no
    slot in the high-resolution texture.
    """
    tid = wp.tid()
    if subgrid_required[tid] == 0:
        return
    if linearity_errors[tid] < error_threshold:
        subgrid_is_linear[tid] = 1
        subgrid_required[tid] = 0


@wp.kernel
def _sample_volume_at_positions_kernel(
    volume: wp.uint64,
    positions: wp.array[wp.vec3],
    out_values: wp.array[float],
):
    """Sample NanoVDB volume at world-space positions."""
    tid = wp.tid()
    pos = positions[tid]
    idx = wp.volume_world_to_index(volume, pos)
    out_values[tid] = wp.volume_sample_f(volume, idx, wp.Volume.LINEAR)


# ============================================================================
# Texture Sampling Functions (wp.func, used by collision kernels)
# ============================================================================


@wp.func
def apply_subgrid_sdf_scale(raw_value: float, min_value: float, value_range: float) -> float:
    """Apply quantization scale to convert normalized [0,1] value back to SDF distance."""
    return raw_value * value_range + min_value


@wp.func
def _texture_sample_sdf_x0(texture: wp.Texture3D, uvw: wp.vec3f, paired_samples: bool) -> float:
    """Sample the original SDF value from channel zero."""
    if paired_samples:
        return wp.texture_sample(texture, uvw, dtype=wp.vec2)[0]
    return wp.texture_sample(texture, uvw, dtype=float)


vec8f = wp.types.vector(length=8, dtype=wp.float32)


@wp.struct
class _CellLookup:
    """Minimal cell lookup shared by the SDF samplers.

    This stops the software and hardware paths from duplicating the
    clamp/fine-cell/coarse-cell/SLOT_LINEAR lookup while leaving the
    branch-specific texture-coordinate math local to each sampler.
    """

    ix: int
    iy: int
    iz: int
    tx: float
    ty: float
    tz: float
    x_base: int
    y_base: int
    z_base: int
    start_slot: wp.uint32


@wp.func
def _locate_cell_coords(sdf: TextureSDFData, f: wp.vec3) -> _CellLookup:
    """Resolve cell coordinates without loading the subgrid slot.

    See :class:`_CellLookup` for the field layout.
    """
    coarse_x = sdf.coarse_texture.width - 1
    coarse_y = sdf.coarse_texture.height - 1
    coarse_z = sdf.coarse_texture.depth - 1

    fine_verts_x = float(coarse_x) * sdf.subgrid_size_f
    fine_verts_y = float(coarse_y) * sdf.subgrid_size_f
    fine_verts_z = float(coarse_z) * sdf.subgrid_size_f

    fx = wp.clamp(f[0], 0.0, fine_verts_x)
    fy = wp.clamp(f[1], 0.0, fine_verts_y)
    fz = wp.clamp(f[2], 0.0, fine_verts_z)

    num_fine_cells_x = int(fine_verts_x)
    num_fine_cells_y = int(fine_verts_y)
    num_fine_cells_z = int(fine_verts_z)
    ix = wp.clamp(int(wp.floor(fx)), 0, num_fine_cells_x - 1)
    iy = wp.clamp(int(wp.floor(fy)), 0, num_fine_cells_y - 1)
    iz = wp.clamp(int(wp.floor(fz)), 0, num_fine_cells_z - 1)
    tx = fx - float(ix)
    ty = fy - float(iy)
    tz = fz - float(iz)

    x_base = wp.clamp(int(float(ix) * sdf.fine_to_coarse), 0, coarse_x - 1)
    y_base = wp.clamp(int(float(iy) * sdf.fine_to_coarse), 0, coarse_y - 1)
    z_base = wp.clamp(int(float(iz) * sdf.fine_to_coarse), 0, coarse_z - 1)

    loc = _CellLookup()
    loc.ix = ix
    loc.iy = iy
    loc.iz = iz
    loc.tx = tx
    loc.ty = ty
    loc.tz = tz
    loc.x_base = x_base
    loc.y_base = y_base
    loc.z_base = z_base
    loc.start_slot = SLOT_EMPTY
    return loc


@wp.func
def _locate_cell(sdf: TextureSDFData, f: wp.vec3) -> _CellLookup:
    """Resolve cell coordinates and the corresponding subgrid slot."""
    loc = _locate_cell_coords(sdf, f)
    loc.start_slot = sdf.subgrid_start_slots[loc.x_base, loc.y_base, loc.z_base]
    return loc


@wp.func
def _locate_cell_pair(sdf: TextureSDFData, f0: wp.vec3, f1: wp.vec3) -> tuple[_CellLookup, _CellLookup]:
    """Resolve two cells while sharing a common subgrid-slot lookup."""
    loc0 = _locate_cell_coords(sdf, f0)
    loc1 = _locate_cell_coords(sdf, f1)
    start_slot0 = sdf.subgrid_start_slots[loc0.x_base, loc0.y_base, loc0.z_base]
    start_slot1 = start_slot0
    if loc0.x_base != loc1.x_base or loc0.y_base != loc1.y_base or loc0.z_base != loc1.z_base:
        start_slot1 = sdf.subgrid_start_slots[loc1.x_base, loc1.y_base, loc1.z_base]
    loc0.start_slot = start_slot0
    loc1.start_slot = start_slot1
    return loc0, loc1


@wp.func
def _read_cell_corners(
    sdf: TextureSDFData,
    f: wp.vec3,
) -> tuple[vec8f, float, float, float]:
    """Locate the fine-grid cell containing *f* and read 8 corner texel values.

    Point-samples each corner at integer+0.5 coordinates (exact texel centres)
    so the caller can perform full float32 trilinear interpolation, avoiding
    the 8-bit fixed-point weight precision of CUDA hardware texture filtering.

    Args:
        sdf: texture SDF data.
        f: query position in fine-grid coordinates
            (``cw_mul(clamped - sdf_box_lower, inv_sdf_dx)``).

    Returns:
        ``(corners, tx, ty, tz)`` where *corners* packs the 8 SDF values as
        ``[v000, v100, v010, v110, v001, v101, v011, v111]`` and
        ``(tx, ty, tz)`` are the fractional interpolation weights in [0, 1].
    """
    loc = _locate_cell(sdf, f)

    v000 = float(0.0)
    v100 = float(0.0)
    v010 = float(0.0)
    v110 = float(0.0)
    v001 = float(0.0)
    v101 = float(0.0)
    v011 = float(0.0)
    v111 = float(0.0)

    tx = loc.tx
    ty = loc.ty
    tz = loc.tz

    if loc.start_slot >= SLOT_LINEAR:
        cx = float(loc.x_base)
        cy = float(loc.y_base)
        cz = float(loc.z_base)
        coarse_f = wp.vec3(float(loc.ix) + loc.tx, float(loc.iy) + loc.ty, float(loc.iz) + loc.tz) * sdf.fine_to_coarse
        tx = coarse_f[0] - cx
        ty = coarse_f[1] - cy
        tz = coarse_f[2] - cz
        v000 = _texture_sample_sdf_x0(sdf.coarse_texture, wp.vec3f(cx + 0.5, cy + 0.5, cz + 0.5), sdf.paired_samples)
        v100 = _texture_sample_sdf_x0(sdf.coarse_texture, wp.vec3f(cx + 1.5, cy + 0.5, cz + 0.5), sdf.paired_samples)
        v010 = _texture_sample_sdf_x0(sdf.coarse_texture, wp.vec3f(cx + 0.5, cy + 1.5, cz + 0.5), sdf.paired_samples)
        v110 = _texture_sample_sdf_x0(sdf.coarse_texture, wp.vec3f(cx + 1.5, cy + 1.5, cz + 0.5), sdf.paired_samples)
        v001 = _texture_sample_sdf_x0(sdf.coarse_texture, wp.vec3f(cx + 0.5, cy + 0.5, cz + 1.5), sdf.paired_samples)
        v101 = _texture_sample_sdf_x0(sdf.coarse_texture, wp.vec3f(cx + 1.5, cy + 0.5, cz + 1.5), sdf.paired_samples)
        v011 = _texture_sample_sdf_x0(sdf.coarse_texture, wp.vec3f(cx + 0.5, cy + 1.5, cz + 1.5), sdf.paired_samples)
        v111 = _texture_sample_sdf_x0(sdf.coarse_texture, wp.vec3f(cx + 1.5, cy + 1.5, cz + 1.5), sdf.paired_samples)
    else:
        block_x = float(loc.start_slot & wp.uint32(0x3FF))
        block_y = float((loc.start_slot >> wp.uint32(10)) & wp.uint32(0x3FF))
        block_z = float((loc.start_slot >> wp.uint32(20)) & wp.uint32(0x3FF))
        lx = float(loc.ix) - float(loc.x_base) * sdf.subgrid_size_f
        ly = float(loc.iy) - float(loc.y_base) * sdf.subgrid_size_f
        lz = float(loc.iz) - float(loc.z_base) * sdf.subgrid_size_f
        ox = block_x * sdf.subgrid_samples_f + lx + 0.5
        oy = block_y * sdf.subgrid_samples_f + ly + 0.5
        oz = block_z * sdf.subgrid_samples_f + lz + 0.5
        v000 = _texture_sample_sdf_x0(sdf.subgrid_texture, wp.vec3f(ox, oy, oz), sdf.paired_samples)
        v100 = _texture_sample_sdf_x0(sdf.subgrid_texture, wp.vec3f(ox + 1.0, oy, oz), sdf.paired_samples)
        v010 = _texture_sample_sdf_x0(sdf.subgrid_texture, wp.vec3f(ox, oy + 1.0, oz), sdf.paired_samples)
        v110 = _texture_sample_sdf_x0(sdf.subgrid_texture, wp.vec3f(ox + 1.0, oy + 1.0, oz), sdf.paired_samples)
        v001 = _texture_sample_sdf_x0(sdf.subgrid_texture, wp.vec3f(ox, oy, oz + 1.0), sdf.paired_samples)
        v101 = _texture_sample_sdf_x0(sdf.subgrid_texture, wp.vec3f(ox + 1.0, oy, oz + 1.0), sdf.paired_samples)
        v011 = _texture_sample_sdf_x0(sdf.subgrid_texture, wp.vec3f(ox, oy + 1.0, oz + 1.0), sdf.paired_samples)
        v111 = _texture_sample_sdf_x0(sdf.subgrid_texture, wp.vec3f(ox + 1.0, oy + 1.0, oz + 1.0), sdf.paired_samples)
        v000 = apply_subgrid_sdf_scale(v000, sdf.subgrids_min_sdf_value, sdf.subgrids_sdf_value_range)
        v100 = apply_subgrid_sdf_scale(v100, sdf.subgrids_min_sdf_value, sdf.subgrids_sdf_value_range)
        v010 = apply_subgrid_sdf_scale(v010, sdf.subgrids_min_sdf_value, sdf.subgrids_sdf_value_range)
        v110 = apply_subgrid_sdf_scale(v110, sdf.subgrids_min_sdf_value, sdf.subgrids_sdf_value_range)
        v001 = apply_subgrid_sdf_scale(v001, sdf.subgrids_min_sdf_value, sdf.subgrids_sdf_value_range)
        v101 = apply_subgrid_sdf_scale(v101, sdf.subgrids_min_sdf_value, sdf.subgrids_sdf_value_range)
        v011 = apply_subgrid_sdf_scale(v011, sdf.subgrids_min_sdf_value, sdf.subgrids_sdf_value_range)
        v111 = apply_subgrid_sdf_scale(v111, sdf.subgrids_min_sdf_value, sdf.subgrids_sdf_value_range)

    corners = vec8f(v000, v100, v010, v110, v001, v101, v011, v111)
    return corners, tx, ty, tz


@wp.func
def _trilinear(corners: vec8f, tx: float, ty: float, tz: float) -> float:
    """Trilinear interpolation from 8 corner values and fractional weights."""
    c00 = corners[0] + (corners[1] - corners[0]) * tx
    c10 = corners[2] + (corners[3] - corners[2]) * tx
    c01 = corners[4] + (corners[5] - corners[4]) * tx
    c11 = corners[6] + (corners[7] - corners[6]) * tx
    c0 = c00 + (c10 - c00) * ty
    c1 = c01 + (c11 - c01) * ty
    return c0 + (c1 - c0) * tz


@wp.func
def _texture_sample_sdf_at_voxel_variant(
    sdf: TextureSDFData,
    ix: int,
    iy: int,
    iz: int,
    paired_samples: bool,
) -> float:
    """Sample SDF at an exact integer fine-grid vertex with a single texel read.

    At integer grid coordinates the trilinear fractional weights are zero, so
    only the corner-0 texel contributes.  This replaces 8 texture reads with 1
    for the common subgrid case, which is the dominant path in hydroelastic
    marching-cubes corner evaluation.

    For coarse (``SLOT_LINEAR``) cells the value must still be interpolated
    from the coarse grid, so this falls back to :func:`texture_sample_sdf`.

    Args:
        sdf: texture SDF data
        ix: fine-grid x index
        iy: fine-grid y index
        iz: fine-grid z index

    Returns:
        Signed distance value [m].
    """
    coarse_x = sdf.coarse_texture.width - 1
    coarse_y = sdf.coarse_texture.height - 1
    coarse_z = sdf.coarse_texture.depth - 1

    x_base = wp.clamp(int(float(ix) * sdf.fine_to_coarse), 0, coarse_x - 1)
    y_base = wp.clamp(int(float(iy) * sdf.fine_to_coarse), 0, coarse_y - 1)
    z_base = wp.clamp(int(float(iz) * sdf.fine_to_coarse), 0, coarse_z - 1)
    start_slot = sdf.subgrid_start_slots[x_base, y_base, z_base]

    if start_slot < SLOT_LINEAR:
        block_x = float(start_slot & wp.uint32(0x3FF))
        block_y = float((start_slot >> wp.uint32(10)) & wp.uint32(0x3FF))
        block_z = float((start_slot >> wp.uint32(20)) & wp.uint32(0x3FF))

        lx = float(ix) - float(x_base) * sdf.subgrid_size_f
        ly = float(iy) - float(y_base) * sdf.subgrid_size_f
        lz = float(iz) - float(z_base) * sdf.subgrid_size_f

        ox = block_x * sdf.subgrid_samples_f + lx + 0.5
        oy = block_y * sdf.subgrid_samples_f + ly + 0.5
        oz = block_z * sdf.subgrid_samples_f + lz + 0.5

        raw = _texture_sample_sdf_x0(sdf.subgrid_texture, wp.vec3f(ox, oy, oz), paired_samples)
        return raw * sdf.subgrids_sdf_value_range + sdf.subgrids_min_sdf_value

    local_pos = sdf.sdf_box_lower + wp.cw_mul(
        wp.vec3(float(ix), float(iy), float(iz)),
        sdf.voxel_size,
    )
    return _texture_sample_sdf_variant(sdf, local_pos, paired_samples)


@wp.func
def _texture_sample_sdf_variant(
    sdf: TextureSDFData,
    local_pos: wp.vec3,
    paired_samples: bool,
) -> float:
    """Sample SDF value (software trilinear).

    Four point-sampled reads return the eight corners as adjacent X pairs,
    followed by a float32 trilinear blend. Sampling at ``int + 0.5``
    collapses the texture-filter weights so the packed texel values are
    returned exactly. Used by paths that prefer accuracy over fetch count,
    such as hydroelastic stress integration.

    Fuses cell lookup, texel reads, trilinear blend, and quantization
    de-scale into a single pass for the value-only path.

    Args:
        sdf: Texture SDF data.
        local_pos: Query position in local SDF space [m].
        paired_samples: Whether to read paired-X or scalar texture storage.

    Returns:
        Signed distance value [m].
    """
    clamped = wp.vec3(
        wp.clamp(local_pos[0], sdf.sdf_box_lower[0], sdf.sdf_box_upper[0]),
        wp.clamp(local_pos[1], sdf.sdf_box_lower[1], sdf.sdf_box_upper[1]),
        wp.clamp(local_pos[2], sdf.sdf_box_lower[2], sdf.sdf_box_upper[2]),
    )
    diff = local_pos - clamped
    diff_sq = wp.dot(diff, diff)

    f = wp.cw_mul(clamped - sdf.sdf_box_lower, sdf.inv_sdf_dx)
    loc = _locate_cell(sdf, f)

    v000 = float(0.0)
    v100 = float(0.0)
    v010 = float(0.0)
    v110 = float(0.0)
    v001 = float(0.0)
    v101 = float(0.0)
    v011 = float(0.0)
    v111 = float(0.0)

    needs_scale = False
    tx = loc.tx
    ty = loc.ty
    tz = loc.tz

    if loc.start_slot >= SLOT_LINEAR:
        cx = float(loc.x_base)
        cy = float(loc.y_base)
        cz = float(loc.z_base)
        coarse_f = wp.vec3(float(loc.ix) + loc.tx, float(loc.iy) + loc.ty, float(loc.iz) + loc.tz) * sdf.fine_to_coarse
        tx = coarse_f[0] - cx
        ty = coarse_f[1] - cy
        tz = coarse_f[2] - cz
        if paired_samples:
            v00 = wp.texture_sample(sdf.coarse_texture, wp.vec3f(cx + 0.5, cy + 0.5, cz + 0.5), dtype=wp.vec2)
            v10 = wp.texture_sample(sdf.coarse_texture, wp.vec3f(cx + 0.5, cy + 1.5, cz + 0.5), dtype=wp.vec2)
            v01 = wp.texture_sample(sdf.coarse_texture, wp.vec3f(cx + 0.5, cy + 0.5, cz + 1.5), dtype=wp.vec2)
            v11 = wp.texture_sample(sdf.coarse_texture, wp.vec3f(cx + 0.5, cy + 1.5, cz + 1.5), dtype=wp.vec2)
            v000, v100 = v00[0], v00[1]
            v010, v110 = v10[0], v10[1]
            v001, v101 = v01[0], v01[1]
            v011, v111 = v11[0], v11[1]
        else:
            v000 = wp.texture_sample(sdf.coarse_texture, wp.vec3f(cx + 0.5, cy + 0.5, cz + 0.5), dtype=float)
            v100 = wp.texture_sample(sdf.coarse_texture, wp.vec3f(cx + 1.5, cy + 0.5, cz + 0.5), dtype=float)
            v010 = wp.texture_sample(sdf.coarse_texture, wp.vec3f(cx + 0.5, cy + 1.5, cz + 0.5), dtype=float)
            v110 = wp.texture_sample(sdf.coarse_texture, wp.vec3f(cx + 1.5, cy + 1.5, cz + 0.5), dtype=float)
            v001 = wp.texture_sample(sdf.coarse_texture, wp.vec3f(cx + 0.5, cy + 0.5, cz + 1.5), dtype=float)
            v101 = wp.texture_sample(sdf.coarse_texture, wp.vec3f(cx + 1.5, cy + 0.5, cz + 1.5), dtype=float)
            v011 = wp.texture_sample(sdf.coarse_texture, wp.vec3f(cx + 0.5, cy + 1.5, cz + 1.5), dtype=float)
            v111 = wp.texture_sample(sdf.coarse_texture, wp.vec3f(cx + 1.5, cy + 1.5, cz + 1.5), dtype=float)
    else:
        needs_scale = True
        block_x = float(loc.start_slot & wp.uint32(0x3FF))
        block_y = float((loc.start_slot >> wp.uint32(10)) & wp.uint32(0x3FF))
        block_z = float((loc.start_slot >> wp.uint32(20)) & wp.uint32(0x3FF))
        lx = float(loc.ix) - float(loc.x_base) * sdf.subgrid_size_f
        ly = float(loc.iy) - float(loc.y_base) * sdf.subgrid_size_f
        lz = float(loc.iz) - float(loc.z_base) * sdf.subgrid_size_f
        ox = block_x * sdf.subgrid_samples_f + lx + 0.5
        oy = block_y * sdf.subgrid_samples_f + ly + 0.5
        oz = block_z * sdf.subgrid_samples_f + lz + 0.5
        if paired_samples:
            v00 = wp.texture_sample(sdf.subgrid_texture, wp.vec3f(ox, oy, oz), dtype=wp.vec2)
            v10 = wp.texture_sample(sdf.subgrid_texture, wp.vec3f(ox, oy + 1.0, oz), dtype=wp.vec2)
            v01 = wp.texture_sample(sdf.subgrid_texture, wp.vec3f(ox, oy, oz + 1.0), dtype=wp.vec2)
            v11 = wp.texture_sample(sdf.subgrid_texture, wp.vec3f(ox, oy + 1.0, oz + 1.0), dtype=wp.vec2)
            v000, v100 = v00[0], v00[1]
            v010, v110 = v10[0], v10[1]
            v001, v101 = v01[0], v01[1]
            v011, v111 = v11[0], v11[1]
        else:
            v000 = wp.texture_sample(sdf.subgrid_texture, wp.vec3f(ox, oy, oz), dtype=float)
            v100 = wp.texture_sample(sdf.subgrid_texture, wp.vec3f(ox + 1.0, oy, oz), dtype=float)
            v010 = wp.texture_sample(sdf.subgrid_texture, wp.vec3f(ox, oy + 1.0, oz), dtype=float)
            v110 = wp.texture_sample(sdf.subgrid_texture, wp.vec3f(ox + 1.0, oy + 1.0, oz), dtype=float)
            v001 = wp.texture_sample(sdf.subgrid_texture, wp.vec3f(ox, oy, oz + 1.0), dtype=float)
            v101 = wp.texture_sample(sdf.subgrid_texture, wp.vec3f(ox + 1.0, oy, oz + 1.0), dtype=float)
            v011 = wp.texture_sample(sdf.subgrid_texture, wp.vec3f(ox, oy + 1.0, oz + 1.0), dtype=float)
            v111 = wp.texture_sample(sdf.subgrid_texture, wp.vec3f(ox + 1.0, oy + 1.0, oz + 1.0), dtype=float)

    # Cover texture latency with the independent extrapolation root.
    diff_mag = wp.sqrt(diff_sq)
    c00 = v000 + (v100 - v000) * tx
    c10 = v010 + (v110 - v010) * tx
    c01 = v001 + (v101 - v001) * tx
    c11 = v011 + (v111 - v011) * tx
    c0 = c00 + (c10 - c00) * ty
    c1 = c01 + (c11 - c01) * ty
    sdf_val = c0 + (c1 - c0) * tz

    if needs_scale:
        sdf_val = sdf_val * sdf.subgrids_sdf_value_range + sdf.subgrids_min_sdf_value

    return sdf_val + diff_mag


@wp.func
def texture_sample_sdf(
    sdf: TextureSDFData,
    local_pos: wp.vec3,
) -> float:
    """Sample an SDF using its stored texture layout and software interpolation."""
    return _texture_sample_sdf_variant(sdf, local_pos, sdf.paired_samples)


@wp.func
def _texture_sample_sdf_paired(
    sdf: TextureSDFData,
    local_pos: wp.vec3,
) -> float:
    """Sample an X-paired SDF texture with software trilinear interpolation."""
    return _texture_sample_sdf_variant(sdf, local_pos, True)


@wp.func
def _texture_sample_sdf_zfiltered(
    sdf: TextureSDFData,
    local_pos: wp.vec3,
) -> float:
    """Sample a paired SDF with hardware Z filtering and float32 X/Y blends."""
    clamped = wp.vec3(
        wp.clamp(local_pos[0], sdf.sdf_box_lower[0], sdf.sdf_box_upper[0]),
        wp.clamp(local_pos[1], sdf.sdf_box_lower[1], sdf.sdf_box_upper[1]),
        wp.clamp(local_pos[2], sdf.sdf_box_lower[2], sdf.sdf_box_upper[2]),
    )
    diff = local_pos - clamped
    diff_sq = wp.dot(diff, diff)

    f = wp.cw_mul(clamped - sdf.sdf_box_lower, sdf.inv_sdf_dx)
    loc = _locate_cell(sdf, f)
    tx = loc.tx
    ty = loc.ty
    tz = loc.tz
    needs_scale = False

    texture = sdf.coarse_texture
    x = float(0.0)
    y0 = float(0.0)
    y1 = float(0.0)
    z = float(0.0)
    if loc.start_slot >= SLOT_LINEAR:
        cx = float(loc.x_base)
        cy = float(loc.y_base)
        cz = float(loc.z_base)
        coarse_f = wp.vec3(float(loc.ix) + loc.tx, float(loc.iy) + loc.ty, float(loc.iz) + loc.tz) * sdf.fine_to_coarse
        tx = coarse_f[0] - cx
        ty = coarse_f[1] - cy
        tz = coarse_f[2] - cz
        x = cx + 0.5
        y0 = cy + 0.5
        y1 = cy + 1.5
        z = cz + tz + 0.5
    else:
        needs_scale = True
        texture = sdf.subgrid_texture
        block_x = float(loc.start_slot & wp.uint32(0x3FF))
        block_y = float((loc.start_slot >> wp.uint32(10)) & wp.uint32(0x3FF))
        block_z = float((loc.start_slot >> wp.uint32(20)) & wp.uint32(0x3FF))
        lx = float(loc.ix) - float(loc.x_base) * sdf.subgrid_size_f
        ly = float(loc.iy) - float(loc.y_base) * sdf.subgrid_size_f
        lz = float(loc.iz) - float(loc.z_base) * sdf.subgrid_size_f
        x = block_x * sdf.subgrid_samples_f + lx + 0.5
        y0 = block_y * sdf.subgrid_samples_f + ly + 0.5
        y1 = y0 + 1.0
        z = block_z * sdf.subgrid_samples_f + lz + tz + 0.5

    x_values_y0 = wp.texture_sample(texture, wp.vec3f(x, y0, z), dtype=wp.vec2)
    x_values_y1 = wp.texture_sample(texture, wp.vec3f(x, y1, z), dtype=wp.vec2)
    x0 = x_values_y0[0] + (x_values_y1[0] - x_values_y0[0]) * ty
    x1 = x_values_y0[1] + (x_values_y1[1] - x_values_y0[1]) * ty
    sdf_val = x0 + (x1 - x0) * tx
    if needs_scale:
        sdf_val = sdf_val * sdf.subgrids_sdf_value_range + sdf.subgrids_min_sdf_value

    return sdf_val + wp.sqrt(diff_sq)


@wp.func
def _texture_sample_sdf_scalar(
    sdf: TextureSDFData,
    local_pos: wp.vec3,
) -> float:
    """Sample a scalar SDF texture with software trilinear interpolation."""
    return _texture_sample_sdf_variant(sdf, local_pos, False)


@wp.func
def texture_sample_sdf_at_voxel(
    sdf: TextureSDFData,
    ix: int,
    iy: int,
    iz: int,
) -> float:
    """Sample an integer fine-grid vertex using the stored texture layout."""
    return _texture_sample_sdf_at_voxel_variant(sdf, ix, iy, iz, sdf.paired_samples)


@wp.func
def _texture_sample_sdf_at_voxel_paired(
    sdf: TextureSDFData,
    ix: int,
    iy: int,
    iz: int,
) -> float:
    """Sample an X-paired SDF texture at an integer fine-grid vertex."""
    return _texture_sample_sdf_at_voxel_variant(sdf, ix, iy, iz, True)


@wp.func
def _texture_sample_sdf_at_voxel_scalar(
    sdf: TextureSDFData,
    ix: int,
    iy: int,
    iz: int,
) -> float:
    """Sample a scalar SDF texture at an integer fine-grid vertex."""
    return _texture_sample_sdf_at_voxel_variant(sdf, ix, iy, iz, False)


@wp.func
def _texture_sample_pair(
    texture0: wp.Texture3D,
    uvw0: wp.vec3f,
    texture1: wp.Texture3D,
    uvw1: wp.vec3f,
    paired_samples: bool,
) -> wp.vec2f:
    """Issue two independent hardware texture samples before consuming either."""
    value0 = _texture_sample_sdf_x0(texture0, uvw0, paired_samples)
    value1 = _texture_sample_sdf_x0(texture1, uvw1, paired_samples)
    return wp.vec2f(value0, value1)


@wp.func
def _texture_sample_sdf_hw_clamped_pair_variant(
    sdf: TextureSDFData,
    clamped0: wp.vec3,
    clamped1: wp.vec3,
    diff_sq0: float,
    diff_sq1: float,
    paired_samples: bool,
) -> wp.vec2f:
    """Sample two already-clamped SDF positions while overlapping texture latency."""

    f0 = wp.cw_mul(clamped0 - sdf.sdf_box_lower, sdf.inv_sdf_dx)
    f1 = wp.cw_mul(clamped1 - sdf.sdf_box_lower, sdf.inv_sdf_dx)
    loc0, loc1 = _locate_cell_pair(sdf, f0, f1)

    texture0 = sdf.coarse_texture
    texture1 = sdf.coarse_texture
    uvw0 = wp.vec3f(0.0)
    uvw1 = wp.vec3f(0.0)

    if loc0.start_slot >= SLOT_LINEAR:
        cx0 = float(loc0.x_base)
        cy0 = float(loc0.y_base)
        cz0 = float(loc0.z_base)
        coarse_f0 = (
            wp.vec3(float(loc0.ix) + loc0.tx, float(loc0.iy) + loc0.ty, float(loc0.iz) + loc0.tz) * sdf.fine_to_coarse
        )
        uvw0 = wp.vec3f(
            cx0 + (coarse_f0[0] - cx0) + 0.5,
            cy0 + (coarse_f0[1] - cy0) + 0.5,
            cz0 + (coarse_f0[2] - cz0) + 0.5,
        )
    else:
        texture0 = sdf.subgrid_texture
        block_x0 = float(loc0.start_slot & wp.uint32(0x3FF))
        block_y0 = float((loc0.start_slot >> wp.uint32(10)) & wp.uint32(0x3FF))
        block_z0 = float((loc0.start_slot >> wp.uint32(20)) & wp.uint32(0x3FF))
        lx0 = float(loc0.ix) - float(loc0.x_base) * sdf.subgrid_size_f
        ly0 = float(loc0.iy) - float(loc0.y_base) * sdf.subgrid_size_f
        lz0 = float(loc0.iz) - float(loc0.z_base) * sdf.subgrid_size_f
        uvw0 = wp.vec3f(
            block_x0 * sdf.subgrid_samples_f + lx0 + 0.5 + loc0.tx,
            block_y0 * sdf.subgrid_samples_f + ly0 + 0.5 + loc0.ty,
            block_z0 * sdf.subgrid_samples_f + lz0 + 0.5 + loc0.tz,
        )

    if loc1.start_slot >= SLOT_LINEAR:
        cx1 = float(loc1.x_base)
        cy1 = float(loc1.y_base)
        cz1 = float(loc1.z_base)
        coarse_f1 = (
            wp.vec3(float(loc1.ix) + loc1.tx, float(loc1.iy) + loc1.ty, float(loc1.iz) + loc1.tz) * sdf.fine_to_coarse
        )
        uvw1 = wp.vec3f(
            cx1 + (coarse_f1[0] - cx1) + 0.5,
            cy1 + (coarse_f1[1] - cy1) + 0.5,
            cz1 + (coarse_f1[2] - cz1) + 0.5,
        )
    else:
        texture1 = sdf.subgrid_texture
        block_x1 = float(loc1.start_slot & wp.uint32(0x3FF))
        block_y1 = float((loc1.start_slot >> wp.uint32(10)) & wp.uint32(0x3FF))
        block_z1 = float((loc1.start_slot >> wp.uint32(20)) & wp.uint32(0x3FF))
        lx1 = float(loc1.ix) - float(loc1.x_base) * sdf.subgrid_size_f
        ly1 = float(loc1.iy) - float(loc1.y_base) * sdf.subgrid_size_f
        lz1 = float(loc1.iz) - float(loc1.z_base) * sdf.subgrid_size_f
        uvw1 = wp.vec3f(
            block_x1 * sdf.subgrid_samples_f + lx1 + 0.5 + loc1.tx,
            block_y1 * sdf.subgrid_samples_f + ly1 + 0.5 + loc1.ty,
            block_z1 * sdf.subgrid_samples_f + lz1 + 0.5 + loc1.tz,
        )

    values = _texture_sample_pair(texture0, uvw0, texture1, uvw1, paired_samples)
    # Cover texture latency with the independent extrapolation roots.
    diff_mag0 = float(0.0)
    diff_mag1 = float(0.0)
    if diff_sq0 != 0.0:
        diff_mag0 = wp.sqrt(diff_sq0)
    if diff_sq1 != 0.0:
        diff_mag1 = wp.sqrt(diff_sq1)
    value0 = values[0]
    value1 = values[1]
    if loc0.start_slot < SLOT_LINEAR:
        value0 = value0 * sdf.subgrids_sdf_value_range + sdf.subgrids_min_sdf_value
    if loc1.start_slot < SLOT_LINEAR:
        value1 = value1 * sdf.subgrids_sdf_value_range + sdf.subgrids_min_sdf_value
    return wp.vec2f(value0 + diff_mag0, value1 + diff_mag1)


@wp.func
def _texture_sample_sdf_hw_pair_variant(
    sdf: TextureSDFData,
    local_pos0: wp.vec3,
    local_pos1: wp.vec3,
    paired_samples: bool,
) -> wp.vec2f:
    """Sample two SDF positions while overlapping their texture latency."""
    clamped0 = wp.vec3(
        wp.clamp(local_pos0[0], sdf.sdf_box_lower[0], sdf.sdf_box_upper[0]),
        wp.clamp(local_pos0[1], sdf.sdf_box_lower[1], sdf.sdf_box_upper[1]),
        wp.clamp(local_pos0[2], sdf.sdf_box_lower[2], sdf.sdf_box_upper[2]),
    )
    clamped1 = wp.vec3(
        wp.clamp(local_pos1[0], sdf.sdf_box_lower[0], sdf.sdf_box_upper[0]),
        wp.clamp(local_pos1[1], sdf.sdf_box_lower[1], sdf.sdf_box_upper[1]),
        wp.clamp(local_pos1[2], sdf.sdf_box_lower[2], sdf.sdf_box_upper[2]),
    )
    diff0 = local_pos0 - clamped0
    diff1 = local_pos1 - clamped1
    diff_sq0 = float(0.0)
    diff_sq1 = float(0.0)
    if diff0[0] != 0.0 or diff0[1] != 0.0 or diff0[2] != 0.0:
        diff_sq0 = wp.dot(diff0, diff0)
    if diff1[0] != 0.0 or diff1[1] != 0.0 or diff1[2] != 0.0:
        diff_sq1 = wp.dot(diff1, diff1)
    return _texture_sample_sdf_hw_clamped_pair_variant(sdf, clamped0, clamped1, diff_sq0, diff_sq1, paired_samples)


@wp.func
def _texture_sample_sdf_hw_pair(
    sdf: TextureSDFData,
    local_pos0: wp.vec3,
    local_pos1: wp.vec3,
) -> wp.vec2f:
    """Sample two SDF positions using their stored texture layout."""
    return _texture_sample_sdf_hw_pair_variant(sdf, local_pos0, local_pos1, sdf.paired_samples)


@wp.func
def _texture_sample_sdf_hw_pair_paired(
    sdf: TextureSDFData,
    local_pos0: wp.vec3,
    local_pos1: wp.vec3,
) -> wp.vec2f:
    """Sample two positions from an X-paired SDF texture."""
    return _texture_sample_sdf_hw_pair_variant(sdf, local_pos0, local_pos1, True)


@wp.func
def _texture_sample_sdf_hw_pair_scalar(
    sdf: TextureSDFData,
    local_pos0: wp.vec3,
    local_pos1: wp.vec3,
) -> wp.vec2f:
    """Sample two positions from a scalar SDF texture."""
    return _texture_sample_sdf_hw_pair_variant(sdf, local_pos0, local_pos1, False)


@wp.func
def _texture_sample_sdf_hw_clamped_variant(
    sdf: TextureSDFData,
    clamped: wp.vec3,
    diff_mag: float,
    paired_samples: bool,
) -> float:
    """Sample a hardware SDF from a point already clamped to its domain."""
    f = wp.cw_mul(clamped - sdf.sdf_box_lower, sdf.inv_sdf_dx)
    loc = _locate_cell(sdf, f)

    sdf_val = float(0.0)

    if loc.start_slot >= SLOT_LINEAR:
        # ``cx + tx + 0.5`` lands at the centre of voxel (cx, cy, cz) and
        # ``+tx`` walks toward (cx+1, ...). The HW filter returns the
        # interpolated value in one fetch.
        cx = float(loc.x_base)
        cy = float(loc.y_base)
        cz = float(loc.z_base)
        coarse_f = wp.vec3(float(loc.ix) + loc.tx, float(loc.iy) + loc.ty, float(loc.iz) + loc.tz) * sdf.fine_to_coarse
        sdf_val = _texture_sample_sdf_x0(
            sdf.coarse_texture,
            wp.vec3f(
                cx + (coarse_f[0] - cx) + 0.5,
                cy + (coarse_f[1] - cy) + 0.5,
                cz + (coarse_f[2] - cz) + 0.5,
            ),
            paired_samples,
        )
    else:
        block_x = float(loc.start_slot & wp.uint32(0x3FF))
        block_y = float((loc.start_slot >> wp.uint32(10)) & wp.uint32(0x3FF))
        block_z = float((loc.start_slot >> wp.uint32(20)) & wp.uint32(0x3FF))
        lx = float(loc.ix) - float(loc.x_base) * sdf.subgrid_size_f
        ly = float(loc.iy) - float(loc.y_base) * sdf.subgrid_size_f
        lz = float(loc.iz) - float(loc.z_base) * sdf.subgrid_size_f
        ox = block_x * sdf.subgrid_samples_f + lx + 0.5
        oy = block_y * sdf.subgrid_samples_f + ly + 0.5
        oz = block_z * sdf.subgrid_samples_f + lz + 0.5
        raw = _texture_sample_sdf_x0(
            sdf.subgrid_texture,
            wp.vec3f(ox + loc.tx, oy + loc.ty, oz + loc.tz),
            paired_samples,
        )
        sdf_val = raw * sdf.subgrids_sdf_value_range + sdf.subgrids_min_sdf_value

    return sdf_val + diff_mag


@wp.func
def _texture_sample_sdf_hw_clamped(
    sdf: TextureSDFData,
    clamped: wp.vec3,
    diff_mag: float,
) -> float:
    """Sample a clamped SDF position using its stored texture layout."""
    return _texture_sample_sdf_hw_clamped_variant(sdf, clamped, diff_mag, sdf.paired_samples)


@wp.func
def _texture_sample_sdf_hw_clamped_paired(
    sdf: TextureSDFData,
    clamped: wp.vec3,
    diff_mag: float,
) -> float:
    """Sample a clamped position from an X-paired SDF texture."""
    return _texture_sample_sdf_hw_clamped_variant(sdf, clamped, diff_mag, True)


@wp.func
def _texture_sample_sdf_hw_clamped_scalar(
    sdf: TextureSDFData,
    clamped: wp.vec3,
    diff_mag: float,
) -> float:
    """Sample a clamped position from a scalar SDF texture."""
    return _texture_sample_sdf_hw_clamped_variant(sdf, clamped, diff_mag, False)


@wp.func
def _texture_sample_sdf_hw_variant(
    sdf: TextureSDFData,
    local_pos: wp.vec3,
    paired_samples: bool,
) -> float:
    """Sample SDF value via the GPU's hardware trilinear filter.

    Issues a single ``wp.texture_sample`` per query at a fractional
    coordinate; the texture unit returns the trilinearly filtered value
    using its 8-bit fixed-point interpolation weights. Eight times fewer
    texture fetches than :func:`texture_sample_sdf` for the value-only
    path; the small interpolation-weight precision loss (~1/256
    relative) is harmless in PGS / TGS contact solvers but should be
    avoided in stress-integration paths like hydroelastic contact.

    Args:
        sdf: Texture SDF data.
        local_pos: Query position in local SDF space [m].
        paired_samples: Whether to read paired-X or scalar texture storage.

    Returns:
        Signed distance value [m].
    """
    clamped = wp.vec3(
        wp.clamp(local_pos[0], sdf.sdf_box_lower[0], sdf.sdf_box_upper[0]),
        wp.clamp(local_pos[1], sdf.sdf_box_lower[1], sdf.sdf_box_upper[1]),
        wp.clamp(local_pos[2], sdf.sdf_box_lower[2], sdf.sdf_box_upper[2]),
    )
    diff = local_pos - clamped
    diff_mag = float(0.0)
    # Avoid a square root for the common in-box path.
    if diff[0] != 0.0 or diff[1] != 0.0 or diff[2] != 0.0:
        diff_mag = wp.length(diff)

    return _texture_sample_sdf_hw_clamped_variant(sdf, clamped, diff_mag, paired_samples)


@wp.func
def texture_sample_sdf_hw(
    sdf: TextureSDFData,
    local_pos: wp.vec3,
) -> float:
    """Sample an SDF using its stored texture layout."""
    return _texture_sample_sdf_hw_variant(sdf, local_pos, sdf.paired_samples)


@wp.func
def _texture_sample_sdf_hw_paired(
    sdf: TextureSDFData,
    local_pos: wp.vec3,
) -> float:
    """Sample an X-paired SDF with hardware interpolation."""
    return _texture_sample_sdf_hw_variant(sdf, local_pos, True)


@wp.func
def _texture_sample_sdf_hw_scalar(
    sdf: TextureSDFData,
    local_pos: wp.vec3,
) -> float:
    """Sample a scalar SDF with hardware interpolation."""
    return _texture_sample_sdf_hw_variant(sdf, local_pos, False)


@wp.func
def texture_sample_sdf_grad(
    sdf: TextureSDFData,
    local_pos: wp.vec3,
) -> tuple[float, wp.vec3]:
    """Sample SDF value and gradient (software trilinear + analytical grad).

    8 point-sampled texel reads via :func:`_read_cell_corners`, full
    float32 trilinear blend for the value, and analytical partial
    derivatives of the trilinear interpolant for the gradient. Most
    accurate path; use it in stress-integration code (hydroelastic).

    Args:
        sdf: texture SDF data
        local_pos: query position in local SDF space [m]

    Returns:
        Tuple of (distance [m], gradient [unitless]).
    """
    clamped = wp.vec3(
        wp.clamp(local_pos[0], sdf.sdf_box_lower[0], sdf.sdf_box_upper[0]),
        wp.clamp(local_pos[1], sdf.sdf_box_lower[1], sdf.sdf_box_upper[1]),
        wp.clamp(local_pos[2], sdf.sdf_box_lower[2], sdf.sdf_box_upper[2]),
    )
    diff = local_pos - clamped
    diff_mag = wp.length(diff)

    f = wp.cw_mul(clamped - sdf.sdf_box_lower, sdf.inv_sdf_dx)
    corners, tx, ty, tz = _read_cell_corners(sdf, f)

    sdf_val = _trilinear(corners, tx, ty, tz)

    # Analytical gradient (partial derivatives of trilinear)
    omtx = 1.0 - tx
    omty = 1.0 - ty
    omtz = 1.0 - tz

    v000 = corners[0]
    v100 = corners[1]
    v010 = corners[2]
    v110 = corners[3]
    v001 = corners[4]
    v101 = corners[5]
    v011 = corners[6]
    v111 = corners[7]

    gx = omty * omtz * (v100 - v000) + ty * omtz * (v110 - v010) + omty * tz * (v101 - v001) + ty * tz * (v111 - v011)
    gy = omtx * omtz * (v010 - v000) + tx * omtz * (v110 - v100) + omtx * tz * (v011 - v001) + tx * tz * (v111 - v101)
    gz = omtx * omty * (v001 - v000) + tx * omty * (v101 - v100) + omtx * ty * (v011 - v010) + tx * ty * (v111 - v110)

    grad = wp.cw_mul(wp.vec3(gx, gy, gz), sdf.inv_sdf_dx)

    if diff_mag > 0.0:
        sdf_val = sdf_val + diff_mag
        grad = diff / diff_mag

    return sdf_val, grad


@wp.func
def _texture_sample_sdf_grad_hw_impl_variant(
    sdf: TextureSDFData,
    local_pos: wp.vec3,
    paired_samples: bool,
) -> wp.vec3:
    """Hardware FD gradient at ``local_pos``, with out-of-box extrapolation.

    Shared body for :func:`texture_sample_sdf_grad_hw` and
    :func:`texture_sample_sdf_grad_only_hw`. When ``local_pos`` is
    outside the SDF box, returns the unit vector from the clamped
    boundary point to ``local_pos`` (matches the
    :func:`texture_sample_sdf_grad` extrapolation convention). Inside
    the box, issues six hardware-filtered fetches (one per ±axis) for
    a centred-difference gradient with half-step ``0.5 / inv_sdf_dx``.
    """
    clamped = wp.vec3(
        wp.clamp(local_pos[0], sdf.sdf_box_lower[0], sdf.sdf_box_upper[0]),
        wp.clamp(local_pos[1], sdf.sdf_box_lower[1], sdf.sdf_box_upper[1]),
        wp.clamp(local_pos[2], sdf.sdf_box_lower[2], sdf.sdf_box_upper[2]),
    )
    diff = local_pos - clamped

    # Out-of-box: the clamp-direction extrapolation defines the gradient
    # exactly, so skip the six FD texture fetches that would be discarded.
    if diff[0] != 0.0 or diff[1] != 0.0 or diff[2] != 0.0:
        diff_mag = wp.length(diff)
        if diff_mag > 0.0:
            return diff / diff_mag

    h_x = 0.5 / sdf.inv_sdf_dx[0]
    x_pos0 = local_pos + wp.vec3(h_x, 0.0, 0.0)
    x_pos1 = local_pos - wp.vec3(h_x, 0.0, 0.0)
    x_coord0 = wp.clamp(x_pos0[0], sdf.sdf_box_lower[0], sdf.sdf_box_upper[0])
    x_coord1 = wp.clamp(x_pos1[0], sdf.sdf_box_lower[0], sdf.sdf_box_upper[0])
    x_delta0 = x_pos0[0] - x_coord0
    x_delta1 = x_pos1[0] - x_coord1
    x_values = _texture_sample_sdf_hw_clamped_pair_variant(
        sdf,
        wp.vec3(x_coord0, x_pos0[1], x_pos0[2]),
        wp.vec3(x_coord1, x_pos1[1], x_pos1[2]),
        x_delta0 * x_delta0,
        x_delta1 * x_delta1,
        paired_samples,
    )
    gx = (x_values[0] - x_values[1]) * sdf.inv_sdf_dx[0]
    h_y = 0.5 / sdf.inv_sdf_dx[1]
    y_pos0 = local_pos + wp.vec3(0.0, h_y, 0.0)
    y_pos1 = local_pos - wp.vec3(0.0, h_y, 0.0)
    y_coord0 = wp.clamp(y_pos0[1], sdf.sdf_box_lower[1], sdf.sdf_box_upper[1])
    y_coord1 = wp.clamp(y_pos1[1], sdf.sdf_box_lower[1], sdf.sdf_box_upper[1])
    y_delta0 = y_pos0[1] - y_coord0
    y_delta1 = y_pos1[1] - y_coord1
    y_values = _texture_sample_sdf_hw_clamped_pair_variant(
        sdf,
        wp.vec3(y_pos0[0], y_coord0, y_pos0[2]),
        wp.vec3(y_pos1[0], y_coord1, y_pos1[2]),
        y_delta0 * y_delta0,
        y_delta1 * y_delta1,
        paired_samples,
    )
    gy = (y_values[0] - y_values[1]) * sdf.inv_sdf_dx[1]
    h_z = 0.5 / sdf.inv_sdf_dx[2]
    z_pos0 = local_pos + wp.vec3(0.0, 0.0, h_z)
    z_pos1 = local_pos - wp.vec3(0.0, 0.0, h_z)
    z_coord0 = wp.clamp(z_pos0[2], sdf.sdf_box_lower[2], sdf.sdf_box_upper[2])
    z_coord1 = wp.clamp(z_pos1[2], sdf.sdf_box_lower[2], sdf.sdf_box_upper[2])
    z_delta0 = z_pos0[2] - z_coord0
    z_delta1 = z_pos1[2] - z_coord1
    z_values = _texture_sample_sdf_hw_clamped_pair_variant(
        sdf,
        wp.vec3(z_pos0[0], z_pos0[1], z_coord0),
        wp.vec3(z_pos1[0], z_pos1[1], z_coord1),
        z_delta0 * z_delta0,
        z_delta1 * z_delta1,
        paired_samples,
    )
    gz = (z_values[0] - z_values[1]) * sdf.inv_sdf_dx[2]
    return wp.vec3(gx, gy, gz)


@wp.func
def _texture_sample_sdf_grad_hw_impl(
    sdf: TextureSDFData,
    local_pos: wp.vec3,
) -> wp.vec3:
    """Sample a hardware gradient using the stored texture layout."""
    return _texture_sample_sdf_grad_hw_impl_variant(sdf, local_pos, sdf.paired_samples)


@wp.func
def texture_sample_sdf_grad_hw(
    sdf: TextureSDFData,
    local_pos: wp.vec3,
) -> tuple[float, wp.vec3]:
    """Sample SDF value and gradient via the hardware filter (FD gradient).

    Issues one hardware-filtered fetch for the value and six more
    (one per ±axis) for a centred-difference gradient. The half-step
    is ``0.5 / inv_sdf_dx[axis]`` so the metre-scale matches the
    analytical-gradient path's. All fetches go through the texture
    unit's filter so the entire SDF read path stays on the hardware
    side -- pair with :func:`texture_sample_sdf_hw` in narrow-phase
    contact kernels.

    Args:
        sdf: texture SDF data
        local_pos: query position in local SDF space [m]

    Returns:
        Tuple of (distance [m], gradient [unitless]).
    """
    sdf_val = texture_sample_sdf_hw(sdf, local_pos)
    grad = _texture_sample_sdf_grad_hw_impl(sdf, local_pos)
    return sdf_val, grad


@wp.func
def texture_sample_sdf_grad_only_hw(
    sdf: TextureSDFData,
    local_pos: wp.vec3,
) -> wp.vec3:
    """Hardware FD gradient at ``local_pos``, no value sample.

    Companion to :func:`texture_sample_sdf_grad_hw` for callers that
    already know the SDF value at ``local_pos`` (e.g. the SDF
    narrow-phase reuses Brent's converged value). Six HW samples
    instead of seven; the centre value is computed by the caller
    from prior context.

    When ``local_pos`` is outside the SDF box, the gradient is the
    unit vector from the clamped boundary point to ``local_pos`` --
    same extrapolation convention as :func:`texture_sample_sdf_grad`.

    Args:
        sdf: texture SDF data
        local_pos: query position in local SDF space [m]

    Returns:
        Gradient [unitless].
    """
    return _texture_sample_sdf_grad_hw_impl(sdf, local_pos)


@wp.func
def _texture_sample_sdf_grad_only_hw_paired(
    sdf: TextureSDFData,
    local_pos: wp.vec3,
) -> wp.vec3:
    """Sample an X-paired SDF hardware gradient."""
    return _texture_sample_sdf_grad_hw_impl_variant(sdf, local_pos, True)


@wp.func
def _texture_sample_sdf_grad_only_hw_scalar(
    sdf: TextureSDFData,
    local_pos: wp.vec3,
) -> wp.vec3:
    """Sample a scalar SDF hardware gradient."""
    return _texture_sample_sdf_grad_hw_impl_variant(sdf, local_pos, False)


# ============================================================================
# Host-side Construction Functions
# ============================================================================


def _build_sparse_sdf(
    source_kind: int,
    mesh: wp.Mesh | None,
    shape_type: int,
    shape_scale: Sequence[float],
    grid_size_x: int,
    grid_size_y: int,
    grid_size_z: int,
    cell_size: np.ndarray,
    min_corner: np.ndarray,
    max_corner: np.ndarray,
    subgrid_size: int = 8,
    narrow_band_thickness: float = 0.1,
    quantization_mode: int = QuantizationMode.UINT16,
    winding_threshold: float = 0.5,
    linearization_error_threshold: float | None = None,
    sign_mode: int = SIGN_MODE_WINDING,
    device: str = "cuda",
) -> dict:
    """Build sparse SDF texture representation by querying a source directly.

    Mirrors the NanoVDB sparse-volume construction pattern: check subgrid
    occupancy at centers, then populate only occupied subgrids.  Linearity
    is evaluated before texture allocation so that subgrids whose SDF is
    well-approximated by the coarse grid consume no high-resolution
    texture memory.

    Args:
        source_kind: SDF query source, either mesh or analytic primitive.
        mesh: Warp mesh for mesh query sources.
        shape_type: Primitive :class:`GeoType` for primitive query sources.
        shape_scale: Primitive shape scale [m].
        grid_size_x: fine grid X dimension [sample].
        grid_size_y: fine grid Y dimension [sample].
        grid_size_z: fine grid Z dimension [sample].
        cell_size: fine grid cell size per axis [m].
        min_corner: lower corner of domain [m].
        max_corner: upper corner of domain [m].
        subgrid_size: cells per subgrid.
        narrow_band_thickness: distance threshold for subgrids [m].
        quantization_mode: :class:`QuantizationMode` value.
        winding_threshold: winding number threshold for inside/outside.
        linearization_error_threshold: maximum absolute SDF error [m] below
            which an occupied subgrid is considered linear and its high-res
            data is omitted.  ``None`` auto-computes from domain extents,
            ``0.0`` disables the optimization.
        sign_mode: inside/outside strategy for the distance queries.
            :data:`SIGN_MODE_WINDING` (default) uses winding numbers (robust
            for general meshes, needs winding-number support on the mesh);
            :data:`SIGN_MODE_PARITY` uses parity ray-casts (cheaper, requires
            a closed manifold mesh); :data:`SIGN_MODE_NORMAL` uses the
            angle-weighted pseudo-normal (local side-of-surface, for open
            meshes).
        device: Warp device string.

    Returns:
        Dictionary with all sparse SDF data.
    """
    # Ceiling division ensures the subgrid grid fully covers the fine grid.
    # Floor division can truncate the domain when the number of fine cells
    # is not a multiple of subgrid_size, leaving narrow-band regions without
    # subgrid coverage.
    num_cells_x = grid_size_x - 1
    num_cells_y = grid_size_y - 1
    num_cells_z = grid_size_z - 1
    w = (num_cells_x + subgrid_size - 1) // subgrid_size
    h = (num_cells_y + subgrid_size - 1) // subgrid_size
    d = (num_cells_z + subgrid_size - 1) // subgrid_size
    total_subgrids = w * h * d

    min_corner_wp = wp.vec3(float(min_corner[0]), float(min_corner[1]), float(min_corner[2]))
    cell_size_wp = wp.vec3(float(cell_size[0]), float(cell_size[1]), float(cell_size[2]))
    mesh_id = mesh.id if mesh is not None else wp.uint64(0)
    shape_type_wp = wp.int32(shape_type)
    shape_scale_wp = wp.vec3(float(shape_scale[0]), float(shape_scale[1]), float(shape_scale[2]))

    bg_size_x = w + 1
    bg_size_y = h + 1
    bg_size_z = d + 1
    total_bg = bg_size_x * bg_size_y * bg_size_z

    half_subgrid = subgrid_size * 0.5 * cell_size
    subgrid_radius = float(np.linalg.norm(half_subgrid))

    # -------------------------------------------------------------------
    # Unified build: *sign_mode* selects the inside/outside strategy for
    # the mesh distance queries (winding numbers, parity ray-casts, or the
    # angle-weighted pseudo-normal). Linearity is evaluated before the
    # texture is sized so that subgrids whose SDF is well-approximated by
    # the coarse grid consume no high-resolution texture memory.
    # -------------------------------------------------------------------
    source_kernels = _create_source_kernels(int(source_kind), int(sign_mode))

    background_sdf = wp.zeros(total_bg, dtype=float, device=device)
    wp.launch(
        source_kernels.build_coarse_sdf_kernel,
        dim=total_bg,
        inputs=[
            mesh_id,
            shape_type_wp,
            shape_scale_wp,
            background_sdf,
            min_corner_wp,
            cell_size_wp,
            subgrid_size,
            bg_size_x,
            bg_size_y,
            bg_size_z,
            winding_threshold,
        ],
        device=device,
    )

    subgrid_required = wp.zeros(total_subgrids, dtype=wp.int32, device=device)
    threshold = wp.vec2f(-narrow_band_thickness - subgrid_radius, narrow_band_thickness + subgrid_radius)
    wp.launch(
        source_kernels.check_subgrid_occupied_kernel,
        dim=total_subgrids,
        inputs=[
            mesh_id,
            shape_type_wp,
            shape_scale_wp,
            threshold,
            winding_threshold,
            subgrid_required,
            subgrid_size,
            w,
            h,
            min_corner_wp,
            cell_size_wp,
        ],
        device=device,
    )

    if linearization_error_threshold is None:
        extents = max_corner - min_corner
        linearization_error_threshold = float(1e-6 * np.linalg.norm(extents))
    subgrid_is_linear = wp.zeros(total_subgrids, dtype=wp.int32, device=device)
    if linearization_error_threshold > 0.0:
        # Per-sample launch so the 9^3 inner loop is parallelized across
        # threads; atomic_max accumulates the per-subgrid linearity error.
        # We deliberately do NOT cache the source samples for reuse in the
        # populate pass: an empirical test showed the cache (one float32
        # per sample, total_subgrids * 9^3 bytes transient) costs more in
        # global-memory traffic than re-querying the source SDF. This was measured for
        # small meshes (cube: 12 tris) and medium meshes (icosphere:
        # 5120 tris) at resolutions up to 256.
        samples_per_dim = subgrid_size + 1
        samples_per_subgrid = samples_per_dim**3
        total_work = total_subgrids * samples_per_subgrid

        linearity_errors = wp.zeros(total_subgrids, dtype=float, device=device)
        wp.launch(
            source_kernels.accumulate_subgrid_linearity_error_kernel,
            dim=total_work,
            inputs=[
                mesh_id,
                shape_type_wp,
                shape_scale_wp,
                background_sdf,
                subgrid_required,
                linearity_errors,
                subgrid_size,
                min_corner_wp,
                cell_size_wp,
                winding_threshold,
                w,
                h,
                d,
                bg_size_x,
                bg_size_y,
                bg_size_z,
            ],
            device=device,
        )
        wp.launch(
            _apply_subgrid_linearity_kernel,
            dim=total_subgrids,
            inputs=[
                subgrid_required,
                linearity_errors,
                subgrid_is_linear,
                linearization_error_threshold,
            ],
            device=device,
        )

    # Exclusive prefix-sum gives each required subgrid a sequential address.
    # Total count = prefix[-1] + input[-1]; single-element readback is enough
    # but .numpy() on the full array is fine — the sync is unavoidable because
    # we need num_required on the host to size the texture allocation.
    subgrid_addresses = wp.zeros(total_subgrids, dtype=wp.int32, device=device)
    wp._src.utils.array_scan(subgrid_required, subgrid_addresses, inclusive=False)

    required_np = subgrid_required.numpy()
    num_required = int(np.sum(required_np))

    # Conservative quantization bounds from narrow band range
    global_sdf_min = -narrow_band_thickness - subgrid_radius
    global_sdf_max = narrow_band_thickness + subgrid_radius
    sdf_range = global_sdf_max - global_sdf_min
    if sdf_range < 1e-10:
        sdf_range = 1.0

    if num_required == 0:
        subgrid_start_slots = np.full((w, h, d), SLOT_EMPTY, dtype=np.uint32)
        subgrid_texture_data = np.zeros((1, 1, 1), dtype=np.float32)
        tex_size = 1
        final_sdf_min = 0.0
        final_sdf_range = 1.0
    else:
        cubic_root = num_required ** (1.0 / 3.0)
        tex_blocks_per_dim = max(1, int(np.ceil(cubic_root)))
        while tex_blocks_per_dim**3 < num_required:
            tex_blocks_per_dim += 1

        samples_per_dim = subgrid_size + 1
        tex_size = tex_blocks_per_dim * samples_per_dim

        subgrid_start_slots = np.full((w, h, d), SLOT_EMPTY, dtype=np.uint32)
        subgrid_start_slots_gpu = wp.array(subgrid_start_slots, dtype=wp.uint32, device=device)

        total_tex_samples = tex_size * tex_size * tex_size
        samples_per_subgrid = samples_per_dim**3
        total_work = total_subgrids * samples_per_subgrid

        sdf_range_inv = 1.0 / sdf_range

        if quantization_mode == QuantizationMode.FLOAT32:
            subgrid_texture_gpu = wp.zeros(total_tex_samples, dtype=float, device=device)
            wp.launch(
                source_kernels.populate_subgrid_texture_float32_kernel,
                dim=total_work,
                inputs=[
                    mesh_id,
                    shape_type_wp,
                    shape_scale_wp,
                    subgrid_required,
                    subgrid_addresses,
                    subgrid_start_slots_gpu,
                    subgrid_texture_gpu,
                    subgrid_size,
                    min_corner_wp,
                    cell_size_wp,
                    winding_threshold,
                    w,
                    h,
                    d,
                    tex_blocks_per_dim,
                    tex_size,
                ],
                device=device,
            )
            final_sdf_min = 0.0
            final_sdf_range = 1.0

        elif quantization_mode == QuantizationMode.UINT16:
            subgrid_texture_gpu = wp.zeros(total_tex_samples, dtype=wp.uint16, device=device)
            wp.launch(
                source_kernels.populate_subgrid_texture_uint16_kernel,
                dim=total_work,
                inputs=[
                    mesh_id,
                    shape_type_wp,
                    shape_scale_wp,
                    subgrid_required,
                    subgrid_addresses,
                    subgrid_start_slots_gpu,
                    subgrid_texture_gpu,
                    subgrid_size,
                    min_corner_wp,
                    cell_size_wp,
                    winding_threshold,
                    w,
                    h,
                    d,
                    tex_blocks_per_dim,
                    tex_size,
                    global_sdf_min,
                    sdf_range_inv,
                ],
                device=device,
            )
            final_sdf_min = global_sdf_min
            final_sdf_range = sdf_range

        elif quantization_mode == QuantizationMode.UINT8:
            subgrid_texture_gpu = wp.zeros(total_tex_samples, dtype=wp.uint8, device=device)
            wp.launch(
                source_kernels.populate_subgrid_texture_uint8_kernel,
                dim=total_work,
                inputs=[
                    mesh_id,
                    shape_type_wp,
                    shape_scale_wp,
                    subgrid_required,
                    subgrid_addresses,
                    subgrid_start_slots_gpu,
                    subgrid_texture_gpu,
                    subgrid_size,
                    min_corner_wp,
                    cell_size_wp,
                    winding_threshold,
                    w,
                    h,
                    d,
                    tex_blocks_per_dim,
                    tex_size,
                    global_sdf_min,
                    sdf_range_inv,
                ],
                device=device,
            )
            final_sdf_min = global_sdf_min
            final_sdf_range = sdf_range

        else:
            raise ValueError(f"Unknown quantization mode: {quantization_mode}")

        subgrid_texture_data = subgrid_texture_gpu.numpy().reshape((tex_size, tex_size, tex_size))
        subgrid_start_slots = subgrid_start_slots_gpu.numpy()

    # Tag subgrids demoted by the linearity pass with the sentinel SLOT_LINEAR
    # so samplers fall back to coarse-grid interpolation and skip the (now
    # absent) packed subgrid texture slot. Vectorized index math mirrors the
    # row-major layout used when laying out subgrid_start_slots (bz outer,
    # by middle, bx inner).
    is_linear_np = subgrid_is_linear.numpy()
    linear_mask = is_linear_np.astype(bool)
    if np.any(linear_mask):
        linear_idx = np.where(linear_mask)[0]
        bz_l = linear_idx // (w * h)
        rem_l = linear_idx - bz_l * w * h
        by_l = rem_l // w
        bx_l = rem_l - by_l * w
        subgrid_start_slots[bx_l, by_l, bz_l] = SLOT_LINEAR

    background_sdf_np = background_sdf.numpy().reshape((bg_size_z, bg_size_y, bg_size_x))

    padded_max = min_corner + np.array([w, h, d], dtype=float) * subgrid_size * cell_size

    return {
        "coarse_sdf": background_sdf_np.astype(np.float32),
        "subgrid_data": subgrid_texture_data,
        "subgrid_start_slots": subgrid_start_slots,
        "coarse_dims": (w, h, d),
        "subgrid_tex_size": tex_size,
        "num_subgrids": num_required,
        "min_extents": min_corner,
        "max_extents": padded_max,
        "cell_size": cell_size,
        "subgrid_size": subgrid_size,
        "quantization_mode": quantization_mode,
        "subgrids_min_sdf_value": final_sdf_min,
        "subgrids_sdf_value_range": final_sdf_range,
        "subgrid_required": required_np,
    }


def build_sparse_sdf_from_mesh(
    mesh: wp.Mesh,
    grid_size_x: int,
    grid_size_y: int,
    grid_size_z: int,
    cell_size: np.ndarray,
    min_corner: np.ndarray,
    max_corner: np.ndarray,
    subgrid_size: int = 8,
    narrow_band_thickness: float = 0.1,
    quantization_mode: int = QuantizationMode.UINT16,
    winding_threshold: float = 0.5,
    linearization_error_threshold: float | None = None,
    sign_mode: int = SIGN_MODE_WINDING,
    device: str = "cuda",
) -> dict:
    """Build sparse SDF texture representation by querying a mesh directly.

    Args:
        mesh: Warp mesh. Must have ``support_winding_number=True`` unless
            *sign_mode* is :data:`SIGN_MODE_PARITY` or :data:`SIGN_MODE_NORMAL`.
        grid_size_x: fine grid X dimension [sample].
        grid_size_y: fine grid Y dimension [sample].
        grid_size_z: fine grid Z dimension [sample].
        cell_size: fine grid cell size per axis [m].
        min_corner: lower corner of domain [m].
        max_corner: upper corner of domain [m].
        subgrid_size: cells per subgrid.
        narrow_band_thickness: distance threshold for subgrids [m].
        quantization_mode: :class:`QuantizationMode` value.
        winding_threshold: winding number threshold for inside/outside.
        linearization_error_threshold: maximum absolute SDF error [m] below
            which an occupied subgrid is considered linear.
        sign_mode: inside/outside strategy for mesh distance queries.
        device: Warp device string.

    Returns:
        Dictionary with all sparse SDF data.
    """
    return _build_sparse_sdf(
        _SDF_SOURCE_MESH,
        mesh,
        0,
        (1.0, 1.0, 1.0),
        grid_size_x,
        grid_size_y,
        grid_size_z,
        cell_size,
        min_corner,
        max_corner,
        subgrid_size=subgrid_size,
        narrow_band_thickness=narrow_band_thickness,
        quantization_mode=quantization_mode,
        winding_threshold=winding_threshold,
        linearization_error_threshold=linearization_error_threshold,
        sign_mode=sign_mode,
        device=device,
    )


def build_sparse_sdf_from_primitive(
    shape_type: int,
    shape_scale: Sequence[float],
    grid_size_x: int,
    grid_size_y: int,
    grid_size_z: int,
    cell_size: np.ndarray,
    min_corner: np.ndarray,
    max_corner: np.ndarray,
    subgrid_size: int = 8,
    narrow_band_thickness: float = 0.1,
    quantization_mode: int = QuantizationMode.UINT16,
    linearization_error_threshold: float | None = None,
    device: str = "cuda",
) -> dict:
    """Build sparse SDF texture representation from an analytical primitive.

    Args:
        shape_type: Primitive :class:`GeoType`.
        shape_scale: Primitive shape scale [m].
        grid_size_x: fine grid X dimension [sample].
        grid_size_y: fine grid Y dimension [sample].
        grid_size_z: fine grid Z dimension [sample].
        cell_size: fine grid cell size per axis [m].
        min_corner: lower corner of domain [m].
        max_corner: upper corner of domain [m].
        subgrid_size: cells per subgrid.
        narrow_band_thickness: distance threshold for subgrids [m].
        quantization_mode: :class:`QuantizationMode` value.
        linearization_error_threshold: maximum absolute SDF error [m] below
            which an occupied subgrid is considered linear.
        device: Warp device string.

    Returns:
        Dictionary with all sparse SDF data.
    """
    shape_type, shape_scale = _validate_primitive_sdf_inputs(shape_type, shape_scale)
    return _build_sparse_sdf(
        _SDF_SOURCE_PRIMITIVE,
        None,
        shape_type,
        shape_scale,
        grid_size_x,
        grid_size_y,
        grid_size_z,
        cell_size,
        min_corner,
        max_corner,
        subgrid_size=subgrid_size,
        narrow_band_thickness=narrow_band_thickness,
        quantization_mode=quantization_mode,
        linearization_error_threshold=linearization_error_threshold,
        device=device,
    )


def _pack_sdf_x_pairs(data: np.ndarray) -> np.ndarray:
    """Pack each SDF sample with its clamped positive-X neighbor."""
    pairs = np.empty((*data.shape, 2), dtype=data.dtype)
    pairs[..., 0] = data
    pairs[..., :-1, 1] = data[..., 1:]
    pairs[..., -1, 1] = data[..., -1]
    return pairs


def create_sparse_sdf_textures(
    sparse_data: dict,
    device: str = "cuda",
    paired_samples: bool = True,
) -> tuple[TextureSDFData, wp.Texture3D, wp.Texture3D]:
    """Create TextureSDFData struct with GPU textures from sparse data.

    Args:
        sparse_data: Dictionary produced by a sparse SDF builder.
        device: Warp device string.
        paired_samples: Store adjacent X samples together for faster software interpolation.

    Returns:
        Tuple of ``(texture_sdf, coarse_texture, subgrid_texture)``.
        Caller must keep texture references alive to prevent GC.
    """
    # Pair adjacent X samples so the software sampler obtains eight corners
    # with four reads. Channel zero preserves the original scalar field for
    # hardware filtering. At an exact texel center, LINEAR filtering returns
    # the stored values exactly, preserving the software interpolation path.
    coarse_data = _pack_sdf_x_pairs(sparse_data["coarse_sdf"]) if paired_samples else sparse_data["coarse_sdf"]
    subgrid_data = _pack_sdf_x_pairs(sparse_data["subgrid_data"]) if paired_samples else sparse_data["subgrid_data"]
    coarse_tex = wp.Texture3D(
        coarse_data,
        filter_mode=wp.TextureFilterMode.LINEAR,
        address_mode=wp.TextureAddressMode.CLAMP,
        normalized_coords=False,
        device=device,
    )

    subgrid_tex = wp.Texture3D(
        subgrid_data,
        filter_mode=wp.TextureFilterMode.LINEAR,
        address_mode=wp.TextureAddressMode.CLAMP,
        normalized_coords=False,
        device=device,
    )

    subgrid_slots = wp.array(sparse_data["subgrid_start_slots"], dtype=wp.uint32, device=device)

    cell_size = sparse_data["cell_size"]

    min_ext = sparse_data["min_extents"]
    max_ext = sparse_data["max_extents"]

    sdf_params = TextureSDFData()
    sdf_params.coarse_texture = coarse_tex
    sdf_params.subgrid_texture = subgrid_tex
    sdf_params.subgrid_start_slots = subgrid_slots
    sdf_params.sdf_box_lower = wp.vec3(float(min_ext[0]), float(min_ext[1]), float(min_ext[2]))
    sdf_params.sdf_box_upper = wp.vec3(float(max_ext[0]), float(max_ext[1]), float(max_ext[2]))
    sdf_params.inv_sdf_dx = wp.vec3(1.0 / float(cell_size[0]), 1.0 / float(cell_size[1]), 1.0 / float(cell_size[2]))
    sdf_params.subgrid_size = sparse_data["subgrid_size"]
    sdf_params.subgrid_size_f = float(sparse_data["subgrid_size"])
    sdf_params.subgrid_samples_f = float(sparse_data["subgrid_size"] + 1)
    sdf_params.fine_to_coarse = 1.0 / sparse_data["subgrid_size"]
    sdf_params.num_subgrids = int(np.count_nonzero(sparse_data["subgrid_start_slots"] != int(SLOT_EMPTY)))

    sdf_params.voxel_size = wp.vec3(float(cell_size[0]), float(cell_size[1]), float(cell_size[2]))
    sdf_params.voxel_radius = float(0.5 * np.linalg.norm(cell_size))

    sdf_params.subgrids_min_sdf_value = sparse_data["subgrids_min_sdf_value"]
    sdf_params.subgrids_sdf_value_range = sparse_data["subgrids_sdf_value_range"]
    sdf_params.paired_samples = paired_samples
    sdf_params.scale_baked = False

    return sdf_params, coarse_tex, subgrid_tex


def _create_texture_sdf_from_source(
    min_ext: np.ndarray,
    max_ext: np.ndarray,
    *,
    sparse_sdf_builder: Callable[..., dict],
    narrow_band_range: tuple[float, float],
    max_resolution: int | None,
    target_voxel_size: float | None,
    subgrid_size: int,
    quantization_mode: int,
    scale_baked: bool,
    device: str,
    paired_samples: bool,
    return_sparse_data: bool = False,
) -> tuple[TextureSDFData, wp.Texture3D, wp.Texture3D] | tuple[TextureSDFData, wp.Texture3D, wp.Texture3D, dict | None]:
    """Create a texture SDF from source extents and a bound sparse-data builder."""
    ext = max_ext - min_ext
    max_ext_scalar = np.max(ext)
    if max_ext_scalar < 1e-10:
        empty = (create_empty_texture_sdf_data(), None, None)
        return (*empty, None) if return_sparse_data else empty

    if target_voxel_size is not None:
        if target_voxel_size <= 0.0:
            raise ValueError("target_voxel_size must be > 0")
        derived_res = int(np.ceil(max_ext_scalar / float(target_voxel_size)))
        derived_res = max(8, ((derived_res + 7) // 8) * 8)
        max_resolution = derived_res
    elif max_resolution is None:
        max_resolution = 64

    max_resolution = int(max_resolution)
    if max_resolution <= 0:
        raise ValueError("max_resolution must be > 0")
    if max_resolution >= (1 << 16):
        raise ValueError(f"max_resolution must be less than {1 << 16}")

    cell_size_scalar = max_ext_scalar / max_resolution
    dims = np.ceil(ext / cell_size_scalar).astype(int) + 1
    grid_x, grid_y, grid_z = int(dims[0]), int(dims[1]), int(dims[2])
    cell_size = ext / (dims - 1)
    narrow_band_thickness = max(abs(narrow_band_range[0]), abs(narrow_band_range[1]))

    sparse_data = sparse_sdf_builder(
        grid_x,
        grid_y,
        grid_z,
        cell_size,
        min_ext,
        max_ext,
        subgrid_size=subgrid_size,
        narrow_band_thickness=narrow_band_thickness,
        quantization_mode=quantization_mode,
        device=device,
    )

    sdf_params, coarse_tex, subgrid_tex = create_sparse_sdf_textures(sparse_data, device, paired_samples)
    sdf_params.scale_baked = scale_baked

    if return_sparse_data:
        return sdf_params, coarse_tex, subgrid_tex, sparse_data
    return sdf_params, coarse_tex, subgrid_tex


def create_texture_sdf_from_mesh(
    mesh: wp.Mesh,
    *,
    margin: float = 0.05,
    narrow_band_range: tuple[float, float] = (-0.1, 0.1),
    max_resolution: int | None = None,
    target_voxel_size: float | None = None,
    subgrid_size: int = 8,
    quantization_mode: int = QuantizationMode.UINT16,
    winding_threshold: float = 0.5,
    scale_baked: bool = False,
    sign_mode: int = SIGN_MODE_WINDING,
    paired_samples: bool = True,
    device: str | None = None,
    return_sparse_data: bool = False,
) -> tuple[TextureSDFData, wp.Texture3D, wp.Texture3D] | tuple[TextureSDFData, wp.Texture3D, wp.Texture3D, dict | None]:
    """Create texture SDF from a Warp mesh.

    This is the main entry point for texture SDF construction. It mirrors the
    parameters of :func:`~newton._src.geometry.sdf_utils._compute_sdf_from_shape_impl`.

    Args:
        mesh: Warp mesh.  Must have ``support_winding_number=True`` unless
            *sign_mode* is :data:`SIGN_MODE_PARITY` or :data:`SIGN_MODE_NORMAL`.
        margin: extra AABB padding [m].
        narrow_band_range: signed narrow-band distance range [m] as ``(inner, outer)``.
        max_resolution: maximum grid dimension [voxel]. Used when
            ``target_voxel_size`` is not provided. Defaults to 64 when both
            ``max_resolution`` and ``target_voxel_size`` are ``None``.
        target_voxel_size: target voxel size [m] along the longest padded-AABB
            axis. When provided, takes precedence over ``max_resolution`` and
            ``max_resolution`` is derived as
            ``ceil(max_padded_extent / target_voxel_size)`` then rounded up to
            a multiple of 8 to match the sparse SDF path.
        subgrid_size: cells per subgrid.
        quantization_mode: :class:`QuantizationMode` value.
        winding_threshold: winding number threshold for inside/outside classification.
        scale_baked: whether shape scale was baked into the mesh vertices.
        sign_mode: inside/outside strategy for the distance queries.
            :data:`SIGN_MODE_WINDING` (default) uses winding numbers;
            :data:`SIGN_MODE_PARITY` uses parity ray-casts (cheaper,
            requires a closed manifold mesh); :data:`SIGN_MODE_NORMAL`
            uses the angle-weighted pseudo-normal (for open meshes).
        paired_samples: Store adjacent X samples together for faster software interpolation.
        device: Warp device string. ``None`` uses the mesh's device.
        return_sparse_data: when ``True``, also return the raw cooked
            ``sparse_data`` dict produced by
            :func:`build_sparse_sdf_from_mesh` (or ``None`` for degenerate
            meshes). Intended for callers that want to persist the cook
            output (e.g. an on-disk SDF cache) before it is consumed by
            the GPU upload. The default ``False`` preserves the original
            return signature.

    Returns:
        Tuple of ``(texture_sdf, coarse_texture, subgrid_texture)``.
        When ``return_sparse_data`` is ``True``, an additional trailing
        ``sparse_data`` element is included.
        Caller must keep texture references alive to prevent GC.
    """
    if device is None:
        device = str(mesh.device)

    points_np = mesh.points.numpy()
    mesh_min = np.min(points_np, axis=0)
    mesh_max = np.max(points_np, axis=0)

    min_ext = mesh_min - margin
    max_ext = mesh_max + margin

    sparse_sdf_builder = functools.partial(
        build_sparse_sdf_from_mesh,
        mesh,
        winding_threshold=winding_threshold,
        sign_mode=sign_mode,
    )
    return _create_texture_sdf_from_source(
        min_ext,
        max_ext,
        sparse_sdf_builder=sparse_sdf_builder,
        narrow_band_range=narrow_band_range,
        max_resolution=max_resolution,
        target_voxel_size=target_voxel_size,
        subgrid_size=subgrid_size,
        quantization_mode=quantization_mode,
        scale_baked=scale_baked,
        device=device,
        return_sparse_data=return_sparse_data,
        paired_samples=paired_samples,
    )


def create_texture_sdf_from_primitive(
    shape_type: int,
    shape_scale: Sequence[float],
    *,
    margin: float = 0.05,
    narrow_band_range: tuple[float, float] = (-0.1, 0.1),
    max_resolution: int | None = None,
    target_voxel_size: float | None = None,
    subgrid_size: int = 8,
    quantization_mode: int = QuantizationMode.UINT16,
    scale_baked: bool = False,
    paired_samples: bool = True,
    device: str = "cuda",
) -> tuple[TextureSDFData, wp.Texture3D, wp.Texture3D]:
    """Create texture SDF from an analytical primitive.

    Args:
        shape_type: Primitive :class:`GeoType`.
        shape_scale: Primitive shape scale [m], shape [3].
        margin: extra AABB padding [m].
        narrow_band_range: signed narrow-band distance range [m] as ``(inner, outer)``.
        max_resolution: maximum grid dimension [voxel]. Used when
            ``target_voxel_size`` is not provided. Defaults to 64 when both
            ``max_resolution`` and ``target_voxel_size`` are ``None``.
        target_voxel_size: target voxel size [m] along the longest padded-AABB
            axis. When provided, takes precedence over ``max_resolution``.
        subgrid_size: cells per subgrid.
        quantization_mode: :class:`QuantizationMode` value.
        scale_baked: whether shape scale was baked into the SDF values.
        paired_samples: Store adjacent X samples together for faster software interpolation.
        device: Warp device string.

    Returns:
        Tuple of ``(texture_sdf, coarse_texture, subgrid_texture)``.
        Caller must keep texture references alive to prevent GC.
    """
    shape_type, shape_scale = _validate_primitive_sdf_inputs(shape_type, shape_scale)

    min_prim, max_prim = get_primitive_extents(shape_type, shape_scale)
    min_ext = np.asarray(min_prim, dtype=float) - margin
    max_ext = np.asarray(max_prim, dtype=float) + margin

    sparse_sdf_builder = functools.partial(
        build_sparse_sdf_from_primitive,
        shape_type,
        shape_scale,
    )
    return _create_texture_sdf_from_source(
        min_ext,
        max_ext,
        sparse_sdf_builder=sparse_sdf_builder,
        narrow_band_range=narrow_band_range,
        max_resolution=max_resolution,
        target_voxel_size=target_voxel_size,
        subgrid_size=subgrid_size,
        quantization_mode=quantization_mode,
        scale_baked=scale_baked,
        device=device,
        paired_samples=paired_samples,
    )


def create_texture_sdf_from_volume(
    sparse_volume: wp.Volume,
    coarse_volume: wp.Volume,
    *,
    min_ext: np.ndarray,
    max_ext: np.ndarray,
    voxel_size: np.ndarray,
    narrow_band_range: tuple[float, float] = (-0.1, 0.1),
    subgrid_size: int = 8,
    scale_baked: bool = False,
    linearization_error_threshold: float | None = None,
    paired_samples: bool = True,
    device: str = "cuda",
) -> tuple[TextureSDFData, wp.Texture3D, wp.Texture3D]:
    """Create texture SDF from existing NanoVDB sparse and coarse volumes.

    Samples the NanoVDB volumes at each texel position to build the texture SDF.
    This is used during construction for primitive shapes that already have NanoVDB
    volumes but need texture SDFs for the collision pipeline.

    Args:
        sparse_volume: NanoVDB sparse volume with SDF values.
        coarse_volume: NanoVDB coarse (background) volume with SDF values.
        min_ext: lower corner of the SDF domain [m].
        max_ext: upper corner of the SDF domain [m].
        voxel_size: fine grid cell size per axis [m].
        narrow_band_range: signed narrow-band distance range [m] as ``(inner, outer)``.
        subgrid_size: cells per subgrid.
        scale_baked: whether shape scale was baked into the SDF.
        linearization_error_threshold: maximum absolute SDF error [m] below
            which an occupied subgrid is considered linear and its high-res
            data is omitted.  ``None`` auto-computes from domain extents,
            ``0.0`` disables the optimization.
        paired_samples: Store adjacent X samples together for faster software interpolation.
        device: Warp device string.

    Returns:
        Tuple of ``(texture_sdf, coarse_texture, subgrid_texture)``.
        Caller must keep texture references alive to prevent GC.
    """
    ext = max_ext - min_ext
    # Compute fine grid dimensions from extents and voxel size.
    # Use ceiling division so the coarse grid fully covers the NanoVDB domain.
    cells_per_axis = np.round(ext / voxel_size).astype(int)
    w = int((cells_per_axis[0] + subgrid_size - 1) // subgrid_size)
    h = int((cells_per_axis[1] + subgrid_size - 1) // subgrid_size)
    d = int((cells_per_axis[2] + subgrid_size - 1) // subgrid_size)
    total_subgrids = w * h * d

    # Padded grid covers w*subgrid_size cells (+ 1 vertex) per axis.
    # Keep cell_size = voxel_size so voxel indices map 1:1.
    cell_size = voxel_size.copy()
    padded_max = min_ext + np.array([w, h, d], dtype=float) * subgrid_size * cell_size

    # Build background/coarse SDF by sampling coarse volume at subgrid corners
    bg_size_x = w + 1
    bg_size_y = h + 1
    bg_size_z = d + 1
    total_bg = bg_size_x * bg_size_y * bg_size_z

    # Sample coarse grid from the coarse NanoVDB volume using a GPU kernel
    bg_positions = np.zeros((total_bg, 3), dtype=np.float32)
    for idx in range(total_bg):
        z_block = idx // (bg_size_x * bg_size_y)
        rem = idx - z_block * bg_size_x * bg_size_y
        y_block = rem // bg_size_x
        x_block = rem - y_block * bg_size_x
        bg_positions[idx] = min_ext + np.array(
            [
                float(x_block * subgrid_size) * cell_size[0],
                float(y_block * subgrid_size) * cell_size[1],
                float(z_block * subgrid_size) * cell_size[2],
            ]
        )

    bg_positions_gpu = wp.array(bg_positions, dtype=wp.vec3, device=device)
    bg_sdf_gpu = wp.zeros(total_bg, dtype=float, device=device)
    wp.launch(
        _sample_volume_at_positions_kernel,
        dim=total_bg,
        inputs=[coarse_volume.id, bg_positions_gpu, bg_sdf_gpu],
        device=device,
    )

    # Check subgrid occupancy by sampling sparse volume at subgrid centers
    narrow_band_thickness = max(abs(narrow_band_range[0]), abs(narrow_band_range[1]))
    half_subgrid = subgrid_size * 0.5 * cell_size
    subgrid_radius = float(np.linalg.norm(half_subgrid))

    subgrid_centers = np.empty((total_subgrids, 3), dtype=np.float32)
    for idx in range(total_subgrids):
        bz = idx // (w * h)
        rem = idx - bz * w * h
        by = rem // w
        bx = rem - by * w
        subgrid_centers[idx, 0] = (bx * subgrid_size + subgrid_size * 0.5) * cell_size[0] + min_ext[0]
        subgrid_centers[idx, 1] = (by * subgrid_size + subgrid_size * 0.5) * cell_size[1] + min_ext[1]
        subgrid_centers[idx, 2] = (bz * subgrid_size + subgrid_size * 0.5) * cell_size[2] + min_ext[2]

    center_positions_gpu = wp.array(subgrid_centers, dtype=wp.vec3, device=device)
    center_sdf_gpu = wp.zeros(total_subgrids, dtype=float, device=device)
    wp.launch(
        _sample_volume_at_positions_kernel,
        dim=total_subgrids,
        inputs=[sparse_volume.id, center_positions_gpu, center_sdf_gpu],
        device=device,
    )

    center_sdf_np = center_sdf_gpu.numpy()
    threshold_inner = -narrow_band_thickness - subgrid_radius
    threshold_outer = narrow_band_thickness + subgrid_radius

    subgrid_required = np.zeros(total_subgrids, dtype=np.int32)
    for idx in range(total_subgrids):
        val = center_sdf_np[idx]
        if val > 0:
            subgrid_required[idx] = 1 if val < threshold_outer else 0
        else:
            subgrid_required[idx] = 1 if val > threshold_inner else 0

    # Demote occupied subgrids whose SDF is well-approximated by the coarse
    # grid (linear field).
    if linearization_error_threshold is None:
        linearization_error_threshold = float(1e-6 * np.linalg.norm(ext))
    subgrid_is_linear = np.zeros(total_subgrids, dtype=np.int32)
    if linearization_error_threshold > 0.0:
        bg_sdf_np = bg_sdf_gpu.numpy()
        samples_per_dim_lin = subgrid_size + 1
        s_inv = 1.0 / float(subgrid_size)

        occupied_indices = np.nonzero(subgrid_required)[0]
        if len(occupied_indices) > 0:
            all_positions = []
            for idx in occupied_indices:
                bz = idx // (w * h)
                rem = idx - bz * w * h
                by = rem // w
                bx = rem - by * w
                for lz in range(samples_per_dim_lin):
                    for ly in range(samples_per_dim_lin):
                        for lx in range(samples_per_dim_lin):
                            gx = bx * subgrid_size + lx
                            gy = by * subgrid_size + ly
                            gz = bz * subgrid_size + lz
                            pos = min_ext + np.array(
                                [
                                    float(gx) * cell_size[0],
                                    float(gy) * cell_size[1],
                                    float(gz) * cell_size[2],
                                ]
                            )
                            all_positions.append(pos)

            all_positions_gpu = wp.array(np.array(all_positions, dtype=np.float32), dtype=wp.vec3, device=device)
            all_sdf_gpu = wp.zeros(len(all_positions), dtype=float, device=device)
            wp.launch(
                _sample_volume_at_positions_kernel,
                dim=len(all_positions),
                inputs=[sparse_volume.id, all_positions_gpu, all_sdf_gpu],
                device=device,
            )
            all_sdf_np = all_sdf_gpu.numpy()

            samples_per_subgrid = samples_per_dim_lin**3
            for i, idx in enumerate(occupied_indices):
                bz_i = idx // (w * h)
                rem_i = idx - bz_i * w * h
                by_i = rem_i // w
                bx_i = rem_i - by_i * w
                max_err = 0.0
                base = i * samples_per_subgrid
                for lz in range(samples_per_dim_lin):
                    for ly in range(samples_per_dim_lin):
                        for lx in range(samples_per_dim_lin):
                            local_idx = lz * samples_per_dim_lin * samples_per_dim_lin + ly * samples_per_dim_lin + lx
                            vol_val = all_sdf_np[base + local_idx]

                            cfx = float(bx_i) + float(lx) * s_inv
                            cfy = float(by_i) + float(ly) * s_inv
                            cfz = float(bz_i) + float(lz) * s_inv

                            x0 = max(0, min(int(np.floor(cfx)), bg_size_x - 2))
                            y0 = max(0, min(int(np.floor(cfy)), bg_size_y - 2))
                            z0 = max(0, min(int(np.floor(cfz)), bg_size_z - 2))
                            tx = np.clip(cfx - float(x0), 0.0, 1.0)
                            ty = np.clip(cfy - float(y0), 0.0, 1.0)
                            tz = np.clip(cfz - float(z0), 0.0, 1.0)

                            def _bg(xi, yi, zi):
                                return float(bg_sdf_np[zi * bg_size_x * bg_size_y + yi * bg_size_x + xi])

                            c00 = _bg(x0, y0, z0) * (1.0 - tx) + _bg(x0 + 1, y0, z0) * tx
                            c10 = _bg(x0, y0 + 1, z0) * (1.0 - tx) + _bg(x0 + 1, y0 + 1, z0) * tx
                            c01 = _bg(x0, y0, z0 + 1) * (1.0 - tx) + _bg(x0 + 1, y0, z0 + 1) * tx
                            c11 = _bg(x0, y0 + 1, z0 + 1) * (1.0 - tx) + _bg(x0 + 1, y0 + 1, z0 + 1) * tx
                            c0 = c00 * (1.0 - ty) + c10 * ty
                            c1 = c01 * (1.0 - ty) + c11 * ty
                            coarse_val = c0 * (1.0 - tz) + c1 * tz

                            max_err = max(max_err, abs(vol_val - coarse_val))

                if max_err < linearization_error_threshold:
                    subgrid_is_linear[idx] = 1
                    subgrid_required[idx] = 0

    num_required = int(np.sum(subgrid_required))

    # Conservative quantization bounds from narrow band range
    global_sdf_min = threshold_inner
    global_sdf_max = threshold_outer
    sdf_range = global_sdf_max - global_sdf_min
    if sdf_range < 1e-10:
        sdf_range = 1.0

    if num_required == 0:
        subgrid_start_slots = np.full((w, h, d), SLOT_EMPTY, dtype=np.uint32)
        subgrid_texture_data = np.zeros((1, 1, 1), dtype=np.float32)
        tex_size = 1
    else:
        cubic_root = num_required ** (1.0 / 3.0)
        tex_blocks_per_dim = max(1, int(np.ceil(cubic_root)))
        while tex_blocks_per_dim**3 < num_required:
            tex_blocks_per_dim += 1

        samples_per_dim = subgrid_size + 1
        tex_size = tex_blocks_per_dim * samples_per_dim

        # Assign sequential addresses to required subgrids
        subgrid_start_slots = np.full((w, h, d), SLOT_EMPTY, dtype=np.uint32)
        address = 0
        for idx in range(total_subgrids):
            if subgrid_required[idx]:
                addr_z = address // (tex_blocks_per_dim * tex_blocks_per_dim)
                addr_rem = address - addr_z * tex_blocks_per_dim * tex_blocks_per_dim
                addr_y = addr_rem // tex_blocks_per_dim
                addr_x = addr_rem - addr_y * tex_blocks_per_dim
                bz = idx // (w * h)
                rem = idx - bz * w * h
                by = rem // w
                bx = rem - by * w
                subgrid_start_slots[bx, by, bz] = int(addr_x) | (int(addr_y) << 10) | (int(addr_z) << 20)
                address += 1

        # Build positions array for all subgrid texels, then sample volume
        total_texel_work = num_required * samples_per_dim**3
        texel_positions = np.empty((total_texel_work, 3), dtype=np.float32)
        texel_tex_indices = np.empty(total_texel_work, dtype=np.int32)

        work_idx = 0
        subgrid_texture_data = np.zeros((tex_size, tex_size, tex_size), dtype=np.float32)
        for sg_idx in range(total_subgrids):
            if not subgrid_required[sg_idx]:
                continue
            sg_z = sg_idx // (w * h)
            sg_rem = sg_idx - sg_z * w * h
            sg_y = sg_rem // w
            sg_x = sg_rem - sg_y * w

            slot = subgrid_start_slots[sg_x, sg_y, sg_z]
            addr_x = int(slot & 0x3FF)
            addr_y = int((slot >> 10) & 0x3FF)
            addr_z = int((slot >> 20) & 0x3FF)

            for lz in range(samples_per_dim):
                for ly in range(samples_per_dim):
                    for lx in range(samples_per_dim):
                        gx = sg_x * subgrid_size + lx
                        gy = sg_y * subgrid_size + ly
                        gz = sg_z * subgrid_size + lz
                        pos = min_ext + np.array(
                            [
                                float(gx) * cell_size[0],
                                float(gy) * cell_size[1],
                                float(gz) * cell_size[2],
                            ]
                        )
                        tex_x = addr_x * samples_per_dim + lx
                        tex_y = addr_y * samples_per_dim + ly
                        tex_z = addr_z * samples_per_dim + lz
                        texel_positions[work_idx] = pos
                        texel_tex_indices[work_idx] = tex_z * tex_size * tex_size + tex_y * tex_size + tex_x
                        work_idx += 1

        # Sample all texel positions from the sparse volume on GPU
        texel_positions_gpu = wp.array(texel_positions, dtype=wp.vec3, device=device)
        texel_sdf_gpu = wp.zeros(total_texel_work, dtype=float, device=device)
        wp.launch(
            _sample_volume_at_positions_kernel,
            dim=total_texel_work,
            inputs=[sparse_volume.id, texel_positions_gpu, texel_sdf_gpu],
            device=device,
        )

        texel_sdf_np = texel_sdf_gpu.numpy()

        # Replace background/corrupted values from sparse volume with
        # coarse volume samples.  The NanoVDB sparse volume uses 1e18 as
        # background for unallocated tiles; linear interpolation near tile
        # boundaries blends this background into texels, corrupting them.
        bg_threshold = threshold_outer * 2.0
        outlier_mask = (texel_sdf_np > bg_threshold) | (texel_sdf_np < -bg_threshold)
        if np.any(outlier_mask):
            outlier_positions = texel_positions[outlier_mask]
            outlier_gpu = wp.array(outlier_positions, dtype=wp.vec3, device=device)
            outlier_sdf_gpu = wp.zeros(len(outlier_positions), dtype=float, device=device)
            wp.launch(
                _sample_volume_at_positions_kernel,
                dim=len(outlier_positions),
                inputs=[coarse_volume.id, outlier_gpu, outlier_sdf_gpu],
                device=device,
            )
            texel_sdf_np[outlier_mask] = outlier_sdf_gpu.numpy()
        flat_texture = subgrid_texture_data.ravel()
        for i in range(total_texel_work):
            flat_texture[texel_tex_indices[i]] = texel_sdf_np[i]
        subgrid_texture_data = flat_texture.reshape((tex_size, tex_size, tex_size))

    # Write SLOT_LINEAR for subgrids that overlap the narrow band but were
    # demoted because their SDF is well-approximated by the coarse grid.
    if np.any(subgrid_is_linear):
        for idx in range(total_subgrids):
            if subgrid_is_linear[idx]:
                bz = idx // (w * h)
                rem = idx - bz * w * h
                by = rem // w
                bx = rem - by * w
                subgrid_start_slots[bx, by, bz] = SLOT_LINEAR

    background_sdf_np = bg_sdf_gpu.numpy().reshape((bg_size_z, bg_size_y, bg_size_x))

    sparse_data = {
        "coarse_sdf": background_sdf_np.astype(np.float32),
        "subgrid_data": subgrid_texture_data,
        "subgrid_start_slots": subgrid_start_slots,
        "coarse_dims": (w, h, d),
        "subgrid_tex_size": tex_size,
        "num_subgrids": num_required,
        "min_extents": min_ext,
        "max_extents": padded_max,
        "cell_size": cell_size,
        "subgrid_size": subgrid_size,
        "quantization_mode": QuantizationMode.FLOAT32,
        "subgrids_min_sdf_value": 0.0,
        "subgrids_sdf_value_range": 1.0,
        "subgrid_required": subgrid_required,
    }

    sdf_params, coarse_tex, subgrid_tex = create_sparse_sdf_textures(sparse_data, device, paired_samples)
    sdf_params.scale_baked = scale_baked

    return sdf_params, coarse_tex, subgrid_tex


def create_empty_texture_sdf_data() -> TextureSDFData:
    """Return an empty TextureSDFData struct for shapes without texture SDF.

    An empty struct has ``coarse_texture.width == 0``, which collision kernels
    use to detect the absence of a texture SDF and fall back to BVH.

    Returns:
        A zeroed-out :class:`TextureSDFData` struct.
    """
    sdf = TextureSDFData()
    sdf.subgrid_size = 0
    sdf.subgrid_size_f = 0.0
    sdf.subgrid_samples_f = 0.0
    sdf.fine_to_coarse = 0.0
    sdf.inv_sdf_dx = wp.vec3(0.0, 0.0, 0.0)
    sdf.sdf_box_lower = wp.vec3(0.0, 0.0, 0.0)
    sdf.sdf_box_upper = wp.vec3(0.0, 0.0, 0.0)
    sdf.voxel_size = wp.vec3(0.0, 0.0, 0.0)
    sdf.voxel_radius = 0.0
    sdf.subgrids_min_sdf_value = 0.0
    sdf.subgrids_sdf_value_range = 1.0
    sdf.scale_baked = False
    sdf.paired_samples = True
    return sdf


# ============================================================================
# Isomesh extraction from texture SDF (marching cubes)
# ============================================================================


@wp.kernel(enable_backward=False)
def _count_isomesh_faces_texture_kernel(
    sdf_array: wp.array[TextureSDFData],
    active_coarse_cells: wp.array[wp.vec3i],
    subgrid_size: int,
    tri_range_table: wp.array[wp.int32],
    corner_offsets_table: wp.array[wp.vec3ub],
    isovalue: wp.float32,
    face_count: wp.array[int],
):
    cell_idx, local_x, local_y, local_z = wp.tid()
    sdf = sdf_array[0]
    coarse = active_coarse_cells[cell_idx]
    x_id = coarse[0] * subgrid_size + local_x
    y_id = coarse[1] * subgrid_size + local_y
    z_id = coarse[2] * subgrid_size + local_z

    cube_idx = wp.int32(0)
    for i in range(8):
        co = wp.vec3i(corner_offsets_table[i])
        v = texture_sample_sdf_at_voxel(sdf, x_id + co.x, y_id + co.y, z_id + co.z)
        if wp.isnan(v):
            return
        if v < isovalue:
            cube_idx |= 1 << i

    tri_start = tri_range_table[cube_idx]
    tri_end = tri_range_table[cube_idx + 1]
    num_faces = (tri_end - tri_start) // 3
    if num_faces > 0:
        wp.atomic_add(face_count, 0, num_faces)


@wp.kernel(enable_backward=False)
def _generate_isomesh_texture_kernel(
    sdf_array: wp.array[TextureSDFData],
    active_coarse_cells: wp.array[wp.vec3i],
    subgrid_size: int,
    tri_range_table: wp.array[wp.int32],
    flat_edge_verts_table: wp.array[wp.vec2ub],
    corner_offsets_table: wp.array[wp.vec3ub],
    isovalue: wp.float32,
    face_count: wp.array[int],
    vertices: wp.array[wp.vec3],
):
    cell_idx, local_x, local_y, local_z = wp.tid()
    sdf = sdf_array[0]
    coarse = active_coarse_cells[cell_idx]
    x_id = coarse[0] * subgrid_size + local_x
    y_id = coarse[1] * subgrid_size + local_y
    z_id = coarse[2] * subgrid_size + local_z

    cube_idx = wp.int32(0)
    corner_vals = vec8f()
    for i in range(8):
        co = wp.vec3i(corner_offsets_table[i])
        v = texture_sample_sdf_at_voxel(sdf, x_id + co.x, y_id + co.y, z_id + co.z)
        if wp.isnan(v):
            return
        corner_vals[i] = v
        if v < isovalue:
            cube_idx |= 1 << i

    tri_start = tri_range_table[cube_idx]
    tri_end = tri_range_table[cube_idx + 1]
    num_verts = tri_end - tri_start
    num_faces = num_verts // 3
    if num_faces == 0:
        return

    out_idx = wp.atomic_add(face_count, 0, num_faces)

    for fi in range(5):
        if fi >= num_faces:
            return
        for vi in range(3):
            edge_verts = wp.vec2i(flat_edge_verts_table[tri_start + 3 * fi + vi])
            v_from = edge_verts[0]
            v_to = edge_verts[1]
            val_0 = wp.float32(corner_vals[v_from])
            val_1 = wp.float32(corner_vals[v_to])
            p_0 = wp.vec3f(corner_offsets_table[v_from])
            p_1 = wp.vec3f(corner_offsets_table[v_to])
            val_diff = val_1 - val_0
            if wp.abs(val_diff) < MC_EDGE_VAL_DIFF_EPS:
                p = 0.5 * (p_0 + p_1)
            else:
                t = wp.clamp((isovalue - val_0) / val_diff, MC_EDGE_CLAMP_MIN, MC_EDGE_CLAMP_MAX)
                p = p_0 + t * (p_1 - p_0)
            vol_idx = p + wp.vec3(float(x_id), float(y_id), float(z_id))
            local_pos = sdf.sdf_box_lower + wp.cw_mul(vol_idx, sdf.voxel_size)
            vertices[3 * out_idx + 3 * fi + vi] = local_pos


def compute_isomesh_from_texture_sdf(
    tex_data_array: wp.array,
    sdf_idx: int,
    subgrid_start_slots: wp.array,
    coarse_dims: tuple[int, int, int],
    device=None,
    isovalue: float = 0.0,
) -> Mesh | None:
    """Extract an isosurface mesh from a texture SDF via marching cubes.

    Iterates over coarse cells that have subgrids (the narrow-band region
    where the surface lives) and runs marching cubes on their fine voxels.

    Args:
        tex_data_array: Warp array of :class:`TextureSDFData` structs.
        sdf_idx: Index into *tex_data_array* to extract.
        subgrid_start_slots: The 3D ``subgrid_start_slots`` array for this SDF
            entry (used to determine which coarse cells are active).
        coarse_dims: ``(cx, cy, cz)`` number of coarse cells per axis.
        device: Warp device.
        isovalue: Surface level to extract [m].  ``0.0`` gives the
            zero-isosurface; positive values extract an outward offset surface.

    Returns:
        :class:`~newton.Mesh` with the isosurface, or ``None`` if empty.
    """
    from .sdf_mc import get_mc_tables  # noqa: PLC0415
    from .types import Mesh  # noqa: PLC0415

    if device is None:
        device = wp.get_device()

    if subgrid_start_slots is None:
        return None

    tex_np = tex_data_array.numpy()
    entry = tex_np[sdf_idx]
    subgrid_size = int(entry["subgrid_size"])
    if subgrid_size == 0:
        return None

    cx, cy, cz = coarse_dims

    single = tex_data_array[sdf_idx : sdf_idx + 1]

    slots_np = subgrid_start_slots.numpy()
    active_cells = []
    for ix in range(cx):
        for iy in range(cy):
            for iz in range(cz):
                if slots_np[ix, iy, iz] != SLOT_EMPTY:
                    active_cells.append((ix, iy, iz))

    if not active_cells:
        return None

    active_coarse_cells = wp.array(active_cells, dtype=wp.vec3i, device=device)
    num_active = len(active_cells)

    mc_tables = get_mc_tables(device)
    tri_range_table = mc_tables[0]
    flat_edge_verts_table = mc_tables[4]
    corner_offsets_table = mc_tables[3]

    face_count = wp.zeros((1,), dtype=int, device=device)
    wp.launch(
        _count_isomesh_faces_texture_kernel,
        dim=(num_active, subgrid_size, subgrid_size, subgrid_size),
        inputs=[single, active_coarse_cells, subgrid_size, tri_range_table, corner_offsets_table, float(isovalue)],
        outputs=[face_count],
        device=device,
    )

    num_faces = int(face_count.numpy()[0])
    if num_faces == 0:
        return None

    max_verts = 3 * num_faces
    verts = wp.empty((max_verts,), dtype=wp.vec3, device=device)

    face_count.zero_()
    wp.launch(
        _generate_isomesh_texture_kernel,
        dim=(num_active, subgrid_size, subgrid_size, subgrid_size),
        inputs=[
            single,
            active_coarse_cells,
            subgrid_size,
            tri_range_table,
            flat_edge_verts_table,
            corner_offsets_table,
            float(isovalue),
        ],
        outputs=[face_count, verts],
        device=device,
    )

    verts_np = verts.numpy()
    faces_np = np.arange(3 * num_faces).reshape(-1, 3)
    faces_np = faces_np[:, ::-1]
    return Mesh(verts_np, faces_np)

# SPDX-FileCopyrightText: Copyright (c) 2025 The Newton Developers
# SPDX-License-Identifier: Apache-2.0

import warnings

from ._src.geometry import (
    BroadPhaseAllPairs,
    BroadPhaseExplicit,
    BroadPhaseSAP,
    TriMeshCollisionInfo,
    collide_box_box,
    collide_capsule_box,
    collide_capsule_capsule,
    collide_plane_box,
    collide_plane_capsule,
    collide_plane_cylinder,
    collide_plane_ellipsoid,
    collide_plane_sphere,
    collide_sphere_box,
    collide_sphere_capsule,
    collide_sphere_cylinder,
    collide_sphere_sphere,
)
from ._src.geometry.contact_match import MATCH_BROKEN as _MATCH_BROKEN
from ._src.geometry.contact_match import MATCH_NOT_FOUND as _MATCH_NOT_FOUND
from ._src.geometry.inertia import compute_inertia_shape, transform_inertia
from ._src.geometry.kernels import sdf_box, sdf_capsule, sdf_cone, sdf_cylinder, sdf_mesh, sdf_plane, sdf_sphere
from ._src.geometry.narrow_phase import NarrowPhase
from ._src.geometry.particle_surface import ParticleSurface, extract_particle_surface
from ._src.geometry.sdf_hydroelastic import HydroelasticSDF
from ._src.geometry.sdf_utils import compute_offset_mesh, create_empty_sdf_data

__all__ = [
    "BroadPhaseAllPairs",
    "BroadPhaseExplicit",
    "BroadPhaseSAP",
    "HydroelasticSDF",
    "NarrowPhase",
    "ParticleSurface",
    "TriMeshCollisionInfo",
    "collide_box_box",
    "collide_capsule_box",
    "collide_capsule_capsule",
    "collide_plane_box",
    "collide_plane_capsule",
    "collide_plane_cylinder",
    "collide_plane_ellipsoid",
    "collide_plane_sphere",
    "collide_sphere_box",
    "collide_sphere_capsule",
    "collide_sphere_cylinder",
    "collide_sphere_sphere",
    "compute_inertia_shape",
    "compute_offset_mesh",
    "create_empty_sdf_data",
    "extract_particle_surface",
    "sdf_box",
    "sdf_capsule",
    "sdf_cone",
    "sdf_cylinder",
    "sdf_mesh",
    "sdf_plane",
    "sdf_sphere",
    "transform_inertia",
]

_DEPRECATED_MATCH_CONSTANTS = {
    "MATCH_BROKEN": _MATCH_BROKEN,
    "MATCH_NOT_FOUND": _MATCH_NOT_FOUND,
}

__deprecated_symbols__ = {
    "MATCH_BROKEN": "Do not rely on this value.",
    "MATCH_NOT_FOUND": "Do not rely on this value.",
}


def __getattr__(name: str):
    try:
        value = _DEPRECATED_MATCH_CONSTANTS[name]
    except KeyError:
        raise AttributeError(f"module {__name__!r} has no attribute {name!r}") from None

    warnings.warn(
        f"newton.geometry.{name} is deprecated and will be removed in a future release. Do not rely on this value.",
        DeprecationWarning,
        stacklevel=2,
    )
    return value


def __dir__() -> list[str]:
    return sorted(set(globals()) | set(_DEPRECATED_MATCH_CONSTANTS))

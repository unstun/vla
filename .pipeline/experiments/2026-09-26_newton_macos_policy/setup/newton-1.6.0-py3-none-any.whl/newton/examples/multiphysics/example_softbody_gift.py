# SPDX-FileCopyrightText: Copyright (c) 2025 The Newton Developers
# SPDX-License-Identifier: Apache-2.0

###########################################################################
# Softbody Gift
#
# This simulation demonstrates four stacked soft body blocks with two cloth
# straps wrapped around them. The blocks fall under gravity, and the cloth
# straps hold them together.
#
# Command: uv run -m newton.examples softbody_gift
#
###########################################################################

import numpy as np
import warp as wp

import newton
import newton.examples

# =============================================================================
# Geometry Helpers
# =============================================================================


def cloth_loop_around_box(
    hx=1.6,  # half-size in X (box width / 2)
    hz=2.0,  # half-size in Z (box height / 2)
    width=0.25,  # strap width (along Y)
    center_y=0.0,  # Y position of the strap center
    nu=120,  # resolution along loop
    nv=6,  # resolution across strap width
):
    """
    Vertical closed cloth loop wrapped around a cuboid.
    Loop lies in X-Z plane, strap width is along Y.
    Z is up.
    """
    verts = []
    faces = []

    # Rectangle perimeter length
    P = 4.0 * (hx + hz)

    for i in range(nu):
        s = (i / nu) * P

        # Walk rectangle in X-Z plane (counter-clockwise)
        if s < 2 * hx:
            x = -hx + s
            z = -hz
        elif s < 2 * hx + 2 * hz:
            x = hx
            z = -hz + (s - 2 * hx)
        elif s < 4 * hx + 2 * hz:
            x = hx - (s - (2 * hx + 2 * hz))
            z = hz
        else:
            x = -hx
            z = hz - (s - (4 * hx + 2 * hz))

        for j in range(nv):
            v = (j / (nv - 1) - 0.5) * width
            y = center_y + v
            verts.append([x, y, z])

    def idx(i, j):
        return (i % nu) * nv + j

    # Triangulation
    for i in range(nu):
        for j in range(nv - 1):
            faces.append([idx(i, j), idx(i + 1, j), idx(i, j + 1)])
            faces.append([idx(i + 1, j), idx(i + 1, j + 1), idx(i, j + 1)])

    return (
        np.array(verts, dtype=np.float32),
        np.array(faces, dtype=np.int32),
    )


# 2x2x1 grid of unit cubes, each split into 5 tets. Adjacent cubes use
# mirrored decompositions (checkerboard) so shared-face diagonals match
# and the surface mesh stays manifold.
PYRAMID_TET_INDICES = np.array(
    [
        # cube (0,0,0): variant A
        [0, 1, 3, 9],
        [1, 4, 3, 13],
        [1, 3, 9, 13],
        [3, 9, 13, 12],
        [1, 9, 10, 13],
        # cube (1,0,0): variant B
        [1, 11, 5, 13],
        [2, 5, 1, 11],
        [4, 1, 5, 13],
        [10, 11, 1, 13],
        [14, 5, 11, 13],
        # cube (0,1,0): variant B
        [3, 13, 7, 15],
        [4, 7, 3, 13],
        [6, 3, 7, 15],
        [12, 13, 3, 15],
        [16, 7, 13, 15],
        # cube (1,1,0): variant A
        [4, 5, 7, 13],
        [5, 8, 7, 17],
        [5, 7, 13, 17],
        [7, 13, 17, 16],
        [5, 13, 14, 17],
    ],
    dtype=np.int32,
)

PYRAMID_PARTICLES = [
    (0.0, 0.0, 0.0),
    (1.0, 0.0, 0.0),
    (2.0, 0.0, 0.0),
    (0.0, 1.0, 0.0),
    (1.0, 1.0, 0.0),
    (2.0, 1.0, 0.0),
    (0.0, 2.0, 0.0),
    (1.0, 2.0, 0.0),
    (2.0, 2.0, 0.0),
    (0.0, 0.0, 1.0),
    (1.0, 0.0, 1.0),
    (2.0, 0.0, 1.0),
    (0.0, 1.0, 1.0),
    (1.0, 1.0, 1.0),
    (2.0, 1.0, 1.0),
    (0.0, 2.0, 1.0),
    (1.0, 2.0, 1.0),
    (2.0, 2.0, 1.0),
]


class Example:
    def __init__(self, viewer, args):
        self.viewer = viewer
        self.solver_type = args.solver
        self.sim_time = 0.0
        self.fps = 60
        self.frame_dt = 1.0 / self.fps
        self.sim_substeps = 10
        self.iterations = 15
        self.sim_dt = self.frame_dt / self.sim_substeps

        if self.solver_type != "vbd":
            raise ValueError("The falling gift example only supports the VBD solver.")

        # Simulation parameters
        self.base_height = 20.0
        self.spacing = 1.01  # small gap to avoid initial penetration

        # Generate cloth geometry
        strap1_verts, strap1_faces = cloth_loop_around_box(hx=1.01, hz=2.02, width=0.6)
        strap2_verts, strap2_faces = cloth_loop_around_box(hx=1.015, hz=2.025, width=0.6)

        builder = newton.ModelBuilder()
        builder.add_ground_plane()

        # Add 4 stacked soft body blocks
        for i in range(4):
            builder.add_soft_mesh(
                pos=(0.0, 0.0, self.base_height + i * self.spacing),
                rot=wp.quat_identity(),
                scale=1.0,
                vel=(0.0, 0.0, 0.0),
                vertices=PYRAMID_PARTICLES,
                indices=PYRAMID_TET_INDICES.flatten().tolist(),
                density=100,
                k_mu=1.0e5,
                k_lambda=1.0e5,
                k_damp=1e0,
            )

        # Add first cloth strap
        builder.add_cloth_mesh(
            pos=(1.0, 1.0, self.base_height + 1.5 * self.spacing + 0.5),
            rot=wp.quat_identity(),
            scale=1.0,
            vel=(0.0, 0.0, 0.0),
            vertices=strap1_verts,
            indices=strap1_faces.flatten().tolist(),
            density=0.02,
            tri_ke=1e5,
            tri_ka=1e5,
            tri_kd=1e0,
            edge_ke=0.01,
            edge_kd=1e-4,
        )

        # Add second cloth strap (rotated 90 degrees)
        builder.add_cloth_mesh(
            pos=(1.0, 1.0, self.base_height + 1.5 * self.spacing + 0.5),
            rot=wp.quat_from_axis_angle(wp.vec3(0.0, 0.0, 1.0), -np.pi / 2),
            scale=1.0,
            vel=(0.0, 0.0, 0.0),
            vertices=strap2_verts,
            indices=strap2_faces.flatten().tolist(),
            density=0.02,
            tri_ke=1e5,
            tri_ka=1e5,
            tri_kd=1e0,
            edge_ke=0.01,
            edge_kd=1e-4,
        )

        # Color the mesh for VBD solver
        builder.color()

        self.model = builder.finalize()

        # Contact parameters
        self.model.soft_contact_ke = 5.0e4
        self.model.soft_contact_kd = 5.0e-1
        self.model.soft_contact_mu = 1.0

        self.solver = newton.solvers.SolverVBD(
            model=self.model,
            iterations=self.iterations,
            particle_enable_self_contact=True,
            particle_self_contact_margin=0.04,
            particle_self_contact_gap=0.02,
            particle_topological_contact_filter_threshold=1,
            particle_enable_tile_solve=False,
        )

        self.state_0 = self.model.state()
        self.state_1 = self.model.state()
        self.control = self.model.control()

        self.collision_pipeline = newton.CollisionPipeline(self.model)
        self.contacts = self.collision_pipeline.contacts()

        self.viewer.set_model(self.model)

        # Set camera parameters (only works for ViewerGL)
        self.viewer.set_camera(pos=wp.vec3(28.97, 0.17, 13.62), pitch=-11.2, yaw=-185.0)
        if hasattr(self.viewer, "camera"):
            self.viewer.camera.fov = 53.0

        self.capture()

    def capture(self):
        with wp.ScopedCapture() as capture:
            self.simulate()
        self.graph = capture.graph

    def simulate(self):
        for _ in range(self.sim_substeps):
            self.state_0.clear_forces()

            # apply forces to the model
            self.viewer.apply_forces(self.state_0)

            self.collision_pipeline.collide(self.state_0, self.contacts)
            self.solver.step(self.state_0, self.state_1, self.control, self.contacts, self.sim_dt)

            # swap states
            self.state_0, self.state_1 = self.state_1, self.state_0

    def step(self):
        if self.graph:
            wp.capture_launch(self.graph)
        else:
            self.simulate()

        self.sim_time += self.frame_dt

    def test_final(self):
        # Test that bounding box size is reasonable (not exploding)
        particle_q = self.state_0.particle_q.numpy()
        min_pos = np.min(particle_q, axis=0)
        max_pos = np.max(particle_q, axis=0)
        bbox_size = np.linalg.norm(max_pos - min_pos)

        # Check bbox size is reasonable
        assert bbox_size < 10.0, f"Bounding box exploded: size={bbox_size:.2f}"

        # Check no excessive penetration
        assert min_pos[2] > -0.5, f"Excessive penetration: z_min={min_pos[2]:.4f}"

    def render(self):
        self.viewer.begin_frame(self.sim_time)
        self.viewer.log_state(self.state_0)
        self.viewer.log_contacts(self.contacts, self.state_0)
        self.viewer.end_frame()

    @staticmethod
    def create_parser():
        parser = newton.examples.create_parser()
        parser.add_argument(
            "--solver",
            help="Type of solver (only 'vbd' supports this example)",
            type=str,
            choices=["vbd"],
            default="vbd",
        )
        return parser


if __name__ == "__main__":
    parser = Example.create_parser()
    viewer, args = newton.examples.init(parser)
    newton.examples.run(Example(viewer, args), args)

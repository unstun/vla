# SPDX-FileCopyrightText: Copyright (c) 2025 The Newton Developers
# SPDX-License-Identifier: Apache-2.0

###########################################################################
# Example for simulating all basic models as a single heterogeneous multi-world model with SolverKamino.
#
# Command: python -m newton.examples kamino_basic_heterogeneous
#
###########################################################################

import argparse

import warp as wp

import newton
import newton.examples
from newton.tests import get_kamino_basics_asset
from newton.tests.utils import basics


class Example:
    def __init__(self, viewer: newton.viewer.ViewerBase, args=None):
        # Set simulation run-time configurations
        self.fps = 50
        self.sim_dt = 0.0025
        self.frame_dt = 1.0 / self.fps
        self.sim_substeps = max(1, round(self.frame_dt / self.sim_dt))
        self.sim_time = 0.0
        self.viewer = viewer
        self.device = wp.get_device()

        # Define a helper function to load each basic model from USD and
        # add it to the builder, with consistent settings for all models
        def load_basic_asset_from_usd(asset_file: str) -> newton.ModelBuilder:
            asset_builder = newton.ModelBuilder(up_axis=newton.Axis.Z)
            newton.solvers.SolverKamino.register_custom_attributes(asset_builder)
            asset_builder.default_shape_cfg.margin = 0.0
            asset_builder.default_shape_cfg.gap = 0.0
            asset_builder.add_usd(
                asset_file,
                joint_ordering=None,
                force_show_colliders=True,
                force_position_velocity_actuation=True,
                enable_self_collisions=False,
                hide_collision_shapes=False,
            )
            return asset_builder

        # Load the heterogeneous basic models either from USD or manually using the
        # model builder API, depending on the command-line argument `--from-usd`
        builder = newton.ModelBuilder()
        if args is not None and args.from_usd:
            # Load all basic USD assets and add them to the builder
            asset_names = [
                "boxes_fourbar",
                "boxes_nunchaku",
                "boxes_hinged",
                "box_pendulum",
                "box_on_plane",
                "cartpole",
            ]
            for asset_name in asset_names:
                asset_file = get_kamino_basics_asset(f"{asset_name}.usda")
                builder.add_world(builder=load_basic_asset_from_usd(asset_file))
        else:
            # Manually build the heterogeneous basic models using the builder API
            basics.make_basics_heterogeneous_builder(builder=builder, ground=True)

        # Create the model from the builder
        builder.request_contact_attributes("force")  # For contact visualization
        self.model = builder.finalize(skip_validation_joints=True)

        # Create and configure settings for SolverKamino and the collision detector
        solver_config = newton.solvers.SolverKamino.Config.from_model(self.model)
        solver_config.use_collision_detector = True
        solver_config.use_fk_solver = True
        solver_config.collision_detector.pipeline = "primitive"
        solver_config.collision_detector.max_contacts = 32 * self.model.world_count
        solver_config.dynamics.preconditioning = True
        solver_config.padmm.primal_tolerance = 1e-4
        solver_config.padmm.dual_tolerance = 1e-4
        solver_config.padmm.compl_tolerance = 1e-4
        solver_config.padmm.max_iterations = 200
        solver_config.padmm.rho_0 = 0.1
        solver_config.padmm.use_acceleration = True
        solver_config.padmm.warmstart_mode = "containers"
        solver_config.padmm.contact_warmstart_method = "geom_pair_net_force"

        # Create the Kamino solver for the given model
        self.solver = newton.solvers.SolverKamino(model=self.model, config=solver_config)

        # Create state, control, and contacts data containers
        self.state_0 = self.model.state()
        self.state_1 = self.model.state()
        self.control = self.model.control()
        self.collision_pipeline = newton.CollisionPipeline(self.model)
        self.contacts = self.collision_pipeline.contacts()

        # Attach the model to the viewer for visualization
        self.viewer.set_model(self.model)
        self.viewer.set_world_offsets(spacing=(5.0, 5.0, 0.0))

        # Capture the simulation graph if running on CUDA
        # NOTE: This only has an effect on GPU devices
        self.capture()

        # If only a single-world is created, set initial
        # camera position for better view of the system
        if hasattr(self.viewer, "set_camera"):
            camera_pos = wp.vec3(0.0, -15.0, 1.6)
            pitch = -1.5
            yaw = 92.0
            self.viewer.set_camera(camera_pos, pitch, yaw)

    def capture(self):
        self.graph = None
        if self.device.is_cuda and not wp.config.verify_cuda:
            with wp.ScopedCapture() as capture:
                self.simulate()
            self.graph = capture.graph

    # simulate() performs one frame's worth of updates
    def simulate(self):
        for _ in range(self.sim_substeps):
            self.state_0.clear_forces()
            self.viewer.apply_forces(self.state_0)
            self.solver.step(self.state_0, self.state_1, self.control, None, self.sim_dt)
            self.solver.update_contacts(self.contacts, self.state_0)
            self.state_0, self.state_1 = self.state_1, self.state_0

    def step(self):
        if self.graph:
            wp.capture_launch(self.graph)
        else:
            self.simulate()
        self.sim_time += self.frame_dt

    def render(self):
        self.viewer.begin_frame(self.sim_time)
        # Since rendering is called after stepping the simulation, the previous and next
        # states correspond to self.state_1 and self.state_0 due to the reference swaps,
        # so contacts are rendered with self.state_1 to match the body positions at the
        # time of contact generation.
        self.viewer.log_state(self.state_0)
        self.viewer.log_contacts(self.contacts, self.state_1)
        self.viewer.end_frame()

    def test_final(self):
        pass  # TODO: Add some assertions here once we have a more meaningful test scenario

    @staticmethod
    def create_parser():
        parser = newton.examples.create_parser()
        parser.add_argument(
            "--from-usd",
            action=argparse.BooleanOptionalAction,
            default=True,
            help="Load the heterogeneous basic models from USD (otherwise build them manually).",
        )
        return parser


if __name__ == "__main__":
    parser = Example.create_parser()
    viewer, args = newton.examples.init(parser)
    newton.examples.run(Example(viewer, args), args)

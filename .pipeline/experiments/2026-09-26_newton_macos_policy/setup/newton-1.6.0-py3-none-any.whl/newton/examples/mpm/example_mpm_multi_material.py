# SPDX-FileCopyrightText: Copyright (c) 2025 The Newton Developers
# SPDX-License-Identifier: Apache-2.0

import numpy as np
import warp as wp

import newton
import newton.examples
from newton.solvers import SolverImplicitMPM


class Example:
    def __init__(self, viewer, args):
        # setup simulation parameters first
        self.fps = 60.0
        self.frame_dt = 1.0 / self.fps

        # group related attributes by prefix
        self.sim_time = 0.0
        self.sim_substeps = 1
        self.sim_dt = self.frame_dt / self.sim_substeps

        # save a reference to the viewer
        self.viewer = viewer
        builder = newton.ModelBuilder()

        # Register MPM custom attributes before adding particles
        SolverImplicitMPM.register_custom_attributes(builder)

        sand_particles, snow_particles, mud_particles = Example.emit_particles(builder, voxel_size=args.voxel_size)

        builder.add_ground_plane()
        self.model = builder.finalize()

        sand_particles = wp.array(sand_particles, dtype=int, device=self.model.device)
        snow_particles = wp.array(snow_particles, dtype=int, device=self.model.device)
        mud_particles = wp.array(mud_particles, dtype=int, device=self.model.device)

        # Multi-material setup via model.mpm.* custom attributes
        # Snow: soft, compressible, low friction
        self.model.mpm.yield_pressure[snow_particles].fill_(2.0e4)
        self.model.mpm.tensile_yield_ratio[snow_particles].fill_(0.2)
        self.model.mpm.friction[snow_particles].fill_(0.1)
        self.model.mpm.hardening[snow_particles].fill_(10.0)
        self.model.mpm.dilatancy[snow_particles].fill_(1.0)

        # Mud: viscous, cohesive
        self.model.mpm.yield_pressure[mud_particles].fill_(1.0e10)
        self.model.mpm.yield_stress[mud_particles].fill_(3.0e2)
        self.model.mpm.tensile_yield_ratio[mud_particles].fill_(1.0)
        self.model.mpm.friction[mud_particles].fill_(0.0)
        self.model.mpm.viscosity[mud_particles].fill_(100.0)

        mpm_options = SolverImplicitMPM.Config()
        mpm_options.voxel_size = args.voxel_size
        mpm_options.tolerance = args.tolerance
        mpm_options.max_iterations = args.max_iterations

        # Initialize MPM solver
        self.solver = SolverImplicitMPM(self.model, config=mpm_options)

        self.state_0 = self.model.state()
        self.state_1 = self.model.state()

        # Assign different colors to each particle type
        self.particle_colors = wp.full(
            shape=self.model.particle_count, value=wp.vec3(0.1, 0.1, 0.2), device=self.model.device
        )
        self.particle_colors[sand_particles].fill_(wp.vec3(0.7, 0.6, 0.4))
        self.particle_colors[snow_particles].fill_(wp.vec3(0.75, 0.75, 0.8))
        self.particle_colors[mud_particles].fill_(wp.vec3(0.4, 0.25, 0.25))

        self.viewer.set_model(self.model)

    def simulate(self):
        for _ in range(self.sim_substeps):
            self.state_0.clear_forces()
            self.solver.step(self.state_0, self.state_1, None, None, self.sim_dt)
            self.solver.project_outside(self.state_1, self.state_1, self.sim_dt)
            self.state_0, self.state_1 = self.state_1, self.state_0

    def step(self):
        self.simulate()
        self.sim_time += self.frame_dt

    def test_final(self):
        newton.examples.test_particle_state(
            self.state_0,
            "all particles are above the ground",
            lambda q, qd: q[2] > -0.05,
        )

    def render(self):
        self.viewer.begin_frame(self.sim_time)
        self.viewer.log_points(
            name="/model/particles",
            points=self.state_0.particle_q,
            radii=self.model.particle_radius,
            colors=self.particle_colors,
            hidden=False,
        )
        self.viewer.end_frame()

    @staticmethod
    def emit_particles(builder: newton.ModelBuilder, voxel_size: float):
        # kinematic particles (mass=0, density=0 triggers infinite-mass BC)
        Example._spawn_particles(
            builder,
            voxel_size,
            bounds_lo=np.array([-0.5, -0.5, 0.0]),
            bounds_hi=np.array([0.5, 0.5, 0.25]),
            density=0.0,
            flags=newton.ParticleFlags.ACTIVE,
        )

        # sand particles
        sand_particles = Example._spawn_particles(
            builder,
            voxel_size,
            bounds_lo=np.array([-0.5, 0.25, 0.5]),
            bounds_hi=np.array([0.5, 0.75, 0.75]),
            density=2500.0,
            flags=newton.ParticleFlags.ACTIVE,
        )

        # snow particles
        snow_particles = Example._spawn_particles(
            builder,
            voxel_size,
            bounds_lo=np.array([-0.5, -0.75, 0.5]),
            bounds_hi=np.array([0.5, -0.25, 0.75]),
            density=300,
            flags=newton.ParticleFlags.ACTIVE,
        )

        # mud particles
        mud_particles = Example._spawn_particles(
            builder,
            voxel_size,
            bounds_lo=np.array([-0.25, -0.5, 1.0]),
            bounds_hi=np.array([0.25, 0.5, 1.5]),
            density=1000.0,
            flags=newton.ParticleFlags.ACTIVE,
        )

        return sand_particles, snow_particles, mud_particles

    @staticmethod
    def _spawn_particles(builder: newton.ModelBuilder, voxel_size, bounds_lo, bounds_hi, density, flags):
        particles_per_cell = 3
        res = np.array(
            np.ceil(particles_per_cell * (bounds_hi - bounds_lo) / voxel_size),
            dtype=int,
        )

        cell_size = (bounds_hi - bounds_lo) / res
        cell_volume = np.prod(cell_size)
        radius = np.max(cell_size) * 0.5
        mass = np.prod(cell_volume) * density

        begin_id = len(builder.particle_q)
        builder.add_particle_grid(
            pos=wp.vec3(bounds_lo),
            rot=wp.quat_identity(),
            vel=wp.vec3(0.0),
            dim_x=res[0] + 1,
            dim_y=res[1] + 1,
            dim_z=res[2] + 1,
            cell_x=cell_size[0],
            cell_y=cell_size[1],
            cell_z=cell_size[2],
            mass=mass,
            jitter=2.0 * radius,
            radius_mean=radius,
            flags=flags,
        )

        end_id = len(builder.particle_q)
        return np.arange(begin_id, end_id, dtype=int)

    @staticmethod
    def create_parser():
        parser = newton.examples.create_parser()
        parser.add_argument("--max-iterations", "-it", type=int, default=250)
        parser.add_argument("--tolerance", "-tol", type=float, default=1.0e-6)
        parser.add_argument("--voxel-size", "-dx", type=float, default=0.05)
        return parser


if __name__ == "__main__":
    parser = Example.create_parser()

    viewer, args = newton.examples.init(parser)

    # Create example and run
    newton.examples.run(Example(viewer, args), args)

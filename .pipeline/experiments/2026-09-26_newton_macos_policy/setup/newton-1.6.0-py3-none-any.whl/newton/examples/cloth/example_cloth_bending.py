# SPDX-FileCopyrightText: Copyright (c) 2025 The Newton Developers
# SPDX-License-Identifier: Apache-2.0

###########################################################################
# Example Sim Cloth Bending
#
# This simulation demonstrates cloth bending behavior using the Vertex Block
# Descent (VBD) integrator. A cloth mesh, initially curved, is dropped on
# the ground. The cloth maintains its curved shape due to bending stiffness,
# controlled by edge_ke and edge_kd parameters.
#
###########################################################################

import numpy as np
import warp as wp
from pxr import Usd

import newton
import newton.examples
import newton.usd


class Example:
    def __init__(self, viewer, args):
        # setup simulation parameters first
        self.fps = 60
        self.frame_dt = 1.0 / self.fps

        self.sim_time = 0.0
        self.sim_substeps = 10
        self.sim_dt = self.frame_dt / self.sim_substeps

        self.iterations = 10

        self.viewer = viewer

        usd_stage = Usd.Stage.Open(newton.examples.get_asset("curvedSurface.usd"))
        usd_prim = usd_stage.GetPrimAtPath("/root/cloth")

        cloth_mesh = newton.usd.get_mesh(usd_prim)
        mesh_points = cloth_mesh.vertices
        mesh_indices = cloth_mesh.indices

        self.input_scale_factor = 1.0
        vertices = [wp.vec3(v) * self.input_scale_factor for v in mesh_points]
        self.faces = mesh_indices.reshape(-1, 3)

        builder = newton.ModelBuilder()

        contact_ke = 1.0e2
        contact_kd = 1.0e2
        contact_mu = 1.5
        builder.default_shape_cfg.ke = contact_ke
        builder.default_shape_cfg.kd = contact_kd
        builder.default_shape_cfg.mu = contact_mu
        builder.add_cloth_mesh(
            pos=wp.vec3(0.0, 0.0, 10.0),
            rot=wp.quat_from_axis_angle(wp.vec3(1.0, 0.0, 0.0), wp.pi / 6.0),
            scale=1.0,
            vertices=vertices,
            indices=mesh_indices,
            vel=wp.vec3(0.0, 0.0, 0.0),
            density=0.02,
            tri_ke=5.0e1,
            tri_ka=5.0e1,
            tri_kd=5.0e0,
            edge_ke=1.0e1,
            edge_kd=1.0e1,
        )

        builder.color(include_bending=True)
        builder.add_ground_plane()

        self.model = builder.finalize()
        self.model.soft_contact_ke = contact_ke
        self.model.soft_contact_kd = contact_kd
        self.model.soft_contact_mu = contact_mu

        # The solver owns the collision pipeline: it runs rigid and particle-shape
        # detection itself at every step and writes soft self-contact results into
        # its own contacts buffer (solver.contacts).
        self.collision_pipeline = newton.CollisionPipeline(
            self.model,
            broad_phase="nxn",
            soft_contact_gap=0.1,
        )

        self.solver = newton.solvers.SolverVBD(
            self.model,
            iterations=self.iterations,
            particle_enable_self_contact=True,
            particle_self_contact_margin=0.2,
            particle_self_contact_gap=0.15,
            collision_pipeline=self.collision_pipeline,
        )

        self.state_0 = self.model.state()
        self.state_1 = self.model.state()
        self.control = self.model.control()

        self.viewer.set_model(self.model)

        self.capture()

    def capture(self):
        with wp.ScopedCapture() as capture:
            self.simulate()
        self.graph = capture.graph

    def simulate(self):
        for _ in range(self.sim_substeps):
            self.state_0.clear_forces()

            # apply forces to the model
            self.viewer.apply_forces(self.state_0)

            # detection runs inside step(): the solver owns the pipeline
            self.solver.step(self.state_0, self.state_1, self.control, None, self.sim_dt)

            # swap states
            self.state_0, self.state_1 = self.state_1, self.state_0

    def step(self):
        if self.graph:
            wp.capture_launch(self.graph)
        else:
            self.simulate()
        self.sim_time += self.frame_dt

    def render(self):
        self.viewer.begin_frame(self.sim_time)
        self.viewer.log_state(self.state_0)
        self.viewer.end_frame()

    def test_final(self):
        # Test that particles have come to rest (lenient velocity threshold)
        newton.examples.test_particle_state(
            self.state_0,
            "particles have come close to a rest",
            lambda q, qd: max(abs(qd)) < 0.5,
        )

        # Test that particles haven't drifted too far from initial x,y position
        # Initial position was (0, 0, 10), so check x,y are within reasonable bounds
        newton.examples.test_particle_state(
            self.state_0,
            "particles stayed near initial x,y position",
            lambda q, qd: abs(q[0]) < 5.0 and abs(q[1]) < 5.0,
        )

        # Test that spring/edge lengths haven't stretched too much from rest length
        if self.model.spring_count > 0:
            positions = self.state_0.particle_q.numpy()
            spring_indices = self.model.spring_indices.numpy().reshape(-1, 2)
            rest_lengths = self.model.spring_rest_length.numpy()

            max_stretch_ratio = 0.0
            for i, (v0, v1) in enumerate(spring_indices):
                current_length = np.linalg.norm(positions[v0] - positions[v1])
                stretch_ratio = abs(current_length - rest_lengths[i]) / rest_lengths[i]
                max_stretch_ratio = max(max_stretch_ratio, stretch_ratio)

            # Allow up to 20% stretch/compression
            assert max_stretch_ratio < 0.2, (
                f"edges stretched too much from rest length: max stretch ratio = {max_stretch_ratio:.2%}"
            )


if __name__ == "__main__":
    # Parse arguments and initialize viewer
    viewer, args = newton.examples.init()

    # Create viewer and run
    newton.examples.run(Example(viewer, args), args)
